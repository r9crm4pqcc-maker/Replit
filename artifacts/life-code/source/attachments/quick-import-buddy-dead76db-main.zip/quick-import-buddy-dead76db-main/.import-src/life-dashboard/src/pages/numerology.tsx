import { useParams, Link } from "wouter";
import { Hash, ChevronRight } from "lucide-react";
import { useMemo, useState } from "react";
import { PROFILE } from "@/lib/profile";
import {
  calcCoreNumbers, gematria, calcPersonalMonth, calcPersonalWeek,
  calcAddressNumber, calcPhoneNumber, calcVehicleNumber,
  NUMBER_MEANINGS_FULL, MATRIX_SIGNALS, hebrewGematria, analyzeNameChange,
} from "@/lib/numerology";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);

const BLUE  = "hsl(212 95% 65%)";
const YELLOW= "hsl(48 96% 53%)";
const PURPLE= "hsl(270 60% 70%)";
const GREEN = "hsl(160 70% 55%)";
const ROSE  = "hsl(340 70% 65%)";

const LIFE_PATH_MEANINGS: Record<number,string> = {
  1:"The Leader — independent, pioneering, driven. You forge your own path. Your 28/10 compound means wealth and completion energy underpin your leadership.",
  2:"The Diplomat — cooperative, sensitive, peace-loving.",3:"The Communicator — creative, expressive, joyful.",
  4:"The Builder — disciplined, practical, reliable.",5:"The Adventurer — freedom-loving, versatile, dynamic.",
  6:"The Nurturer — caring, responsible, harmonious.",7:"The Seeker — analytical, spiritual, introspective.",
  8:"The Powerhouse — ambitious, authoritative, material mastery.",9:"The Humanitarian — compassionate, wise, universal.",
  11:"The Illuminator — highly intuitive, visionary, sensitive master.",22:"The Master Builder — large-scale achievement.",33:"The Master Teacher — devotion to elevating others.",
};

const PERSONAL_YEAR_MEANINGS: Record<number,string> = {
  1:"New beginnings. Start fresh — plant seeds for the next 9-year cycle. Bold action.",
  2:"Cooperation and patience. Build partnerships. Wait before acting.",
  3:"Creative expression and joy. Socialize, create, communicate widely.",
  4:"Hard work and foundation building. Discipline and structure are required.",
  5:"Change and freedom. Expect shifts. Travel, try new things.",
  6:"Responsibility and love. Focus on home, family, relationships and service.",
  7:"Reflection and inner work. Study, meditate, trust intuition.",
  8:"Power and achievement. Financial and professional gains arrive.",
  9:"Completion and release. End cycles gracefully. Prepare for renewal.",
  11:"Master illumination year. Heightened intuition and spiritual awakenings.",
  22:"Master manifestation year. Large-scale building and global impact.",
};

const NUMBER_MEANINGS: Record<number, { headline: string; energy: string; color: string }> = {
  1:{headline:"Leadership & New Beginnings",energy:"Sun — fire, ambition, independence",color:"#f87171"},
  2:{headline:"Cooperation & Balance",energy:"Moon — water, intuition, receptivity",color:"#fb923c"},
  3:{headline:"Creativity & Expression",energy:"Jupiter — expansion, joy, communication",color:"#facc15"},
  4:{headline:"Structure & Discipline",energy:"Uranus/Rahu — change through order",color:"#4ade80"},
  5:{headline:"Freedom & Change",energy:"Mercury — intellect, travel, versatility",color:"#22d3ee"},
  6:{headline:"Harmony & Service",energy:"Venus — love, beauty, responsibility",color:"#60a5fa"},
  7:{headline:"Reflection & Wisdom",energy:"Neptune/Ketu — spiritual depth",color:"#a78bfa"},
  8:{headline:"Power & Abundance",energy:"Saturn — karma, discipline, material mastery",color:"#c084fc"},
  9:{headline:"Completion & Compassion",energy:"Mars — courage, universal love",color:"#f472b6"},
};

function NumberCard({ label, value, compound, desc, color }: { label:string; value:number; compound?:string; desc?:string; color:string }) {
  return (
    <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
      <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.35)" }}>{label}</p>
      <div className="flex items-end gap-2 mb-1.5">
        <span className="text-4xl font-black leading-none" style={{ color }}>{value}</span>
        {compound && <span className="text-xs pb-1" style={{ color:"rgba(255,255,255,0.35)" }}>({compound})</span>}
      </div>
      {desc && <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>{desc}</p>}
    </div>
  );
}

const tabs = [
  { key:"core",     label:"Core Numbers",   href:"/numerology" },
  { key:"karmic",   label:"Karmic & Cycles", href:"/numerology/karmic" },
  { key:"advanced", label:"Advanced",        href:"/numerology/advanced" },
  { key:"tools",    label:"Tools",           href:"/numerology/tools" },
  { key:"number-guide", label:"1–33 Guide",  href:"/numerology/number-guide" },
  { key:"matrix-signals", label:"Matrix Signals", href:"/numerology/matrix-signals" },
  { key:"date-energy", label:"Date Energy",  href:"/numerology/date-energy" },
  { key:"lucky",    label:"Lucky",           href:"/numerology/lucky" },
];

export default function NumerologyPage() {
  const params = useParams<{ sub?: string }>();
  const sub = params.sub ?? "core";
  const gmtr = useMemo(() => gematria(PROFILE.fullName), []);

  const [addressInput, setAddressInput] = useState("");
  const [phoneInput, setPhoneInput] = useState("");
  const [vehicleInput, setVehicleInput] = useState("");
  const [nameFirst, setNameFirst] = useState("");
  const [nameLast, setNameLast] = useState("");

  const addressResult = useMemo(() => addressInput.length > 0 ? calcAddressNumber(addressInput) : null, [addressInput]);
  const phoneResult = useMemo(() => phoneInput.length > 0 ? calcPhoneNumber(phoneInput) : null, [phoneInput]);
  const vehicleResult = useMemo(() => vehicleInput.length > 0 ? calcVehicleNumber(vehicleInput) : null, [vehicleInput]);
  const nameChangeResult = useMemo(() => {
    if (nameFirst.length > 0 && nameLast.length > 0) {
      return analyzeNameChange(nameFirst, "", nameLast, PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear);
    }
    return null;
  }, [nameFirst, nameLast]);

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const pm = calcPersonalMonth(N.personalYear, currentMonth);
  const weekOfMonth = Math.ceil(now.getDate() / 7);
  const pw = calcPersonalWeek(pm.reduced, weekOfMonth);

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Hash size={12} style={{ color:YELLOW }} />
          <span>Numerology</span><ChevronRight size={10} />
          <span style={{ color:YELLOW }}>Cristian Zavala</span>
        </div>
        <h1 className="page-title">Numerology</h1>
        <p className="page-subtitle">Born September 8, 2009 · Chicago, IL</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t => {
          const active = sub===t.key || (sub==="core" && t.key==="core") || (!tabs.find(x=>x.key===sub) && t.key==="core");
          return (
            <Link key={t.key} href={t.href}>
              <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                style={active
                  ? { background:"rgba(250,204,21,0.12)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
                  : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
                {t.label}
              </button>
            </Link>
          );
        })}
      </div>

      {(sub==="core" || !tabs.find(x=>x.key===sub)) && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <NumberCard label="Life Path" value={N.lifePath} compound={`${N.lifePathCompound}/10`} desc={LIFE_PATH_MEANINGS[N.lifePath]} color={YELLOW} />
            <NumberCard label="Expression / Destiny" value={N.expression} compound={`${N.expressionCompound}`} desc="Natural talents from full birth name" color={BLUE} />
            <NumberCard label="Soul Urge" value={N.soulUrge} compound={`${N.soulUrgeCompound}`} desc="Heart's desire from vowels only" color={PURPLE} />
            <NumberCard label="Personality" value={N.personality} compound={`${N.personalityCompound}`} desc="How others perceive you — consonants" color={GREEN} />
            <NumberCard label="Birthday Number" value={N.birthday} desc="Special gift from your day of birth" color={ROSE} />
            <NumberCard label="Personal Year 2026" value={N.personalYear} compound={`${N.personalYearCompound}`} desc={PERSONAL_YEAR_MEANINGS[N.personalYear]} color={YELLOW} />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <NumberCard label="Maturity" value={N.maturityNumber} desc="LP + Expression — activates mid-life" color={BLUE} />
            <NumberCard label="Balance" value={N.balanceNumber} desc="How you handle crisis — from initials" color={PURPLE} />
            <NumberCard label="Cornerstone" value={N.cornerstone} desc={`First letter '${PROFILE.firstName[0]}' — how you begin`} color={GREEN} />
            <NumberCard label="Capstone" value={N.capstone} desc={`Last letter '${PROFILE.lastName[PROFILE.lastName.length-1]}' — how you finish`} color={ROSE} />
            <NumberCard label="First Vowel" value={N.firstVowel} desc="Inner reaction — instinctive response" color={YELLOW} />
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Personal Timing — Current Period</p>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(250,204,21,0.06)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Personal Year</p>
                <p className="text-3xl font-black" style={{ color:YELLOW }}>{N.personalYear}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>2026</p>
              </div>
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(96,165,250,0.06)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Personal Month</p>
                <p className="text-3xl font-black" style={{ color:BLUE }}>{pm.reduced}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Compound: {pm.compound}</p>
              </div>
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(168,85,247,0.06)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Personal Week</p>
                <p className="text-3xl font-black" style={{ color:PURPLE }}>{pw.reduced}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Week {weekOfMonth}</p>
              </div>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Life Path {N.lifePath} — Deep Meaning</p>
            <p className="text-sm leading-relaxed" style={{ color:"rgba(255,255,255,0.7)" }}>{LIFE_PATH_MEANINGS[N.lifePath]}</p>
            <div className="divider-blue" />
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>Planet: <span style={{ color:YELLOW }}>{N.planet}</span></span>
              <span className="text-xs" style={{ color:"rgba(255,255,255,0.2)" }}>·</span>
              <span className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>Mulank: <span style={{ color:BLUE }}>{N.mulank}</span></span>
              <span className="text-xs" style={{ color:"rgba(255,255,255,0.2)" }}>·</span>
              <span className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>Compound: <span style={{ color:PURPLE }}>{N.lifePathCompound}/10/{N.lifePath}</span></span>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Name Gematria — Cristian Zavala</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label:"English Ordinal", value:gmtr.englishOrdinal },
                { label:"Full Reduction", value:gmtr.fullReduction },
                { label:"Reverse Ordinal", value:gmtr.reverseOrdinal },
                { label:"Sumerian", value:gmtr.sumerian },
              ].map(g => (
                <div key={g.label} className="text-center">
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{g.label}</p>
                  <p className="text-2xl font-black" style={{ color:BLUE }}>{g.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {sub==="karmic" && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <NumberCard label="Personal Year 2026" value={N.personalYear} compound={`${N.personalYearCompound}`} desc={PERSONAL_YEAR_MEANINGS[N.personalYear]} color={YELLOW} />
            <div className="glass-card p-4 col-span-2" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Karmic Lessons (Missing Numbers)</p>
              {N.karmicLessons.length === 0
                ? <p className="text-sm" style={{ color:GREEN }}>No missing numbers — complete karmic palette</p>
                : <div className="flex gap-2">{N.karmicLessons.map(n=>(
                    <div key={n} className="text-center px-3 py-2 rounded-lg" style={{ background:"rgba(248,113,113,0.1)", border:"1px solid rgba(248,113,113,0.2)" }}>
                      <p className="text-2xl font-black" style={{ color:"#f87171" }}>{n}</p>
                      <p className="text-[9px] mt-0.5" style={{ color:"rgba(255,255,255,0.4)" }}>{NUMBER_MEANINGS[n]?.headline}</p>
                    </div>
                  ))}</div>
              }
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Pinnacles with Ages</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {N.pinnacleAges.map((p,i) => (
                <div key={i} className="text-center p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border: N.pinnacleAges[i].from <= 16 && (N.pinnacleAges[i].to === null || N.pinnacleAges[i].to! >= 16) ? "1px solid rgba(250,204,21,0.3)" : "1px solid rgba(255,255,255,0.06)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Pinnacle {i+1}</p>
                  <p className="text-3xl font-black" style={{ color:BLUE }}>{p.number}</p>
                  <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>Ages {p.from}–{p.to ?? "end"}</p>
                  {p.from <= 16 && (p.to === null || p.to >= 16) && (
                    <span className="text-[8px] px-1.5 py-0.5 rounded mt-1 inline-block" style={{ background:"rgba(250,204,21,0.15)", color:YELLOW }}>CURRENT</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Challenges</p>
            <div className="grid grid-cols-4 gap-3">
              {N.challenges.map((c,i) => (
                <div key={i} className="text-center">
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Challenge {i+1}</p>
                  <p className="text-3xl font-black" style={{ color:ROSE }}>{c}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Life Path Periods (3 Major Cycles)</p>
            <div className="space-y-3">
              {N.lifePeriods.map((lp, i) => (
                <div key={i} className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border: lp.from <= 16 && (lp.to === null || lp.to >= 16) ? "1px solid rgba(96,165,250,0.3)" : "1px solid rgba(255,255,255,0.06)" }}>
                  <div className="flex items-center gap-3 mb-1">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-black shrink-0" style={{ background:"rgba(96,165,250,0.12)", color:BLUE }}>{lp.number}</div>
                    <div>
                      <p className="text-xs font-semibold text-white">Period {lp.period} — {lp.ruling}</p>
                      <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>Ages {lp.from}–{lp.to ?? "end of life"}</p>
                    </div>
                    {lp.from <= 16 && (lp.to === null || lp.to >= 16) && (
                      <span className="ml-auto text-[9px] px-2 py-0.5 rounded font-bold" style={{ background:"rgba(250,204,21,0.12)", color:YELLOW }}>ACTIVE</span>
                    )}
                  </div>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>
                    {NUMBER_MEANINGS_FULL[lp.number]?.meaning ?? `Number ${lp.number} energy governs this period.`}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {N.karmicDebts.length > 0 && (
            <div className="glass-card p-4 border-red-500/20" style={{ background:"rgba(248,113,113,0.05)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(248,113,113,0.7)" }}>Karmic Debts Detected</p>
              <div className="flex gap-3">{N.karmicDebts.map(d=>(
                <span key={d} className="px-3 py-1.5 rounded-lg text-sm font-bold" style={{ background:"rgba(248,113,113,0.15)", color:"#f87171", border:"1px solid rgba(248,113,113,0.25)" }}>{d}</span>
              ))}</div>
            </div>
          )}
        </div>
      )}

      {sub==="advanced" && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Hidden Passion</p>
              <p className="text-4xl font-black" style={{ color:YELLOW }}>{N.hiddenPassion}</p>
              <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>Most repeated digit in {PROFILE.fullName} — your obsession & secret power</p>
            </div>
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Subconscious Self</p>
              <p className="text-4xl font-black" style={{ color:BLUE }}>{N.subconsciousSelf}</p>
              <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>9 minus {N.karmicLessons.length} karmic lessons — your crisis instinct</p>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Planes of Expression</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label:"Physical", value:N.planesOfExpression.physical, letters:"D,E,M,N,V,W", color:ROSE },
                { label:"Mental",   value:N.planesOfExpression.mental,   letters:"A,H,J,Q,S,Z", color:BLUE },
                { label:"Emotional",value:N.planesOfExpression.emotional,letters:"B,C,F,K,L,O,T,U,X", color:PURPLE },
                { label:"Intuitive",value:N.planesOfExpression.intuitive,letters:"G,I,P,R,Y", color:GREEN },
              ].map(p => (
                <div key={p.label} className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{p.label}</p>
                  <p className="text-3xl font-black" style={{ color:p.color }}>{p.value}</p>
                  <p className="text-[8px] mt-1" style={{ color:"rgba(255,255,255,0.25)" }}>{p.letters}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Intensity Table — {PROFILE.fullName}</p>
            <div className="grid grid-cols-9 gap-1.5 text-center">
              {[1,2,3,4,5,6,7,8,9].map(n => {
                const pythagorean: Record<string,number>={A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,I:9,J:1,K:2,L:3,M:4,N:5,O:6,P:7,Q:8,R:9,S:1,T:2,U:3,V:4,W:5,X:6,Y:7,Z:8};
                const count = [...PROFILE.fullName.toUpperCase()].filter(c=>/[A-Z]/.test(c)&&pythagorean[c]===n).length;
                const intensity = count===0?"missing":count>=4?"intense":count>=2?"balanced":"low";
                const col = intensity==="missing"?"#f87171":intensity==="intense"?YELLOW:intensity==="balanced"?BLUE:"rgba(255,255,255,0.4)";
                return (
                  <div key={n} className="p-2 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                    <p className="text-[9px] mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>{n}</p>
                    <p className="text-lg font-black" style={{ color:col }}>{count}</p>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Hebrew Gematria — Cristian Zavala</p>
            {(() => {
              const hg = hebrewGematria(PROFILE.fullName);
              return (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Mispar Gadol</p>
                    <p className="text-2xl font-black" style={{ color:YELLOW }}>{hg.misparGadol}</p>
                    <p className="text-[8px]" style={{ color:"rgba(255,255,255,0.3)" }}>Standard Value</p>
                  </div>
                  <div className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Mispar Katan</p>
                    <p className="text-2xl font-black" style={{ color:BLUE }}>{hg.misparKatan}</p>
                    <p className="text-[8px]" style={{ color:"rgba(255,255,255,0.3)" }}>Small Value</p>
                  </div>
                  <div className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Chaldean</p>
                    <p className="text-2xl font-black" style={{ color:PURPLE }}>{hg.chaldean}</p>
                    <p className="text-[8px]" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced: {hg.chaldeanReduced}</p>
                  </div>
                  <div className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Atbash</p>
                    <p className="text-2xl font-black" style={{ color:GREEN }}>{hg.atbashOrdinal}</p>
                    <p className="text-[8px]" style={{ color:"rgba(255,255,255,0.3)" }}>Mirror: {hg.atbashText.substring(0,8)}...</p>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {sub==="tools" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Address Numerology</p>
            <input type="text" value={addressInput} onChange={e=>setAddressInput(e.target.value)} placeholder="Enter address (e.g. 1234 Oak St Apt 5B)"
              className="w-full px-4 py-3 rounded-xl text-sm font-medium mb-3"
              style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.2)", color:"white", outline:"none" }} />
            {addressResult && (
              <div className="p-4 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(96,165,250,0.15)" }}>
                <div className="flex items-center gap-4 mb-2">
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Compound</p>
                    <p className="text-2xl font-black" style={{ color:BLUE }}>{addressResult.compound}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p>
                    <p className="text-2xl font-black" style={{ color:YELLOW }}>{addressResult.reduced}</p>
                  </div>
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{addressResult.meaning}</p>
              </div>
            )}
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:BLUE }}>Phone Number Analysis</p>
            <input type="text" value={phoneInput} onChange={e=>setPhoneInput(e.target.value)} placeholder="Enter phone number (e.g. 312-555-1234)"
              className="w-full px-4 py-3 rounded-xl text-sm font-medium mb-3"
              style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.2)", color:"white", outline:"none" }} />
            {phoneResult && (
              <div className="p-4 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(96,165,250,0.15)" }}>
                <div className="flex items-center gap-4 mb-2">
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Compound</p>
                    <p className="text-2xl font-black" style={{ color:BLUE }}>{phoneResult.compound}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p>
                    <p className="text-2xl font-black" style={{ color:YELLOW }}>{phoneResult.reduced}</p>
                  </div>
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{phoneResult.meaning}</p>
              </div>
            )}
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PURPLE }}>Vehicle / License Plate</p>
            <input type="text" value={vehicleInput} onChange={e=>setVehicleInput(e.target.value)} placeholder="Enter license plate (e.g. ABC 1234)"
              className="w-full px-4 py-3 rounded-xl text-sm font-medium mb-3"
              style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.2)", color:"white", outline:"none" }} />
            {vehicleResult && (
              <div className="p-4 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(96,165,250,0.15)" }}>
                <div className="flex items-center gap-4 mb-2">
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Compound</p>
                    <p className="text-2xl font-black" style={{ color:PURPLE }}>{vehicleResult.compound}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p>
                    <p className="text-2xl font-black" style={{ color:YELLOW }}>{vehicleResult.reduced}</p>
                  </div>
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{vehicleResult.meaning}</p>
              </div>
            )}
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Name Change Analysis</p>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <input type="text" value={nameFirst} onChange={e=>setNameFirst(e.target.value)} placeholder="New first name"
                className="w-full px-4 py-3 rounded-xl text-sm font-medium"
                style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.2)", color:"white", outline:"none" }} />
              <input type="text" value={nameLast} onChange={e=>setNameLast(e.target.value)} placeholder="New last name"
                className="w-full px-4 py-3 rounded-xl text-sm font-medium"
                style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.2)", color:"white", outline:"none" }} />
            </div>
            {nameChangeResult && (
              <div className="p-4 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(96,165,250,0.15)" }}>
                <div className="grid grid-cols-3 gap-3 mb-3">
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>New Expression</p>
                    <p className="text-2xl font-black" style={{ color:BLUE }}>{nameChangeResult.core.expression}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>New Soul Urge</p>
                    <p className="text-2xl font-black" style={{ color:PURPLE }}>{nameChangeResult.core.soulUrge}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Compatibility</p>
                    <p className="text-2xl font-black" style={{ color:nameChangeResult.compatibility >= 80 ? GREEN : nameChangeResult.compatibility >= 60 ? YELLOW : "#f87171" }}>{nameChangeResult.compatibility}%</p>
                  </div>
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{nameChangeResult.recommendation}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {sub==="number-guide" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Complete Number Guide</p>
            <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>Interpretations for numbers 1–33 with tarot, crystal, color, and planetary correspondences</p>
          </div>
          {Object.entries(NUMBER_MEANINGS_FULL).map(([num, info]) => (
            <div key={num} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-black shrink-0" style={{ background:"rgba(96,165,250,0.12)", color:BLUE }}>{num}</div>
                <div>
                  <p className="text-sm font-bold text-white">{info.title}</p>
                  <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>{info.keywords}</p>
                </div>
              </div>
              <p className="text-xs leading-relaxed mb-3" style={{ color:"rgba(255,255,255,0.6)" }}>{info.meaning}</p>
              <div className="flex flex-wrap gap-2">
                {[
                  { label:"Planet", value:info.planet, c:YELLOW },
                  { label:"Element", value:info.element, c:GREEN },
                  { label:"Tarot", value:info.tarot, c:PURPLE },
                  { label:"Crystal", value:info.crystal, c:BLUE },
                  { label:"Color", value:info.color, c:ROSE },
                ].filter(x => x.value).map(x => (
                  <span key={x.label} className="text-[9px] px-2 py-1 rounded-lg" style={{ background:`rgba(255,255,255,0.04)`, color:x.c }}>
                    {x.label}: {x.value}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {sub==="matrix-signals" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:YELLOW }}>Matrix Signals & Repeating Numbers</p>
            <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>When you see these numbers repeatedly, the Matrix is sending a message</p>
          </div>
          {Object.entries(MATRIX_SIGNALS).map(([signal, info]) => (
            <div key={signal} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="flex items-center gap-3 mb-2">
                <p className="text-2xl font-black" style={{ color:YELLOW }}>{signal}</p>
              </div>
              <p className="text-xs leading-relaxed mb-2" style={{ color:"rgba(255,255,255,0.6)" }}>{info.meaning}</p>
              <div className="flex items-start gap-2">
                <span className="text-[9px] font-bold px-2 py-0.5 rounded shrink-0" style={{ background:"rgba(96,165,250,0.12)", color:BLUE }}>ACTION</span>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{info.action}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {sub==="date-energy" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>How Date Energy is Calculated</p>
            <div className="space-y-2 mt-3">
              {[
                { step:"1", label:"Full digit sum", desc:"Add every single digit of MMDDYYYY — keep compound alive" },
                { step:"2", label:"Reduce to single", desc:"Continue reducing until single digit or master (11, 22, 33)" },
                { step:"3", label:"Layer check", desc:"Green (harmonious) = higher compound. Red (conflicting) = tension compound" },
                { step:"4", label:"Personal overlay", desc:"Birth month + birth day + date digit sum → your Personal Day" },
              ].map(s => (
                <div key={s.step} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold" style={{ background:"rgba(96,165,250,0.15)", color:BLUE }}>{s.step}</div>
                  <div>
                    <p className="text-xs font-semibold" style={{ color:"rgba(255,255,255,0.8)" }}>{s.label}</p>
                    <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-sm font-semibold mb-2" style={{ color:YELLOW }}>Your Imprint</p>
            <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>
              Birth: {PROFILE.birthMonth}/{PROFILE.birthDay}/{PROFILE.birthYear} → Life Path <span style={{ color:YELLOW }}>1</span>
            </p>
            <p className="text-xs mt-2 font-bold" style={{ color:BLUE }}>28/10/1 — Wealth & Leadership Portal</p>
          </div>
        </div>
      )}

      {sub==="lucky" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Lucky Numbers — Cristian Zavala</p>
            <div className="flex flex-wrap gap-3">
              {[
                { num:N.lifePath,   reason:"Life Path — primary power number" },
                { num:N.birthday,   reason:"Birthday Number — natural gift" },
                { num:N.expression, reason:"Expression — talent number" },
                { num:N.soulUrge,   reason:"Soul Urge — desire number" },
                { num:28,           reason:"Compound Life Path — wealth portal" },
                { num:10,           reason:"Reduced compound — completion & leadership" },
                { num:1,            reason:"Final reduction — total independence" },
              ].map(n => (
                <div key={n.num+n.reason} className="flex flex-col items-center p-3 rounded-xl" style={{ background:"rgba(250,204,21,0.08)", border:"1px solid rgba(250,204,21,0.15)", minWidth:72 }}>
                  <p className="text-3xl font-black" style={{ color:YELLOW }}>{n.num}</p>
                  <p className="text-[9px] text-center mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>{n.reason}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Lucky Colors — Life Path 1 / Saturn (8 Birthday)</p>
            <div className="flex flex-wrap gap-2">
              {["Gold","Yellow","Orange","Royal Blue","Black","Dark Blue"].map(c => (
                <div key={c} className="px-3 py-1.5 rounded-full text-xs font-semibold" style={{ background:"rgba(96,165,250,0.1)", color:BLUE, border:"1px solid rgba(96,165,250,0.2)" }}>{c}</div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
