import { reduce, digitSum, LUCKY_COLORS } from "./numerology";

// ─── Entity database ─────────────────────────────────────────────────────────
export interface TradingEntity {
  symbol: string;
  name: string;
  category: "index" | "stock" | "etf" | "crypto" | "custom";
  anchorDate: string; // MM/DD/YYYY
  description: string;
}

export const TRADING_ENTITIES: TradingEntity[] = [
  // Indices
  { symbol: "SPX",  name: "S&P 500",    category: "index",  anchorDate: "03/04/1957", description: "S&P 500 composite index" },
  { symbol: "NDX",  name: "Nasdaq 100", category: "index",  anchorDate: "02/08/1971", description: "Nasdaq composite index" },
  { symbol: "DJI",  name: "Dow Jones",  category: "index",  anchorDate: "05/26/1896", description: "Dow Jones Industrial Average" },
  { symbol: "RUT",  name: "Russell 2000", category: "index", anchorDate: "01/01/1984", description: "Small-cap index" },
  // ETFs
  { symbol: "SPY",  name: "SPY ETF",    category: "etf",    anchorDate: "01/22/1993", description: "SPDR S&P 500 ETF" },
  { symbol: "QQQ",  name: "QQQ ETF",    category: "etf",    anchorDate: "03/10/1999", description: "Invesco Nasdaq ETF" },
  // High-volume stocks
  { symbol: "NVDA", name: "NVIDIA",     category: "stock",  anchorDate: "01/22/1999", description: "AI/GPU leader" },
  { symbol: "TSLA", name: "Tesla",      category: "stock",  anchorDate: "06/29/2010", description: "EV & energy company" },
  { symbol: "AAPL", name: "Apple",      category: "stock",  anchorDate: "12/12/1980", description: "Consumer electronics leader" },
  { symbol: "AMD",  name: "AMD",        category: "stock",  anchorDate: "09/27/1972", description: "Semiconductor company" },
  { symbol: "META", name: "Meta",       category: "stock",  anchorDate: "02/01/2012", description: "Social media giant" },
  { symbol: "AMZN", name: "Amazon",     category: "stock",  anchorDate: "05/15/1997", description: "E-commerce & cloud leader" },
  { symbol: "GOOGL",name: "Alphabet",   category: "stock",  anchorDate: "08/19/2004", description: "Search & cloud giant" },
  { symbol: "MSFT", name: "Microsoft",  category: "stock",  anchorDate: "03/13/1986", description: "Software & cloud leader" },
  { symbol: "COIN", name: "Coinbase",   category: "stock",  anchorDate: "04/14/2021", description: "Crypto exchange" },
  { symbol: "MSTR", name: "MicroStrategy", category: "stock", anchorDate: "06/11/1998", description: "Bitcoin treasury company" },
  { symbol: "PLTR", name: "Palantir",   category: "stock",  anchorDate: "09/30/2020", description: "AI/data analytics" },
  { symbol: "SMCI", name: "Super Micro", category: "stock", anchorDate: "03/29/2007", description: "AI server hardware" },
  // Crypto
  { symbol: "BTC",  name: "Bitcoin",    category: "crypto", anchorDate: "01/03/2009", description: "Bitcoin genesis block" },
  { symbol: "ETH",  name: "Ethereum",   category: "crypto", anchorDate: "07/30/2015", description: "Ethereum mainnet launch" },
];

// ─── Imprint calculation ─────────────────────────────────────────────────────
export function calcEntityImprint(anchorDate: string): { fullSum: number; compound: number; reduced: number } {
  const digits = anchorDate.replace(/\//g, "");
  const fullSum = [...digits].reduce((a, d) => a + +d, 0);
  const compound = fullSum;
  const reduced = reduce(compound);
  return { fullSum, compound, reduced };
}

// ─── Daily battlefield ───────────────────────────────────────────────────────
export interface BattlefieldResult {
  date: string;
  entityImprint: { fullSum: number; compound: number; reduced: number };
  greenLayer: number; // harmonious
  redLayer: number;   // lower/conflicting
  greenCompound: number;
  redCompound: number;
  difference: number;
  signal: "RALLY" | "NEUTRAL" | "FADE";
  isMaster11: boolean;
  isMaster22: boolean;
  tag: string;
  breakdown: string;
  entryWindow: string;
  exitWindow: string;
}

function getAllCompounds(sum: number): number[] {
  const comps: number[] = [sum];
  let n = sum;
  while (n > 9) {
    n = [...String(n)].reduce((a, d) => a + +d, 0);
    comps.push(n);
  }
  return comps;
}

export function calcBattlefield(
  entity: TradingEntity,
  month: number, day: number, year: number
): BattlefieldResult {
  const dateStr = `${String(month).padStart(2,"0")}/${String(day).padStart(2,"0")}/${year}`;
  const imprint = calcEntityImprint(entity.anchorDate);

  // Date digit sum
  const dateFull = [...`${String(month).padStart(2,"0")}${String(day).padStart(2,"0")}${year}`].reduce((a,d)=>a+(+d),0);
  const allDateComps = getAllCompounds(dateFull);

  // Combine entity imprint with date energy
  const combined = imprint.fullSum + dateFull;
  const allComps = getAllCompounds(combined);

  // Green = higher harmonious layer (higher compound in the reduction chain)
  // Red = lower/conflicting (the compound closest to final reduce, when combined with tension)
  const greenLayer = reduce(combined);
  const greenCompound = combined > 9 ? [...String(combined)].reduce((a,d)=>a+(+d),0) : combined;
  const tension = Math.abs(imprint.reduced - reduce(dateFull));
  const redLayer = reduce(dateFull + tension);
  const redCompound = dateFull + tension;

  const diff = Math.abs(greenCompound - redCompound);
  const isMaster11 = allComps.includes(11) || allDateComps.includes(11);
  const isMaster22 = allComps.includes(22) || allDateComps.includes(22);

  let signal: "RALLY" | "NEUTRAL" | "FADE" = "NEUTRAL";
  let tag = "";

  if (diff >= 5 && greenLayer > redLayer) {
    signal = isMaster11 ? "RALLY" : "RALLY";
    tag = isMaster11 ? "M11 RALLY" : isMaster22 ? "M22 RALLY" : "RALLY";
  } else if (diff >= 5 && redLayer > greenLayer) {
    signal = "FADE";
    tag = "FADE";
  } else {
    signal = "NEUTRAL";
    tag = isMaster11 ? "M11 NEUTRAL" : "NEUTRAL";
  }

  const breakdown =
    `Entity ${entity.symbol} imprint: ${imprint.fullSum}/${imprint.compound} (${imprint.reduced})\n` +
    `Date full sum: ${dateFull} → compounds: ${allDateComps.join(" → ")}\n` +
    `Combined: ${combined} → chain: ${allComps.join(" → ")}\n` +
    `Green (harmonious): ${greenCompound} → ${greenLayer} | Red (conflict): ${redCompound} → ${redLayer}\n` +
    `Difference: ${diff} | Master 11: ${isMaster11} | Master 22: ${isMaster22}`;

  // Entry/exit windows based on reduced green number
  const windows: Record<number, { entry: string; exit: string }> = {
    1: { entry: "9:30–10:15 AM", exit: "2:00–3:00 PM" },
    2: { entry: "10:00–10:45 AM", exit: "1:00–2:00 PM" },
    3: { entry: "9:45–10:30 AM", exit: "3:00–4:00 PM" },
    4: { entry: "10:30–11:30 AM", exit: "2:30–3:30 PM" },
    5: { entry: "9:30–10:00 AM", exit: "11:30 AM–12:30 PM" },
    6: { entry: "11:00 AM–12:00 PM", exit: "2:00–3:00 PM" },
    7: { entry: "9:30–10:15 AM", exit: "1:30–2:30 PM" },
    8: { entry: "9:30–10:00 AM", exit: "3:30–4:00 PM" },
    9: { entry: "10:00–11:00 AM", exit: "3:00–4:00 PM" },
    11: { entry: "9:30–9:45 AM", exit: "Volatile — trail stop" },
    22: { entry: "10:00–11:00 AM", exit: "Strong trend — hold" },
  };
  const win = windows[greenLayer] ?? { entry: "10:00–11:00 AM", exit: "2:00–3:00 PM" };

  return {
    date: dateStr,
    entityImprint: imprint,
    greenLayer, redLayer, greenCompound, redCompound,
    difference: diff, signal, isMaster11, isMaster22, tag,
    breakdown, entryWindow: win.entry, exitWindow: win.exit,
  };
}

// ─── Weekly battlefield (7 days) ─────────────────────────────────────────────
export function calcWeekBattlefield(entity: TradingEntity, startDate: Date): BattlefieldResult[] {
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(startDate);
    d.setDate(d.getDate() + i);
    return calcBattlefield(entity, d.getMonth()+1, d.getDate(), d.getFullYear());
  });
}
