import { Link } from "wouter";
import { useParams } from "wouter";
import { useMemo, useState, useEffect, useCallback } from "react";
import { Bot, ChevronRight } from "lucide-react";
import { PROFILE } from "@/lib/profile";
import { GG33_TRUTH, calcCoreNumbers, calcDateEnergy, calcPersonalDay } from "@/lib/numerology";
import { LearnTheCode, OutputTags } from "@/components/LearnTheCode";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);

const YELLOW = "#facc15";
const BLUE   = "#60a5fa";
const GREEN  = "#4ade80";
const PURPLE = "#a855f7";
const ROSE   = "#fb7185";
const ORANGE = "#fb923c";

// GG33 color map: 1=Red, 2=Orange, 3=Purple, 4=Green, 5=Cyan, 6=Blue, 7=Violet, 8=Black/Gold, 9=Gold/Red, 10=Red/Gold, 11=Silver/White, 22=Yellow/Gold, 33=Orange
const GG33_COLORS: Record<number, { name: string; hex: string }> = {
  1:  { name: "Red / Gold",        hex: "#dc2626" },
  2:  { name: "Orange",             hex: "#ea580c" },
  3:  { name: "Purple",             hex: "#7c3aed" },
  4:  { name: "Green",              hex: "#16a34a" },
  5:  { name: "Cyan / Turquoise",   hex: "#0891b2" },
  6:  { name: "Blue / Indigo",      hex: "#2563eb" },
  7:  { name: "Violet / Lavender",  hex: "#6d28d9" },
  8:  { name: "Black / Gold",       hex: "#111827" },
  9:  { name: "Gold / Deep Red",    hex: "#b45309" },
  10: { name: "Red / Gold",         hex: "#dc2626" },
  11: { name: "Silver / White",     hex: "#e2e8f0" },
  22: { name: "Yellow / Gold",      hex: "#b45309" },
  33: { name: "Orange (33 Portal)", hex: "#ea580c" },
};

const energyColors: Record<number, string> = {
  1:"#dc2626", 2:"#ea580c", 3:"#7c3aed", 4:"#16a34a", 5:"#0891b2",
  6:"#2563eb", 7:"#6d28d9", 8:"#111827", 9:"#b45309",
  11:"#e2e8f0", 22:"#b45309", 33:"#ea580c",
};

// Personal day advice by number
const PD_ADVICE: Record<number, { title: string; actions: string[]; avoid: string[]; color: string }> = {
  1: { title: "INITIATE — Start New Things", actions:["Launch a new project or goal","Make first contact — reach out to someone important","Train with maximum intensity"], avoid:["Following others blindly","Passive waiting"], color:"#dc2626" },
  2: { title: "COOPERATE — Partner & Listen", actions:["Work with teammates, not against them","Have patience — things take time today","Good day for negotiations and diplomacy"], avoid:["Forcing outcomes","Confrontation"], color:"#ea580c" },
  3: { title: "CREATE — Express Yourself", actions:["Train creatively — try new moves","Connect socially — your charisma peaks","Create content or share ideas today"], avoid:["Isolation","Negative self-talk"], color:"#7c3aed" },
  4: { title: "BUILD — Work & Systems", actions:["Focus on structured practice drills","Handle administrative tasks","Build routines and systems today"], avoid:["Shortcuts","Impulsive decisions"], color:"#16a34a" },
  5: { title: "FREEDOM — Change & Adapt", actions:["Try something completely different in training","Be spontaneous — flexibility wins today","Travel, move, explore"], avoid:["Rigid plans","Overcommitting"], color:"#0891b2" },
  6: { title: "NURTURE — Family & Service", actions:["Check in with family and teammates","Focus on team harmony and relationships","Handle home/personal responsibilities"], avoid:["Neglecting others","Self-centeredness"], color:"#2563eb" },
  7: { title: "REFLECT — Study & Analyze", actions:["Watch game film and analyze performance","Study, research, read strategy materials","Meditate and recharge alone"], avoid:["Crowds and excessive social activity","Major decisions today"], color:"#6d28d9" },
  8: { title: "EXECUTE — Power & Authority", actions:["Make major moves — contracts, decisions, negotiations","Compete with full power","Handle financial matters"], avoid:["Timidity","Letting opportunities pass"], color:"#92400e" },
  9: { title: "COMPLETE — Release & Give", actions:["Finish outstanding projects","Give generously — mentoring, helping others","Release what no longer serves you"], avoid:["Clinging to the past","Starting major new ventures"], color:"#b45309" },
};

// Wardrobe guide by core numbers
const WARDROBE_CODE = [
  { label: "Primary Color (LP 1)", color: GG33_COLORS[1].name, hex: GG33_COLORS[1].hex, context: "Default daily power color. Sun energy. Leadership and initiative." },
  { label: "Secondary Color (Expression 3)", color: GG33_COLORS[3].name, hex: GG33_COLORS[3].hex, context: "Creative + charismatic energy. Wear for social events and creative tasks." },
  { label: "Authority Color (Birthday 8)", color: GG33_COLORS[8].name, hex: GG33_COLORS[8].hex, context: "Saturn authority. Wear Black/Gold for negotiations, competitions, serious work." },
  { label: "Completion Color (PY 9)", color: GG33_COLORS[9].name, hex: GG33_COLORS[9].hex, context: "2026 Personal Year 9 = Gold/Deep Red. Harvest and completion energy." },
];

const BRANDS_BY_ENERGY: Record<number, { wear:string[]; avoid:string[] }> = {
  1:{ wear:["Nike(1→1)","Apple(5→leader tech)","Jordan Brand(4→active)"], avoid:["Chanel(2→passive)","Givenchy(3→soft)"] },
  2:{ wear:["Adidas(5→flow)","Gucci(4→harmony)","New Balance(8→stable)"], avoid:["Supreme(5→chaotic)","Red Bull(6→aggression)"] },
  3:{ wear:["Puma(4→creative)","Louis Vuitton(9→expressive)","Spotify(8→creative flow)"], avoid:["GAP(6→plain)","Toyota(1→rigid)"] },
  4:{ wear:["Under Armour(7→disciplined)","Ford(4→foundation)","Levi's(9→sturdy)"], avoid:["Off-White(5→unstable)","Tesla(5→chaotic)"] },
  5:{ wear:["Nike(1→speed)","Red Bull(6→adventure)","Reebok(5→freedom)"], avoid:["BMW(8→heavy)","Porsche(4→rigid)"] },
  6:{ wear:["Ralph Lauren(5→harmony)","Starbucks(9→nurture)","H&M(2→soft)"], avoid:["Nike(1→aggressive)","Supreme(5→chaos)"] },
  7:{ wear:["Apple(5→intellect)","Sony(2→contemplative)","NVIDIA(4→precision)"], avoid:["Adidas(5→social)","Champion(3→flashy)"] },
  8:{ wear:["Gucci(4→luxury)","Mercedes-Benz(9→authority)","NVIDIA(4→power)"], avoid:["Puma(4→casual)","H&M(2→cheap energy)"] },
  9:{ wear:["Louis Vuitton(9→universal)","Ferrari(2→passion)","Dior(2→elegance)"], avoid:["GAP(6→basic)","Dodge(9→conflict)"] },
};

const LUCKY_GEMS: Record<number, { gem:string; color:string; why:string }[]> = {
  1:[{gem:"Ruby",color:"#dc2626",why:"Sun stone — amplifies LP1 leadership"},{gem:"Garnet",color:"#7f1d1d",why:"Grounding fire energy"},{gem:"Citrine",color:"#f59e0b",why:"Abundance activator"}],
  2:[{gem:"Moonstone",color:"#e2e8f0",why:"Moon energy for intuition"},{gem:"Pearl",color:"#f0f0f0",why:"Calming partnership energy"}],
  3:[{gem:"Amethyst",color:"#7c3aed",why:"Creative third eye opener"},{gem:"Yellow Sapphire",color:"#f59e0b",why:"Jupiter stone for expression"}],
  4:[{gem:"Hessonite",color:"#92400e",why:"Rahu stone for structure"},{gem:"Emerald",color:"#10b981",why:"Mercury stone for intellect"}],
  5:[{gem:"Emerald",color:"#10b981",why:"Mercury stone for communication"},{gem:"Aquamarine",color:"#22d3ee",why:"Flow and adaptability"}],
  6:[{gem:"Diamond",color:"#e2e8f0",why:"Venus stone for harmony"},{gem:"Opal",color:"#a78bfa",why:"Emotional balance"}],
  7:[{gem:"Cat's Eye",color:"#65a30d",why:"Ketu stone for spiritual insight"},{gem:"Amethyst",color:"#7c3aed",why:"Crown chakra activator"}],
  8:[{gem:"Blue Sapphire",color:"#1d4ed8",why:"Saturn stone — amplifies Birthday 8"},{gem:"Black Onyx",color:"#111827",why:"Grounding Saturn energy"}],
  9:[{gem:"Red Coral",color:"#dc2626",why:"Mars stone for completion drive"},{gem:"Carnelian",color:"#ea580c",why:"Motivation and courage"}],
};

const ROUTINE_STEPS = [
  {
    time: "5:00-5:30 AM",
    title: "Wake + Prime",
    items: ["Make bed", "Cold face splash", "Brush teeth", "Grounding on mat (15 min)", "Give thanks (3 things)", "Cobra stretch (2 min)", "Cat cow stretch (2 min)", "Hang from bar (2 min)"],
  },
  {
    time: "5:30-6:15 AM",
    title: "Fascial Rolling + GOATA",
    items: ["10 min fascia rolling", "30 min GOATA"],
  },
  {
    time: "6:15 AM",
    title: "Breakfast + Prep",
    items: ["High-protein breakfast", "Cold shower", "Hair", "Clothes", "Make breakfast"],
  },
  {
    time: "7:00 AM - 3:00 PM",
    title: "School",
    items: ["Pack lunch"],
  },
  {
    time: "3:00 PM - 4:30 PM",
    title: "After School",
    items: ["Work on businesses"],
  },
  {
    time: "4:30 PM - 6:40 PM",
    title: "Training Block",
    items: ["4:30-5:40 PM: Unrestricted Instinct Training", "5:40-6:30 PM: Fascia Training", "6:30-6:40 PM: Mental Training"],
  },
  {
    time: "6:40 PM - 10:30 PM",
    title: "Evening Wind-Down",
    items: ["6:45: Fortnite / Self Time", "8:30: Block blue light", "9:30: Read football book / watch documentary / research", "10:00: Bedtime", "Cobra stretch (2 min)", "Cat cow stretch (2 min)", "Hang from bar (2 min)", "Room mimics a cave", "Phone airplane mode"],
  },
  {
    time: "11:00 PM",
    title: "Sleep",
    items: ["Sleep"],
  },
];

const ROUTINE_STORAGE_KEY = "routine_checks";

function getTodayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function loadChecked(): Record<string, boolean | string> {
  try {
    const raw = localStorage.getItem(ROUTINE_STORAGE_KEY);
    if (!raw) return { _date: getTodayKey() };
    const data = JSON.parse(raw);
    if (data._date !== getTodayKey()) return { _date: getTodayKey() };
    return data;
  } catch { return { _date: getTodayKey() }; }
}

function saveChecked(state: Record<string, boolean | string>) {
  localStorage.setItem(ROUTINE_STORAGE_KEY, JSON.stringify({ ...state, _date: getTodayKey() }));
}

function useRoutineChecks() {
  const [checked, setChecked] = useState<Record<string, boolean | string>>(() => loadChecked());

  useEffect(() => {
    const interval = setInterval(() => {
      const today = getTodayKey();
      if (checked._date !== today) {
        const fresh = { _date: today };
        setChecked(fresh);
        saveChecked(fresh);
      }
    }, 15_000);
    return () => clearInterval(interval);
  }, [checked]);

  const toggle = useCallback((key: string) => {
    setChecked(prev => {
      const today = getTodayKey();
      const base = prev._date === today ? { ...prev } : { _date: today };
      base[key] = !base[key];
      saveChecked(base);
      return base;
    });
  }, []);

  const totalItems = ROUTINE_STEPS.reduce((s, step) => s + step.items.length, 0);
  const doneItems = Object.entries(checked).filter(([k, v]) => k !== "_date" && v === true).length;

  return { checked, toggle, totalItems, doneItems };
}

function birthDateLuckyNumber(month: number, day: number) {
  const digits = `${month}${day}`.replace(/\D/g, "");
  if (!digits) return 0;
  const first = Number(digits[0]);
  const last = Number(digits[digits.length - 1]);
  return first + last;
}

const tabs = [
  { key: "",         label: "Today",          href: "/day-life" },
  { key: "wardrobe", label: "Wardrobe Code",  href: "/day-life/wardrobe" },
  { key: "brands",   label: "Brands",         href: "/day-life/brands" },
  { key: "lucky",    label: "Lucky Dates",    href: "/day-life/lucky" },
  { key: "gems",     label: "Lucky Gems",     href: "/day-life/gems" },
  { key: "routine",  label: "Daily Routine",  href: "/day-life/routine" },
  { key: "matrix",   label: "Matrix Hacks",   href: "/day-life/matrix" },
  { key: "food",     label: "Numerology Diet", href: "/day-life/food" },
];

export default function DayLifePage() {
  const params = useParams<{ sub?: string }>();
  const sub = params.sub ?? "";
  const today = new Date();

  const de = useMemo(() => calcDateEnergy(today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const pd = useMemo(() => calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, today.getMonth()+1, today.getDate(), today.getFullYear()), []);

  const pdAdvice = PD_ADVICE[pd.reduced] ?? PD_ADVICE[1];
  const deColor  = energyColors[de.reduced] ?? BLUE;
  const pdColor  = pdAdvice.color;
  const pdGG33Color = GG33_COLORS[pd.reduced];
  const deGG33Color = GG33_COLORS[de.reduced];
  const birthLucky = birthDateLuckyNumber(PROFILE.birthMonth, PROFILE.birthDay);
  const birthLuckyInfo = GG33_TRUTH[birthLucky as keyof typeof GG33_TRUTH] ?? null;
  const { checked, toggle, totalItems, doneItems } = useRoutineChecks();

  return (
    <div className="max-w-4xl space-y-5">
      {/* Header */}
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>
          <Bot size={12} style={{ color: GREEN }} />
          <span>Day-to-Day Life AI</span>
          <ChevronRight size={10} />
          <span style={{ color: GREEN }}>Live Intelligence — Cristian Zavala</span>
        </div>
        <h1 className="page-title">Day-to-Day Life AI</h1>
        <p className="page-subtitle">Daily guidance · GG33 Color Code · Wardrobe · Matrix Hacks</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t => (
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub === t.key
                ? { background: "rgba(74,222,128,0.12)", color: GREEN, border: "1px solid rgba(74,222,128,0.25)" }
                : { color: "rgba(255,255,255,0.4)", border: "1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── TODAY ── */}
      {sub === "" && (
        <div className="space-y-4">
          <LearnTheCode
            title="Personal Day Formula"
            steps={[
              { step: "Personal Day", formula: "Birth Month + Birth Day + full digit sum of today's date → reduce", example: `9 + 8 + digitSum(${today.toLocaleDateString()}) → reduce` },
              { step: "GG33 Color", formula: "Personal Day number → GG33 color chart (1=Red, 3=Purple, 8=Black/Gold, etc.)", example: `PD ${pd.reduced} = ${pdGG33Color?.name ?? "See chart"}` },
              { step: "Universal Day", formula: "Sum all digits of MMDDYYYY → reduce (keep compound alive first)", example: `${today.getMonth()+1}${String(today.getDate()).padStart(2,'0')}${today.getFullYear()} → reduce` },
            ]}
            confidenceTag="High"
          />

          {/* Hero: Today */}
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${pdColor}30` }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>
              {today.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
            </p>
            <div className="flex items-start gap-5">
              <div className="text-center shrink-0">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Your Day</p>
                <p className="text-6xl font-black" style={{ color: pdColor }}>{pd.reduced}</p>
                <p className="text-[10px] mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>{pd.compound}</p>
              </div>
              <div className="text-center shrink-0">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Universal</p>
                <p className="text-6xl font-black" style={{ color: deColor }}>{de.reduced}</p>
                <p className="text-[10px] mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>{de.compound}</p>
              </div>
              <div className="flex-1">
                <p className="text-base font-bold text-white mb-1">{pdAdvice.title}</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>
                  {pd.reduced === de.reduced ? "⚡ Your personal + universal energy match — amplified day!" :
                   Math.abs(pd.reduced - de.reduced) <= 2 ? "✓ Good flow — energy in harmony today" :
                   "Neutral — navigate consciously"}
                </p>
                <OutputTags
                  calculated={`PD ${pd.compound}→${pd.reduced} · Universal ${de.compound}→${de.reduced}`}
                  interpretive={pdAdvice.title}
                  confidence="High"
                />
              </div>
            </div>
          </div>

          {/* GG33 color for today */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${pdColor}20` }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: "rgba(255,255,255,0.3)" }}>GG33 Color Code — Today (PD {pd.reduced})</p>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl shrink-0" style={{ background: pdGG33Color?.hex ?? pdColor, border: "2px solid rgba(255,255,255,0.15)" }} />
              <div>
                <p className="text-sm font-bold text-white">{pdGG33Color?.name ?? "See GG33 Chart"}</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>Wear this color today. Activate your Personal Day {pd.reduced} energy.</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: GREEN }}>Today's Power Actions</p>
            <div className="space-y-2">
              {pdAdvice.actions.map(a => (
                <div key={a} className="flex items-start gap-2">
                  <span style={{ color: GREEN }}>→</span>
                  <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>{a}</p>
                </div>
              ))}
            </div>
            <div className="mt-3 pt-3" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: ROSE }}>Avoid Today</p>
              {pdAdvice.avoid.map(a => (
                <div key={a} className="flex items-start gap-2">
                  <span style={{ color: ROSE }}>✗</span>
                  <p className="text-xs" style={{ color: "rgba(255,255,255,0.45)" }}>{a}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: BLUE }}>GG33 Truth Table</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {Object.entries(GG33_TRUTH).map(([num, info]) => (
                <div key={num} className="p-3 rounded-lg" style={{ background: "rgba(255,255,255,0.03)" }}>
                  <p className="text-xs font-bold text-white">{num} → {info.color}</p>
                  <p className="text-[10px] mt-1" style={{ color: "rgba(255,255,255,0.45)" }}>{info.lucky}</p>
                  <p className="text-[10px] mt-1" style={{ color: "rgba(255,255,255,0.35)" }}>{info.gems}</p>
                  <p className="text-[10px] mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>{info.notes}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: ROSE }}>Lucky Number Rules</p>
            <div className="space-y-2">
              <div className="p-3 rounded-lg" style={{ background: "rgba(96,165,250,0.05)" }}>
                <p className="text-xs font-bold text-white">Your Lucky Numbers: 1, 8, 9, 10, 22</p>
                <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.4)" }}>
                  These are the numbers that actually match your code.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── ROUTINE ── */}
      {sub === "routine" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)" }}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: YELLOW }}>Daily Routine</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.45)" }}>
                  Weekends / Non School Days
                </p>
              </div>
              <div className="text-right">
                <p className="text-lg font-black" style={{ color: doneItems === totalItems ? GREEN : BLUE }}>
                  {doneItems}/{totalItems}
                </p>
                <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.35)" }}>
                  {doneItems === totalItems ? "ALL DONE" : "completed"}
                </p>
              </div>
            </div>
            {totalItems > 0 && (
              <div className="mt-3 h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(doneItems/totalItems)*100}%`, background: doneItems === totalItems ? GREEN : BLUE }} />
              </div>
            )}
            <p className="text-[10px] mt-2" style={{ color: "rgba(255,255,255,0.25)" }}>Resets automatically at midnight</p>
          </div>
          <div className="space-y-3">
            {ROUTINE_STEPS.map((step, si) => {
              const stepItems = step.items;
              const stepDone = stepItems.every((_, ii) => checked[`${si}-${ii}`]);
              return (
                <div key={step.time} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: stepDone ? `1px solid ${GREEN}30` : "1px solid transparent" }}>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-[10px] uppercase tracking-widest" style={{ color: stepDone ? GREEN : BLUE }}>{step.time}</p>
                    {stepDone && <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: `${GREEN}15`, color: GREEN }}>DONE</span>}
                  </div>
                  <p className="text-sm font-semibold text-white mb-2" style={{ opacity: stepDone ? 0.5 : 1 }}>{step.title}</p>
                  <div className="space-y-1">
                    {stepItems.map((item, ii) => {
                      const key = `${si}-${ii}`;
                      const isDone = !!checked[key];
                      return (
                        <button key={key} onClick={() => toggle(key)} className="flex items-start gap-2 w-full text-left group">
                          <span className="mt-0.5 w-4 h-4 shrink-0 rounded border flex items-center justify-center transition-all" style={{
                            borderColor: isDone ? GREEN : "rgba(255,255,255,0.2)",
                            background: isDone ? `${GREEN}20` : "transparent"
                          }}>
                            {isDone && <span className="text-[10px]" style={{ color: GREEN }}>✓</span>}
                          </span>
                          <p className="text-xs transition-all" style={{
                            color: isDone ? "rgba(255,255,255,0.3)" : "rgba(255,255,255,0.6)",
                            textDecoration: isDone ? "line-through" : "none"
                          }}>{item}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── WARDROBE CODE ── */}
      {sub === "wardrobe" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${YELLOW}20` }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: YELLOW }}>GG33 Color Code — Your Personal Wardrobe Blueprint</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
              Every number has an exact GG33 color. Wear your number's color to activate that energy in your field. Layer your LP, Birthday, and Personal Day colors for compounding effect.
            </p>
          </div>

          {/* GG33 full color chart */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>GG33 Master Color Chart</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {Object.entries(GG33_COLORS).map(([num, info]) => (
                <div key={num} className="flex items-center gap-2 p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.02)" }}>
                  <div className="w-6 h-6 rounded-full shrink-0" style={{ background: info.hex, border: "1px solid rgba(255,255,255,0.15)" }} />
                  <div>
                    <p className="text-[10px] font-black" style={{ color: "rgba(255,255,255,0.7)" }}>{num} → {info.name}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Your personal wardrobe */}
          {WARDROBE_CODE.map(w => (
            <div key={w.label} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${w.hex}20` }}>
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-xl shrink-0" style={{ background: w.hex, border: `2px solid ${w.hex}60` }} />
                <div>
                  <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>{w.label}</p>
                  <p className="text-sm font-bold text-white">{w.color}</p>
                  <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.5)" }}>{w.context}</p>
                </div>
              </div>
            </div>
          ))}

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: BLUE }}>Match Day Power Outfit</p>
            <div className="space-y-2 text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>
              <p>→ <strong style={{ color: YELLOW }}>Kit:</strong> Black (LP8/Birthday8 Saturn activation) + Gold/Red accents (LP1 Sun energy)</p>
              <p>→ <strong style={{ color: GREEN }}>Cleats:</strong> Black with Gold detail (maximum Saturn authority)</p>
              <p>→ <strong style={{ color: BLUE }}>Grip Socks:</strong> Black primary, Gold secondary</p>
              <p>→ <strong style={{ color: PURPLE }}>Crystal:</strong> Black tourmaline in boot (protection) + Citrine in bag (prosperity)</p>
              <p>→ <strong style={{ color: ROSE }}>Tape:</strong> Red strapping tape activates LP1 Root chakra before kickoff</p>
            </div>
          </div>
        </div>
      )}

      {/* ── BRANDS ── */}
      {sub === "brands" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: GREEN }}>Today's Brand Energy — PD {pd.reduced}</p>
            <p className="text-xs mb-4" style={{ color: "rgba(255,255,255,0.4)" }}>Brands aligned with your Personal Day energy. Wear these to amplify your code.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-semibold mb-3" style={{ color: GREEN }}>✅ Brands to Wear</p>
                {(BRANDS_BY_ENERGY[pd.reduced]?.wear ?? []).map(b=>(
                  <div key={b} className="flex items-center gap-2 mb-2 p-2.5 rounded-lg" style={{ background:"rgba(74,222,128,0.05)" }}>
                    <span className="text-sm">✓</span>
                    <p className="text-xs text-white font-semibold">{b}</p>
                  </div>
                ))}
              </div>
              <div>
                <p className="text-xs font-semibold mb-3" style={{ color: ROSE }}>🚫 Brands to Avoid</p>
                {(BRANDS_BY_ENERGY[pd.reduced]?.avoid ?? []).map(b=>(
                  <div key={b} className="flex items-center gap-2 mb-2 p-2.5 rounded-lg" style={{ background:"rgba(248,113,113,0.05)" }}>
                    <span className="text-sm">✗</span>
                    <p className="text-xs text-white font-semibold">{b}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: YELLOW }}>Permanent Brand Alignment — LP {N.lifePath}</p>
            <p className="text-xs mb-3" style={{ color: "rgba(255,255,255,0.4)" }}>These brands always align with your core energy regardless of the day.</p>
            {(BRANDS_BY_ENERGY[N.lifePath]?.wear ?? []).map(b=>(
              <div key={b} className="flex items-center gap-2 mb-1.5 p-2 rounded-lg" style={{ background:"rgba(250,204,21,0.04)" }}>
                <span className="text-sm" style={{ color: YELLOW }}>★</span>
                <p className="text-xs text-white">{b}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── LUCKY DATES ── */}
      {sub === "lucky" && (() => {
        const m = today.getMonth()+1;
        const y = today.getFullYear();
        const daysInMonth = new Date(y,m,0).getDate();
        const luckyDays: { day:number; score:number; reason:string }[] = [];
        for(let d=1;d<=daysInMonth;d++){
          const de2 = calcDateEnergy(m,d,y);
          const pd2 = calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, m, d, y);
          const match = pd2.reduced === N.lifePath || pd2.reduced === N.birthday || de2.reduced === N.lifePath;
          const master = de2.reduced === 11 || de2.reduced === 22 || de2.reduced === 33;
          if(match || master) {
            const score = (pd2.reduced===N.lifePath?35:0)+(pd2.reduced===N.birthday?25:0)+(de2.reduced===N.lifePath?20:0)+(master?20:0);
            const reasons: string[] = [];
            if(pd2.reduced===N.lifePath) reasons.push(`PD=${pd2.reduced} matches LP`);
            if(pd2.reduced===N.birthday) reasons.push(`PD=${pd2.reduced} matches Birthday`);
            if(de2.reduced===N.lifePath) reasons.push(`UD=${de2.reduced} matches LP`);
            if(master) reasons.push(`Master ${de2.reduced}`);
            luckyDays.push({ day:d, score, reason:reasons.join(" · ") });
          }
        }
        luckyDays.sort((a,b)=>b.score-a.score);
        const luckyWeekdays = [1,8,10,19,28].map(n=>({ num:n, reason:n===1?"LP 1":n===8?"Birthday 8":n===10?"LP compound":n===19?"Karmic 19":"LP compound 28" }));
        return (
          <div className="space-y-4">
            <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: YELLOW }}>Lucky Dates This Month</p>
              <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>Days where your Personal Day or Universal Day aligns with your core numbers.</p>
              {luckyDays.length===0 ? (
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.3)" }}>No perfect alignment dates this month. Use your permanent lucky days instead.</p>
              ) : (
                <div className="space-y-2">
                  {luckyDays.map(d=>(
                    <div key={d.day} className="flex items-center justify-between p-3 rounded-lg" style={{ background:"rgba(250,204,21,0.05)", border:"1px solid rgba(250,204,21,0.1)" }}>
                      <div className="flex items-center gap-3">
                        <p className="text-2xl font-black" style={{ color: YELLOW }}>{d.day}</p>
                        <div>
                          <p className="text-xs font-semibold text-white">{new Date(y,m-1,d.day).toLocaleDateString("en-US",{weekday:"long",month:"short",day:"numeric"})}</p>
                          <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>{d.reason}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        {Array.from({length:Math.ceil(d.score/20)},(_,i)=>(
                          <span key={i} className="text-xs" style={{ color:YELLOW }}>★</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: GREEN }}>Permanent Lucky Days (Any Month)</p>
              <div className="flex gap-2 flex-wrap">
                {luckyWeekdays.map(d=>(
                  <div key={d.num} className="text-center px-4 py-3 rounded-xl" style={{ background:"rgba(74,222,128,0.06)", border:"1px solid rgba(74,222,128,0.12)" }}>
                    <p className="text-2xl font-black" style={{ color:GREEN }}>{d.num}</p>
                    <p className="text-[8px]" style={{ color:"rgba(255,255,255,0.3)" }}>{d.reason}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })()}

      {/* ── LUCKY GEMS ── */}
      {sub === "gems" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: PURPLE }}>Your Lucky Gemstones</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>Based on LP {N.lifePath} (primary) and Birthday {N.birthday} (secondary). Wear or carry these stones to amplify your energy field.</p>
            <div className="space-y-3">
              <p className="text-xs font-semibold" style={{ color: YELLOW }}>Life Path {N.lifePath} Stones</p>
              {(LUCKY_GEMS[N.lifePath] ?? []).map(g=>(
                <div key={g.gem} className="flex items-center gap-3 p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <div className="w-8 h-8 rounded-full shrink-0" style={{ background:g.color, boxShadow:`0 0 15px ${g.color}40` }} />
                  <div>
                    <p className="text-sm font-bold text-white">{g.gem}</p>
                    <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{g.why}</p>
                  </div>
                </div>
              ))}
              <p className="text-xs font-semibold mt-3" style={{ color: BLUE }}>Birthday {N.birthday} Stones</p>
              {(LUCKY_GEMS[N.birthday] ?? []).map(g=>(
                <div key={g.gem} className="flex items-center gap-3 p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <div className="w-8 h-8 rounded-full shrink-0" style={{ background:g.color, boxShadow:`0 0 15px ${g.color}40` }} />
                  <div>
                    <p className="text-sm font-bold text-white">{g.gem}</p>
                    <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{g.why}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: GREEN }}>How to Use Your Stones</p>
            {[
              "Wear on your dominant hand (right) during competitions and big decisions",
              "Place under your pillow for overnight chakra activation",
              "Carry in your left pocket for passive energy reception throughout the day",
              "Cleanse monthly under running water on a Full Moon night (PY9 amplifies releases)",
            ].map((tip,i)=>(
              <div key={i} className="flex items-start gap-2 mb-2">
                <span className="text-xs" style={{ color:GREEN }}>→</span>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.55)" }}>{tip}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── MATRIX HACKS ── */}
      {sub === "matrix" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${YELLOW}20` }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: YELLOW }}>Matrix Hacks — Daily Life Activation Codes</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>These are real-world applications of your numerology codes in everyday life — GG33 style.</p>
          </div>
          {[
            { emoji: "📱", title: "Phone Lock Screen", code: "Set to 111 (LP1 × 111) or 1010 (LP compound)", why: "Every time you see your lock screen you activate your Life Path code." },
            { emoji: "⏰", title: "Wake Alarm", code: "Set alarm to 6:28 AM — 28 = your LP compound, wealth portal", why: "The first numbers you see each day program your subconscious for wealth." },
            { emoji: "💧", title: "Water Activation", code: "Write '528 Hz' on a piece of tape, stick to water bottle", why: "528 Hz is the Solar Plexus frequency. Drinking 'programmed' water is a GG33 matrix hack." },
            { emoji: "👟", title: "Jersey Number", code: "Always request #10 — LP 28/10/1 compound activation", why: "Your jersey number broadcasts your energy number to the universe during play." },
            { emoji: "💰", title: "Wallet Hack", code: "Keep a folded piece of paper with '1-28-10' written in gold ink", why: "28/10/1 is your wealth code. Keep it in contact with your money." },
            { emoji: "🏠", title: "Room Setup", code: "North wall: achievements (career energy). East corner: wealth bowl", why: "Kua 9 activates success via East direction. North = relationships per Kua 9." },
            { emoji: "🌙", title: "Moon Ritual", code: "On Full Moon: write one thing to release (PY9 energy). New Moon: write one thing to call in.", why: "PY 9 is a completion year — Full Moon release rituals amplify PY9 closing cycle." },
            { emoji: "🔢", title: "Pattern Recognition", code: "Notice 1:11, 10:10, 28:xx, 111 everywhere — do not dismiss", why: "GG33 teaches these are matrix confirmations your energy is aligned." },
          ].map(h => (
            <div key={h.title} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
              <div className="flex items-start gap-3">
                <span className="text-2xl shrink-0">{h.emoji}</span>
                <div>
                  <p className="text-sm font-bold text-white">{h.title}</p>
                  <p className="text-xs font-semibold mt-1" style={{ color: YELLOW }}>{h.code}</p>
                  <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.5)" }}>{h.why}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── FOOD ── */}
      {sub === "food" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: GREEN }}>Numerology Diet — GG33 Food Codes</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>Every color of food activates a different chakra and number energy. Eating your number's food literally programs your biology with that number's frequency.</p>
          </div>
          {[
            { number: 1, label: "LP 1 — Red Foods", foods: ["Cherries", "Strawberries", "Pomegranate", "Red apple", "Beets", "Red peppers", "Tomatoes"], benefit: "Root chakra + Sun energy. Courage, vitality, physical strength. Eat daily.", color: "#dc2626" },
            { number: 3, label: "Expression 3 — Yellow & Gold Foods", foods: ["Banana", "Pineapple", "Yellow bell pepper", "Corn", "Turmeric", "Lemon", "Mango"], benefit: "Solar Plexus + Jupiter activation. Creativity, confidence, charisma.", color: "#ca8a04" },
            { number: 4, label: "Soul Urge 4 — Green Foods", foods: ["Broccoli", "Kale", "Spinach", "Avocado", "Green apple", "Cucumber", "Zucchini"], benefit: "Heart chakra + Uranus stability. Foundation, heart health, endurance.", color: "#16a34a" },
            { number: 8, label: "Birthday/Personality 8 — Dark & Black Foods", foods: ["Black beans", "Black rice", "Dark chocolate", "Blackberries", "Black sesame", "Dark leafy greens"], benefit: "Saturn + Soul Star. Authority, discipline, long-term health.", color: "#4b5563" },
            { number: 9, label: "PY 9 (2026) — Gold & Deep Red Foods", foods: ["Dates", "Figs", "Garnet grapes", "Dark berries", "Red wine (minimal)", "Pomegranate seeds"], benefit: "Mars/9 completion energy. Releasing, harvesting, gratitude.", color: "#b45309" },
            { number: 6, label: "Heal KL6 (Third Eye) — Indigo & Purple Foods", foods: ["Blueberries", "Purple grapes", "Eggplant", "Purple cabbage", "Lavender", "Plums", "Blackcurrant"], benefit: "KARMIC LESSON HEALING — Third Eye activation. Eat purple daily to heal blocked chakra 6.", color: "#4338ca" },
            { number: 7, label: "Heal KL7 (Crown) — White & Violet Foods", foods: ["Coconut", "White mushroom", "Cauliflower", "Garlic", "Onion", "White peach", "Vanilla"], benefit: "KARMIC LESSON HEALING — Crown chakra purification. Eat white foods for spiritual clarity.", color: "#7c3aed" },
          ].map(f => (
            <div key={f.number} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${f.color}18` }}>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-full shrink-0" style={{ background: f.color + "30", border: `2px solid ${f.color}40` }}>
                  <div className="w-full h-full rounded-full" style={{ background: f.color, opacity: 0.5 }} />
                </div>
                <p className="text-sm font-bold text-white">{f.label}</p>
              </div>
              <div className="flex flex-wrap gap-1.5 mb-3">
                {f.foods.map(food => (
                  <span key={food} className="text-[9px] px-2 py-1 rounded-full" style={{ background: `${f.color}12`, color: f.color }}>{food}</span>
                ))}
              </div>
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>{f.benefit}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
