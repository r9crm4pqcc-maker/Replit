import { useState, useMemo, useRef } from "react";
import { Radio, Search, ChevronRight, Clock, Zap, Play, Pause, Volume2 } from "lucide-react";

const YELLOW = "hsl(48 96% 53%)";
const BLUE   = "hsl(212 95% 65%)";
const PURPLE = "hsl(270 60% 70%)";
const GREEN  = "#4ade80";
const ROSE   = "#f472b6";

type RifeEntry = {
  condition: string;
  category: string;
  frequencies: { hz: number; label: string }[];
  duration: string;
  sessions: string;
  notes: string;
  intensity: "Low" | "Medium" | "High";
};

type SelectedRife = RifeEntry & { hz: number; label: string };

const RIFE_DATABASE: RifeEntry[] = [
  {
    condition: "General Cellular Rebalance",
    category: "Core Healing",
    frequencies: [{ hz: 432, label: "Harmony" }, { hz: 528, label: "Repair" }, { hz: 963, label: "Alignment" }],
    duration: "20–30 min",
    sessions: "Daily",
    notes: "Base protocol for gentle whole-body balancing.",
    intensity: "Low",
  },
  {
    condition: "General Energy Boost",
    category: "Core Healing",
    frequencies: [{ hz: 40, label: "Activation" }, { hz: 1000, label: "Energy" }, { hz: 7.83, label: "Earth Sync" }],
    duration: "15–20 min",
    sessions: "Morning",
    notes: "Good starter session before work, training, or study.",
    intensity: "Low",
  },
  // ── Immunity & Infection ──
  {
    condition: "Immune Boost",
    category: "Immunity",
    frequencies: [{ hz:727, label:"Immune Activation"},{hz:787,label:"Cell Energizer"},{hz:880,label:"Pathogen Clearance"}],
    duration: "20–30 min",sessions:"Daily or every other day",
    notes:"Best used in the morning on an empty stomach. Stay well hydrated.",
    intensity:"Medium",
  },
  {
    condition: "Viral Support",
    category: "Immunity",
    frequencies:[{hz:432,label:"Repair"},{hz:727,label:"Immune"},{hz:787,label:"Anti-viral"},{hz:880,label:"Anti-pathogen"}],
    duration:"25–35 min",sessions:"Daily",
    notes:"General viral load support protocol.",
    intensity:"High",
  },
  {
    condition: "Common Cold",
    category: "Immunity",
    frequencies:[{hz:465,label:"Rhinovirus"},{hz:727,label:"Immune Stimulation"},{hz:787,label:"Anti-viral"},{hz:880,label:"Anti-pathogen"}],
    duration:"20–30 min",sessions:"2–3× daily for 5–7 days",
    notes:"Increase water intake significantly. Rest between sessions.",
    intensity:"Medium",
  },
  {
    condition: "Flu / Influenza",
    category: "Immunity",
    frequencies:[{hz:432,label:"DNA Repair"},{hz:464,label:"Influenza Virus"},{hz:727,label:"Immune"},{hz:787,label:"Anti-viral"},{hz:880,label:"Anti-pathogen"}],
    duration:"25–35 min",sessions:"3× daily during acute phase",
    notes:"Combine with Vitamin C, zinc, and rest. Use 30-min sessions.",
    intensity:"High",
  },
  {
    condition: "Bacterial Infection",
    category: "Immunity",
    frequencies:[{hz:728,label:"Bacteria General"},{hz:880,label:"Anti-bacterial"},{hz:432,label:"Cellular Repair"}],
    duration:"20–30 min",sessions:"2× daily for 7–10 days",
    notes:"Never replace antibiotics if prescribed. Use as complementary support.",
    intensity:"Medium",
  },
  {
    condition: "Lyme Disease Support",
    category: "Immunity",
    frequencies:[{hz:432,label:"Borrelia Base"},{hz:524,label:"Borrelia Burgdorferi"},{hz:660,label:"Spirochete"},{hz:727,label:"Immune Activation"},{hz:880,label:"Anti-pathogen"}],
    duration:"30–45 min",sessions:"Daily, build up gradually",
    notes:"Start with shorter sessions (10–15 min) to avoid Herxheimer reaction. Work with a practitioner.",
    intensity:"High",
  },

  // ── Pain & Inflammation ──
  {
    condition: "Muscle Pain / Soreness",
    category: "Pain & Recovery",
    frequencies:[{hz:40,label:"Anti-inflammatory"},{hz:10000,label:"Muscle Repair"},{hz:304,label:"Pain Relief"},{hz:1.5,label:"Cellular Relaxation"}],
    duration:"20–30 min",sessions:"After training, daily",
    notes:"Place electrodes near affected muscle groups. Gentle warmth is normal.",
    intensity:"Low",
  },
  {
    condition: "Knee Pain",
    category: "Pain & Recovery",
    frequencies:[{hz:9.39,label:"Anti-inflammation"},{hz:304,label:"Pain"},{hz:10000,label:"Tissue Repair"}],
    duration:"20–30 min",sessions:"Daily",
    notes:"Supportive option for athletes with impact stress.",
    intensity:"Medium",
  },
  {
    condition: "Joint Pain / Arthritis",
    category: "Pain & Recovery",
    frequencies:[{hz:9.39,label:"Anti-inflammation"},{hz:464,label:"Joint"},{hz:10000,label:"Connective Tissue"},{hz:304,label:"Pain"}],
    duration:"25–35 min",sessions:"Daily for 3–4 weeks",
    notes:"Consistent daily use shows cumulative benefits. Reduce inflammatory foods.",
    intensity:"Medium",
  },
  {
    condition: "Back Pain",
    category: "Pain & Recovery",
    frequencies:[{hz:40,label:"Anti-inflammatory"},{hz:304,label:"Pain"},{hz:3.0,label:"Muscle Tension"},{hz:727,label:"Tissue Repair"}],
    duration:"20–30 min",sessions:"Daily until resolved",
    notes:"Lie flat during sessions. Combine with stretching.",
    intensity:"Medium",
  },
  {
    condition: "Headache / Migraine",
    category: "Pain & Recovery",
    frequencies:[{hz:10,label:"Alpha Calming"},{hz:304,label:"Pain Relief"},{hz:1.5,label:"Relaxation"},{hz:20,label:"Vascular"}],
    duration:"20–30 min",sessions:"At onset, then every 4 hours if needed",
    notes:"Reduce screen time. Dark room. Hydrate well. Lower intensity first.",
    intensity:"Low",
  },
  {
    condition: "Nerve Pain / Neuropathy",
    category: "Pain & Recovery",
    frequencies:[{hz:2,label:"Nerve Regeneration"},{hz:7.83,label:"Schumann Resonance"},{hz:40,label:"GABA Activation"},{hz:304,label:"Pain"}],
    duration:"30–40 min",sessions:"Daily for 6–8 weeks",
    notes:"Consistent long-term use required. Combine with B12 and Alpha Lipoic Acid.",
    intensity:"Medium",
  },

  // ── Athletic Performance ──
  {
    condition: "Athletic Performance",
    category: "Performance",
    frequencies:[{hz:40,label:"Focus & Reaction"},{hz:528,label:"DNA Integrity"},{hz:1000,label:"Energy Activation"},{hz:10000,label:"Muscle Fiber"}],
    duration:"15–20 min",sessions:"Before training or competition",
    notes:"Use as pre-activation. Best 30–60 minutes before activity.",
    intensity:"Medium",
  },
  {
    condition: "Pre-Game Focus",
    category: "Performance",
    frequencies:[{hz:40,label:"Gamma Focus"},{hz:14,label:"Beta Activation"},{hz:528,label:"Flow"}],
    duration:"10–15 min",sessions:"Before competition",
    notes:"Use immediately before warmups.",
    intensity:"Medium",
  },
  {
    condition: "Muscle Recovery",
    category: "Performance",
    frequencies:[{hz:10000,label:"Muscle Repair"},{hz:528,label:"Cellular Healing"},{hz:432,label:"Natural Harmony"},{hz:40,label:"Inflammation Control"}],
    duration:"20–30 min",sessions:"Within 2 hours post-training",
    notes:"Hydrate, eat protein-rich meal. Sleep is your partner — use before bed too.",
    intensity:"Low",
  },
  {
    condition: "Endurance & Stamina",
    category: "Performance",
    frequencies:[{hz:1000,label:"ATP Production"},{hz:528,label:"Mitochondria"},{hz:7.83,label:"Earth Resonance"},{hz:10,label:"Alpha Energy"}],
    duration:"20–25 min",sessions:"3–5× weekly",
    notes:"Best results when combined with proper nutrition and recovery sleep.",
    intensity:"Medium",
  },
  {
    condition: "Speed & Reaction Time",
    category: "Performance",
    frequencies:[{hz:40,label:"Gamma Focus"},{hz:14,label:"Beta Activation"},{hz:1000,label:"Neural Firing"}],
    duration:"15–20 min",sessions:"Before training or games",
    notes:"Short sessions (15 min) before competition. Don't overstimulate.",
    intensity:"Medium",
  },
  {
    condition: "Sports Injury Recovery",
    category: "Performance",
    frequencies:[{hz:528,label:"DNA Repair"},{hz:432,label:"Cellular Harmony"},{hz:40,label:"Anti-inflammatory"},{hz:10000,label:"Tissue Regeneration"}],
    duration:"30–45 min",sessions:"2× daily during recovery",
    notes:"Always follow medical advice first. Use alongside RICE protocol.",
    intensity:"Medium",
  },

  // ── Mental & Cognitive ──
  {
    condition: "Anxiety & Stress",
    category: "Mental",
    frequencies:[{hz:10,label:"Alpha Calm"},{hz:7.83,label:"Schumann Earth"},{hz:528,label:"Love Frequency"},{hz:1.5,label:"Deep Relaxation"}],
    duration:"20–30 min",sessions:"Daily, especially evenings",
    notes:"Best in a quiet, dark room. Use headphones with binaural beats if possible.",
    intensity:"Low",
  },
  {
    condition: "Nervous System Calm",
    category: "Mental",
    frequencies:[{hz:1.5,label:"Deep Relaxation"},{hz:7.83,label:"Earth Rhythm"},{hz:432,label:"Harmony"}],
    duration:"20–30 min",sessions:"Daily",
    notes:"Use before sleep or after hard days.",
    intensity:"Low",
  },
  {
    condition: "Depression Support",
    category: "Mental",
    frequencies:[{hz:40,label:"Gamma Activation"},{hz:10,label:"Alpha Balance"},{hz:528,label:"Healing"},{hz:432,label:"Harmony"}],
    duration:"25–35 min",sessions:"Daily, morning preferred",
    notes:"Not a replacement for therapy or medication. Complementary support only.",
    intensity:"Low",
  },
  {
    condition: "Focus & Concentration",
    category: "Mental",
    frequencies:[{hz:40,label:"Gamma"},{hz:14,label:"Beta"},{hz:18,label:"SMR Focus"}],
    duration:"15–25 min",sessions:"Before study or work",
    notes:"Best results when you need to be fully alert. Not for evening use.",
    intensity:"Medium",
  },
  {
    condition: "Sleep / Insomnia",
    category: "Mental",
    frequencies:[{hz:1.5,label:"Delta Deep Sleep"},{hz:3.0,label:"Sleep Stage 3"},{hz:7.83,label:"Earth Rhythm"},{hz:0.5,label:"Epsilon"}],
    duration:"30–45 min",sessions:"30–60 min before bed, nightly",
    notes:"Keep volume very low. Let yourself drift off. Do not combine with stimulants.",
    intensity:"Low",
  },
  {
    condition: "Study Mode",
    category: "Mental",
    frequencies:[{hz:14,label:"Beta"},{hz:18,label:"SMR Focus"},{hz:40,label:"Gamma"}],
    duration:"15–20 min",sessions:"Before homework",
    notes:"Best before reading, writing, or exams.",
    intensity:"Medium",
  },
  {
    condition: "ADHD / Mental Clarity",
    category: "Mental",
    frequencies:[{hz:40,label:"Gamma"},{hz:10,label:"Alpha"},{hz:14,label:"Beta Balance"},{hz:528,label:"Brain Coherence"}],
    duration:"20–30 min",sessions:"Daily, morning routine",
    notes:"Consistent daily practice builds lasting neurological benefits over weeks.",
    intensity:"Medium",
  },
  {
    condition: "Memory Enhancement",
    category: "Mental",
    frequencies:[{hz:40,label:"Gamma Memory"},{hz:10,label:"Alpha Retention"},{hz:7.83,label:"Neural Sync"}],
    duration:"20–25 min",sessions:"Before learning sessions",
    notes:"Study immediately after for 2–3× better retention.",
    intensity:"Low",
  },

  // ── Digestive ──
  {
    condition: "Digestive Issues / IBS",
    category: "Digestive",
    frequencies:[{hz:9.19,label:"Gut Healing"},{hz:304,label:"Inflammation"},{hz:528,label:"Cellular Repair"},{hz:40,label:"Anti-inflammatory"}],
    duration:"20–30 min",sessions:"Daily before meals",
    notes:"Eliminate gluten and dairy during treatment. Stay hydrated.",
    intensity:"Low",
  },
  {
    condition: "Stomach Bloating",
    category: "Digestive",
    frequencies:[{hz:9.19,label:"Gut Healing"},{hz:304,label:"Inflammation"},{hz:432,label:"Relaxation"}],
    duration:"20–25 min",sessions:"Daily",
    notes:"Good for slow digestion and bloating patterns.",
    intensity:"Low",
  },
  {
    condition: "Candida / Yeast Overgrowth",
    category: "Digestive",
    frequencies:[{hz:464,label:"Candida"},{hz:728,label:"Anti-fungal"},{hz:880,label:"Pathogen"},{hz:787,label:"Anti-microbial"}],
    duration:"25–35 min",sessions:"Daily for 4–8 weeks",
    notes:"Strict diet during treatment. Herxheimer reactions possible — reduce sessions if uncomfortable.",
    intensity:"High",
  },
  {
    condition: "Liver Support",
    category: "Digestive",
    frequencies:[{hz:317,label:"Liver"},{hz:304,label:"Detox Support"},{hz:9.19,label:"Organ Healing"}],
    duration:"20–30 min",sessions:"3–4× weekly",
    notes:"Avoid alcohol completely. Combine with milk thistle and dandelion.",
    intensity:"Medium",
  },

  // ── Respiratory ──
  {
    condition: "Asthma Support",
    category: "Respiratory",
    frequencies:[{hz:727,label:"Bronchial"},{hz:10,label:"Relaxation"},{hz:304,label:"Inflammation"},{hz:880,label:"Anti-inflammatory"}],
    duration:"20–30 min",sessions:"Daily",
    notes:"Never stop rescue inhaler. Use as complementary support.",
    intensity:"Low",
  },
  {
    condition: "Breathing Ease",
    category: "Respiratory",
    frequencies:[{hz:432,label:"Relax"},{hz:727,label:"Bronchial"},{hz:880,label:"Open Airway"}],
    duration:"20–25 min",sessions:"Daily",
    notes:"Gentle support for tight breathing days.",
    intensity:"Low",
  },
  {
    condition: "Allergies",
    category: "Respiratory",
    frequencies:[{hz:727,label:"Histamine"},{hz:787,label:"Anti-allergy"},{hz:304,label:"Inflammation"},{hz:880,label:"Immune Modulation"}],
    duration:"20–30 min",sessions:"Daily during allergy season",
    notes:"Begin 2–3 weeks before peak season for preventive effect.",
    intensity:"Medium",
  },
  {
    condition: "Sinus Congestion",
    category: "Respiratory",
    frequencies:[{hz:20,label:"Sinus"},{hz:727,label:"Pathogen"},{hz:304,label:"Pressure Relief"}],
    duration:"15–25 min",sessions:"2–3× daily",
    notes:"Steam inhalation before session enhances results.",
    intensity:"Low",
  },

  // ── Skin ──
  {
    condition: "Acne / Skin Inflammation",
    category: "Skin",
    frequencies:[{hz:465,label:"Skin Bacteria"},{hz:727,label:"Anti-microbial"},{hz:528,label:"Skin Healing"},{hz:40,label:"Anti-inflammatory"}],
    duration:"20–25 min",sessions:"Daily",
    notes:"Combine with clean diet (no processed sugar). Keep skin clean.",
    intensity:"Low",
  },
  {
    condition: "Skin Glow",
    category: "Skin",
    frequencies:[{hz:528,label:"Repair"},{hz:639,label:"Harmony"},{hz:40,label:"Inflammation"}],
    duration:"20–25 min",sessions:"Daily",
    notes:"General complexion-support protocol.",
    intensity:"Low",
  },
  {
    condition: "Eczema / Psoriasis",
    category: "Skin",
    frequencies:[{hz:9.19,label:"Skin Repair"},{hz:40,label:"Anti-inflammatory"},{hz:528,label:"DNA Healing"},{hz:304,label:"Itch Relief"}],
    duration:"25–35 min",sessions:"Daily for 4–6 weeks",
    notes:"Avoid known triggers. Moisturize immediately after session.",
    intensity:"Low",
  },
  {
    condition: "Wound Healing",
    category: "Skin",
    frequencies:[{hz:528,label:"DNA Repair"},{hz:432,label:"Cellular Harmony"},{hz:10000,label:"Tissue Regeneration"}],
    duration:"20–30 min",sessions:"2× daily during healing phase",
    notes:"Apply directly to area if using pads. Keep wound clean.",
    intensity:"Low",
  },

  // ── Energy & Detox ──
  {
    condition: "Detox / Heavy Metal Cleanse",
    category: "Detox",
    frequencies:[{hz:727,label:"Toxin Clearance"},{hz:787,label:"Metal Detox"},{hz:880,label:"Pathogen Sweep"},{hz:10000,label:"Cellular Cleanse"}],
    duration:"20–30 min",sessions:"3–4× weekly",
    notes:"Must drink 2–3L of water daily. Detox symptoms (fatigue, headache) are normal at first.",
    intensity:"High",
  },
  {
    condition: "Lymph Drainage",
    category: "Detox",
    frequencies:[{hz:727,label:"Clearance"},{hz:787,label:"Detox"},{hz:10000,label:"Flow"}],
    duration:"20–30 min",sessions:"3× weekly",
    notes:"Add walking and water intake for better results.",
    intensity:"Medium",
  },
  {
    condition: "Fatigue / Low Energy",
    category: "Energy",
    frequencies:[{hz:1000,label:"Energy Activation"},{hz:40,label:"ATP Production"},{hz:528,label:"Mitochondria"},{hz:10,label:"Alpha Restore"}],
    duration:"20–25 min",sessions:"Morning, daily",
    notes:"Check for underlying causes (thyroid, iron, sleep). Best with morning sunlight.",
    intensity:"Medium",
  },
  {
    condition: "Adrenal Fatigue",
    category: "Energy",
    frequencies:[{hz:10,label:"Cortisol Balance"},{hz:7.83,label:"Earth Frequency"},{hz:528,label:"Adrenal Repair"},{hz:1.5,label:"Rest Activation"}],
    duration:"25–35 min",sessions:"Daily, reduce intense exercise",
    notes:"Avoid caffeine. Sleep 8–9 hours. Ashwagandha complements this protocol.",
    intensity:"Low",
  },

  // ── Spiritual / Matrix ──
  {
    condition: "DNA Activation",
    category: "Spiritual",
    frequencies:[{hz:528,label:"DNA Miracle Frequency"},{hz:432,label:"Universal Harmony"},{hz:963,label:"Pineal Activation"}],
    duration:"20–30 min",sessions:"Daily morning practice",
    notes:"Best combined with meditation and intention. Use high-quality speakers or headphones.",
    intensity:"Low",
  },
  {
    condition: "Crown Activation",
    category: "Spiritual",
    frequencies:[{hz:963,label:"Crown"},{hz:1111,label:"Portal"},{hz:432,label:"Harmony"}],
    duration:"20–30 min",sessions:"Daily",
    notes:"Useful for spiritual alignment and stillness.",
    intensity:"Low",
  },
  {
    condition: "Chakra Alignment",
    category: "Spiritual",
    frequencies:[{hz:396,label:"Root Chakra"},{hz:417,label:"Sacral Chakra"},{hz:528,label:"Solar Plexus"},{hz:639,label:"Heart Chakra"},{hz:741,label:"Throat Chakra"},{hz:852,label:"Third Eye"},{hz:963,label:"Crown Chakra"}],
    duration:"30–45 min",sessions:"Weekly deep, daily light",
    notes:"One frequency per chakra, 5 min each. Set clear intention before starting.",
    intensity:"Low",
  },
  {
    condition: "Third Eye / Intuition",
    category: "Spiritual",
    frequencies:[{hz:852,label:"Third Eye Activation"},{hz:963,label:"Pineal Gland"},{hz:936,label:"Higher Consciousness"}],
    duration:"20–30 min",sessions:"Daily, preferably at night",
    notes:"Meditate immediately after. Journal your insights.",
    intensity:"Low",
  },
  {
    condition: "Manifestation / Law of Attraction",
    category: "Spiritual",
    frequencies:[{hz:528,label:"DNA Love"},{hz:432,label:"Heart Coherence"},{hz:963,label:"Higher Self"},{hz:639,label:"Heart Opening"}],
    duration:"20–30 min",sessions:"Daily, before visualization practice",
    notes:"State your intentions clearly before and during the session.",
    intensity:"Low",
  },
  {
    condition: "Grounding / Stability",
    category: "Spiritual",
    frequencies:[{hz:396,label:"Root"},{hz:7.83,label:"Earth"},{hz:432,label:"Balance"}],
    duration:"20–25 min",sessions:"Daily",
    notes:"Great before competition or stressful events.",
    intensity:"Low",
  },
];

const CATEGORIES = ["All", ...Array.from(new Set(RIFE_DATABASE.map(r => r.category)))];

const INTENSITY_COLOR: Record<string,string> = {
  Low: GREEN,
  Medium: YELLOW,
  High: ROSE,
};

const CATEGORY_COLOR: Record<string,string> = {
  Immunity: ROSE,
  "Pain & Recovery": BLUE,
  Performance: YELLOW,
  Mental: PURPLE,
  Digestive: GREEN,
  Respiratory: BLUE,
  Skin: ROSE,
  Detox: YELLOW,
  Energy: YELLOW,
  Spiritual: PURPLE,
};

export default function RifePage() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [selected, setSelected] = useState<SelectedRife | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.18);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const gainRef = useRef<GainNode | null>(null);

  const togglePlay = () => {
    if (!selected) return;
    const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextCtor) return;
    if (isPlaying) {
      try { oscRef.current?.stop(); } catch {}
      try { oscRef.current?.disconnect(); } catch {}
      try { gainRef.current?.disconnect(); } catch {}
      try { audioCtxRef.current?.close(); } catch {}
      oscRef.current = null;
      gainRef.current = null;
      audioCtxRef.current = null;
      setIsPlaying(false);
      return;
    }
    const ctx = new AudioContextCtor();
    if (ctx.state === "suspended") ctx.resume();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = Math.max(20, Math.min(20000, selected.hz));
    gain.gain.value = volume;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    audioCtxRef.current = ctx;
    oscRef.current = osc;
    gainRef.current = gain;
    setIsPlaying(true);
  };

  const stopPlay = () => {
    try { oscRef.current?.stop(); } catch {}
    try { oscRef.current?.disconnect(); } catch {}
    try { gainRef.current?.disconnect(); } catch {}
    try { audioCtxRef.current?.close(); } catch {}
    oscRef.current = null;
    gainRef.current = null;
    audioCtxRef.current = null;
    setIsPlaying(false);
  };

  const results = useMemo(() => {
    let list = RIFE_DATABASE;
    if (activeCategory !== "All") list = list.filter(r => r.category === activeCategory);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(r =>
        r.condition.toLowerCase().includes(q) ||
        r.category.toLowerCase().includes(q) ||
        r.notes.toLowerCase().includes(q)
      );
    }
    return list;
  }, [query, activeCategory]);

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Radio size={12} style={{ color:GREEN }} />
          <span>Rife Frequencies</span><ChevronRight size={10} /><span style={{ color:GREEN }}>Condition Lookup</span>
        </div>
        <h1 className="page-title">Rife Frequency Finder</h1>
        <p className="page-subtitle">Type any condition to find healing frequencies and recommended session duration</p>
      </div>

      {/* Search bar */}
      <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(74,222,128,0.2)" }}>
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color:"rgba(255,255,255,0.3)" }} />
          <input
            type="text"
            placeholder="Type a condition (e.g. muscle pain, anxiety, immune boost...)"
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full rounded-xl pl-9 pr-4 py-3 text-sm text-white placeholder:text-white/30"
            style={{ background:"rgba(255,255,255,0.06)", border:"1px solid rgba(74,222,128,0.25)", outline:"none" }}
            autoFocus
          />
        </div>
        <div className="flex flex-wrap gap-1.5 mt-3">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className="px-3 py-1 rounded-full text-[10px] font-semibold transition-all"
              style={activeCategory === cat
                ? { background:"rgba(74,222,128,0.15)", color:GREEN, border:"1px solid rgba(74,222,128,0.3)" }
                : { color:"rgba(255,255,255,0.35)", border:"1px solid rgba(255,255,255,0.08)" }}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {selected && (
        <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(96,165,250,0.18)" }}>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Selected Frequency</p>
              <p className="text-sm font-bold text-white">{selected.condition} · {selected.hz} Hz</p>
              <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.4)" }}>{selected.label}</p>
            </div>
            <button onClick={togglePlay} className="px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-2"
              style={{ background:"rgba(96,165,250,0.12)", color:BLUE, border:"1px solid rgba(96,165,250,0.2)" }}>
              {isPlaying ? <Pause size={12} /> : <Play size={12} />}
              {isPlaying ? "Pause" : "Play"}
            </button>
          </div>
          <div className="mt-3 flex items-center gap-3">
            <Volume2 size={12} style={{ color:"rgba(255,255,255,0.4)" }} />
            <input type="range" min="0" max="1" step="0.01" value={volume} onChange={e=>{
              const v = +e.target.value;
              setVolume(v);
              if (gainRef.current) gainRef.current.gain.value = v;
            }}
              className="flex-1" />
          </div>
          <p className="text-[10px] mt-2" style={{ color:"rgba(255,255,255,0.35)" }}>Tap a frequency chip below to load it into the player.</p>
        </div>
      )}

      {/* Disclaimer */}
      <div className="px-4 py-3 rounded-xl" style={{ background:"rgba(250,204,21,0.05)", border:"1px solid rgba(250,204,21,0.15)" }}>
        <p className="text-[10px] leading-relaxed" style={{ color:"rgba(255,255,255,0.4)" }}>
          <span style={{ color:YELLOW }}>⚡ Informational Use Only</span> — Rife frequencies are for educational and complementary wellness purposes. They are not a replacement for medical diagnosis or treatment. Always consult a licensed healthcare professional for serious conditions.
        </p>
      </div>

      {/* Results count */}
      <div className="flex items-center justify-between">
        <p className="text-[10px] uppercase tracking-widest" style={{ color:"rgba(255,255,255,0.3)" }}>
          {results.length} {results.length === 1 ? "Protocol" : "Protocols"} Found
          {query && <span style={{ color:GREEN }}> · "{query}"</span>}
        </p>
        <div className="flex items-center gap-3 text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>
          {Object.entries(INTENSITY_COLOR).map(([lvl, col]) => (
            <span key={lvl} className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full inline-block" style={{ background:col }} />
              {lvl}
            </span>
          ))}
        </div>
      </div>

      {/* Result cards */}
      {results.length === 0 ? (
        <div className="glass-card p-8 text-center" style={{ background:"hsl(228 28% 7%)" }}>
          <p className="text-2xl mb-2">🔍</p>
          <p className="text-sm" style={{ color:"rgba(255,255,255,0.4)" }}>No protocols found for "{query}"</p>
          <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.25)" }}>Try different keywords or browse all categories</p>
        </div>
      ) : (
        <div className="space-y-4">
          {results.map(entry => (
            <div key={entry.condition} className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:`1px solid ${INTENSITY_COLOR[entry.intensity]}18` }}>
              {/* Header */}
              <div className="flex items-start justify-between gap-3 mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ background:`${CATEGORY_COLOR[entry.category] ?? BLUE}15`, color:CATEGORY_COLOR[entry.category] ?? BLUE }}>{entry.category}</span>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ background:`${INTENSITY_COLOR[entry.intensity]}15`, color:INTENSITY_COLOR[entry.intensity] }}>Intensity: {entry.intensity}</span>
                  </div>
                  <h3 className="text-base font-bold text-white">{entry.condition}</h3>
                </div>
                <div className="text-right shrink-0">
                  <div className="flex items-center gap-1 justify-end" style={{ color:GREEN }}>
                    <Clock size={10} />
                    <span className="text-[9px] font-semibold">{entry.duration}</span>
                  </div>
                  <p className="text-[8px] mt-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>{entry.sessions}</p>
                </div>
              </div>

              {/* Frequencies */}
              <div className="mb-4">
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Frequencies</p>
                <div className="flex flex-wrap gap-2">
                  {entry.frequencies.map(f => (
                        <button key={f.hz} onClick={() => { stopPlay(); setSelected({ ...entry, hz: f.hz, label: f.label }); }}
                      className="px-3 py-2 rounded-xl text-left"
                      style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${BLUE}20` }}>
                      <div className="flex items-center gap-1.5">
                        <Zap size={10} style={{ color:YELLOW }} />
                        <span className="text-sm font-black" style={{ color:YELLOW }}>{f.hz.toLocaleString()}</span>
                        <span className="text-[9px] font-semibold" style={{ color:BLUE }}>Hz</span>
                      </div>
                      <p className="text-[8px] mt-0.5" style={{ color:"rgba(255,255,255,0.35)" }}>{f.label}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Session timing bar */}
              <div className="flex items-center gap-3 mb-3 p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <Clock size={12} style={{ color:BLUE }} />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[9px] font-semibold" style={{ color:BLUE }}>Recommended Session</span>
                    <span className="text-xs font-black" style={{ color:YELLOW }}>{entry.duration}</span>
                  </div>
                  <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>{entry.sessions}</p>
                </div>
              </div>

              {/* Notes */}
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.05)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Protocol Notes</p>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{entry.notes}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Footer reference */}
      <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
        <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>About Rife Frequencies</p>
        <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.45)" }}>
          Dr. Royal Raymond Rife (1888–1971) developed a frequency-based approach to healing, theorizing that specific electromagnetic frequencies could destroy pathogens and stimulate cellular healing. Modern researchers continue exploring resonant frequency therapy. Common delivery methods include PEMF devices, frequency generators, and binaural audio tracks. Sessions work best with adequate hydration, quality rest, and clean nutrition as supporting factors.
        </p>
      </div>
    </div>
  );
}
