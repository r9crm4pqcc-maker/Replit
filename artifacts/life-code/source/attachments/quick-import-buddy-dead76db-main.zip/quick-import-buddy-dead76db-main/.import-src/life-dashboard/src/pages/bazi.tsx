import { Link } from "wouter";
import { useParams } from "wouter";
import { Sparkles, ChevronRight } from "lucide-react";
import { BAZI, ZODIAC_COMPAT, ELEMENT_SEASONS } from "@/lib/bazi";
import { PROFILE } from "@/lib/profile";
import { LearnTheCode, OutputTags } from "@/components/LearnTheCode";

const YELLOW = "#facc15";
const BLUE   = "#60a5fa";
const GREEN  = "#4ade80";
const PURPLE = "#a855f7";
const ROSE   = "#fb7185";
const ORANGE = "#fb923c";

const ELEM_COLOR: Record<string, string> = {
  Wood:  "#4ade80",
  Fire:  "#f87171",
  Earth: "#facc15",
  Metal: "#e2e8f0",
  Water: "#60a5fa",
};

const tabs = [
  { key: "",           label: "Four Pillars",    href: "/bazi" },
  { key: "luck",       label: "Luck Pillars",    href: "/bazi/luck" },
  { key: "animal",     label: "Chinese Zodiac",  href: "/bazi/animal" },
  { key: "seasons",    label: "Five Elements",   href: "/bazi/seasons" },
  { key: "overlay",    label: "LP Overlay",      href: "/bazi/overlay" },
];

const PILLAR_LABELS = ["Year Pillar", "Month Pillar", "Day Pillar", "Hour Pillar"];
const PILLARS = [BAZI.year, BAZI.month, BAZI.day, BAZI.hour];

export default function BaZiPage() {
  const params = useParams<{ sub?: string }>();
  const sub = params.sub ?? "";

  return (
    <div className="max-w-4xl space-y-5">
      {/* Header */}
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>
          <Sparkles size={12} style={{ color: ORANGE }} />
          <span>Chinese Astrology</span>
          <ChevronRight size={10} />
          <span style={{ color: ORANGE }}>BaZi — Cristian Zavala · Ox Year · Water Rabbit Day</span>
        </div>
        <h1 className="page-title">Chinese Astrology & BaZi</h1>
        <p className="page-subtitle">Four Pillars of Destiny · BaZi Analysis · Life Path 1 Overlay</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t => (
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub === t.key
                ? { background: "rgba(251,146,60,0.12)", color: ORANGE, border: "1px solid rgba(251,146,60,0.25)" }
                : { color: "rgba(255,255,255,0.4)", border: "1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── FOUR PILLARS ── */}
      {sub === "" && (
        <div className="space-y-4">
          <LearnTheCode
            title="BaZi Four Pillars"
            steps={[
              { step: "Year Pillar", formula: "Chinese Lunar Year → Heavenly Stem + Earthly Branch", example: "2009 = Ji (Earth-Yin) + Chou (Ox) = Earth Ox" },
              { step: "Month Pillar", formula: "Chinese Month from Solar Terms → Stem+Branch pair", example: "Sep 8, 2009 = Month 8 (Rooster month) → Xin You (Metal Rooster)" },
              { step: "Day Pillar", formula: "Day Pillar from BaZi Day Table (60-cycle Jia Zi)", example: "Sep 8, 2009 = Gui Mao (Water Rabbit)" },
              { step: "Hour Pillar", formula: "Hour stem from Day stem cycle + Branch from 2-hour block", example: "11:18 AM (Wu hour 11am–1pm) + Gui day → Jia Wu (Wood Horse)" },
              { step: "Day Master", formula: "Heavenly Stem of Day Pillar = your core identity", example: "Gui (Yin Water) = Day Master for Cristian" },
            ]}
            sourceLabel="Per GG33 Academy + Standard BaZi"
            confidenceTag="Medium"
            extraNotes="Day Pillar requires precise 60-cycle day chart. Medium confidence — verify with certified BaZi practitioner for exact day stem confirmation."
          />

          {/* Day Master hero */}
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${BLUE}25` }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: "rgba(255,255,255,0.3)" }}>Day Master</p>
            <div className="flex items-center gap-5">
              <div className="text-center p-4 rounded-xl shrink-0" style={{ background: "rgba(96,165,250,0.08)" }}>
                <p className="text-4xl font-black" style={{ color: BLUE }}>Gui</p>
                <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.4)" }}>癸 · Yin Water</p>
              </div>
              <div>
                <p className="text-sm font-semibold text-white mb-1">{BAZI.interpretation.slice(0, 120)}…</p>
                <div className="flex gap-2 flex-wrap mt-2">
                  <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: `${ELEM_COLOR[BAZI.dayMasterElement]}18`, color: ELEM_COLOR[BAZI.dayMasterElement] }}>
                    {BAZI.dayMasterElement} · {BAZI.dayMasterPolarity}
                  </span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: "rgba(250,204,21,0.12)", color: YELLOW }}>
                    Strength: {BAZI.dayMasterStrength}
                  </span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: "rgba(74,222,128,0.1)", color: GREEN }}>
                    Chinese Animal: {BAZI.chineseAnimal}
                  </span>
                </div>
                <OutputTags
                  calculated={`Gui (Yin Water) Day Master · ${BAZI.dayMasterStrength} strength`}
                  interpretive="Rain archetype — nourishing, adaptable, penetrating"
                  confidence="Medium"
                />
              </div>
            </div>
          </div>

          {/* Four Pillars Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {PILLARS.map((pillar, i) => (
              <div key={i} className="glass-card p-4 text-center" style={{ background: "hsl(228 28% 7%)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color: "rgba(255,255,255,0.3)" }}>{PILLAR_LABELS[i]}</p>
                <div className="space-y-1">
                  <p className="text-2xl font-black" style={{ color: ELEM_COLOR[pillar.element] }}>{pillar.stem}</p>
                  <p className="text-sm font-semibold text-white">{pillar.branch}</p>
                  <p className="text-[9px]" style={{ color: ELEM_COLOR[pillar.element] }}>{pillar.element}</p>
                  <p className="text-[10px] font-bold" style={{ color: ORANGE }}>{pillar.animal}</p>
                </div>
                <div className="mt-3 pt-2" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
                  <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>Hidden: {pillar.hiddenStems.join(", ")}</p>
                  <p className="text-[8px] mt-0.5" style={{ color: "rgba(255,255,255,0.25)" }}>{pillar.stemPolarity}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Element count */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>Element Balance in Chart</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-[9px] mb-2" style={{ color: GREEN }}>Strong / Favorable</p>
                {BAZI.favorableElements.map(el => (
                  <div key={el} className="flex items-center gap-2 mb-1">
                    <div className="w-2 h-2 rounded-full" style={{ background: ELEM_COLOR[el] }} />
                    <p className="text-xs font-semibold" style={{ color: ELEM_COLOR[el] }}>{el}</p>
                  </div>
                ))}
              </div>
              <div>
                <p className="text-[9px] mb-2" style={{ color: ROSE }}>Challenging</p>
                {BAZI.unfavorableElements.map(el => (
                  <div key={el} className="flex items-center gap-2 mb-1">
                    <div className="w-2 h-2 rounded-full" style={{ background: ELEM_COLOR[el] }} />
                    <p className="text-xs font-semibold" style={{ color: ELEM_COLOR[el] }}>{el}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Full interpretation */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${ORANGE}20` }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: ORANGE }}>Chart Interpretation</p>
            <p className="text-xs leading-relaxed mb-3" style={{ color: "rgba(255,255,255,0.65)" }}>{BAZI.interpretation}</p>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: GREEN }}>Athletic Timing</p>
            <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.55)" }}>{BAZI.athleticTiming}</p>
          </div>
        </div>
      )}

      {/* ── LUCK PILLARS ── */}
      {sub === "luck" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Luck Pillars — 10-Year Cycles</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>Each pillar runs approximately 10 years and shifts the energetic climate of your life.</p>
          </div>
          {BAZI.luckPillars.map((lp, i) => {
            const isCurrentPillar = i === 1; // ages 11-20, 2020-2029 is current
            return (
              <div key={i} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: isCurrentPillar ? `1px solid ${YELLOW}30` : "1px solid transparent" }}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-xl text-center shrink-0" style={{ background: "rgba(255,255,255,0.04)", minWidth: 60 }}>
                    <p className="text-[9px] uppercase" style={{ color: "rgba(255,255,255,0.3)" }}>Ages</p>
                    <p className="text-sm font-black" style={{ color: isCurrentPillar ? YELLOW : BLUE }}>{lp.age}</p>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-bold text-white">{lp.stem} {lp.branch}</p>
                      <span className="text-[9px] px-2 py-0.5 rounded" style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.5)" }}>{lp.yearRange}</span>
                      {isCurrentPillar && <span className="text-[9px] px-2 py-0.5 rounded font-bold" style={{ background: `${YELLOW}15`, color: YELLOW }}>CURRENT</span>}
                    </div>
                    <p className="text-[9px] mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>Element: {lp.element}</p>
                  </div>
                </div>
                <p className="text-xs mb-2" style={{ color: "rgba(255,255,255,0.6)" }}>{lp.theme}</p>
                <div className="flex items-start gap-2">
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded shrink-0" style={{ background: "rgba(74,222,128,0.12)", color: GREEN }}>SOCCER</span>
                  <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.45)" }}>{lp.sports}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── CHINESE ZODIAC ── */}
      {sub === "animal" && (
        <div className="space-y-4">
          {/* Ox hero */}
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${YELLOW}25` }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: YELLOW }}>Your Year Animal — Earth Ox (2009)</p>
            <div className="flex items-start gap-5">
              <div className="text-5xl">🐂</div>
              <div>
                <p className="text-sm font-bold text-white mb-2">Ji Chou — Earth Ox</p>
                <div className="space-y-1.5 text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>
                  <p>→ <strong style={{ color: YELLOW }}>Endurance</strong>: The Ox never stops — relentless work ethic on and off the pitch.</p>
                  <p>→ <strong style={{ color: YELLOW }}>Discipline</strong>: Ox energy demands consistent, methodical training — no shortcuts.</p>
                  <p>→ <strong style={{ color: YELLOW }}>Dependability</strong>: Teammates trust Ox players because they show up, every time.</p>
                  <p>→ <strong style={{ color: YELLOW }}>Slow start, powerful finish</strong>: The Ox builds slowly but never breaks under pressure.</p>
                  <p>→ <strong style={{ color: GREEN }}>Element overlay</strong>: Ji (Yin Earth) + LP 1 (Fire) — Fire generates Earth in the cycle. Your inner fire fuels your grounded determination.</p>
                </div>
                <OutputTags
                  calculated="Year 2009 = Ji Chou (Earth Ox)"
                  interpretive="Disciplined builder, endurance athlete, trustworthy leader"
                  confidence="High"
                />
              </div>
            </div>
          </div>

          {/* GG33 overlay: LP 1 × Ox */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: BLUE }}>GG33 Overlay: LP 1 (Pioneer) × Ox (Endurance)</p>
            <div className="grid grid-cols-2 gap-3">
              {[
                { trait: "Playing Style", value: "Lead from the front, never quit, technically precise", color: YELLOW },
                { trait: "Peak Period", value: "Autumn (Metal season) — feeds Gui Water Day Master", color: GREEN },
                { trait: "Recovery", value: "Slower than peers — Ox needs full rest cycles", color: BLUE },
                { trait: "Mental Game", value: "Stubborn resilience — never accepts defeat", color: ORANGE },
              ].map(t => (
                <div key={t.trait} className="p-3 rounded-lg" style={{ background: "rgba(255,255,255,0.03)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>{t.trait}</p>
                  <p className="text-xs font-semibold" style={{ color: t.color }}>{t.value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Compatibility table */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>Chinese Zodiac Compatibility with Ox</p>
            <div className="space-y-2">
              {Object.entries(ZODIAC_COMPAT).map(([animal, { score, note }]) => {
                const scoreColor = score >= 85 ? GREEN : score >= 70 ? YELLOW : score >= 55 ? BLUE : ROSE;
                return (
                  <div key={animal} className="flex items-center gap-3 p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.02)" }}>
                    <p className="text-xs font-bold w-20" style={{ color: scoreColor }}>{animal}</p>
                    <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
                      <div className="h-full rounded-full" style={{ width: `${score}%`, background: scoreColor }} />
                    </div>
                    <p className="text-xs font-black w-10 text-right" style={{ color: scoreColor }}>{score}%</p>
                    <p className="text-[9px] flex-1 hidden sm:block" style={{ color: "rgba(255,255,255,0.35)" }}>{note}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── FIVE ELEMENTS / SEASONS ── */}
      {sub === "seasons" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Five Elements — Athletic Timing Calendar</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
              Your Gui (Yin Water) Day Master is supported by Metal and weakened by Fire and Earth. Time your peak performances accordingly.
            </p>
          </div>
          {Object.entries(ELEMENT_SEASONS).map(([elem, info]) => {
            const isFav = BAZI.favorableElements.includes(elem);
            const isUnfav = BAZI.unfavorableElements.includes(elem);
            const col = ELEM_COLOR[elem] ?? BLUE;
            return (
              <div key={elem} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${col}20` }}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${col}15` }}>
                    <p className="text-sm font-black" style={{ color: col }}>{elem[0]}</p>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold text-white">{elem}</p>
                      <span className="text-[9px] px-2 py-0.5 rounded font-bold" style={{
                        background: isFav ? "rgba(74,222,128,0.12)" : isUnfav ? "rgba(251,113,133,0.12)" : "rgba(255,255,255,0.05)",
                        color: isFav ? GREEN : isUnfav ? ROSE : "rgba(255,255,255,0.4)"
                      }}>
                        {isFav ? "FAVORABLE" : isUnfav ? "CHALLENGING" : "NEUTRAL"}
                      </span>
                    </div>
                    <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.3)" }}>{info.season} · {info.months}</p>
                  </div>
                </div>
                <p className="text-xs mb-2" style={{ color: "rgba(255,255,255,0.6)" }}>{info.sports}</p>
                <div className="flex items-start gap-2">
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded shrink-0" style={{ background: `${col}12`, color: col }}>TRAINING</span>
                  <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.45)" }}>{info.training}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── LP OVERLAY ── */}
      {sub === "overlay" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${ORANGE}25` }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: ORANGE }}>GG33 × BaZi Integration</p>
            <p className="text-xs leading-relaxed mb-4" style={{ color: "rgba(255,255,255,0.65)" }}>
              GG33 teaches that Life Path number must be overlaid on the BaZi chart to create a unified cosmic profile. Your LP 1 (Sun/Fire) feeds Earth (your Ox year animal). Fire also drains your Gui Water Day Master — meaning LP 1 creates both gifts and challenges in your BaZi chart.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "LP 1 Gift", value: "Leadership DNA + Sun visibility", why: "Fire = visibility. LP 1 = pioneer. You are meant to be seen.", color: YELLOW },
                { label: "LP 1 Challenge", value: "Fire drains Gui Water DM", why: "Overworking burns through your Water energy. Rest is strategic.", color: ROSE },
                { label: "Ox Amplification", value: "Saturn/8 × Ox = unstoppable discipline", why: "Birthday 8 (Saturn) + Ox endurance = iron will combination.", color: GREEN },
                { label: "Rabbit Day", value: "Speed + agility + social grace", why: "Rabbit is fastest animal. Winger position is your destiny position.", color: BLUE },
              ].map(item => (
                <div key={item.label} className="p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.03)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>{item.label}</p>
                  <p className="text-xs font-bold" style={{ color: item.color }}>{item.value}</p>
                  <p className="text-[9px] mt-1" style={{ color: "rgba(255,255,255,0.4)" }}>{item.why}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: GREEN }}>Soccer Overlay</p>
            <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>{BAZI.sportOverlay}</p>
          </div>

          {/* Chinese number codes × GG33 33 signal */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${PURPLE}20` }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: PURPLE }}>33 Matrix Signals in Your BaZi</p>
            {[
              { signal: "2009", note: "2+0+0+9=11 → 11 = Master Builder year. Born in a master number year." },
              { signal: "Sep 8", note: "9+8=17→8. Birthday = 8. Saturn activation. Career destiny number." },
              { signal: "11:18 AM", note: "11:18 = 1+1+1+8=11. Master 11 birth hour = intuition and spiritual sensitivity." },
              { signal: "Life Path 28/10/1", note: "2+8=10→1. LP in GG33 33 system = 1 (Sun). Pioneer of the new matrix cycle." },
            ].map(s => (
              <div key={s.signal} className="flex items-start gap-3 mb-3">
                <p className="text-lg font-black shrink-0 w-20" style={{ color: PURPLE }}>{s.signal}</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>{s.note}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
