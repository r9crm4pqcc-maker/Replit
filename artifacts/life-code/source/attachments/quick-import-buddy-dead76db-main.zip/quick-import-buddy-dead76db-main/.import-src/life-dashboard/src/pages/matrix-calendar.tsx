import { useParams, Link } from "wouter";
import { Grid3x3, ChevronRight } from "lucide-react";
import { useState, useMemo } from "react";
import { PROFILE } from "@/lib/profile";
import { calcCoreNumbers, calcDateEnergy, calcPersonalDay, reduce } from "@/lib/numerology";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);

const DAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const BLUE  = "hsl(212 95% 65%)";
const YELLOW= "hsl(48 96% 53%)";

const energyColors: Record<number,string> = {
  1:"#f87171",2:"#fb923c",3:"#facc15",4:"#4ade80",5:"#22d3ee",
  6:"#60a5fa",7:"#a78bfa",8:"#c084fc",9:"#f472b6",11:"#e0f2fe",22:"#fde68a",
};

const ENERGY_LABELS: Record<number,string> = {
  1:"Leadership",2:"Cooperation",3:"Creativity",4:"Structure",
  5:"Freedom",6:"Harmony",7:"Wisdom",8:"Power",9:"Completion",
  11:"Illumination",22:"Manifestation",
};

const CHEAT_CODE_MEANINGS: Record<number,{ action:string; avoid:string; lucky:string; remedy:string; gem:string }> = {
  1:{action:"Start new projects, lead, be bold and assertive",avoid:"Hesitation and waiting for others",lucky:"Gold, Red, Orange",remedy:"Begin fast, speak clearly, and take the first step.",gem:"Ruby / Citrine"},
  2:{action:"Collaborate, negotiate, build relationships",avoid:"Confrontation and hasty decisions",lucky:"Silver, White, Cream",remedy:"Pair up, listen first, and stay calm.",gem:"Moonstone / Pearl"},
  3:{action:"Create, communicate, be social and expressive",avoid:"Gossip and scattered energy",lucky:"Purple, Gold",remedy:"Share ideas, create, and keep it light.",gem:"Amethyst / Yellow Sapphire"},
  4:{action:"Plan, organize, work with discipline and focus",avoid:"Shortcuts and cutting corners",lucky:"Blue, Grey",remedy:"Use structure, routines, and lists.",gem:"Sapphire / Emerald"},
  5:{action:"Break routine, travel, try something new",avoid:"Rigid expectations",lucky:"Turquoise, Light Blue",remedy:"Change environment, move, and adapt.",gem:"Aquamarine / Turquoise"},
  6:{action:"Nurture relationships, beautify your environment",avoid:"People-pleasing and neglecting self",lucky:"Royal Blue, Green",remedy:"Heal the space, check in, and restore balance.",gem:"Rose Quartz / Jade"},
  7:{action:"Meditate, study, trust your gut, go inward",avoid:"Major financial or relationship decisions",lucky:"Purple, Indigo",remedy:"Quiet time, reflection, and intuition work.",gem:"Amethyst / Labradorite"},
  8:{action:"Negotiate, close deals, assert power",avoid:"Arrogance and greed",lucky:"Black, Dark Blue, Gold",remedy:"Act like a leader, but stay disciplined.",gem:"Black Onyx / Blue Sapphire"},
  9:{action:"Complete tasks, release the old, be compassionate",avoid:"Clinging to what no longer serves",lucky:"Gold, Deep Red",remedy:"Finish, forgive, and clear space.",gem:"Garnet / Bloodstone"},
  11:{action:"Follow your intuition completely — magic happens today",avoid:"Overthinking and fear",lucky:"White, Silver",remedy:"Trust signs and let insight lead.",gem:"Selenite / Clear Quartz"},
  22:{action:"Take massive action toward your biggest goal",avoid:"Small thinking",lucky:"Gold, Iridescent",remedy:"Build something real and long-term.",gem:"Moldavite / Diamond"},
};

const tabs = [
  { key:"", label:"Calendar", href:"/matrix-calendar" },
  { key:"cheat-codes", label:"Cheat Codes", href:"/matrix-calendar/cheat-codes" },
  { key:"personal", label:"Personal Days", href:"/matrix-calendar/personal" },
];

function CalendarWidget() {
  const today = new Date();
  const [year, setYear]   = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  const monthName = new Date(year, month, 1).toLocaleDateString("en-US", { month:"long", year:"numeric" });

  const days = useMemo(() => Array.from({length:daysInMonth},(_,i)=>{
    const d = i+1;
    const de = calcDateEnergy(month+1, d, year);
    const pd = calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, month+1, d, year);
    return { day:d, de, pd };
  }), [month, year]);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <button onClick={()=>{ if(month===0){setMonth(11);setYear(y=>y-1)}else setMonth(m=>m-1) }}
          className="px-3 py-1.5 rounded-lg text-sm" style={{ color:"rgba(255,255,255,0.5)", border:"1px solid rgba(255,255,255,0.08)" }}>←</button>
        <p className="text-sm font-semibold text-white">{monthName}</p>
        <button onClick={()=>{ if(month===11){setMonth(0);setYear(y=>y+1)}else setMonth(m=>m+1) }}
          className="px-3 py-1.5 rounded-lg text-sm" style={{ color:"rgba(255,255,255,0.5)", border:"1px solid rgba(255,255,255,0.08)" }}>→</button>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-2">
        {DAYS.map(d=><p key={d} className="text-center text-[9px] font-semibold py-1" style={{ color:"rgba(255,255,255,0.3)" }}>{d}</p>)}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {Array.from({length:firstDay}).map((_,i)=><div key={`e${i}`} />)}
        {days.map(({day,de,pd})=>{
          const isToday = day===today.getDate()&&month===today.getMonth()&&year===today.getFullYear();
          const col = energyColors[de.reduced] ?? BLUE;
          const matchesCristian = de.reduced===N.lifePath||de.reduced===N.birthday||de.reduced===N.expression;
          return (
            <div key={day}
              className="aspect-square flex flex-col items-center justify-center rounded-lg text-center cursor-pointer"
              style={{ background:isToday?"hsl(212 60% 35%)":matchesCristian?"rgba(250,204,21,0.08)":"rgba(255,255,255,0.025)",
                border:isToday?"1px solid hsl(212 95% 65%)":matchesCristian?"1px solid rgba(250,204,21,0.2)":"1px solid rgba(255,255,255,0.04)" }}>
              <span className="text-[10px] font-bold leading-none" style={{ color:isToday?"white":col }}>{day}</span>
              <span className="text-[8px] leading-none mt-0.5" style={{ color:"rgba(255,255,255,0.4)" }}>{de.reduced}/{pd.reduced}</span>
            </div>
          );
        })}
      </div>

      <div className="flex items-center gap-4 mt-3 flex-wrap">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded" style={{ background:"rgba(250,204,21,0.2)", border:"1px solid rgba(250,204,21,0.4)" }} />
          <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>Cristian's power numbers ({N.lifePath},{N.birthday},{N.expression})</span>
        </div>
        <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>Format: Universal/Personal</span>
      </div>
    </div>
  );
}

export default function MatrixCalendarPage() {
  const params = useParams<{ sub?:string }>();
  const sub = params.sub ?? "";
  const today = new Date();
  const de = useMemo(() => calcDateEnergy(today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const pd = useMemo(() => calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, today.getMonth()+1, today.getDate(), today.getFullYear()), []);

  // Next 14 days
  const nextDays = useMemo(() => Array.from({length:14},(_,i)=>{
    const d = new Date(today); d.setDate(today.getDate()+i);
    return { date:d, de:calcDateEnergy(d.getMonth()+1,d.getDate(),d.getFullYear()), pd:calcPersonalDay(PROFILE.birthMonth,PROFILE.birthDay,d.getMonth()+1,d.getDate(),d.getFullYear()) };
  }), []);

  const cc = CHEAT_CODE_MEANINGS[de.reduced];

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Grid3x3 size={12} style={{ color:BLUE }} />
          <span>Matrix Calendar</span><ChevronRight size={10} /><span style={{ color:BLUE }}>Live Energy</span>
        </div>
        <h1 className="page-title">Matrix Calendar</h1>
        <p className="page-subtitle">Daily universal energy × Cristian's personal day numbers</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(96,165,250,0.12)", color:BLUE, border:"1px solid rgba(96,165,250,0.2)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {sub==="" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <CalendarWidget />
          </div>

          {/* Today strip */}
          <div className="glass-card p-4 flex items-center gap-4" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="text-center">
              <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Universal</p>
              <p className="text-4xl font-black" style={{ color:energyColors[de.reduced]??BLUE }}>{de.reduced}</p>
            </div>
            <div className="text-center">
              <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Cristian's</p>
              <p className="text-4xl font-black" style={{ color:energyColors[pd.reduced]??YELLOW }}>{pd.reduced}</p>
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">{ENERGY_LABELS[de.reduced]} Day</p>
              <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>
                {today.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})} · Compound {de.compound}
              </p>
            </div>
          </div>
        </div>
      )}

      {sub==="cheat-codes" && (
        <div className="space-y-3">
          {/* Today */}
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:`1px solid ${(energyColors[de.reduced]??BLUE)}40` }}>
            <div className="flex items-center gap-2 mb-3">
              <span className="pill-yellow">TODAY</span>
              <span className="text-xs" style={{ color:"rgba(255,255,255,0.3)" }}>{today.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}</span>
            </div>
            <p className="text-4xl font-black mb-1" style={{ color:energyColors[de.reduced]??BLUE }}>{de.reduced}</p>
            <p className="text-sm font-semibold mb-3" style={{ color:energyColors[de.reduced]??BLUE }}>{ENERGY_LABELS[de.reduced]}</p>
            {cc && (
              <div className="space-y-2">
                <div><p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Action</p><p className="text-xs" style={{ color:"rgba(255,255,255,0.7)" }}>{cc.action}</p></div>
                <div><p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Avoid</p><p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{cc.avoid}</p></div>
                <div><p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Lucky Colors</p><p className="text-xs" style={{ color:YELLOW }}>{cc.lucky}</p></div>
                <div><p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Best Remedy</p><p className="text-xs" style={{ color:GREEN }}>{cc.remedy}</p></div>
                <div><p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Best Gem</p><p className="text-xs" style={{ color:BLUE }}>{cc.gem}</p></div>
              </div>
            )}
          </div>

          {/* Next 14 days */}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>14-Day Cheat Code Schedule</p>
            <div className="space-y-1.5">
              {nextDays.map(({date,de:d,pd:p},i)=>{
                const col=energyColors[d.reduced]??BLUE;
                const cc2=CHEAT_CODE_MEANINGS[d.reduced];
                const isPower = d.reduced===N.lifePath||d.reduced===N.birthday||d.reduced===N.expression;
                return (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-lg"
                    style={{ background:i===0?"rgba(250,204,21,0.07)":isPower?"rgba(96,165,250,0.05)":"rgba(255,255,255,0.02)", border:isPower?`1px solid ${col}25`:"1px solid transparent" }}>
                    <div className="flex items-center gap-2">
                      <div className="text-center w-8">
                        <p className="text-base font-black" style={{ color:col }}>{d.reduced}</p>
                        <p className="text-[8px]" style={{ color:"rgba(255,255,255,0.3)" }}>{p.reduced}</p>
                      </div>
                      <div>
                        <p className="text-xs font-medium" style={{ color:i===0?YELLOW:"rgba(255,255,255,0.6)" }}>
                          {i===0?"Today":date.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}
                          {isPower&&<span className="ml-2 text-[9px] font-bold" style={{ color:YELLOW }}>⚡ POWER</span>}
                        </p>
                        <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.35)" }}>{cc2?.action.slice(0,60)}…</p>
                        <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.35)" }}>{cc2?.gem ?? ""}</p>
                      </div>
                    </div>
                    <span className="text-[9px] shrink-0" style={{ color:col }}>{ENERGY_LABELS[d.reduced]}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {sub==="personal" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>How Personal Day is Calculated</p>
            <p className="text-xs mt-2" style={{ color:"rgba(255,255,255,0.5)" }}>
              Birth month ({PROFILE.birthMonth}) + birth day ({PROFILE.birthDay}) + full digit sum of target date → reduce to single digit or master number.
            </p>
            <p className="text-xs mt-2 font-bold" style={{ color:YELLOW }}>
              Today: {PROFILE.birthMonth} + {PROFILE.birthDay} + dateDigits = {pd.compound} → {pd.reduced}
            </p>
          </div>
          <div className="glass-card overflow-hidden" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="grid grid-cols-5 gap-2 px-4 py-2 text-[9px] uppercase tracking-widest border-b" style={{ color:"rgba(255,255,255,0.3)", borderColor:"rgba(255,255,255,0.06)" }}>
              <span className="col-span-2">Date</span>
              <span className="text-center">Universal</span>
              <span className="text-center">Personal</span>
              <span className="text-center">Alignment</span>
            </div>
            {nextDays.map(({date,de:d,pd:p},i)=>{
              const same = d.reduced===p.reduced;
              const close = Math.abs(d.reduced-p.reduced)<=1;
              const align = same?"⚡ PEAK":close?"✓ FLOW":"Neutral";
              const alignCol = same?YELLOW:close?"#4ade80":"rgba(255,255,255,0.4)";
              return (
                <div key={i} className="grid grid-cols-5 gap-2 px-4 py-2.5 items-center border-b" style={{ borderColor:"rgba(255,255,255,0.04)" }}>
                  <p className="col-span-2 text-xs" style={{ color:i===0?YELLOW:"rgba(255,255,255,0.6)" }}>
                    {i===0?"Today":date.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}
                  </p>
                  <p className="text-center text-sm font-black" style={{ color:energyColors[d.reduced]??BLUE }}>{d.reduced}</p>
                  <p className="text-center text-sm font-black" style={{ color:energyColors[p.reduced]??YELLOW }}>{p.reduced}</p>
                  <p className="text-center text-xs font-bold" style={{ color:alignCol }}>{align}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
