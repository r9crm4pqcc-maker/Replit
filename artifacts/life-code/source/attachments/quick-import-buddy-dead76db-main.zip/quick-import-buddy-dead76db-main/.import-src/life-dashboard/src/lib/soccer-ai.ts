import { reduce, calcDateEnergy, calcPersonalDay, LUCKY_COLORS, digitSum } from "./numerology";
import { PROFILE } from "./profile";

// ── Color maps from the methodology ─────────────────────────────────────────
const ENERGY_COLORS: Record<string, { cleat: string[]; shin: string[]; sock: string[] }> = {
  "1":  { cleat: ["Gold","Yellow","Orange"], shin: ["Red","Orange"], sock: ["Black","Navy"] },
  "8":  { cleat: ["Gold","Yellow","Royal Blue"], shin: ["Black","Dark Blue"], sock: ["Black","Dark Green"] },
  "10": { cleat: ["Gold","Yellow","Orange","Royal Blue"], shin: ["Orange","Gold"], sock: ["Black","Dark Navy"] },
  "28": { cleat: ["Gold","Yellow","Royal Blue"], shin: ["Gold","Orange"], sock: ["Black","Dark Navy"] },
  "6":  { cleat: ["Green","Light Blue"], shin: ["Green","Teal"], sock: ["White","Light Blue"] },
  "42": { cleat: ["Green","Light Blue"], shin: ["Green","Teal"], sock: ["White","Silver"] },
  "7":  { cleat: ["Purple","Indigo"], shin: ["Purple","Violet"], sock: ["Dark Navy","Black"] },
  "16": { cleat: ["Purple","Indigo"], shin: ["Indigo","Dark Blue"], sock: ["Black","Dark Navy"] },
  "9":  { cleat: ["Red","Black"], shin: ["Red","Crimson"], sock: ["Black","Dark Red"] },
  "18": { cleat: ["Red","Black"], shin: ["Red","Black"], sock: ["Black","Charcoal"] },
  "11": { cleat: ["White","Silver"], shin: ["White","Silver"], sock: ["White","Light Grey"] },
  "22": { cleat: ["Iridescent","Gold"], shin: ["White","Gold"], sock: ["Silver","White"] },
  "2":  { cleat: ["Silver","Cream"], shin: ["Silver","Light Blue"], sock: ["White","Silver"] },
  "3":  { cleat: ["Yellow","Gold"], shin: ["Yellow","Orange"], sock: ["White","Gold"] },
  "4":  { cleat: ["Blue","Grey"], shin: ["Navy","Grey"], sock: ["Dark Blue","Black"] },
  "5":  { cleat: ["Turquoise","Light Blue"], shin: ["Turquoise","Cyan"], sock: ["White","Light Blue"] },
};

function getColorConfig(energy: number, compound: number) {
  const key = String(compound) in ENERGY_COLORS ? String(compound)
    : String(energy) in ENERGY_COLORS ? String(energy) : String(energy);
  return ENERGY_COLORS[key] ?? ENERGY_COLORS["1"];
}

const ZODIAC_SIGNS = [
  "Rat", "Ox", "Tiger", "Rabbit", "Dragon", "Snake",
  "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig",
];

const ZODIAC_COMPATIBILITY: Record<string, string[]> = {
  Rat: ["Ox", "Dragon", "Monkey"],
  Ox: ["Rat", "Snake", "Rooster"],
  Tiger: ["Horse", "Dog", "Pig"],
  Rabbit: ["Goat", "Dog", "Pig"],
  Dragon: ["Rat", "Monkey", "Rooster"],
  Snake: ["Ox", "Rooster", "Monkey"],
  Horse: ["Tiger", "Goat", "Dog"],
  Goat: ["Rabbit", "Horse", "Pig"],
  Monkey: ["Rat", "Dragon", "Snake"],
  Rooster: ["Ox", "Dragon", "Snake"],
  Dog: ["Tiger", "Rabbit", "Horse"],
  Pig: ["Tiger", "Rabbit", "Goat"],
};

function getChineseYearCompatibility(birthYear: number, gameYear: number) {
  const birthSign = ZODIAC_SIGNS[(birthYear - 4) % 12];
  const yearSign = ZODIAC_SIGNS[(gameYear - 4) % 12];
  const isSame = birthSign === yearSign;
  const compatible = ZODIAC_COMPATIBILITY[birthSign]?.includes(yearSign) ?? false;
  const score = isSame ? 95 : compatible ? 82 : 58;
  const label = isSame ? "Same Zodiac" : compatible ? "Compatible Zodiac" : "Challenging Zodiac";
  return { birthSign, yearSign, score, label };
}

export interface SoccerGameDay {
  gameDate: string;
  universalEnergy: number;
  universalCompound: number;
  universalLabel: string;
  personalDay: number;
  personalDayCompound: number;
  compatibility: number;
  compatLabel: string;
  compatDesc: string;
  cleatColors: string[];
  shinColors: string[];
  sockColors: string[];
  bestNumbers: number[];
  bestNumberReasons: string[];
  jerseyRecommendation: number;
  jerseyReason: string;
  sockType: "grip" | "regular";
  sockHeight: "low" | "mid" | "high" | "otk";
  jerseyTuck: "tucked" | "untucked";
  gearFormula: string;
  rankedNumbers: { number: number; score: number; label: string; reason: string }[];
  colorHarmonizedWith: number[];
}

function reduceToNine(n: number) {
  return n <= 9 ? n : n % 9 || 9;
}

function scoreNumber(n: number, de: number, pd: number, lifePath: number, birthdayNum: number) {
  const targets = [lifePath, birthdayNum, de, pd, 10, 28, 8, 1, 9];
  let score = 0;
  if (n === 10) score += 100;
  if (n === 28) score += 96;
  if (n === lifePath) score += 90;
  if (n === birthdayNum) score += 88;
  if (n === de) score += 84;
  if (n === pd) score += 82;
  if (n === reduce(digitSum(lifePath + birthdayNum + pd))) score += 14;
  if (n === reduce(digitSum(pd + de))) score += 10;
  if (n === 8 && lifePath === 1) score += 12;
  if (n === 1 && pd === 1) score += 10;
  if (n === 9 && pd === 9) score += 12;
  score += Math.max(0, 60 - targets.indexOf(n) * 5);
  return score;
}

export function calcGameDay(
  gameMonth: number, gameDay: number, gameYear: number,
  lifePath: number, birthdayNum: number,
): SoccerGameDay {
  const de = calcDateEnergy(gameMonth, gameDay, gameYear);
  const personalYear = reduce(digitSum(PROFILE.birthMonth) + digitSum(PROFILE.birthDay) + digitSum(gameYear));
  const zodiac = getChineseYearCompatibility(PROFILE.birthYear, gameYear);
  const pd = calcPersonalDay(
    PROFILE.birthMonth, PROFILE.birthDay,
    gameMonth, gameDay, gameYear
  );

  // Compatibility %
  const diff = Math.abs(de.reduced - pd.reduced);
  const exactMatch = de.reduced === pd.reduced;
  const compoundHarmony = de.compound === pd.compound;
  let compat: number;
  if (exactMatch || compoundHarmony) compat = 90 + Math.min(9, de.compound % 5);
  else if (diff <= 1) compat = 80 + (5 - diff) * 2;
  else if (diff <= 2) compat = 70 - diff * 2;
  else if (diff <= 3) compat = 60 - diff * 3;
  else compat = Math.max(30, 55 - diff * 5);

  const compatLabel = compat >= 85 ? "Strong Flow"
    : compat >= 65 ? "Good Energy"
    : compat >= 40 ? "Neutral"
    : "Tension";
  const compatDesc = `${compat}% — ${de.compound}/${de.reduced} date energy ${
    exactMatch ? "exactly matches" : "flows with"} your personal ${pd.compound}/${pd.reduced}`;

  // Ranked numbers (compute early so colors can reference top 3)
  const rankedNumbers = [10, 28, lifePath, birthdayNum, de.reduced, pd.reduced, personalYear, 8, 1, 9, 11, 22]
    .filter((n, i, a) => a.indexOf(n) === i)
    .map(n => ({
      number: n,
      score: scoreNumber(n, de.reduced, pd.reduced, lifePath, birthdayNum) + (n === personalYear ? 86 : 0) + (n === zodiac.score ? 0 : 0),
      label: n === 10 ? "Primary" : n === 28 ? "Compound" : n === lifePath ? "Life Path" : n === birthdayNum ? "Birthday" : n === de.reduced ? "Universal" : n === pd.reduced ? "Personal Day" : n === personalYear ? "Personal Year" : n === 8 ? "Power" : n === 1 ? "Leader" : n === 9 ? "Completion" : n === 11 ? "Master 11" : "Master 22",
      reason: n === 10 ? "Strongest current jersey portal" : n === 28 ? "Life Path compound portal" : n === lifePath ? "Core identity number" : n === birthdayNum ? "Birthday gift" : n === de.reduced ? "Today's universal energy" : n === pd.reduced ? "Today's personal energy" : n === personalYear ? "Your current year cycle" : n === 8 ? "Authority and power" : n === 1 ? "Initiation and leadership" : n === 9 ? "Completion and harvest" : n === 11 ? "Intuition portal" : "Builder portal",
    }))
    .sort((a, b) => b.score - a.score);

  const top3Numbers = rankedNumbers.slice(0, 3).map(r => r.number);

  // Colors — harmonized with date energy AND top 3 jersey numbers
  const baseColors = getColorConfig(de.reduced, de.compound);
  const top3ColorSets = top3Numbers.map(n => {
    const r = n > 9 && !(n === 10 || n === 11 || n === 22 || n === 28) ? reduceToNine(n) : n;
    return getColorConfig(r, n);
  });

  function pickBestColor(slot: "cleat" | "shin" | "sock", base: string[]): string[] {
    const allCandidates = new Map<string, number>();
    base.forEach((c, i) => allCandidates.set(c, (allCandidates.get(c) ?? 0) + (i === 0 ? 10 : 5)));
    top3ColorSets.forEach((cs, rank) => {
      const weight = rank === 0 ? 8 : rank === 1 ? 5 : 3;
      cs[slot].forEach((c, i) => allCandidates.set(c, (allCandidates.get(c) ?? 0) + (i === 0 ? weight : Math.ceil(weight / 2))));
    });
    const sorted = [...allCandidates.entries()].sort((a, b) => b[1] - a[1]);
    const result = sorted.map(s => s[0]);
    return result.length >= 2 ? result.slice(0, 2) : [...result, ...base.slice(0, 2 - result.length)];
  }

  const colors = {
    cleat: pickBestColor("cleat", baseColors.cleat),
    shin: pickBestColor("shin", baseColors.shin),
    sock: pickBestColor("sock", baseColors.sock),
  };

  // Best numbers
  const bestNums = [...new Set([lifePath, birthdayNum, de.reduced, pd.reduced, personalYear, de.compound])].slice(0, 5);
  const bestReasons = [
    `${lifePath} — your Life Path power number`,
    `${birthdayNum} — your Birthday Number gift`,
    `${de.reduced} — today's universal energy`,
    `${personalYear} — your Personal Year cycle`,
    `${de.compound} — compound activation`,
    `${zodiac.birthSign} ↔ ${zodiac.yearSign} — ${zodiac.label}`,
  ];

  // Jersey recommendation
  const jersey = lifePath === 1 ? 10 : lifePath === 8 ? 8 : lifePath === 3 ? 3 : lifePath * 10 <= 99 ? lifePath * 10 : lifePath;
  const jerseyReason = `#${jersey} carries your Life Path ${lifePath} compound energy — activates your wealth/power portal`;
  const fusion = reduceToNine(de.reduced + pd.reduced + lifePath + birthdayNum);
  const sockType = fusion <= 4 || lifePath === 1 || birthdayNum === 8 ? "grip" : "regular";
  const sockHeight = fusion <= 3 ? "low" : fusion <= 6 ? "mid" : fusion <= 8 ? "high" : "otk";
  const jerseyTuck = [1, 4, 8, 10, 22].includes(jersey) || de.reduced >= 8 ? "tucked" : "untucked";
  const gearFormula = `Fusion ${fusion} = reduce(${de.reduced}+${pd.reduced}+${lifePath}+${birthdayNum}) → ${sockType}, ${sockHeight}, ${jerseyTuck}`;

  const gameDate = `${String(gameMonth).padStart(2,"0")}/${String(gameDay).padStart(2,"0")}/${gameYear}`;

  return {
    gameDate,
    universalEnergy: de.reduced,
    universalCompound: de.compound,
    universalLabel: de.label,
    personalDay: pd.reduced,
    personalDayCompound: pd.compound,
    compatibility: compat,
    compatLabel,
    compatDesc,
    cleatColors: colors.cleat,
    shinColors: colors.shin,
    sockColors: colors.sock,
    bestNumbers: bestNums,
    bestNumberReasons: bestReasons,
    jerseyRecommendation: jersey,
    jerseyReason,
    sockType,
    sockHeight,
    jerseyTuck,
    gearFormula,
    rankedNumbers,
    colorHarmonizedWith: top3Numbers,
  };
}

// ── Training plan ────────────────────────────────────────────────────────────
export function getWeeklyPlan(personalYear: number, lifePath: number) {
  const energy = personalYear;
  const focus = energy <= 3 ? "Speed & Creativity" : energy <= 6 ? "Tactical & Teamwork" : "Power & Finishing";
  return {
    focus,
    mon: { type: "Technical", desc: "Ball mastery — 500 touches, first touch control, weak foot work" },
    tue: { type: "Speed & Agility", desc: "Shuttle runs, ladder drills, explosive start bursts" },
    wed: { type: "Tactical", desc: "Video review + position-specific movement patterns (winger runs)" },
    thu: { type: "Strength", desc: "Gym — legs (squats, lunges), core stability, rotational power" },
    fri: { type: "Match Prep", desc: "Light training, mental visualization, gear selection ritual" },
    sat: { type: "MATCH DAY", desc: "Check game day energy, cleat colors, jersey number before kickoff" },
    sun: { type: "Recovery", desc: "Active recovery — walk, stretch, foam roll. Reflect on your numbers" },
  };
}

// ── Diet plan ────────────────────────────────────────────────────────────────
export const DIET_PLAN = {
  preMatch: [
    "3–4 hrs before: Complex carbs — pasta, rice, sweet potato",
    "1–2 hrs before: Banana + peanut butter (fast energy)",
    "30 min before: Small handful of dates (natural sugar spike)",
  ],
  hydration: [
    "Morning: 16–20 oz water immediately on waking",
    "Training: 8 oz every 20 min",
    "Post-match: Electrolyte drink + 24 oz water within 30 min",
  ],
  recovery: [
    "Within 30 min post-match: Protein shake + fruit",
    "Dinner: Lean protein (chicken, fish), rice, vegetables",
    "Before bed: Casein protein or cottage cheese",
  ],
  luckyFoods: ["Dates (energy portal food — 28/10 vibration)", "Bananas (3 energy — creative power)", "Almonds (grounding — 4 vibration)"],
};
