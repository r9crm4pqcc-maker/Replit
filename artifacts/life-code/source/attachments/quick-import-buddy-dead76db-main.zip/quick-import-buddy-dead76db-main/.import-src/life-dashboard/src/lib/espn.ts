// Pythagorean numerology: A=1, B=2 ... Z=8 (9 letters per value, cycling)
const PYTHAGOREAN: Record<string, number> = {
  A: 1, B: 2, C: 3, D: 4, E: 5, F: 6, G: 7, H: 8, I: 9,
  J: 1, K: 2, L: 3, M: 4, N: 5, O: 6, P: 7, Q: 8, R: 9,
  S: 1, T: 2, U: 3, V: 4, W: 5, X: 6, Y: 7, Z: 8,
};

export const NUM_LABELS: Record<number, string> = {
  1: "The Leader", 2: "The Partner", 3: "The Creator",
  4: "The Builder", 5: "The Explorer", 6: "The Nurturer",
  7: "The Seeker", 8: "The Achiever", 9: "The Humanitarian",
  11: "The Visionary", 22: "The Master Builder", 33: "The Master Teacher",
};

// Element by numerological number
export const NUM_ELEMENT: Record<number, string> = {
  1: "Fire", 2: "Water", 3: "Air", 4: "Earth",
  5: "Fire", 6: "Air", 7: "Water", 8: "Earth",
  9: "Fire", 11: "Air", 22: "Earth", 33: "Fire",
};

// Reduce a number to a single digit, preserving master numbers 11, 22, 33
export function reduce(n: number): number {
  if (n === 11 || n === 22 || n === 33) return n;
  if (n < 10) return n;
  const sum = String(n).split("").reduce((a, c) => a + Number(c), 0);
  return reduce(sum);
}

export function isMasterNumber(n: number): boolean {
  return n === 11 || n === 22 || n === 33;
}

export function is369(n: number): boolean {
  return n === 3 || n === 6 || n === 9;
}

// Calculate the numerological value of a team name
export function nameValue(name: string): number {
  const letters = name.toUpperCase().replace(/[^A-Z]/g, "").split("");
  const raw = letters.reduce((acc, ch) => acc + (PYTHAGOREAN[ch] ?? 0), 0);
  return reduce(raw);
}

// Sun sign from month/day
export function getSunSign(month: number, day: number): { sign: string; element: string } {
  const table: { sign: string; element: string; m: number; d: number }[] = [
    { sign: "Capricorn", element: "Earth", m: 12, d: 22 },
    { sign: "Aquarius", element: "Air",   m: 1,  d: 20 },
    { sign: "Pisces",   element: "Water", m: 2,  d: 19 },
    { sign: "Aries",    element: "Fire",  m: 3,  d: 21 },
    { sign: "Taurus",   element: "Earth", m: 4,  d: 20 },
    { sign: "Gemini",   element: "Air",   m: 5,  d: 21 },
    { sign: "Cancer",   element: "Water", m: 6,  d: 21 },
    { sign: "Leo",      element: "Fire",  m: 7,  d: 23 },
    { sign: "Virgo",    element: "Earth", m: 8,  d: 23 },
    { sign: "Libra",    element: "Air",   m: 9,  d: 23 },
    { sign: "Scorpio",  element: "Water", m: 10, d: 23 },
    { sign: "Sagittarius", element: "Fire", m: 11, d: 22 },
  ];
  for (let i = table.length - 1; i >= 0; i--) {
    const row = table[i];
    if (month === row.m && day >= row.d) return { sign: row.sign, element: row.element };
    if (month === row.m + 1 && day < row.d) {
      // belongs to previous sign
    }
  }
  for (const row of table) {
    if (month === row.m && day >= row.d) return { sign: row.sign, element: row.element };
  }
  const prev = (i: number) => table[(i - 1 + table.length) % table.length];
  for (let i = 0; i < table.length; i++) {
    const row = table[i];
    if (month === row.m && day < row.d) return { sign: prev(i).sign, element: prev(i).element };
  }
  return { sign: "Capricorn", element: "Earth" };
}

// Moon phase calculation using Jan 6 2000 new moon reference
export function getMoonPhase(year: number, month: number, day: number): { phase: string; waxing: boolean } {
  const refNewMoon = new Date(2000, 0, 6).getTime();
  const target = new Date(year, month - 1, day).getTime();
  const diffDays = (target - refNewMoon) / 86400000;
  const cycle = ((diffDays % 29.53059) + 29.53059) % 29.53059;
  const waxing = cycle < 14.765;
  let phase: string;
  if (cycle < 1.85) phase = "New Moon";
  else if (cycle < 7.38) phase = "Waxing Crescent";
  else if (cycle < 9.22) phase = "First Quarter";
  else if (cycle < 14.77) phase = "Waxing Gibbous";
  else if (cycle < 16.61) phase = "Full Moon";
  else if (cycle < 22.15) phase = "Waning Gibbous";
  else if (cycle < 23.99) phase = "Last Quarter";
  else phase = "Waning Crescent";
  return { phase, waxing };
}

// Mercury retrograde windows (2024-2027)
const RETRO: { start: Date; end: Date }[] = [
  { start: new Date(2024, 3, 1),  end: new Date(2024, 3, 25) },
  { start: new Date(2024, 7, 5),  end: new Date(2024, 7, 28) },
  { start: new Date(2024, 10, 26), end: new Date(2024, 11, 15) },
  { start: new Date(2025, 2, 15), end: new Date(2025, 3, 7) },
  { start: new Date(2025, 6, 18), end: new Date(2025, 7, 11) },
  { start: new Date(2025, 10, 9), end: new Date(2025, 10, 29) },
  { start: new Date(2026, 2, 2),  end: new Date(2026, 2, 25) },
  { start: new Date(2026, 5, 26), end: new Date(2026, 6, 20) },
  { start: new Date(2026, 9, 13), end: new Date(2026, 10, 2) },
];

export function isMercuryRetrograde(year: number, month: number, day: number): boolean {
  const d = new Date(year, month - 1, day);
  return RETRO.some(p => d >= p.start && d <= p.end);
}

// Day of week and its planetary ruler
export function getDayInfo(year: number, month: number, day: number): { dayOfWeek: string; dayRuler: string; rulerNumbers: number[] } {
  const date = new Date(year, month - 1, day);
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const rulers = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"];
  const rulerNums: number[][] = [
    [1, 9],    // Sun
    [2, 7],    // Moon
    [1, 5, 9], // Mars
    [3, 5],    // Mercury
    [3, 6, 9], // Jupiter
    [2, 6],    // Venus
    [4, 8],    // Saturn
  ];
  const dow = date.getDay();
  return { dayOfWeek: days[dow], dayRuler: rulers[dow], rulerNumbers: rulerNums[dow] };
}

export interface DateEnergyResult {
  reduced: number;
  compound: number;
  digits: number[];
  label: string;
  isMaster: boolean;
  monthNumber: number;
  dayReduced: number;
  is369: boolean;
  pairs: string[];
}

export function calcDateEnergy(month: number, day: number, year: number): DateEnergyResult {
  const yearDigits = String(year).split("").map(Number);
  const dayDigits = String(day).split("").map(Number);
  const digits = [month, ...dayDigits, ...yearDigits];
  const compound = digits.reduce((a, b) => a + b, 0);
  const reduced = reduce(compound);
  const dayReduced = reduce(day);
  const monthNumber = reduce(month);
  const masterInCompound = isMasterNumber(compound);
  const pairs = [
    `${month}+${day}=${month + day}`,
    `${reduce(month + day)}+${reduce(year)}=${reduce(reduce(month + day) + reduce(year))}`,
  ];
  return {
    reduced, compound, digits,
    label: NUM_LABELS[reduced] ?? "Unknown",
    isMaster: isMasterNumber(reduced) || masterInCompound,
    monthNumber, dayReduced,
    is369: is369(reduced),
    pairs,
  };
}

// Compute harmony score for a team against the date (0-100)
export function calcTeamHarmony(
  teamName: string,
  dateResult: DateEnergyResult,
  isHome: boolean,
  moonWaxing: boolean,
  rulerNumbers: number[],
  mercuryRetro: boolean,
  opponentName: string,
  isUnderdog: boolean,
): {
  imprint: number; score: number;
  harmony: "CHEAT CODE" | "STRONG CODE" | "LEAN" | "FADE";
  teamNameValue: number; oppNameValue: number;
  combinedCode: number; teamVsOppDiff: number; oddsType: string;
} {
  const teamNameValue = nameValue(teamName);
  const oppNameValue = nameValue(opponentName);
  const combinedCode = reduce(teamNameValue + oppNameValue);
  const teamVsOppDiff = Math.abs(teamNameValue - oppNameValue);
  const dateEnergy = dateResult.reduced;
  const dateElement = NUM_ELEMENT[dateEnergy] ?? "Fire";
  const teamElement = NUM_ELEMENT[teamNameValue] ?? "Fire";

  let score = 0;

  // 1. Name value alignment with date energy (0-35 pts)
  const diff = Math.abs(teamNameValue - dateEnergy);
  if (diff === 0) score += 35;
  else if (diff === 1) score += 28;
  else if (diff === 2) score += 20;
  else if (diff === 3) score += 12;
  else score += 5;

  // 2. 3-6-9 family bonus (0-15 pts)
  if (is369(teamNameValue) && is369(dateEnergy)) score += 15;
  else if (is369(teamNameValue) || is369(dateEnergy)) score += 7;

  // 3. Master number bonus (0-10 pts)
  if (isMasterNumber(teamNameValue) || dateResult.isMaster) score += 10;

  // 4. Combined code alignment (0-8 pts)
  if (combinedCode === dateEnergy) score += 8;
  else if (is369(combinedCode)) score += 4;

  // 5. Element alignment (0-10 pts)
  if (teamElement === dateElement) score += 10;

  // 6. Moon phase (0-5 pts)
  if (isHome && moonWaxing) score += 5;
  if (!isHome && !moonWaxing) score += 3;

  // 7. Day ruler alignment (0-8 pts)
  if (rulerNumbers.includes(teamNameValue)) score += 8;
  else if (rulerNumbers.includes(reduce(teamNameValue + dateEnergy))) score += 4;

  // 8. Mercury retrograde — underdog boost (0-8 pts)
  if (mercuryRetro && isUnderdog) score += 8;

  // 9. Team vs Opp diff bonus
  if (teamVsOppDiff > oppNameValue) score += 4;

  score = Math.min(100, Math.max(0, score));

  let harmony: "CHEAT CODE" | "STRONG CODE" | "LEAN" | "FADE";
  if (score >= 80) harmony = "CHEAT CODE";
  else if (score >= 65) harmony = "STRONG CODE";
  else if (score >= 50) harmony = "LEAN";
  else harmony = "FADE";

  return {
    imprint: teamNameValue, score, harmony,
    teamNameValue, oppNameValue, combinedCode, teamVsOppDiff,
    oddsType: isUnderdog ? "Underdog" : "Favorite",
  };
}