import { useState, useMemo } from "react";
import { TrendingUp, ChevronDown } from "lucide-react";
import { TRADING_ENTITIES, calcBattlefield, calcWeekBattlefield, type TradingEntity } from "@/lib/trading-ai";

const BLUE  = "hsl(212 95% 65%)";
const YELLOW= "hsl(48 96% 53%)";
const GREEN = "#4ade80";
const RED   = "#f87171";

const SIGNAL_COLORS = { RALLY:GREEN, NEUTRAL:YELLOW, FADE:RED };
const SIGNAL_BG = { RALLY:"rgba(74,222,128,0.1)", NEUTRAL:"rgba(250,204,21,0.1)", FADE:"rgba(248,113,113,0.1)" };
const SIGNAL_BORDER = { RALLY:"rgba(74,222,128,0.25)", NEUTRAL:"rgba(250,204,21,0.2)", FADE:"rgba(248,113,113,0.25)" };

const cats = ["All","index","etf","stock","crypto"] as const;

function reduceNum(n:number):number { let r=n; while(r>9&&r!==11&&r!==22&&r!==33) r=[...String(r)].reduce((a,d)=>a+(+d),0); return r; }
function dateEnergy(m:number,d:number,y:number):number { return reduceNum(m+d+[...String(y)].reduce((a,c)=>a+(+c),0)); }

export default function TradingAIPage() {
  const today = new Date();
  const [selSymbol, setSelSymbol] = useState("SPX");
  const [cat, setCat] = useState<typeof cats[number]>("All");
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [view, setView] = useState<"day"|"week"|"month"|"method">("day");

  const filtered = useMemo(() =>
    TRADING_ENTITIES.filter(e => cat==="All" || e.category===cat), [cat]);

  const entity = TRADING_ENTITIES.find(e => e.symbol===selSymbol) ?? TRADING_ENTITIES[0];

  const dayResult = useMemo(() =>
    calcBattlefield(entity, today.getMonth()+1, today.getDate(), today.getFullYear()),
    [entity, selSymbol]);

  const weekStart = new Date(today);
  weekStart.setDate(today.getDate() - today.getDay()); // Monday of current week
  const weekResults = useMemo(() => calcWeekBattlefield(entity, weekStart), [entity, selSymbol]);

  const sig = dayResult.signal;

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp size={13} style={{ color:YELLOW }} />
          <span className="text-xs" style={{ color:"rgba(255,255,255,0.3)" }}>Trading AI · Battlefield Mode</span>
        </div>
        <h1 className="page-title">Trading AI</h1>
        <p className="page-subtitle">Wealth Code Signals — Entity imprint × Daily date energy</p>
      </div>

      {/* Category filter */}
      <div className="flex gap-1.5 flex-wrap">
        {cats.map(c => (
          <button key={c} onClick={()=>setCat(c)} className="px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all"
            style={cat===c
              ? { background:"rgba(250,204,21,0.12)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
              : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
            {c}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Entity picker */}
        <div className="glass-card p-3 overflow-y-auto" style={{ background:"hsl(228 28% 7%)", maxHeight:"420px" }}>
          <p className="text-[10px] uppercase tracking-widest mb-3 sticky top-0" style={{ color:"rgba(255,255,255,0.3)", background:"hsl(228 28% 7%)" }}>
            Select Entity ({filtered.length})
          </p>
          <div className="space-y-0.5">
            {filtered.map(e => {
              const r = calcBattlefield(e, today.getMonth()+1, today.getDate(), today.getFullYear());
              return (
                <button key={e.symbol} onClick={()=>setSelSymbol(e.symbol)}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-left"
                  style={selSymbol===e.symbol
                    ? { background:"rgba(96,165,250,0.12)", border:"1px solid rgba(96,165,250,0.2)" }
                    : { border:"1px solid transparent" }}>
                  <div>
                    <p className="text-xs font-bold" style={{ color:"rgba(255,255,255,0.9)" }}>{e.symbol}</p>
                    <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{e.name}</p>
                  </div>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded" style={{ background:SIGNAL_BG[r.signal], color:SIGNAL_COLORS[r.signal], border:`1px solid ${SIGNAL_BORDER[r.signal]}` }}>
                    {r.tag}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main panel */}
        <div className="lg:col-span-2 space-y-4">
          {/* Signal card */}
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:`1px solid ${SIGNAL_BORDER[sig]}` }}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>
                  {entity.symbol} · {entity.name}
                </p>
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-black px-3 py-1 rounded-lg" style={{ background:SIGNAL_BG[sig], color:SIGNAL_COLORS[sig], border:`1px solid ${SIGNAL_BORDER[sig]}` }}>
                    {dayResult.tag}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.3)" }}>{today.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</p>
                {dayResult.isMaster11 && <span className="pill-yellow">M11 Active</span>}
                {dayResult.isMaster22 && <span className="pill-yellow">M22 Active</span>}
              </div>
            </div>

            {/* Red vs Green bars */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3 rounded-lg text-center" style={{ background:"rgba(248,113,113,0.08)", border:"1px solid rgba(248,113,113,0.2)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(248,113,113,0.7)" }}>▼ Lower Layer (Red)</p>
                <p className="text-3xl font-black" style={{ color:RED }}>{dayResult.redCompound}</p>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.3)" }}>→ {dayResult.redLayer}</p>
              </div>
              <div className="p-3 rounded-lg text-center" style={{ background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(74,222,128,0.7)" }}>▲ Higher Layer (Green)</p>
                <p className="text-3xl font-black" style={{ color:GREEN }}>{dayResult.greenCompound}</p>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.3)" }}>→ {dayResult.greenLayer}</p>
              </div>
            </div>

            {/* Timing */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Entry Window</p>
                <p className="text-sm font-semibold" style={{ color:GREEN }}>{dayResult.entryWindow}</p>
              </div>
              <div>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Exit Window</p>
                <p className="text-sm font-semibold" style={{ color:YELLOW }}>{dayResult.exitWindow}</p>
              </div>
            </div>

            {/* Imprint */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Entity Imprint ({entity.anchorDate})</p>
                <p className="text-sm font-bold" style={{ color:BLUE }}>
                  {dayResult.entityImprint.fullSum} → {dayResult.entityImprint.compound} → {dayResult.entityImprint.reduced}
                </p>
              </div>
              <button onClick={()=>setShowBreakdown(b=>!b)} className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg transition-all"
                style={{ color:BLUE, background:"rgba(96,165,250,0.08)", border:"1px solid rgba(96,165,250,0.15)" }}>
                Breakdown <ChevronDown size={12} style={{ transform:showBreakdown?"rotate(180deg)":"none" }} />
              </button>
            </div>

            {showBreakdown && (
              <div className="mt-3 p-3 rounded-lg text-xs font-mono whitespace-pre-wrap leading-relaxed"
                style={{ background:"rgba(0,0,0,0.3)", color:"rgba(255,255,255,0.5)" }}>
                {dayResult.breakdown}
              </div>
            )}
          </div>

          {/* View toggle */}
          <div className="flex gap-1.5 flex-wrap">
            {([["day","Day Trading"],["week","Swing (Week)"],["month","Monthly Best Dates"],["method","Your Trading Style"]] as const).map(([v,label]) => (
              <button key={v} onClick={()=>setView(v as any)} className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                style={view===v
                  ? { background:"rgba(96,165,250,0.12)", color:BLUE, border:"1px solid rgba(96,165,250,0.2)" }
                  : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
                {label}
              </button>
            ))}
          </div>

          {/* Week view */}
          {view==="week" && (
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Weekly Battlefield — {entity.symbol}</p>
              <div className="space-y-2">
                {weekResults.map((r,i) => {
                  const dayName = new Date(weekStart.getTime()+i*86400000).toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"});
                  return (
                    <div key={i} className="flex items-center justify-between p-2.5 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                      <p className="text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>{dayName}</p>
                      <div className="flex items-center gap-3">
                        <span className="text-xs" style={{ color:RED }}>▼ {r.redCompound}/{r.redLayer}</span>
                        <span className="text-xs" style={{ color:GREEN }}>▲ {r.greenCompound}/{r.greenLayer}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded" style={{ background:SIGNAL_BG[r.signal], color:SIGNAL_COLORS[r.signal] }}>{r.tag}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Monthly Best Dates */}
          {view==="month" && (() => {
            const m = today.getMonth()+1;
            const y = today.getFullYear();
            const daysInMonth = new Date(y,m,0).getDate();
            const monthDays = Array.from({length:daysInMonth},(_,i)=>{
              const d = i+1;
              const r = calcBattlefield(entity, m, d, y);
              return { day:d, ...r };
            });
            const signalRank = (s:string)=> s==="RALLY"?2:s==="NEUTRAL"?1:0;
            const best = [...monthDays].sort((a,b)=>signalRank(b.signal)-signalRank(a.signal)||b.greenCompound-a.greenCompound).slice(0,5);
            const worst = [...monthDays].sort((a,b)=>signalRank(a.signal)-signalRank(b.signal)||a.greenCompound-b.greenCompound).slice(0,3);
            const turnScore = Math.round(monthDays.reduce((s,d)=> s + (d.signal==="RALLY"?1:d.signal==="FADE"?-1:0),0) / daysInMonth * 100 + 50);
            return (
              <div className="space-y-4">
                <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(96,165,250,0.15)" }}>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Market Turn Score — {entity.symbol}</p>
                      <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{new Date(y,m-1).toLocaleDateString("en-US",{month:"long",year:"numeric"})}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-4xl font-black" style={{ color: turnScore >= 60 ? GREEN : turnScore >= 40 ? YELLOW : RED }}>{turnScore}</p>
                      <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>/ 100</p>
                    </div>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden" style={{ background:"rgba(255,255,255,0.06)" }}>
                    <div className="h-full rounded-full" style={{ width:`${turnScore}%`, background: turnScore>=60?GREEN:turnScore>=40?YELLOW:RED }} />
                  </div>
                  <p className="text-[9px] mt-2" style={{ color:"rgba(255,255,255,0.3)" }}>{turnScore>=65?"Strong rally month expected":turnScore>=50?"Neutral — selective entries":"Bearish month — favor shorts or cash"}</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                    <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Top 5 Trading Days</p>
                    {best.map((d,i)=>(
                      <div key={d.day} className="flex items-center justify-between p-2 rounded-lg mb-1" style={{ background:"rgba(74,222,128,0.04)" }}>
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black" style={{ background:"rgba(74,222,128,0.15)", color:GREEN }}>{i+1}</span>
                          <p className="text-xs font-semibold text-white">{new Date(y,m-1,d.day).toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}</p>
                        </div>
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded" style={{ background:SIGNAL_BG[d.signal], color:SIGNAL_COLORS[d.signal] }}>{d.tag}</span>
                      </div>
                    ))}
                  </div>
                  <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                    <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:RED }}>Worst 3 Days — Avoid</p>
                    {worst.map((d,i)=>(
                      <div key={d.day} className="flex items-center justify-between p-2 rounded-lg mb-1" style={{ background:"rgba(248,113,113,0.04)" }}>
                        <p className="text-xs font-semibold text-white">{new Date(y,m-1,d.day).toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}</p>
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded" style={{ background:SIGNAL_BG[d.signal], color:SIGNAL_COLORS[d.signal] }}>{d.tag}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                  <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Full Month Calendar</p>
                  <div className="grid grid-cols-7 gap-1">
                    {["Su","Mo","Tu","We","Th","Fr","Sa"].map(d=>(
                      <div key={d} className="text-center text-[8px] font-semibold py-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>{d}</div>
                    ))}
                    {Array.from({length:new Date(y,m-1,1).getDay()},(_,i)=><div key={`p${i}`}/>)}
                    {monthDays.map(d=>(
                      <div key={d.day} className="p-1 rounded text-center" style={{ background:`${SIGNAL_COLORS[d.signal]}08` }}>
                        <p className="text-[10px] font-bold" style={{ color: d.day===today.getDate()?"white":"rgba(255,255,255,0.6)" }}>{d.day}</p>
                        <div className="w-1.5 h-1.5 rounded-full mx-auto mt-0.5" style={{ background:SIGNAL_COLORS[d.signal] }} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Trading Method Assignment */}
          {view==="method" && (
            <div className="space-y-4">
              <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
                <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:YELLOW }}>Your Numerology Trading Profile</p>
                <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>Based on LP 1 (Leadership) · Expression 3 (Creative) · Birthday 8 (Saturn/Authority) · PY 9 (Completion)</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-4 rounded-xl" style={{ background:"rgba(250,204,21,0.06)", border:"1px solid rgba(250,204,21,0.15)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:YELLOW }}>Primary Method</p>
                    <p className="text-lg font-black text-white">Momentum / Breakout Trading</p>
                    <p className="text-xs mt-2" style={{ color:"rgba(255,255,255,0.5)" }}>
                      LP 1 = leader energy. You thrive catching moves early, not waiting for confirmation. Breakout entries on high volume suit your decisive nature.
                    </p>
                  </div>
                  <div className="p-4 rounded-xl" style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.15)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:BLUE }}>Secondary Method</p>
                    <p className="text-lg font-black text-white">Swing Trading (3-7 days)</p>
                    <p className="text-xs mt-2" style={{ color:"rgba(255,255,255,0.5)" }}>
                      Expression 3 = creative patience. You see patterns others miss. Hold swings for 3-7 days letting your creative vision play out.
                    </p>
                  </div>
                </div>
              </div>
              <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Strengths</p>
                {[
                  { trait:"Decisive Entries", detail:"LP1 makes quick decisions. Your edge: entering before the crowd.", icon:"⚡" },
                  { trait:"Pattern Recognition", detail:"Expression 3 sees creative setups — unusual chart patterns.", icon:"👁️" },
                  { trait:"Authority Under Pressure", detail:"Birthday 8 (Saturn) = steady hands during volatility.", icon:"🪨" },
                  { trait:"Exit Discipline", detail:"PY9 completion energy means you know when to close positions.", icon:"🎯" },
                ].map(s=>(
                  <div key={s.trait} className="flex items-start gap-3 p-3 rounded-lg mb-2" style={{ background:"rgba(74,222,128,0.04)" }}>
                    <span className="text-lg">{s.icon}</span>
                    <div><p className="text-sm font-semibold text-white">{s.trait}</p><p className="text-xs mt-0.5" style={{ color:"rgba(255,255,255,0.4)" }}>{s.detail}</p></div>
                  </div>
                ))}
              </div>
              <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:RED }}>Weaknesses to Watch</p>
                {[
                  { trait:"Overtrading", detail:"LP1 impatience can lead to revenge trading after losses. Set daily trade limits.", icon:"⚠️" },
                  { trait:"Ignoring Stops", detail:"Birthday 8 stubbornness — you hate being wrong. Always use stop losses.", icon:"🛑" },
                  { trait:"FOMO on Trends", detail:"Expression 3 wants to be in everything creative. Focus on 2-3 setups max.", icon:"📊" },
                ].map(s=>(
                  <div key={s.trait} className="flex items-start gap-3 p-3 rounded-lg mb-2" style={{ background:"rgba(248,113,113,0.04)" }}>
                    <span className="text-lg">{s.icon}</span>
                    <div><p className="text-sm font-semibold text-white">{s.trait}</p><p className="text-xs mt-0.5" style={{ color:"rgba(255,255,255,0.4)" }}>{s.detail}</p></div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
