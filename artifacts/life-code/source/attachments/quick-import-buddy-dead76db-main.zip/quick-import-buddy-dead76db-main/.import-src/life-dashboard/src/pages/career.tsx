import { useParams, Link } from "wouter";
import { Briefcase, ChevronRight } from "lucide-react";
import { calcCoreNumbers } from "@/lib/numerology";
import { PROFILE } from "@/lib/profile";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);
const YELLOW = "hsl(48 96% 53%)";
const BLUE   = "hsl(212 95% 65%)";
const PURPLE = "hsl(270 60% 70%)";
const GREEN  = "#4ade80";
const ROSE   = "#f472b6";

const tabs = [
  { key:"", label:"Overview", href:"/career" },
  { key:"paths", label:"Career Paths", href:"/career/paths" },
  { key:"timing", label:"Timing & Cycles", href:"/career/timing" },
  { key:"strengths", label:"Strengths", href:"/career/strengths" },
  { key:"finances", label:"Finances", href:"/career/finances" },
];

export default function CareerPage() {
  const params = useParams<{ sub?:string }>();
  const sub = params.sub ?? "";

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Briefcase size={12} style={{ color:YELLOW }} />
          <span>Career Consultant</span><ChevronRight size={10} /><span style={{ color:YELLOW }}>Cristian Zavala</span>
        </div>
        <h1 className="page-title">Career Consultant</h1>
        <p className="page-subtitle">Life Path 1 · 28/10 Wealth Portal · Personal Year 9 Completion</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(250,204,21,0.12)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── OVERVIEW ── */}
      {sub==="" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Life Path 1 · 28/10 — The Pioneer King</p>
            <p className="text-sm leading-relaxed mb-4" style={{ color:"rgba(255,255,255,0.8)" }}>
              Your 28/10/1 Life Path is one of the most powerful wealth-creation codes in numerology. The compound 28 carries Saturn energy (discipline, authority, real-world mastery) + the Moon (public recognition, emotional connection with audiences) converging into the 10 of completion and finally the 1 of pure leadership. You are built to pioneer, to lead institutions, and to become the first in your domain.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label:"Core Drive", value:"Leadership", color:YELLOW },
                { label:"Natural Role", value:"The Pioneer", color:BLUE },
                { label:"Peak Age", value:"28–37", color:GREEN },
                { label:"2026 Phase", value:"Completion", color:PURPLE },
              ].map(s=>(
                <div key={s.label} className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{s.label}</p>
                  <p className="text-sm font-bold" style={{ color:s.color }}>{s.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Core Strengths</p>
              {["Natural born leader — others instinctively follow","Pioneering instinct — see opportunity before others","Total self-reliance — thrive without external validation","Competitive drive that never fully switches off","Ability to initiate and bring ideas into the physical world","Courage to take action when others hesitate"].map(s=>(
                <div key={s} className="flex items-start gap-2 mb-2">
                  <span style={{ color:GREEN }}>✓</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.65)" }}>{s}</p>
                </div>
              ))}
            </div>
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:ROSE }}>Shadow Patterns to Master</p>
              {["Stubbornness — difficulty delegating or asking for help","Impatience with those who move slower","Can bulldoze others in pursuit of goals","Pride that prevents accepting guidance","Starting multiple things without finishing (curbed by your 9 PY)","Isolation — needs connection despite independence"].map(s=>(
                <div key={s} className="flex items-start gap-2 mb-2">
                  <span style={{ color:ROSE }}>→</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.55)" }}>{s}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>The 28 Compound — Wealth Code</p>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>
              The number 28 carries the Moon (2) and Saturn (8) — the archetype of the self-made authority figure who earns wealth through discipline and earns respect through service. Historical 28 energy figures build empires quietly, accumulate material resources, and become respected authorities in their fields. Your wealth comes through leadership roles, not passive income. You build from ground zero to top — and the journey is the point.
            </p>
          </div>
        </div>
      )}

      {/* ── CAREER PATHS ── */}
      {sub==="paths" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-4" style={{ color:YELLOW }}>Primary Career Paths — Life Path 1 + Virgo Sun + Sagittarius Rising</p>
            {[
              { category:"🏆 Sports & Athletics", paths:["Professional Soccer Player","Athletic Director","Sports Team Owner/Management","Personal Trainer / Performance Coach","Sports Agent or Brand Builder"], why:"Moon in 5th (sports), Sagittarius Rising (athletics), Mars in 8th (intense drive), Virgo precision (technical excellence in craft)", strength:"NATURAL" },
              { category:"🏢 Entrepreneurship & Leadership", paths:["CEO / Founder of a Company","Brand Builder / Personal Brand","Real Estate Developer","Management Consultant","Startup Founder"], why:"Life Path 1 is the entrepreneur number. 28/10 compound carries Saturn discipline meeting material achievement.", strength:"PRIMARY" },
              { category:"💡 Media & Influence", paths:["Content Creator / Influencer","Public Speaker","Author / Writer","Podcast Host","Social Media Strategist"], why:"Sun+Saturn+Mercury in 10th — born for public visibility. Jupiter conjunct Neptune — visionary creative communication.", strength:"HIGH" },
              { category:"🌍 Leadership Roles", paths:["Military Officer","Political Leader","Non-Profit Executive","Community Organizer","Activist Leader"], why:"Life Path 1 at its highest expression leads communities and movements, not just companies.", strength:"HIGH" },
              { category:"🏗️ Building & Architecture", paths:["Architect","Civil Engineer","Urban Planner","Construction Executive","Infrastructure Developer"], why:"The 28/10/1 builds — literally and figuratively. Saturn energy loves physical, tangible structures.", strength:"COMPATIBLE" },
            ].map(c=>(
              <div key={c.category} className="mb-4 p-4 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)" }}>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-semibold text-white">{c.category}</p>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background:c.strength==="NATURAL"?"rgba(74,222,128,0.15)":c.strength==="PRIMARY"?"rgba(250,204,21,0.15)":"rgba(96,165,250,0.1)", color:c.strength==="NATURAL"?GREEN:c.strength==="PRIMARY"?YELLOW:BLUE }}>{c.strength}</span>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {c.paths.map(p=>(
                    <span key={p} className="text-[10px] px-2 py-1 rounded-full" style={{ background:"rgba(255,255,255,0.05)", color:"rgba(255,255,255,0.7)" }}>{p}</span>
                  ))}
                </div>
                <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.35)" }}>{c.why}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── TIMING & CYCLES ── */}
      {sub==="timing" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.2)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:YELLOW }}>2026 — Personal Year 9 (Completion)</p>
            <p className="text-sm font-semibold text-white mb-2">The Harvest & The Release</p>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>
              In 2026 you are completing a 9-year cycle that started in 2018 (your PY1). This year demands you: finish unfinished business, close chapters that no longer serve, and prepare for 2027's monumental Personal Year 1. Trying to start new major projects in a PY9 is fighting the current — this year is about consolidating and releasing. What you clear now determines the quality of your next 9-year cycle.
            </p>
          </div>
          {[
            { year:"2026", py:9, phase:"Completion", action:"Release, finish, consolidate. Close what's done. Give back.", color:PURPLE },
            { year:"2027", py:1, phase:"The Rebirth", action:"NEW 9-YEAR CYCLE BEGINS. Launch, initiate, be bold. Maximum new beginnings.", color:YELLOW },
            { year:"2028", py:2, phase:"Build Relationships", action:"Partnerships and alliances. Patient cooperation. Don't rush.", color:BLUE },
            { year:"2029", py:3, phase:"Creative Explosion", action:"Express everything you've held back. Maximum visibility and creativity.", color:GREEN },
            { year:"2030", py:4, phase:"Build The Foundation", action:"Systems, structures, discipline. Build what will last decades.", color:ROSE },
          ].map(r=>(
            <div key={r.year} className="feature-card">
              <div className="flex items-center gap-3">
                <span className="text-sm font-black" style={{ color:r.color }}>{r.year}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded" style={{ background:`${r.color}15`, color:r.color }}>PY {r.py}</span>
                <span className="text-xs font-semibold text-white">{r.phase}</span>
              </div>
              <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{r.action}</p>
            </div>
          ))}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Pinnacle Career Phases (Numerology)</p>
            {[
              { label:"Pinnacle 1 (Ages 0–34)", value:N.pinnacles[0], note:"Your formative pinnacle shapes your foundational energy and early career." },
              { label:"Pinnacle 2 (Ages 34–43)", value:N.pinnacles[1], note:"Second pinnacle — a shift in career focus and life approach." },
              { label:"Pinnacle 3 (Ages 43–52)", value:N.pinnacles[2], note:"Third pinnacle — refinement and mastery of your life's work." },
              { label:"Pinnacle 4 (Ages 52+)", value:N.pinnacles[3], note:"Final pinnacle — your legacy energy and ultimate expression." },
            ].map(p=>(
              <div key={p.label} className="flex items-center gap-3 mb-2">
                <p className="text-xl font-black w-8" style={{ color:YELLOW }}>{p.value}</p>
                <div>
                  <p className="text-xs font-semibold text-white">{p.label}</p>
                  <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>{p.note}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── STRENGTHS ── */}
      {sub==="strengths" && (
        <div className="space-y-4">
          {[
            { title:"🧠 Mental Strengths (Virgo Sun + Mercury 10th)", items:["Extraordinary attention to detail — you catch what others miss","Analytical, systematic thinking — excellent problem-solver","Self-critical drive for perfection — fuel for excellence","Memory for details, data and patterns","Deep capacity for focused, concentrated work"] },
            { title:"🔥 Leadership Strengths (Life Path 1)", items:["Natural authority — people follow without being told to","Initiative — you start things, you don't wait","Self-reliance — perform best when given autonomy","Competitive fire that activates under pressure","Decisive — you don't get stuck in indecision"] },
            { title:"💫 Intuitive Strengths (Jupiter-Neptune-Chiron Aquarius)", items:["Visionary thinking — you see futures others can't imagine","Humanitarian instinct — success that serves a larger purpose","Healing capacity — your experiences uplift others","Creative genius that operates through channels beyond logic","Spiritual intelligence — connected to something larger"] },
            { title:"⚡ Physical/Athletic Strengths (Sagittarius Rising + Mars 8th)", items:["Natural athleticism — Sagittarius rules hips and thighs","Explosive power under pressure (Mars in 8th)","Stamina through adversity — keeps going when others stop","Tactical adaptability — reads the game (Virgo mind)","Hidden reserves — strength emerges when most needed"] },
          ].map(s=>(
            <div key={s.title} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-sm font-semibold text-white mb-3">{s.title}</p>
              <div className="space-y-1.5">
                {s.items.map(item=>(
                  <div key={item} className="flex items-start gap-2">
                    <span style={{ color:YELLOW }}>→</span>
                    <p className="text-xs" style={{ color:"rgba(255,255,255,0.65)" }}>{item}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── FINANCES ── */}
      {sub==="finances" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.2)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:YELLOW }}>28/10 Wealth Code — How Your Money Works</p>
            <p className="text-xs leading-relaxed mb-3" style={{ color:"rgba(255,255,255,0.6)" }}>
              The 28 is the Moon (2) + Saturn (8). Your wealth is earned through discipline, authority and service — never through shortcuts. Saturn (your Birthday Number ruler) demands you build correctly the first time. Pluto in your 2nd house and North Node in Capricorn both point to a transformative and ultimately abundant financial destiny — but it requires patient, structured building.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label:"Money Style", value:"Builder — accumulates steadily over time", color:YELLOW },
                { label:"Money Source", value:"Leadership roles, entrepreneurship, ownership", color:BLUE },
                { label:"Money Blocker", value:"Impatience, chasing quick wins, no structure", color:ROSE },
                { label:"Money Amplifier", value:"Investing in yourself, authority and expertise", color:GREEN },
              ].map(m=>(
                <div key={m.label} className="p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>{m.label}</p>
                  <p className="text-xs font-semibold" style={{ color:m.color }}>{m.value}</p>
                </div>
              ))}
            </div>
          </div>
          {[
            { title:"Best Financial Actions — PY9 (2026)", items:["Complete outstanding financial obligations and close debts","Don't start major new financial ventures this year — set them up for 2027","Invest in education, skills and knowledge that will serve your 2027 launch","Release financial relationships that drain or limit you","Build your financial foundation: emergency fund, basic systems"] },
            { title:"Best Financial Actions — PY1 (2027)", items:["Launch the business / brand / project you've been preparing","Take the leadership position you've earned","Make the bold financial moves — new accounts, new income streams","First steps of your next 9-year financial building cycle","Brand yourself and make your name known"] },
            { title:"Long-Term Wealth Blueprint", items:["Your peak earning years begin around age 28–30 (your Life Path number)","Multiple income streams: primary skill + investments + authority/brand","Real estate and tangible assets align with your Saturn/Capricorn energy","The 8 personality and 8 birthday mean negotiation is your superpower — use it in every deal","Wealth grows through expertise → authority → premium pricing → ownership"] },
          ].map(s=>(
            <div key={s.title} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>{s.title}</p>
              {s.items.map(item=>(
                <div key={item} className="flex items-start gap-2 mb-1.5">
                  <span style={{ color:YELLOW }}>→</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>{item}</p>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
