import { Switch, Route, Router as WouterRouter, Link, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState } from "react";
import {
  Hash, Star, BookOpen, TrendingUp, Trophy, Dribbble,
  Heart, CalendarDays, Grid3x3, Layers, Briefcase,
  ChevronDown, ChevronRight, Menu, X, Zap, Home, Radio,
  Sparkles, Wind, Activity, Bot
} from "lucide-react";

import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home";
import NumerologyPage from "@/pages/numerology";
import AstrologyPage from "@/pages/astrology";
import GematriaPage from "@/pages/gematria";
import TradingAIPage from "@/pages/trading-ai";
import SportsPredictionPage from "@/pages/sports-prediction";
import SoccerAIPage from "@/pages/soccer-ai";
import CompatibilityPage from "@/pages/compatibility";
import ForecastsPage from "@/pages/forecasts";
import MatrixCalendarPage from "@/pages/matrix-calendar";
import TarotPage from "@/pages/tarot";
import CareerPage from "@/pages/career";
import RifePage from "@/pages/rife";
import BaZiPage from "@/pages/bazi";
import FengShuiPage from "@/pages/feng-shui";
import ChakraPage from "@/pages/chakra";
import DayLifePage from "@/pages/day-life";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
});

type NavGroup = {
  label: string;
  icon: React.ElementType;
  color: string;
  href?: string;
  children?: { label: string; href: string }[];
  status?: "soon";
};

const navGroups: NavGroup[] = [
  { label: "Home", icon: Home, href: "/", color: "hsl(212 95% 60%)" },
  {
    label: "Numerology", icon: Hash, color: "hsl(48 96% 53%)",
    children: [
      { label: "Core Numbers", href: "/numerology" },
      { label: "Karmic & Cycles", href: "/numerology/karmic" },
      { label: "Advanced Analysis", href: "/numerology/advanced" },
      { label: "Tools & Calculators", href: "/numerology/tools" },
      { label: "Date Energy", href: "/numerology/date-energy" },
      { label: "Lucky Numbers & Colors", href: "/numerology/lucky" },
    ],
  },
  {
    label: "Astrology", icon: Star, color: "hsl(270 60% 65%)",
    children: [
      { label: "Chart Overview", href: "/astrology" },
      { label: "Dignities & Rulers", href: "/astrology/dignities" },
      { label: "Aspects & Patterns", href: "/astrology/aspects" },
      { label: "Timing & Transits", href: "/astrology/timing" },
      { label: "Nodes & Karma", href: "/astrology/nodes" },
      { label: "Vedic & Divisional", href: "/astrology/vedic" },
      { label: "Locational Astrology", href: "/astrology/locational" },
      { label: "Deep Chart & Remedies", href: "/astrology/advanced" },
    ],
  },
  {
    label: "Gematria", icon: BookOpen, color: "hsl(160 70% 50%)",
    children: [
      { label: "English Ciphers", href: "/gematria" },
      { label: "Hebrew Ciphers", href: "/gematria/hebrew" },
      { label: "Matrix Decoder", href: "/gematria/matrix" },
      { label: "Cross-Reference", href: "/gematria/cross" },
      { label: "Applications", href: "/gematria/date" },
    ],
  },
  { label: "Trading AI", icon: TrendingUp, href: "/trading-ai", color: "hsl(142 70% 50%)" },
  { label: "Sports Prediction AI", icon: Trophy, href: "/sports-prediction", color: "hsl(28 95% 55%)" },
  {
    label: "Soccer AI", icon: Dribbble, color: "hsl(212 95% 60%)",
    children: [
      { label: "Game Day Intel", href: "/soccer-ai" },
      { label: "Schedule Optimizer", href: "/soccer-ai/schedule" },
      { label: "Training Routine", href: "/soccer-ai/training" },
      { label: "Diet Plan", href: "/soccer-ai/diet" },
      { label: "Mental Routine", href: "/soccer-ai/mental" },
      { label: "Athleticism", href: "/soccer-ai/athleticism" },
    ],
  },
  {
    label: "Compatibility", icon: Heart, color: "hsl(340 70% 60%)",
    children: [
      { label: "Person to Person", href: "/compatibility" },
      { label: "Day & Month Calendar", href: "/compatibility/calendar" },
      { label: "Vehicle Compatibility", href: "/compatibility/vehicle" },
      { label: "House Numbers", href: "/compatibility/house" },
      { label: "Compatible Brands", href: "/compatibility/brands" },
      { label: "Places to Live", href: "/compatibility/places" },
    ],
  },
  {
    label: "Forecasts", icon: CalendarDays, color: "hsl(48 96% 53%)",
    children: [
      { label: "Daily Forecast", href: "/forecasts" },
      { label: "Monthly Forecast", href: "/forecasts/monthly" },
      { label: "Yearly Forecast", href: "/forecasts/yearly" },
    ],
  },
  {
    label: "Matrix Calendar", icon: Grid3x3, color: "hsl(212 95% 60%)",
    children: [
      { label: "Live Matrix Calendar", href: "/matrix-calendar" },
      { label: "Date Energy Breakdowns", href: "/matrix-calendar/energy" },
      { label: "Matrix Cheat Codes", href: "/matrix-calendar/cheat-codes" },
    ],
  },
  { label: "Tarot", icon: Layers, href: "/tarot", color: "hsl(290 60% 65%)" },
  {
    label: "Career Consultant", icon: Briefcase, color: "hsl(48 96% 53%)",
    children: [
      { label: "Overview", href: "/career" },
      { label: "Career Paths", href: "/career/paths" },
      { label: "Timing & Cycles", href: "/career/timing" },
      { label: "Strengths", href: "/career/strengths" },
      { label: "Finances", href: "/career/finances" },
    ],
  },
  { label: "Rife Frequencies", icon: Radio, href: "/rife", color: "hsl(160 70% 55%)" },
  {
    label: "Chinese Astrology", icon: Sparkles, color: "hsl(28 95% 60%)",
    children: [
      { label: "Four Pillars", href: "/bazi" },
      { label: "Luck Pillars", href: "/bazi/luck" },
      { label: "Chinese Zodiac", href: "/bazi/animal" },
      { label: "Five Elements", href: "/bazi/seasons" },
      { label: "LP Overlay", href: "/bazi/overlay" },
    ],
  },
  {
    label: "Feng Shui", icon: Wind, color: "hsl(35 90% 55%)",
    children: [
      { label: "Kua Profile", href: "/feng-shui" },
      { label: "Directions", href: "/feng-shui/dirs" },
      { label: "Room Advice", href: "/feng-shui/rooms" },
      { label: "Color Therapy", href: "/feng-shui/colors" },
      { label: "Flying Stars 2026", href: "/feng-shui/stars" },
      { label: "Address Calculator", href: "/feng-shui/address" },
    ],
  },
  {
    label: "Chakra & Color Therapy", icon: Activity, color: "hsl(270 60% 65%)",
    children: [
      { label: "Chakra Scan", href: "/chakra" },
      { label: "Healing Plan", href: "/chakra/heal" },
      { label: "Color Therapy", href: "/chakra/colors" },
      { label: "Daily Wearables", href: "/chakra/daily" },
      { label: "Rife Hz", href: "/chakra/rife" },
    ],
  },
  {
    label: "Day-to-Day Life AI", icon: Bot, color: "hsl(142 70% 50%)",
    children: [
      { label: "Today", href: "/day-life" },
      { label: "Wardrobe Code", href: "/day-life/wardrobe" },
      { label: "Daily Routine", href: "/day-life/routine" },
      { label: "Matrix Hacks", href: "/day-life/matrix" },
      { label: "Numerology Diet", href: "/day-life/food" },
    ],
  },
];

function NavGroupItem({ group, onClose }: { group: NavGroup; onClose: () => void }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(() =>
    group.children?.some(c => location.startsWith(c.href)) ?? false
  );
  const Icon = group.icon;

  if (group.href) {
    const isActive = location === group.href;
    return (
      <Link href={group.href} onClick={onClose}
        className={`nav-item ${isActive ? "nav-item-active" : "nav-item-inactive"}`}>
        <span className="shrink-0 w-5 flex items-center justify-center">
          <Icon size={15} style={{ color: isActive ? group.color : undefined }} />
        </span>
        <span className="flex-1 truncate">{group.label}</span>
        {group.status && <span className="pill-yellow">{group.status === "soon" ? "Soon" : ""}</span>}
      </Link>
    );
  }

  const anyChildActive = group.children?.some(c => location.startsWith(c.href));

  return (
    <div>
      <button onClick={() => setOpen(o => !o)}
        className={`nav-item w-full text-left ${anyChildActive ? "nav-item-active" : "nav-item-inactive"}`}>
        <span className="shrink-0 w-5 flex items-center justify-center">
          <Icon size={15} style={{ color: anyChildActive ? group.color : undefined }} />
        </span>
        <span className="flex-1 truncate">{group.label}</span>
        {open ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
      </button>
      {open && group.children && (
        <div className="ml-5 mt-0.5 pl-3 space-y-0.5"
          style={{ borderLeft: "1px solid hsl(228 20% 14%)" }}>
          {group.children.map(child => {
            const isActive = location === child.href || location.startsWith(child.href + "/");
            return (
              <Link key={child.href} href={child.href} onClick={onClose}
                className={`flex items-center py-1.5 px-2 rounded-md text-xs transition-all duration-100 ${
                  isActive
                    ? "font-semibold"
                    : "opacity-50 hover:opacity-80"
                }`}
                style={{ color: isActive ? group.color : undefined }}>
                {child.label}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <>
      {open && <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden" onClick={onClose}
        style={{ transition: "opacity 0.3s ease" }} />}
      <aside className={`fixed top-0 left-0 h-full w-[15.5rem] flex flex-col z-50 transition-transform duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        } lg:static lg:z-auto`}
        style={{ background: "hsl(var(--sidebar))", borderRight: "1px solid hsl(var(--sidebar-border))" }}>

        <div className="px-4 py-4 flex items-center justify-between shrink-0"
          style={{ borderBottom: "1px solid hsl(var(--sidebar-border))" }}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-[10px] flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, hsl(212 95% 55%), hsl(228 70% 40%))", boxShadow: "0 2px 8px rgba(96,165,250,0.25)" }}>
              <Zap size={14} className="text-white" />
            </div>
            <div>
              <h1 className="text-[13px] font-bold tracking-wider text-white" style={{ letterSpacing: "0.08em" }}>MATRIX</h1>
              <p className="text-[8.5px] tracking-[0.12em] uppercase"
                style={{ color: "hsl(212 95% 65%)" }}>Command Center</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden opacity-40 hover:opacity-70 text-white transition-opacity duration-200">
            <X size={16} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-2 space-y-px">
          {navGroups.map(group => (
            <NavGroupItem key={group.label} group={group} onClose={onClose} />
          ))}
        </nav>

        <div className="px-4 py-3 shrink-0" style={{ borderTop: "1px solid hsl(var(--sidebar-border))" }}>
          <div className="flex items-center gap-2">
            <div className="status-dot-active" />
            <span className="text-[11px] font-medium" style={{ color: "hsl(var(--muted-foreground))" }}>System Online</span>
          </div>
          <p className="text-[10px] mt-0.5 font-medium" style={{ color: "hsl(228 12% 28%)" }}>
            {new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" })}
          </p>
        </div>
      </aside>
    </>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  return (
    <div className="flex h-screen overflow-hidden sparkle-bg" style={{ background: "hsl(var(--background))" }}>
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative z-10">
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 shrink-0"
          style={{ background: "hsl(var(--sidebar))", borderBottom: "1px solid hsl(var(--sidebar-border))" }}>
          <button onClick={() => setSidebarOpen(true)} className="text-white/50 hover:text-white/80 transition-colors duration-200">
            <Menu size={20} />
          </button>
          <span className="text-[13px] font-bold tracking-wide text-white">Matrix Command Center</span>
        </header>
        <main className="flex-1 overflow-y-auto px-5 py-6 lg:px-10 lg:py-8">
          {children}
        </main>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/numerology" component={NumerologyPage} />
        <Route path="/numerology/:sub" component={NumerologyPage} />
        <Route path="/astrology" component={AstrologyPage} />
        <Route path="/astrology/:sub" component={AstrologyPage} />
        <Route path="/gematria" component={GematriaPage} />
        <Route path="/gematria/:sub" component={GematriaPage} />
        <Route path="/trading-ai" component={TradingAIPage} />
        <Route path="/sports-prediction" component={SportsPredictionPage} />
        <Route path="/soccer-ai" component={SoccerAIPage} />
        <Route path="/soccer-ai/:sub" component={SoccerAIPage} />
        <Route path="/compatibility" component={CompatibilityPage} />
        <Route path="/compatibility/:sub" component={CompatibilityPage} />
        <Route path="/forecasts" component={ForecastsPage} />
        <Route path="/forecasts/:sub" component={ForecastsPage} />
        <Route path="/matrix-calendar" component={MatrixCalendarPage} />
        <Route path="/matrix-calendar/:sub" component={MatrixCalendarPage} />
        <Route path="/tarot" component={TarotPage} />
        <Route path="/tarot/:sub" component={TarotPage} />
        <Route path="/career" component={CareerPage} />
        <Route path="/career/:sub" component={CareerPage} />
        <Route path="/rife" component={RifePage} />
        <Route path="/bazi" component={BaZiPage} />
        <Route path="/bazi/:sub" component={BaZiPage} />
        <Route path="/feng-shui" component={FengShuiPage} />
        <Route path="/feng-shui/:sub" component={FengShuiPage} />
        <Route path="/chakra" component={ChakraPage} />
        <Route path="/chakra/:sub" component={ChakraPage} />
        <Route path="/day-life" component={DayLifePage} />
        <Route path="/day-life/:sub" component={DayLifePage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
