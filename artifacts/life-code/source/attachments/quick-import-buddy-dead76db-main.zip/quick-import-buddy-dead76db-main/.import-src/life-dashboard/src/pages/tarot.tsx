import { useParams, Link } from "wouter";
import { useState, useMemo } from "react";
import { Layers, ChevronRight } from "lucide-react";
import { MAJOR_ARCANA, getDailyCard, getCardOfYear, getThreeCardSpread, LP_CARD, SUIT_MEANINGS, getElementalSpread } from "@/lib/tarot";
import { calcCoreNumbers, calcPersonalDay, calcDateEnergy } from "@/lib/numerology";
import { PROFILE } from "@/lib/profile";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);
const YELLOW = "hsl(48 96% 53%)";
const BLUE   = "hsl(212 95% 65%)";
const PURPLE = "hsl(270 60% 70%)";
const GREEN  = "#4ade80";

const tabs = [
  { key:"", label:"Daily Draw", href:"/tarot" },
  { key:"spread", label:"3-Card Spread", href:"/tarot/spread" },
  { key:"reader", label:"Ask a Question", href:"/tarot/reader" },
  { key:"year", label:"Card of the Year", href:"/tarot/year" },
  { key:"arcana", label:"Major Arcana", href:"/tarot/arcana" },
  { key:"minors", label:"Minor Arcana", href:"/tarot/minors" },
];

const CARD_BG = [
  "linear-gradient(135deg,#1a0a3a,#0d0520)",
  "linear-gradient(135deg,#0a1a3a,#051020)",
  "linear-gradient(135deg,#1a1a0a,#0d0d05)",
  "linear-gradient(135deg,#0a2a1a,#051510)",
  "linear-gradient(135deg,#3a0a1a,#200510)",
];

function CardDisplay({ card, label, flipped=false }: { card: typeof MAJOR_ARCANA[0]; label?: string; flipped?: boolean }) {
  const [revealed, setRevealed] = useState(false);
  const bg = CARD_BG[card.number % CARD_BG.length];
  return (
    <div className="flex flex-col items-center gap-3">
      {label && <p className="text-[9px] uppercase tracking-widest" style={{ color:"rgba(255,255,255,0.35)" }}>{label}</p>}
      <div
        onClick={()=>setRevealed(true)}
        className="relative rounded-2xl overflow-hidden cursor-pointer transition-all"
        style={{ width:130, height:220, background:bg, border:"1px solid rgba(255,255,255,0.1)", boxShadow:"0 8px 40px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.05)", transform:flipped?"rotate(180deg)":"none" }}>
        <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center">
          <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.4)" }}>{card.arcana} {card.number}</p>
          <p className="text-4xl mb-2">{card.emoji}</p>
          <p className="text-xs font-bold text-white leading-tight">{card.name}</p>
          <div className="mt-3 flex flex-wrap gap-1 justify-center">
            {card.keywords.slice(0,2).map(k=>(
              <span key={k} className="text-[8px] px-1.5 py-0.5 rounded-full" style={{ background:"rgba(255,255,255,0.08)", color:"rgba(255,255,255,0.5)" }}>{k}</span>
            ))}
          </div>
        </div>
      </div>
      {revealed && (
        <div className="w-full max-w-xs p-3 rounded-xl text-xs text-center" style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", color:"rgba(255,255,255,0.6)" }}>
          {flipped ? card.reversed : card.upright}
        </div>
      )}
      {!revealed && (
        <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.25)" }}>Tap card to reveal</p>
      )}
    </div>
  );
}

export default function TarotPage() {
  const params = useParams<{ sub?:string }>();
  const sub = params.sub ?? "";
  const today = new Date();
  const [selectedCard, setSelectedCard] = useState<typeof MAJOR_ARCANA[0] | null>(null);

  const dailyCard = useMemo(() => getDailyCard(today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const yearCard  = useMemo(() => getCardOfYear(N.lifePath, N.personalYear), []);
  const spread    = useMemo(() => getThreeCardSpread(today.getMonth()+1, today.getDate(), today.getFullYear(), N.lifePath), []);
  const pd = useMemo(() => calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const elemental = useMemo(() => getElementalSpread(pd.reduced), []);
  const lpCard = LP_CARD[N.lifePath];

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Layers size={12} style={{ color:PURPLE }} />
          <span>Tarot</span><ChevronRight size={10} /><span style={{ color:PURPLE }}>Cristian Zavala</span>
        </div>
        <h1 className="page-title">Tarot</h1>
        <p className="page-subtitle">Daily draw · 3-card spreads · Numerology-aligned cards</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(167,139,250,0.12)", color:PURPLE, border:"1px solid rgba(167,139,250,0.25)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── DAILY DRAW ── */}
      {sub==="" && (
        <div className="space-y-5">
          {/* Today's key info */}
          <div className="glass-card p-4 flex items-center gap-4" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="text-center">
              <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Today's Energy</p>
              <p className="text-3xl font-black" style={{ color:YELLOW }}>{calcDateEnergy(today.getMonth()+1, today.getDate(), today.getFullYear()).reduced}</p>
            </div>
            <div className="text-center">
              <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Your Personal Day</p>
              <p className="text-3xl font-black" style={{ color:BLUE }}>{pd.reduced}</p>
            </div>
            <div className="flex-1 text-xs" style={{ color:"rgba(255,255,255,0.4)", paddingLeft:"1rem", borderLeft:"1px solid rgba(255,255,255,0.06)" }}>
              {today.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}
            </div>
          </div>

          {/* Daily card */}
          <div className="glass-card p-6" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-5 text-center" style={{ color:"rgba(255,255,255,0.3)" }}>Card of the Day</p>
            <div className="flex justify-center">
              <CardDisplay card={dailyCard} />
            </div>
            <div className="mt-5 space-y-3">
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:YELLOW }}>Numerology Connection</p>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>{dailyCard.numerology}</p>
              </div>
              {dailyCard.planet && (
                <div className="flex gap-3">
                  <div className="flex-1 p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Planet</p>
                    <p className="text-xs font-semibold text-white">{dailyCard.planet}</p>
                  </div>
                  {dailyCard.zodiac && (
                    <div className="flex-1 p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                      <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Zodiac</p>
                      <p className="text-xs font-semibold text-white">{dailyCard.zodiac}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Elemental mini spread */}
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-4 text-center" style={{ color:"rgba(255,255,255,0.3)" }}>Elemental Guidance — Personal Day {pd.reduced}</p>
            <div className="grid grid-cols-4 gap-3">
              {[
                { label:"🔥 Fire", card:elemental.fire },
                { label:"💧 Water", card:elemental.water },
                { label:"🌍 Earth", card:elemental.earth },
                { label:"💨 Air", card:elemental.air },
              ].map(e=>(
                <div key={e.label} className="text-center">
                  <p className="text-[9px] mb-2" style={{ color:"rgba(255,255,255,0.35)" }}>{e.label}</p>
                  <div className="h-24 rounded-xl flex flex-col items-center justify-center" style={{ background:"linear-gradient(135deg,#1a0a3a,#0d0520)", border:"1px solid rgba(255,255,255,0.08)" }}>
                    <p className="text-2xl">{e.card.emoji}</p>
                    <p className="text-[8px] text-center mt-1 px-1" style={{ color:"rgba(255,255,255,0.6)" }}>{e.card.name}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── 3-CARD SPREAD ── */}
      {sub==="spread" && (
        <div className="space-y-4">
          <div className="glass-card p-6" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-6 text-center" style={{ color:"rgba(255,255,255,0.3)" }}>Past · Present · Future — {today.toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}</p>
            <div className="flex justify-center gap-6 flex-wrap">
              <CardDisplay card={spread.past}    label="Past — What shaped you" />
              <CardDisplay card={spread.present} label="Present — What's active now" />
              <CardDisplay card={spread.future}  label="Future — What's emerging" />
            </div>
          </div>
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Spread Reading</p>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>
              The three cards reveal the arc of your current chapter. Past shows the foundation, Present shows the active energy demanding attention, and Future shows what naturally flows from your current path. Your Life Path {N.lifePath} energy infuses the spread's calculation.
            </p>
          </div>
        </div>
      )}

      {/* ── ASK A QUESTION (Reader Mode) ── */}
      {sub==="reader" && (() => {
        const [question, setQ] = useState("");
        const [drawn, setDrawn] = useState(false);
        const reading = useMemo(() => {
          if(!drawn || !question) return null;
          const seed = [...question].reduce((a,c)=>a+c.charCodeAt(0),0) + today.getDate() + today.getMonth() + N.lifePath;
          const idx1 = seed % MAJOR_ARCANA.length;
          const idx2 = (seed * 7 + 3) % MAJOR_ARCANA.length;
          const idx3 = (seed * 13 + 7) % MAJOR_ARCANA.length;
          const c1 = MAJOR_ARCANA[idx1];
          const c2 = MAJOR_ARCANA[idx2 === idx1 ? (idx2+1) % MAJOR_ARCANA.length : idx2];
          const c3Idx = idx3 === idx1 || idx3 === idx2 ? (idx3+2) % MAJOR_ARCANA.length : idx3;
          const c3 = MAJOR_ARCANA[c3Idx];
          const flipped = seed % 3 === 0;
          return { situation:c1, advice:c2, outcome:c3, flipped };
        }, [drawn, question]);
        return (
          <div className="space-y-4">
            <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PURPLE }}>Full Tarot Reader — Ask Any Question</p>
              <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>Focus on your question deeply, type it below, and draw your cards. The spread uses your numerology + question energy to select cards.</p>
              <div className="space-y-3">
                <textarea value={question} onChange={e=>{setQ(e.target.value);setDrawn(false);}} placeholder="What do I need to know about...?" rows={3}
                  className="w-full px-4 py-3 rounded-xl text-sm resize-none"
                  style={{ background:"rgba(167,139,250,0.06)", border:"1px solid rgba(167,139,250,0.2)", color:"white", outline:"none" }} />
                <button onClick={()=>setDrawn(true)} disabled={!question.trim()}
                  className="w-full py-3 rounded-xl text-sm font-bold transition-all"
                  style={{ background: question.trim() ? "rgba(167,139,250,0.15)" : "rgba(255,255,255,0.05)", color: question.trim() ? PURPLE : "rgba(255,255,255,0.2)", border:`1px solid ${question.trim() ? "rgba(167,139,250,0.3)" : "rgba(255,255,255,0.05)"}` }}>
                  🔮 Draw Cards for This Question
                </button>
              </div>
            </div>
            {reading && (
              <>
                <div className="glass-card p-6" style={{ background:"hsl(228 28% 7%)" }}>
                  <p className="text-[10px] uppercase tracking-widest mb-5 text-center" style={{ color:"rgba(255,255,255,0.3)" }}>Your Reading — "{question.slice(0,50)}{question.length>50?"...":""}"</p>
                  <div className="flex justify-center gap-6 flex-wrap">
                    <CardDisplay card={reading.situation} label="The Situation" />
                    <CardDisplay card={reading.advice} label="The Advice" />
                    <CardDisplay card={reading.outcome} label="The Outcome" flipped={reading.flipped} />
                  </div>
                </div>
                <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                  <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:PURPLE }}>Interpretation</p>
                  <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>
                    <strong style={{ color:"white" }}>{reading.situation.name}</strong> reveals the core energy surrounding your question — {reading.situation.upright.slice(0,80)}...
                  </p>
                  <p className="text-xs leading-relaxed mt-2" style={{ color:"rgba(255,255,255,0.55)" }}>
                    <strong style={{ color:"white" }}>{reading.advice.name}</strong> offers guidance — {reading.advice.upright.slice(0,80)}...
                  </p>
                  <p className="text-xs leading-relaxed mt-2" style={{ color:"rgba(255,255,255,0.55)" }}>
                    <strong style={{ color:"white" }}>{reading.outcome.name}</strong> {reading.flipped ? "(reversed) warns" : "shows the likely outcome"} — {reading.flipped ? reading.outcome.reversed.slice(0,80) : reading.outcome.upright.slice(0,80)}...
                  </p>
                  <p className="text-xs mt-3 font-semibold" style={{ color:YELLOW }}>
                    Your LP{N.lifePath} energy infuses this reading. Trust your intuition on what resonates most.
                  </p>
                </div>
              </>
            )}
          </div>
        );
      })()}

      {/* ── CARD OF THE YEAR ── */}
      {sub==="year" && (
        <div className="space-y-4">
          <div className="glass-card p-6" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1 text-center" style={{ color:"rgba(255,255,255,0.3)" }}>Card of 2026 — Personal Year {N.personalYear}</p>
            <p className="text-xs mb-5 text-center" style={{ color:"rgba(255,255,255,0.35)" }}>Life Path {N.lifePath} + Personal Year {N.personalYear} = {N.lifePath + N.personalYear} → reduced → card</p>
            <div className="flex justify-center">
              <CardDisplay card={yearCard} label="Your 2026 Energy Card" />
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(167,139,250,0.2)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:PURPLE }}>Your Life Path Archetype</p>
            <p className="text-sm font-bold text-white mb-1">{lpCard?.card}</p>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{lpCard?.interpretation}</p>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Year Card Reading</p>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{yearCard.upright}</p>
            <div className="divider-blue" />
            <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{yearCard.numerology}</p>
          </div>
        </div>
      )}

      {/* ── MAJOR ARCANA REFERENCE ── */}
      {sub==="arcana" && (
        <div className="space-y-2">
          {selectedCard ? (
            <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="flex items-center gap-3 mb-4">
                <button onClick={()=>setSelectedCard(null)} className="text-xs px-3 py-1.5 rounded-lg" style={{ color:BLUE, background:"rgba(96,165,250,0.08)", border:"1px solid rgba(96,165,250,0.15)" }}>← Back</button>
                <p className="text-sm font-bold text-white">{selectedCard.emoji} {selectedCard.name}</p>
              </div>
              <div className="space-y-3">
                <div className="flex gap-2 flex-wrap">{selectedCard.keywords.map(k=><span key={k} className="px-2 py-0.5 rounded-full text-[10px]" style={{ background:"rgba(167,139,250,0.1)", color:PURPLE, border:"1px solid rgba(167,139,250,0.2)" }}>{k}</span>)}</div>
                <div><p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Upright</p><p className="text-xs" style={{ color:"rgba(255,255,255,0.7)" }}>{selectedCard.upright}</p></div>
                <div><p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reversed</p><p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{selectedCard.reversed}</p></div>
                <div><p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Numerology</p><p className="text-xs" style={{ color:YELLOW }}>{selectedCard.numerology}</p></div>
                {selectedCard.planet && <div className="flex gap-3"><div><p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>Planet</p><p className="text-xs font-bold" style={{ color:BLUE }}>{selectedCard.planet}</p></div>{selectedCard.zodiac&&<div><p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>Zodiac</p><p className="text-xs font-bold" style={{ color:GREEN }}>{selectedCard.zodiac}</p></div>}</div>}
              </div>
            </div>
          ) : (
            <div className="glass-card overflow-hidden" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-1 p-2">
                {MAJOR_ARCANA.map(card=>(
                  <button key={card.number} onClick={()=>setSelectedCard(card)}
                    className="p-3 rounded-xl text-center hover:bg-white/[0.05] transition-all"
                    style={{ border:"1px solid rgba(255,255,255,0.06)" }}>
                    <p className="text-2xl mb-1">{card.emoji}</p>
                    <p className="text-[9px] font-bold" style={{ color:"rgba(255,255,255,0.7)" }}>{card.number}. {card.name}</p>
                    <p className="text-[8px] mt-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>{card.keywords[0]}</p>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── MINOR ARCANA ── */}
      {sub==="minors" && (
        <div className="space-y-4">
          {Object.entries(SUIT_MEANINGS).map(([suit, info])=>(
            <div key={suit} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="flex items-center gap-3 mb-2">
                <p className="text-sm font-bold text-white">Suit of {suit}</p>
                <span className="text-xs px-2 py-0.5 rounded" style={{ background:"rgba(96,165,250,0.1)", color:BLUE }}>{info.element}</span>
              </div>
              <p className="text-xs mb-1" style={{ color:"rgba(255,255,255,0.6)" }}>{info.realm}</p>
              <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{info.energy}</p>
            </div>
          ))}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Your Suits by Core Numbers</p>
            <div className="space-y-2">
              {[
                { num:N.lifePath, label:"Life Path → Wands (Fire = Action & Leadership)", suit:"Wands" },
                { num:N.soulUrge, label:"Soul Urge → Cups (Water = Inner Desire)", suit:"Cups" },
                { num:N.expression, label:"Expression → Wands (Fire = Talent Expression)", suit:"Wands" },
                { num:N.personality, label:"Personality → Pentacles (Earth = How Others See You)", suit:"Pentacles" },
              ].map(s=>(
                <div key={s.num} className="flex items-center gap-2">
                  <span className="text-sm font-black w-6 text-center" style={{ color:YELLOW }}>{s.num}</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
