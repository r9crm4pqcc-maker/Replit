import { useState, useMemo, useEffect, useCallback, useRef } from "react";
import { Zap, ChevronDown, ChevronUp, RefreshCw, Tv, MapPin, TrendingUp, Trophy, Loader2, AlertCircle, Calendar } from "lucide-react";
import { fetchESPNGames, analyzeGameEnergy, getLeagueInfo, type ESPNGame } from "@/lib/espn";
import { calcDateEnergy } from "@/lib/numerology";

const YELLOW = "#FACC15";
const BLUE   = "#60A5FA";
const GREEN  = "#4ade80";
const ROSE   = "#f472b6";

function harmonyColor(h: string): string {
  if (h === "CHEAT CODE")  return GREEN;
  if (h === "STRONG CODE") return BLUE;
  if (h === "LEAN")        return YELLOW;
  if (h === "FADE")        return ROSE;
  return "rgba(255,255,255,0.4)";
}

function harmonyBg(h: string): string {
  if (h === "CHEAT CODE")  return "rgba(74,222,128,0.08)";
  if (h === "STRONG CODE") return "rgba(96,165,250,0.08)";
  if (h === "LEAN")        return "rgba(250,204,21,0.06)";
  return "rgba(255,255,255,0.02)";
}

const LEAGUE_GROUPS = [
  { label: "US Major", leagues: ["NBA", "NFL", "MLB", "NHL"] },
  { label: "Soccer", leagues: ["MLS", "Premier League", "La Liga", "Bundesliga", "Serie A", "Ligue 1"] },
  { label: "European Cups", leagues: ["UCL", "UEL", "UECL"] },
  { label: "More", leagues: ["Liga MX", "WNBA", "College Football", "College Basketball"] },
];

function StatusBadge({ status, detail }: { status: string; detail: string }) {
  if (status === "in") {
    return (
      <span className="inline-flex items-center gap-1 text-[9px] font-bold px-2 py-0.5 rounded-full animate-pulse"
        style={{ background: "rgba(239,68,68,0.15)", color: "#ef4444", border: "1px solid rgba(239,68,68,0.25)" }}>
        <span className="w-1.5 h-1.5 rounded-full bg-red-500" /> LIVE
      </span>
    );
  }
  if (status === "post") {
    return (
      <span className="text-[9px] font-semibold px-2 py-0.5 rounded-full"
        style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.5)" }}>
        FINAL
      </span>
    );
  }
  return (
    <span className="text-[9px] font-medium px-2 py-0.5 rounded-full"
      style={{ background: "rgba(96,165,250,0.08)", color: BLUE }}>
      {detail || "Scheduled"}
    </span>
  );
}

function GameCard({ game, month, day, year }: { game: ESPNGame; month: number; day: number; year: number }) {
  const [open, setOpen] = useState(false);
  const energy = useMemo(() => analyzeGameEnergy(game, month, day, year), [game, month, day, year]);
  const winnerSide = energy.predictedWinner;
  const winnerTeam = winnerSide === "home" ? game.homeTeam : game.awayTeam;
  const winnerHarmony = winnerSide === "home" ? energy.home : energy.away;
  const bestMoneyline = winnerSide === "home" ? game.odds.moneylineHome : game.odds.moneylineAway;
  const bestSpread = winnerSide === "home" ? game.odds.spreadHome : game.odds.spreadAway;
  const bestTeam = winnerSide === "home" ? game.homeAbbr : game.awayAbbr;

  return (
    <div className="rounded-2xl overflow-hidden transition-all hover:scale-[1.005]" style={{
      background: "linear-gradient(135deg, hsl(228 30% 8%), hsl(228 25% 11%))",
      border: `1px solid ${harmonyColor(winnerHarmony.harmony)}20`,
      boxShadow: winnerHarmony.harmony === "CHEAT CODE"
        ? "0 0 30px rgba(74,222,128,0.06)"
        : winnerHarmony.harmony === "STRONG CODE"
        ? "0 0 20px rgba(96,165,250,0.05)"
        : "none",
    }}>
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <StatusBadge status={game.status} detail={game.statusDetail} />
            {game.broadcast && (
              <span className="flex items-center gap-1 text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>
                <Tv size={9} /> {game.broadcast}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {energy.parlayWorthy && (
              <span className="text-[8px] font-black px-2 py-0.5 rounded-full"
                style={{ background: "rgba(250,204,21,0.12)", color: YELLOW, border: "1px solid rgba(250,204,21,0.25)" }}>
                ⚡ PARLAY
              </span>
            )}
            <span className="text-[9px] font-bold" style={{ color: harmonyColor(winnerHarmony.harmony) }}>
              {energy.confidence}%
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex-1">
            <div className={`flex items-center gap-3 p-3 rounded-xl mb-2 transition-all`}
              style={{
                background: winnerSide === "away" ? harmonyBg(energy.away.harmony) : "rgba(255,255,255,0.02)",
                border: winnerSide === "away" ? `1px solid ${harmonyColor(energy.away.harmony)}30` : "1px solid transparent",
              }}>
              {game.awayLogo && <img src={game.awayLogo} alt="" className="w-8 h-8 object-contain" />}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white truncate">{game.awayTeam}</p>
                <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.35)" }}>{game.awayRecord}</p>
              </div>
              <div className="text-right">
                {game.status !== "pre" && (
                  <p className="text-lg font-black" style={{ color: winnerSide === "away" ? harmonyColor(energy.away.harmony) : "rgba(255,255,255,0.6)" }}>
                    {game.awayScore}
                  </p>
                )}
                <span className="text-[7px] font-bold px-1.5 py-0.5 rounded"
                  style={{ background: `${harmonyColor(energy.away.harmony)}14`, color: harmonyColor(energy.away.harmony) }}>
                  {energy.away.harmony}
                </span>
              </div>
            </div>

            <div className={`flex items-center gap-3 p-3 rounded-xl transition-all`}
              style={{
                background: winnerSide === "home" ? harmonyBg(energy.home.harmony) : "rgba(255,255,255,0.02)",
                border: winnerSide === "home" ? `1px solid ${harmonyColor(energy.home.harmony)}30` : "1px solid transparent",
              }}>
              {game.homeLogo && <img src={game.homeLogo} alt="" className="w-8 h-8 object-contain" />}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white truncate">{game.homeTeam}</p>
                <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.35)" }}>{game.homeRecord}</p>
              </div>
              <div className="text-right">
                {game.status !== "pre" && (
                  <p className="text-lg font-black" style={{ color: winnerSide === "home" ? harmonyColor(energy.home.harmony) : "rgba(255,255,255,0.6)" }}>
                    {game.homeScore}
                  </p>
                )}
                <span className="text-[7px] font-bold px-1.5 py-0.5 rounded"
                  style={{ background: `${harmonyColor(energy.home.harmony)}14`, color: harmonyColor(energy.home.harmony) }}>
                  {energy.home.harmony}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              <Trophy size={10} style={{ color: harmonyColor(winnerHarmony.harmony) }} />
              <p className="text-[9px] font-bold" style={{ color: harmonyColor(winnerHarmony.harmony) }}>
                {winnerTeam}
              </p>
            </div>
            <span className="text-[8px] px-1.5 py-0.5 rounded"
              style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.4)" }}>
              {energy.overUnder}
            </span>
            <span className="text-[8px] px-1.5 py-0.5 rounded"
              style={{ background: "rgba(96,165,250,0.08)", color: BLUE }}>
              {bestTeam} ML {bestMoneyline > 0 ? `+${bestMoneyline}` : bestMoneyline}
            </span>
            <span className="text-[8px] px-1.5 py-0.5 rounded"
              style={{ background: "rgba(250,204,21,0.08)", color: YELLOW }}>
              Spread {bestSpread > 0 ? `+${bestSpread}` : bestSpread}
            </span>
          </div>
          <button onClick={() => setOpen(o => !o)} className="flex items-center gap-1 text-[8px] hover:opacity-80 transition-opacity"
            style={{ color: "rgba(255,255,255,0.3)" }}>
            {open ? "Less" : "Details"} {open ? <ChevronUp size={10} /> : <ChevronDown size={10} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="px-4 pb-4 pt-2 border-t" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.025)" }}>
              <p className="text-[8px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Away Energy</p>
              <p className="text-xs font-bold" style={{ color: harmonyColor(energy.away.harmony) }}>
                {game.awayAbbr} — Imprint {energy.away.imprint}
              </p>
              <p className="text-[8px] mt-1" style={{ color: "rgba(255,255,255,0.35)" }}>
                Score: {energy.away.score}% · Date Energy {energy.dateEnergy}
              </p>
            </div>
            <div className="p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.025)" }}>
              <p className="text-[8px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Home Energy</p>
              <p className="text-xs font-bold" style={{ color: harmonyColor(energy.home.harmony) }}>
                {game.homeAbbr} — Imprint {energy.home.imprint}
              </p>
              <p className="text-[8px] mt-1" style={{ color: "rgba(255,255,255,0.35)" }}>
                Score: {energy.home.score}% · Date Energy {energy.dateEnergy}
              </p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-3">
            <div className="p-3 rounded-xl" style={{ background: "rgba(96,165,250,0.06)", border: "1px solid rgba(96,165,250,0.12)" }}>
              <p className="text-[8px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Moneyline</p>
              <p className="text-xs font-bold text-white">{energy.betCard.side}</p>
              <p className="text-[8px] mt-1" style={{ color: "rgba(255,255,255,0.35)" }}>{energy.betCard.reason}</p>
              <p className="text-[8px] mt-1" style={{ color: BLUE }}>{energy.betCard.odds > 0 ? `+${energy.betCard.odds}` : energy.betCard.odds}</p>
            </div>
            <div className="p-3 rounded-xl" style={{ background: "rgba(250,204,21,0.06)", border: "1px solid rgba(250,204,21,0.12)" }}>
              <p className="text-[8px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Spread</p>
              <p className="text-xs font-bold text-white">{energy.spreadPick.side}</p>
              <p className="text-[8px] mt-1" style={{ color: "rgba(255,255,255,0.35)" }}>{energy.spreadPick.reason}</p>
              <p className="text-[8px] mt-1" style={{ color: YELLOW }}>{energy.spreadPick.odds > 0 ? `+${energy.spreadPick.odds}` : energy.spreadPick.odds}</p>
            </div>
            <div className="p-3 rounded-xl" style={{ background: "rgba(74,222,128,0.06)", border: "1px solid rgba(74,222,128,0.12)" }}>
              <p className="text-[8px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Total</p>
              <p className="text-xs font-bold text-white">{energy.totalPickObject.side}</p>
              <p className="text-[8px] mt-1" style={{ color: "rgba(255,255,255,0.35)" }}>{energy.totalPickObject.reason}</p>
              <p className="text-[8px] mt-1" style={{ color: GREEN }}>{energy.totalPickObject.odds ? `O/U ${energy.totalPickObject.odds}` : "No total posted"}</p>
            </div>
          </div>
          <div className="mt-3 p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.02)" }}>
            <p className="text-[8px] uppercase tracking-widest mb-2" style={{ color: "rgba(255,255,255,0.3)" }}>Full Calculation</p>
            <div className="grid grid-cols-2 gap-3 text-[8px]">
              <div>
                <p style={{ color: "rgba(255,255,255,0.45)" }}>Date Digits</p>
                <p className="text-white">{energy.dateDigits.join(" + ")} = {energy.dateCompound}</p>
                <p className="mt-1" style={{ color: "rgba(255,255,255,0.45)" }}>Date Energy</p>
                <p className="text-white">{energy.dateEnergy}</p>
                <p className="mt-1" style={{ color: "rgba(255,255,255,0.45)" }}>Pairs</p>
                <p className="text-white">{energy.datePairs.join(" · ")}</p>
              </div>
              <div>
                <p style={{ color: "rgba(255,255,255,0.45)" }}>Away Imprint</p>
                <p className="text-white">{game.awayTeam}: {energy.away.imprint} → {energy.away.harmony} ({energy.away.score}%)</p>
                <p className="mt-1" style={{ color: "rgba(255,255,255,0.45)" }}>Home Imprint</p>
                <p className="text-white">{game.homeTeam}: {energy.home.imprint} → {energy.home.harmony} ({energy.home.score}%)</p>
                <p className="mt-1" style={{ color: "rgba(255,255,255,0.45)" }}>Winner</p>
                <p className="text-white">{winnerTeam} · {energy.confidence}%</p>
              </div>
            </div>
          </div>
          {game.venue && (
            <div className="flex items-center gap-1.5 mt-2">
              <MapPin size={9} style={{ color: "rgba(255,255,255,0.25)" }} />
              <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.25)" }}>{game.venue}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function SportsPredictionPage() {
  const today = new Date();
  const [month, setMonth] = useState(today.getMonth() + 1);
  const [day, setDay] = useState(today.getDate());
  const [year, setYear] = useState(today.getFullYear());
  const [league, setLeague] = useState("MLB");
  const [games, setGames] = useState<ESPNGame[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [allGames, setAllGames] = useState<Record<string, ESPNGame[]>>({});
  const fetchVersion = useRef(0);

  const de = useMemo(() => calcDateEnergy(month, day, year), [month, day, year]);
  const leagueInfo = getLeagueInfo(league);
  const isMaster = de.isMaster;

  const displayDate = new Date(year, month - 1, day).toLocaleDateString("en-US", {
    weekday: "long", month: "long", day: "numeric", year: "numeric"
  });

  const fetchGames = useCallback(async () => {
    const version = ++fetchVersion.current;
    setLoading(true);
    setError(null);
    try {
      const result = await fetchESPNGames(league, month, day, year);
      if (fetchVersion.current !== version) return;
      setGames(result);
    } catch {
      if (fetchVersion.current !== version) return;
      setError("Failed to fetch games");
      setGames([]);
    } finally {
      if (fetchVersion.current === version) setLoading(false);
    }
  }, [league, month, day, year]);

  useEffect(() => { fetchGames(); }, [fetchGames]);

  const fetchAllForParlay = useCallback(async () => {
    const majorLeagues = ["NBA", "NFL", "MLB", "NHL", "MLS", "Premier League", "La Liga"];
    const results: Record<string, ESPNGame[]> = {};
    await Promise.all(majorLeagues.map(async (lg) => {
      try {
        results[lg] = await fetchESPNGames(lg, month, day, year);
      } catch {
        results[lg] = [];
      }
    }));
    setAllGames(results);
    const preferredOrder = ["NBA", "MLB", "NHL", "NFL", "MLS", "Premier League", "La Liga"];
    const currentHasGames = (results[league]?.length ?? 0) > 0;
    if (!currentHasGames) {
      const firstWithGames = preferredOrder.find(lg => (results[lg]?.length ?? 0) > 0);
      if (firstWithGames) {
        setLeague(firstWithGames);
      }
    }
  }, [month, day, year]);

  useEffect(() => { fetchAllForParlay(); }, [fetchAllForParlay]);

  const parlayLegs = useMemo(() => {
    const legs: { game: ESPNGame; team: string; harmony: string; confidence: number; league: string }[] = [];
    for (const [lg, lgGames] of Object.entries(allGames)) {
      for (const g of lgGames) {
        if (legs.length >= 5) break;
        const e = analyzeGameEnergy(g, month, day, year);
        if (e.parlayWorthy) {
          const winner = e.predictedWinner === "home" ? g.homeTeam : g.awayTeam;
          const harmony = e.predictedWinner === "home" ? e.home.harmony : e.away.harmony;
          legs.push({ game: g, team: winner, harmony, confidence: e.confidence, league: lg });
        }
      }
    }
    return legs.sort((a, b) => b.confidence - a.confidence).slice(0, 4);
  }, [allGames, month, day, year]);

  const totalGamesToday = useMemo(() => {
    return Object.values(allGames).reduce((sum, g) => sum + g.length, 0);
  }, [allGames]);

  const leagueGameCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const [lg, lgGames] of Object.entries(allGames)) {
      if (lgGames.length > 0) counts[lg] = lgGames.length;
    }
    return counts;
  }, [allGames]);

  return (
    <div className="max-w-5xl space-y-6">

      <div className="rounded-2xl overflow-hidden" style={{
        background: "linear-gradient(135deg, hsl(228 40% 6%), hsl(228 30% 12%), hsl(228 35% 8%))",
        border: isMaster ? "1px solid rgba(250,204,21,0.2)" : "1px solid rgba(96,165,250,0.12)",
      }}>
        <div className="p-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "rgba(96,165,250,0.12)" }}>
                  <TrendingUp size={16} style={{ color: BLUE }} />
                </div>
                <div>
                  <p className="text-[8px] uppercase tracking-[0.2em] font-semibold" style={{ color: "rgba(255,255,255,0.35)" }}>
                    Sports Prediction AI
                  </p>
                  <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.25)" }}>
                    Live ESPN Schedules + Numerology Analysis
                  </p>
                </div>
              </div>

              <div className="flex items-end gap-3">
                <p className="font-black leading-none" style={{
                  fontSize: "4.5rem", color: isMaster ? YELLOW : BLUE,
                  lineHeight: 1, letterSpacing: "-0.04em",
                  textShadow: isMaster ? "0 0 40px rgba(250,204,21,0.15)" : "0 0 30px rgba(96,165,250,0.1)",
                }}>
                  {de.reduced}
                </p>
                <div className="pb-2">
                  {isMaster && (
                    <span className="inline-block text-[7px] font-black px-2 py-0.5 rounded mb-1"
                      style={{ background: "rgba(250,204,21,0.12)", color: YELLOW }}>
                      MASTER {de.reduced}
                    </span>
                  )}
                  <p className="text-sm font-bold text-white">{de.label}</p>
                  <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.35)" }}>{displayDate}</p>
                  <p className="text-[8px] mt-0.5" style={{ color: "rgba(255,255,255,0.25)" }}>
                    Compound {de.compound} → {de.reduced}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-end gap-2">
              {[
                { l: "Month", v: month, s: setMonth, min: 1, max: 12, w: "w-16" },
                { l: "Day", v: day, s: setDay, min: 1, max: 31, w: "w-16" },
                { l: "Year", v: year, s: setYear, min: 2020, max: 2030, w: "w-20" },
              ].map(f => (
                <div key={f.l}>
                  <p className="text-[8px] uppercase tracking-widest mb-1 text-center" style={{ color: "rgba(255,255,255,0.3)" }}>{f.l}</p>
                  <input type="number" min={f.min} max={f.max} value={f.v}
                    onChange={e => f.s(+e.target.value)}
                    className={`${f.w} text-center rounded-xl px-2 py-2.5 text-sm font-bold`}
                    style={{
                      background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
                      color: "white", outline: "none",
                    }} />
                </div>
              ))}
            </div>
          </div>

          {totalGamesToday > 0 && (
            <div className="mt-4 flex items-center gap-2 flex-wrap">
              <span className="text-[9px] font-semibold" style={{ color: GREEN }}>
                {totalGamesToday} games today
              </span>
              <span className="text-[8px]" style={{ color: "rgba(255,255,255,0.2)" }}>·</span>
              {Object.entries(leagueGameCounts).map(([lg, count]) => (
                <span key={lg} className="text-[8px] px-1.5 py-0.5 rounded-full"
                  style={{ background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.4)" }}>
                  {getLeagueInfo(lg).emoji} {count}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {parlayLegs.length > 0 && (
        <div className="rounded-2xl overflow-hidden" style={{
          background: "linear-gradient(135deg, hsl(45 60% 5%), hsl(228 30% 8%))",
          border: "1px solid rgba(250,204,21,0.18)",
        }}>
          <div className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "rgba(250,204,21,0.12)" }}>
                <Zap size={14} style={{ color: YELLOW }} />
              </div>
              <div>
                <p className="text-xs font-black tracking-wide" style={{ color: YELLOW }}>BEST PARLAY</p>
                <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>
                  {parlayLegs.length} legs from today's real schedule
                </p>
              </div>
            </div>
            <div className="space-y-2">
              {parlayLegs.map((leg, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-xl" style={{
                  background: "rgba(255,255,255,0.03)", border: "1px solid rgba(250,204,21,0.08)",
                }}>
                  <div className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-black shrink-0"
                    style={{ background: "rgba(250,204,21,0.15)", color: YELLOW }}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">
                      {leg.team}
                    </p>
                    <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.35)" }}>
                      {getLeagueInfo(leg.league).emoji} {leg.league} · {leg.harmony} · {leg.confidence}%
                    </p>
                  </div>
                  <span className="text-[7px] px-1.5 py-0.5 rounded font-bold"
                    style={{ background: `${harmonyColor(leg.harmony)}15`, color: harmonyColor(leg.harmony) }}>
                    {leg.harmony}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div>
        <p className="text-[8.5px] uppercase tracking-[0.2em] mb-3 font-semibold" style={{ color: "rgba(255,255,255,0.3)" }}>
          Select League
        </p>
        <div className="space-y-3">
          {LEAGUE_GROUPS.map(group => (
            <div key={group.label}>
              <p className="text-[7px] uppercase tracking-widest mb-1.5 ml-0.5" style={{ color: "rgba(255,255,255,0.2)" }}>
                {group.label}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {group.leagues.map(l => {
                  const info = getLeagueInfo(l);
                  const active = league === l;
                  const count = leagueGameCounts[l];
                  return (
                    <button key={l} onClick={() => setLeague(l)}
                      className="px-3 py-2 rounded-xl text-[9px] font-semibold transition-all flex items-center gap-1.5"
                      style={active ? {
                        background: "rgba(96,165,250,0.15)",
                        color: BLUE,
                        border: "1px solid rgba(96,165,250,0.3)",
                        boxShadow: "0 0 15px rgba(96,165,250,0.08)",
                      } : {
                        background: "rgba(255,255,255,0.03)",
                        color: count ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.25)",
                        border: "1px solid rgba(255,255,255,0.06)",
                      }}>
                      {info.emoji} {l}
                      {count !== undefined && (
                        <span className="text-[7px] px-1 rounded-full"
                          style={{ background: active ? "rgba(96,165,250,0.2)" : "rgba(74,222,128,0.12)", color: active ? BLUE : GREEN }}>
                          {count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <p className="text-base font-black text-white">{leagueInfo.emoji} {leagueInfo.label}</p>
            <span className="text-[9px] px-2.5 py-1 rounded-lg" style={{
              background: games.length > 0 ? "rgba(74,222,128,0.08)" : "rgba(255,255,255,0.04)",
              color: games.length > 0 ? GREEN : "rgba(255,255,255,0.35)",
              border: games.length > 0 ? "1px solid rgba(74,222,128,0.15)" : "1px solid rgba(255,255,255,0.06)",
            }}>
              {loading ? "Loading..." : `${games.length} game${games.length !== 1 ? "s" : ""}`}
            </span>
          </div>
          <button onClick={fetchGames} disabled={loading}
            className="flex items-center gap-1.5 text-[9px] px-3 py-1.5 rounded-lg transition-all hover:opacity-80"
            style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <RefreshCw size={10} className={loading ? "animate-spin" : ""} /> Refresh
          </button>
        </div>

        {loading ? (
          <div className="rounded-2xl p-12 text-center" style={{ background: "hsl(228 28% 7%)", border: "1px solid rgba(255,255,255,0.05)" }}>
            <Loader2 size={28} className="animate-spin mx-auto mb-3" style={{ color: BLUE }} />
            <p className="text-sm font-semibold text-white">Loading {leagueInfo.label} Schedule...</p>
            <p className="text-[9px] mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>Fetching from ESPN</p>
          </div>
        ) : error ? (
          <div className="rounded-2xl p-8 text-center" style={{ background: "hsl(228 28% 7%)", border: "1px solid rgba(239,68,68,0.15)" }}>
            <AlertCircle size={24} className="mx-auto mb-2" style={{ color: ROSE }} />
            <p className="text-sm font-semibold text-white mb-1">Connection Error</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{error}</p>
            <button onClick={fetchGames} className="mt-3 text-[10px] px-4 py-1.5 rounded-lg"
              style={{ background: "rgba(96,165,250,0.12)", color: BLUE, border: "1px solid rgba(96,165,250,0.2)" }}>
              Try Again
            </button>
          </div>
        ) : games.length === 0 ? (
          <div className="rounded-2xl p-10 text-center" style={{ background: "hsl(228 28% 7%)", border: "1px solid rgba(255,255,255,0.05)" }}>
            <Calendar size={32} className="mx-auto mb-3" style={{ color: "rgba(255,255,255,0.15)" }} />
            <p className="text-sm font-semibold text-white mb-1">No {leagueInfo.label} Games</p>
            <p className="text-xs mb-3" style={{ color: "rgba(255,255,255,0.35)" }}>
              No games scheduled for {displayDate}
            </p>
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.25)" }}>Try a league with games today:</p>
              {Object.entries(leagueGameCounts).slice(0, 4).map(([lg, count]) => (
                <button key={lg} onClick={() => setLeague(lg)} className="text-[9px] px-2 py-1 rounded-lg"
                  style={{ background: "rgba(74,222,128,0.08)", color: GREEN, border: "1px solid rgba(74,222,128,0.15)" }}>
                  {getLeagueInfo(lg).emoji} {lg} ({count})
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {games.map(g => (
              <GameCard key={g.id} game={g} month={month} day={day} year={year} />
            ))}
          </div>
        )}
      </div>

      {games.length > 0 && (
        <div className="rounded-2xl overflow-hidden" style={{ background: "hsl(228 28% 7%)", border: "1px solid rgba(255,255,255,0.05)" }}>
          <div className="px-5 py-3 border-b" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
            <p className="text-xs font-bold text-white">Energy Rankings — {leagueInfo.label}</p>
            <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>
              All teams playing today ranked by date energy {de.reduced} alignment
            </p>
          </div>
          <div className="divide-y divide-white/[0.04]">
            {games.flatMap(g => {
              const e = analyzeGameEnergy(g, month, day, year);
              return [
                { team: g.homeTeam, abbr: g.homeAbbr, logo: g.homeLogo, ...e.home, vs: g.awayAbbr },
                { team: g.awayTeam, abbr: g.awayAbbr, logo: g.awayLogo, ...e.away, vs: g.homeAbbr },
              ];
            })
              .sort((a, b) => b.score - a.score)
              .map((t, i) => (
                <div key={`${t.team}-${i}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-white/[0.02] transition-colors">
                  <span className="text-[9px] font-bold w-5 text-right" style={{ color: "rgba(255,255,255,0.2)" }}>{i + 1}</span>
                  {t.logo && <img src={t.logo} alt="" className="w-5 h-5 object-contain" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-bold text-white truncate">{t.team}</p>
                    <p className="text-[7.5px]" style={{ color: "rgba(255,255,255,0.25)" }}>vs {t.vs} · imp {t.imprint}</p>
                  </div>
                  <span className="text-[7.5px] font-bold px-2 py-0.5 rounded"
                    style={{ background: `${harmonyColor(t.harmony)}12`, color: harmonyColor(t.harmony) }}>
                    {t.harmony}
                  </span>
                  <p className="text-[10px] font-bold w-10 text-right" style={{ color: harmonyColor(t.harmony) }}>{t.score}%</p>
                </div>
              ))}
          </div>
        </div>
      )}

      <p className="text-[7px] text-center" style={{ color: "rgba(255,255,255,0.15)" }}>
        Live schedules from ESPN · Energy analysis for entertainment only · Bet responsibly
      </p>
    </div>
  );
}
