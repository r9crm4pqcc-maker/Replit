import { pgTable, text, serial, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const financeGoalsTable = pgTable("finance_goals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  targetAmount: real("target_amount").notNull(),
  currentAmount: real("current_amount").notNull().default(0),
  deadline: text("deadline"),
  category: text("category").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertFinanceGoalSchema = createInsertSchema(financeGoalsTable).omit({ id: true, createdAt: true });
export type InsertFinanceGoal = z.infer<typeof insertFinanceGoalSchema>;
export type FinanceGoal = typeof financeGoalsTable.$inferSelect;
