# Roadmap

- [x] Audit personal and universal cycle formulas across all modules
- [x] Add lunar lifepath, phase-favored numbers, and GG33/lunar lucky numbers
- [x] Unify letterology-based color compatibility across the app
- [x] Add complete publicly documented founding dates for sports brands
- [x] Verify affected routes and calculations
- [x] Full 5-part decode (game energies, teams, key players, city, stadium + date matrix) on every game card
- [ ] Team Dates editor tab (fix founding/stadium/city dates)
- [ ] Exact Healingood date chart (waiting on user's chart)
