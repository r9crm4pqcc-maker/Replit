import { createFileRoute } from "@tanstack/react-router";
import MatrixCalendarPage from "@/imported-pages/matrix-calendar";

export const Route = createFileRoute("/matrix-calendar")({
  head: () => ({
    meta: [
      { title: "Matrix Calendar — Matrix Command Center" },
      { name: "description", content: "Matrix Calendar tools and analysis." },
    ],
  }),
  component: MatrixCalendarPage,
});
