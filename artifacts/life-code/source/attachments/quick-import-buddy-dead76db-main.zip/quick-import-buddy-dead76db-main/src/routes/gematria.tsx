import { createFileRoute } from "@tanstack/react-router";
import GematriaPage from "@/imported-pages/gematria";

export const Route = createFileRoute("/gematria")({
  head: () => ({
    meta: [
      { title: "Gematria — Matrix Command Center" },
      { name: "description", content: "Gematria tools and analysis." },
    ],
  }),
  component: GematriaPage,
});
