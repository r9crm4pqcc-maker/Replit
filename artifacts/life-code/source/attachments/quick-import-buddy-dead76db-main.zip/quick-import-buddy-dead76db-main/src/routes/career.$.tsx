import { createFileRoute } from "@tanstack/react-router";
import CareerPage from "@/imported-pages/career";

export const Route = createFileRoute("/career/$")({
  head: () => ({
    meta: [
      { title: "Career Consultant — Matrix Command Center" },
      { name: "description", content: "Career Consultant tools and analysis." },
    ],
  }),
  component: CareerPage,
});
