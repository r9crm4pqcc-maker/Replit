import { createFileRoute } from "@tanstack/react-router";
import NumerologyPage from "@/imported-pages/numerology";

export const Route = createFileRoute("/numerology")({
  head: () => ({
    meta: [
      { title: "Numerology — Matrix Command Center" },
      { name: "description", content: "Numerology tools and analysis." },
    ],
  }),
  component: NumerologyPage,
});
