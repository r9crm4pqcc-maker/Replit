import { createFileRoute } from "@tanstack/react-router";
import ChakraPage from "@/imported-pages/chakra";

export const Route = createFileRoute("/chakra")({
  head: () => ({
    meta: [
      { title: "Chakra & Color Therapy — Matrix Command Center" },
      { name: "description", content: "Chakra & Color Therapy tools and analysis." },
    ],
  }),
  component: ChakraPage,
});
