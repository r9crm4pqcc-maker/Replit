import { useState, useEffect } from "react";
import {
  Outlet,
  Link,
  createRootRoute,
  HeadContent,
  Scripts,
  useRouterState,
} from "@tanstack/react-router";
import {
  Hash, Star, BookOpen, TrendingUp, Trophy, Dribbble,
  Heart, CalendarDays, Grid3x3, Layers, Briefcase,
  ChevronDown, ChevronRight, Menu, X, Zap, Home, Radio,
  Sparkles, Wind, Activity, Bot,
} from "lucide-react";
import type { ComponentType } from "react";

import appCss from "../styles.css?url";
import { ChatWidget } from "@/components/ChatWidget";

function ClientDate() {
  const [text, setText] = useState("");
  useEffect(() => {
    setText(
      new Date().toLocaleDateString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
        year: "numeric",
      }),
    );
  }, []);
  return <>{text}</>;
}

type NavGroup = {
  label: string;
  icon: ComponentType<{ size?: number; className?: string; style?: React.CSSProperties }>;
  color: string;
  href?: string;
  children?: { label: string; href: string }[];
};

const navGroups: NavGroup[] = [
  { label: "Home", icon: Home, href: "/", color: "hsl(212 95% 60%)" },
  {
    label: "Numerology", icon: Hash, color: "hsl(48 96% 53%)",
    children: [
      { label: "Core Numbers", href: "/numerology" },
      { label: "Karmic & Cycles", href: "/numerology/karmic" },
      { label: "Advanced Analysis", href: "/numerology/advanced" },
      { label: "Date Energy", href: "/numerology/date-energy" },
      { label: "Lucky Numbers & Colors", href: "/numerology/lucky" },
    ],
  },
  {
    label: "Astrology", icon: Star, color: "hsl(270 60% 65%)",
    children: [
      { label: "Chart Overview", href: "/astrology" },
      { label: "Dignities & Rulers", href: "/astrology/dignities" },
      { label: "Aspects & Patterns", href: "/astrology/aspects" },
      { label: "Timing & Transits", href: "/astrology/timing" },
      { label: "Nodes & Karma", href: "/astrology/nodes" },
      { label: "Vedic & Divisional", href: "/astrology/vedic" },
      { label: "Locational Astrology", href: "/astrology/locational" },
      { label: "Deep Chart & Remedies", href: "/astrology/advanced" },
    ],
  },
  {
    label: "Tools", icon: Grid3x3, color: "hsl(160 70% 50%)",
    children: [
      { label: "Gematria", href: "/gematria" },
      { label: "Matrix Calendar", href: "/matrix-calendar" },
      { label: "Tarot", href: "/tarot" },
      { label: "Compatibility", href: "/compatibility" },
      { label: "Forecasts", href: "/forecasts" },
      { label: "Chinese Astrology", href: "/bazi" },
      { label: "Feng Shui", href: "/feng-shui" },
      { label: "Chakra & Color", href: "/chakra" },
      { label: "Rife Frequencies", href: "/rife" },
      { label: "Career Consultant", href: "/career" },
      { label: "Day-to-Day Life AI", href: "/day-life" },
    ],
  },
  {
    label: "Sports AI", icon: Trophy, color: "hsl(28 95% 55%)",
    children: [
      { label: "Sports Prediction", href: "/sports-prediction" },
      { label: "Soccer AI", href: "/soccer-ai" },
    ],
  },
  { label: "Stock Market AI", icon: TrendingUp, href: "/trading-ai", color: "hsl(142 70% 50%)" },
];

function NavGroupItem({ group, onClose }: { group: NavGroup; onClose: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const Icon = group.icon;
  const [open, setOpen] = useState(
    () => group.children?.some((c) => pathname.startsWith(c.href)) ?? false,
  );

  if (group.href) {
    const isActive = pathname === group.href;
    return (
      <Link
        to={group.href}
        onClick={onClose}
        className={`nav-item ${isActive ? "nav-item-active" : "nav-item-inactive"}`}
      >
        <span className="shrink-0 w-5 flex items-center justify-center">
          <Icon size={15} style={{ color: isActive ? group.color : undefined }} />
        </span>
        <span className="flex-1 truncate">{group.label}</span>
      </Link>
    );
  }

  const anyChildActive = group.children?.some((c) => pathname.startsWith(c.href));

  return (
    <div>
      <button
        onClick={() => setOpen((o) => !o)}
        className={`nav-item w-full text-left ${anyChildActive ? "nav-item-active" : "nav-item-inactive"}`}
      >
        <span className="shrink-0 w-5 flex items-center justify-center">
          <Icon size={15} style={{ color: anyChildActive ? group.color : undefined }} />
        </span>
        <span className="flex-1 truncate">{group.label}</span>
        {open ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
      </button>
      {open && group.children && (
        <div
          className="ml-5 mt-0.5 pl-3 space-y-0.5"
          style={{ borderLeft: "1px solid hsl(228 20% 14%)" }}
        >
          {group.children.map((child) => {
            const isActive =
              pathname === child.href || pathname.startsWith(child.href + "/");
            return (
              <Link
                key={child.href}
                to={child.href}
                onClick={onClose}
                className={`flex items-center py-1.5 px-2 rounded-md text-xs transition-all duration-100 ${
                  isActive ? "font-semibold" : "opacity-50 hover:opacity-80"
                }`}
                style={{ color: isActive ? group.color : undefined }}
              >
                {child.label}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <>
      {open && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
          style={{ transition: "opacity 0.3s ease" }}
        />
      )}
      <aside
        className={`fixed top-0 left-0 h-full w-[15.5rem] flex flex-col z-50 transition-transform duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        } lg:static lg:z-auto`}
        style={{
          background: "hsl(var(--sidebar))",
          borderRight: "1px solid hsl(var(--sidebar-border))",
        }}
      >
        <div
          className="px-4 py-4 flex items-center justify-between shrink-0"
          style={{ borderBottom: "1px solid hsl(var(--sidebar-border))" }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-[10px] flex items-center justify-center"
              style={{
                background: "var(--gradient-gold)",
                boxShadow: "var(--shadow-gold)",
              }}
            >
              <Zap size={15} style={{ color: "hsl(0 0% 6%)" }} />
            </div>
            <div>
              <h1
                className="text-[13px] font-bold tracking-[0.14em] font-display"
                style={{ color: "hsl(42 40% 92%)" }}
              >
                DASHBOARD
              </h1>
              <p
                className="text-[8.5px] tracking-[0.16em] uppercase"
                style={{ color: "hsl(42 55% 54%)" }}
              >
                Decode Suite
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden opacity-50 hover:opacity-90 transition-opacity"
            style={{ color: "hsl(42 40% 88%)" }}
          >
            <X size={16} />
          </button>

        </div>

        <nav className="flex-1 overflow-y-auto p-2 space-y-px">
          {navGroups.map((group) => (
            <NavGroupItem key={group.label} group={group} onClose={onClose} />
          ))}
        </nav>

        <div
          className="px-4 py-3 shrink-0"
          style={{ borderTop: "1px solid hsl(var(--sidebar-border))" }}
        >
          <div className="flex items-center gap-2">
            <div className="status-dot-active" />
            <span
              className="text-[11px] font-medium"
              style={{ color: "hsl(var(--muted-foreground))" }}
            >
              System Online
            </span>
          </div>
          <p
            className="text-[10px] mt-0.5 font-medium"
            style={{ color: "hsl(228 12% 28%)" }}
          >
            <ClientDate />
          </p>
        </div>
      </aside>
    </>
  );
}

function moduleForPath(pathname: string): { id: string; title: string } | null {
  if (pathname.startsWith("/numerology")) return { id: "numerology", title: "Numerology Chat" };
  if (pathname.startsWith("/astrology")) return { id: "astrology", title: "Astrology Chat" };
  if (pathname.startsWith("/sports-prediction") || pathname.startsWith("/soccer-ai")) return { id: "sports", title: "Sports AI Chat" };
  if (pathname.startsWith("/trading-ai")) return { id: "trading", title: "Stock Market AI Chat" };
  if (pathname === "/" ) return null;
  return { id: "tools", title: "Tools Chat" };
}

function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const mod = moduleForPath(pathname);
  return (
    <div
      className="flex h-screen overflow-hidden sparkle-bg"
      style={{ background: "hsl(var(--background))" }}
    >
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative z-10">
        <header
          className="lg:hidden flex items-center gap-3 px-4 py-3 shrink-0"
          style={{
            background: "hsl(var(--sidebar))",
            borderBottom: "1px solid hsl(var(--sidebar-border))",
          }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="text-white/50 hover:text-white/80 transition-colors duration-200"
          >
            <Menu size={20} />
          </button>
          <span className="text-[13px] font-bold tracking-[0.14em] font-display" style={{ color: "hsl(42 40% 92%)" }}>
            DASHBOARD
          </span>
        </header>
        <main className="flex-1 overflow-y-auto px-5 py-6 lg:px-10 lg:py-8">
          <Outlet />
        </main>
      </div>
      {mod && <ChatWidget moduleId={mod.id} title={mod.title} />}
    </div>
  );
}

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Dashboard — Numerology, Astrology & Decode AI" },
      { name: "description", content: "Numerology, astrology, sports and stock market decode intelligence." },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: Layout,
  notFoundComponent: NotFoundComponent,
});


function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}
