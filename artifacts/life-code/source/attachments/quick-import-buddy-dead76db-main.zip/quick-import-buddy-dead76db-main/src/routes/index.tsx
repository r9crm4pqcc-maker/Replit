import { createFileRoute } from "@tanstack/react-router";
import HomePage from "@/imported-pages/home";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Matrix Command Center — Matrix Command Center" },
      { name: "description", content: "Matrix Command Center tools and analysis." },
    ],
  }),
  component: HomePage,
});
