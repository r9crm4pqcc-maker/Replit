import { createFileRoute } from "@tanstack/react-router";
import BaZiPage from "@/imported-pages/bazi";

export const Route = createFileRoute("/bazi")({
  head: () => ({
    meta: [
      { title: "Chinese Astrology — Matrix Command Center" },
      { name: "description", content: "Chinese Astrology tools and analysis." },
    ],
  }),
  component: BaZiPage,
});
