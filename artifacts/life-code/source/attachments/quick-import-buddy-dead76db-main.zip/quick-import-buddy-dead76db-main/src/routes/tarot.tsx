import { createFileRoute } from "@tanstack/react-router";
import TarotPage from "@/imported-pages/tarot";

export const Route = createFileRoute("/tarot")({
  head: () => ({
    meta: [
      { title: "Tarot — Matrix Command Center" },
      { name: "description", content: "Tarot tools and analysis." },
    ],
  }),
  component: TarotPage,
});
