import { createFileRoute } from "@tanstack/react-router";
import CompatibilityPage from "@/imported-pages/compatibility";

export const Route = createFileRoute("/compatibility")({
  head: () => ({
    meta: [
      { title: "Compatibility — Matrix Command Center" },
      { name: "description", content: "Compatibility tools and analysis." },
    ],
  }),
  component: CompatibilityPage,
});
