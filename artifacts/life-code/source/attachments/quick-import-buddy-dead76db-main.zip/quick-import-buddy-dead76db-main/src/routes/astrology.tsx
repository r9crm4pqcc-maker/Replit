import { createFileRoute } from "@tanstack/react-router";
import AstrologyPage from "@/imported-pages/astrology";

export const Route = createFileRoute("/astrology")({
  head: () => ({
    meta: [
      { title: "Astrology — Matrix Command Center" },
      { name: "description", content: "Astrology tools and analysis." },
    ],
  }),
  component: AstrologyPage,
});
