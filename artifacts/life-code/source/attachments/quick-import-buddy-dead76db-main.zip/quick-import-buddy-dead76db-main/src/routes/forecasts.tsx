import { createFileRoute } from "@tanstack/react-router";
import ForecastsPage from "@/imported-pages/forecasts";

export const Route = createFileRoute("/forecasts")({
  head: () => ({
    meta: [
      { title: "Forecasts — Matrix Command Center" },
      { name: "description", content: "Forecasts tools and analysis." },
    ],
  }),
  component: ForecastsPage,
});
