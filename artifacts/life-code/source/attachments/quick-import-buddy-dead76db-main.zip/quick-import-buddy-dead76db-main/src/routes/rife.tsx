import { createFileRoute } from "@tanstack/react-router";
import RifePage from "@/imported-pages/rife";

export const Route = createFileRoute("/rife")({
  head: () => ({
    meta: [
      { title: "Rife Frequencies — Matrix Command Center" },
      { name: "description", content: "Rife Frequencies tools and analysis." },
    ],
  }),
  component: RifePage,
});
