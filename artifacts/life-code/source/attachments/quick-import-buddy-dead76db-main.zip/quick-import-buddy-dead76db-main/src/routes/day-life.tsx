import { createFileRoute } from "@tanstack/react-router";
import DayLifePage from "@/imported-pages/day-life";

export const Route = createFileRoute("/day-life")({
  head: () => ({
    meta: [
      { title: "Day-to-Day Life AI — Matrix Command Center" },
      { name: "description", content: "Day-to-Day Life AI tools and analysis." },
    ],
  }),
  component: DayLifePage,
});
