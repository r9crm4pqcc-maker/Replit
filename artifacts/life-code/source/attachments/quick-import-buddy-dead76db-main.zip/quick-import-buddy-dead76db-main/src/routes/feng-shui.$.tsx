import { createFileRoute } from "@tanstack/react-router";
import FengShuiPage from "@/imported-pages/feng-shui";

export const Route = createFileRoute("/feng-shui/$")({
  head: () => ({
    meta: [
      { title: "Feng Shui — Matrix Command Center" },
      { name: "description", content: "Feng Shui tools and analysis." },
    ],
  }),
  component: FengShuiPage,
});
