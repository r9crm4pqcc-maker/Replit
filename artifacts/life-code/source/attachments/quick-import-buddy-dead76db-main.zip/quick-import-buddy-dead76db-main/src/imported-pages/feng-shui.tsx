import { Link } from "@/lib/wouter";
import { useParams } from "@/lib/wouter";
import { useState } from "react";
import { Home, ChevronRight } from "lucide-react";
import { FENG_SHUI, calcAddressNumber, FLYING_STARS_2026 } from "@/lib/feng-shui";
import { LearnTheCode, OutputTags } from "@/components/LearnTheCode";

const YELLOW = "#facc15";
const BLUE   = "#60a5fa";
const GREEN  = "#4ade80";
const PURPLE = "#a855f7";
const ROSE   = "#fb7185";
const ORANGE = "#fb923c";

const STRENGTH_COLOR = (s: string) =>
  s === "Best" ? GREEN : s === "Good" ? YELLOW : s === "Moderate" ? BLUE : s === "Worst" ? "#ef4444" : ROSE;

const tabs = [
  { key: "",         label: "Kua Profile",    href: "/feng-shui" },
  { key: "dirs",     label: "Directions",     href: "/feng-shui/dirs" },
  { key: "rooms",    label: "Room Advice",    href: "/feng-shui/rooms" },
  { key: "colors",   label: "Color Therapy",  href: "/feng-shui/colors" },
  { key: "stars",    label: "Flying Stars",   href: "/feng-shui/stars" },
  { key: "address",  label: "Address Calc",   href: "/feng-shui/address" },
];

export default function FengShuiPage() {
  const params = useParams<{ sub?: string }>();
  const sub = params.sub ?? "";
  const [addressInput, setAddressInput] = useState("1234");
  const addr = calcAddressNumber(addressInput);

  return (
    <div className="max-w-4xl space-y-5">
      {/* Header */}
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>
          <Home size={12} style={{ color: ORANGE }} />
          <span>Feng Shui</span>
          <ChevronRight size={10} />
          <span style={{ color: ORANGE }}>Kua 9 · East Group · Cristian Zavala</span>
        </div>
        <h1 className="page-title">Feng Shui</h1>
        <p className="page-subtitle">Kua Number Analysis · Directions · Flying Stars 2026</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t => (
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub === t.key
                ? { background: "rgba(251,146,60,0.12)", color: ORANGE, border: "1px solid rgba(251,146,60,0.25)" }
                : { color: "rgba(255,255,255,0.4)", border: "1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── KUA PROFILE ── */}
      {sub === "" && (
        <div className="space-y-4">
          <LearnTheCode
            title="Kua Number Formula"
            steps={[
              { step: "Sum birth year digits", formula: "Year digits → reduce to single digit", example: "2009 → 2+0+0+9=11 → 1+1=2" },
              { step: "Male formula (post-2000)", formula: "9 − reduced year = Kua (if 0, becomes 9)", example: "9 − 9 = 0 → becomes 9 → Kua 9" },
              { step: "Female formula (post-2000)", formula: "6 + reduced year = Kua (reduce if needed)", example: "6 + 9 = 15 → 1+5 = 6 → Kua 6 (female)" },
              { step: "Address reduction", formula: "Sum all digits in house number → reduce to single digit", example: "1234 → 1+2+3+4=10 → 1+0=1" },
            ]}
            confidenceTag="High"
            sourceLabel="Per GG33 Academy + Classical Feng Shui"
          />

          {/* Kua hero */}
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${ORANGE}25` }}>
            <div className="flex items-center gap-5">
              <div className="text-center p-5 rounded-2xl shrink-0" style={{ background: "rgba(251,146,60,0.1)", border: `1px solid ${ORANGE}30` }}>
                <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Kua Number</p>
                <p className="text-6xl font-black" style={{ color: ORANGE }}>{FENG_SHUI.kuaNumber}</p>
                <p className="text-xs font-semibold mt-1" style={{ color: ORANGE }}>{FENG_SHUI.kuaName}</p>
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap gap-2 mb-3">
                  <span className="text-[9px] px-2 py-0.5 rounded font-bold" style={{ background: "rgba(250,204,21,0.12)", color: YELLOW }}>
                    Group: {FENG_SHUI.kuaGroup}
                  </span>
                  <span className="text-[9px] px-2 py-0.5 rounded" style={{ background: "rgba(74,222,128,0.1)", color: GREEN }}>
                    Element: {FENG_SHUI.element}
                  </span>
                  <span className="text-[9px] px-2 py-0.5 rounded" style={{ background: "rgba(96,165,250,0.1)", color: BLUE }}>
                    LP Element: {FENG_SHUI.lifePathElement}
                  </span>
                </div>
                <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.6)" }}>{FENG_SHUI.interpretation}</p>
                <OutputTags
                  calculated="Kua 9 — East Group (E best direction)"
                  interpretive="Fire illuminator, spotlight, brilliance"
                  confidence="High"
                />
              </div>
            </div>
          </div>

          {/* Best direction summary */}
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: GREEN }}>Best Directions</p>
              {FENG_SHUI.bestDirections.map(d => (
                <div key={d.direction} className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black shrink-0" style={{ background: `${STRENGTH_COLOR(d.strength)}15`, color: STRENGTH_COLOR(d.strength) }}>
                    {d.direction.slice(0, 2)}
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold" style={{ color: STRENGTH_COLOR(d.strength) }}>{d.direction}</p>
                    <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>{d.code}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: ROSE }}>Avoid</p>
              {FENG_SHUI.worstDirections.map(d => (
                <div key={d.direction} className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black shrink-0" style={{ background: "rgba(251,113,133,0.12)", color: ROSE }}>
                    {d.direction.slice(0, 2)}
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold" style={{ color: ROSE }}>{d.direction}</p>
                    <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>{d.code}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── DIRECTIONS ── */}
      {sub === "dirs" && (
        <div className="space-y-3">
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>Kua 9 — East Group personal directions. Face these directions for maximum energy alignment.</p>
          {[...FENG_SHUI.bestDirections, ...FENG_SHUI.worstDirections].map(d => {
            const col = STRENGTH_COLOR(d.strength);
            return (
              <div key={d.direction} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${col}20` }}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-lg font-black shrink-0" style={{ background: `${col}12`, color: col }}>
                    {d.direction.slice(0, 2)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold text-white">{d.direction}</p>
                      <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background: `${col}15`, color: col }}>{d.strength}</span>
                    </div>
                    <p className="text-[10px]" style={{ color: col }}>{d.code}</p>
                  </div>
                </div>
                <p className="text-xs mb-2" style={{ color: "rgba(255,255,255,0.6)" }}>{d.benefit}</p>
                <div className="flex items-start gap-2">
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded shrink-0" style={{ background: "rgba(96,165,250,0.1)", color: BLUE }}>ACTIVATE</span>
                  <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.45)" }}>{d.activate}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── ROOMS ── */}
      {sub === "rooms" && (
        <div className="space-y-3">
          {FENG_SHUI.roomAdvice.map(r => (
            <div key={r.room} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
              <p className="text-sm font-bold text-white mb-2">{r.room}</p>
              <div className="grid grid-cols-2 gap-3 mb-2">
                <div>
                  <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color: GREEN }}>Best Location</p>
                  <p className="text-xs font-semibold" style={{ color: GREEN }}>{r.bestLocation}</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color: ROSE }}>Avoid</p>
                  <p className="text-xs font-semibold" style={{ color: ROSE }}>{r.avoidLocation}</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-[9px] font-bold px-2 py-0.5 rounded shrink-0" style={{ background: "rgba(250,204,21,0.1)", color: YELLOW }}>TIP</span>
                <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.5)" }}>{r.tip}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── COLORS ── */}
      {sub === "colors" && (
        <div className="space-y-4">
          {FENG_SHUI.colorTherapy.map(ct => (
            <div key={ct.purpose} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>{ct.purpose}</p>
              <div className="flex flex-wrap gap-2 mb-3">
                {ct.colors.map(c => (
                  <span key={c} className="px-3 py-1.5 rounded-full text-xs font-semibold" style={{ background: "rgba(250,204,21,0.1)", color: YELLOW, border: "1px solid rgba(250,204,21,0.2)" }}>{c}</span>
                ))}
              </div>
              {ct.avoid.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-2">
                  <span className="text-[9px] font-bold" style={{ color: ROSE }}>AVOID:</span>
                  {ct.avoid.map(c => (
                    <span key={c} className="px-2 py-0.5 rounded text-[10px]" style={{ background: "rgba(251,113,133,0.1)", color: ROSE }}>{c}</span>
                  ))}
                </div>
              )}
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>{ct.why}</p>
            </div>
          ))}
        </div>
      )}

      {/* ── FLYING STARS 2026 ── */}
      {sub === "stars" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: YELLOW }}>Flying Stars 2026 — Annual Star Positions</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>Each year the 9 Flying Stars move to different sectors. Knowing where they land helps you activate positive sectors and protect against negative ones.</p>
          </div>
          {FLYING_STARS_2026.map(s => {
            const isBad = s.effect.includes("DANGER") || s.effect.includes("ILLNESS") || s.effect.includes("CONFLICT") || s.effect.includes("ROBBERY");
            const isGood = s.effect.includes("WEALTH") || s.effect.includes("Career") || s.effect.includes("Authority");
            const col = isBad ? ROSE : isGood ? GREEN : YELLOW;
            return (
              <div key={s.sector} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${col}18` }}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl font-black shrink-0" style={{ background: `${col}12`, color: col }}>
                    {s.star}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">{s.sector}</p>
                    <p className="text-[9px]" style={{ color: col }}>{s.effect.split("—")[0].trim()}</p>
                  </div>
                  <span className="ml-auto text-[9px] px-2 py-0.5 rounded font-bold" style={{ background: `${col}12`, color: col }}>
                    Star {s.star}
                  </span>
                </div>
                <p className="text-xs mb-2" style={{ color: "rgba(255,255,255,0.6)" }}>{s.effect}</p>
                <div className="flex items-start gap-2">
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded shrink-0" style={{ background: "rgba(96,165,250,0.1)", color: BLUE }}>REMEDY</span>
                  <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.45)" }}>{s.remedy}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── ADDRESS CALC ── */}
      {sub === "address" && (
        <div className="space-y-4">
          <LearnTheCode
            title="Address Number Calculator"
            steps={[
              { step: "Extract address number", formula: "Take only the numeric portion of your address", example: "1234 N Main St → 1234" },
              { step: "Sum all digits", formula: "Add all digits together", example: "1+2+3+4=10" },
              { step: "Reduce to single digit", formula: "Continue reducing until 1-9 (preserve 11/22/33)", example: "10 → 1+0 = 1" },
              { step: "Match to Kua or LP", formula: "Compare to Kua 9 and Life Path 1", example: "Reduced=1 → matches LP 1 = EXCELLENT" },
            ]}
            confidenceTag="High"
          />

          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>Enter Your Address Number</p>
            <div className="flex gap-3 items-center mb-4">
              <input
                type="text"
                value={addressInput}
                onChange={e => setAddressInput(e.target.value)}
                placeholder="e.g. 1234"
                className="flex-1 px-4 py-3 rounded-xl text-sm font-medium"
                style={{ background: "rgba(251,146,60,0.06)", border: "1px solid rgba(251,146,60,0.2)", color: "white", outline: "none" }}
              />
            </div>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Compound</p>
                <p className="text-4xl font-black" style={{ color: BLUE }}>{addr.compound}</p>
              </div>
              <div className="text-center">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Reduced</p>
                <p className="text-4xl font-black" style={{ color: YELLOW }}>{addr.reduced}</p>
              </div>
              <div className="flex-1">
                <p className="text-xs font-semibold" style={{ color: addr.harmony.startsWith("PERFECT") ? GREEN : addr.harmony.startsWith("EXCELLENT") ? YELLOW : BLUE }}>
                  {addr.harmony}
                </p>
                <OutputTags
                  calculated={`Compound: ${addr.compound} → Reduced: ${addr.reduced}`}
                  interpretive={addr.harmony}
                  confidence="High"
                />
              </div>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>Best Address Numbers for Cristian</p>
            {[
              { num: 9, reason: "Kua 9 + PY9 = double resonance. Fire/illumination + completion energy." },
              { num: 1, reason: "Life Path 1 = pioneer energy. Fresh starts and leadership." },
              { num: 8, reason: "Birthday & Personality 8. Saturn/authority energy at home." },
              { num: 4, reason: "Maturity number. Foundation and structure energy." },
              { num: 28, reason: "Compound LP 28 = wealth portal. Extremely powerful if unreduced." },
              { num: 10, reason: "Soccer jersey number. LP compound activation." },
            ].map(n => (
              <div key={n.num} className="flex items-center gap-3 mb-2">
                <p className="text-xl font-black w-8 text-right" style={{ color: YELLOW }}>{n.num}</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>{n.reason}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
