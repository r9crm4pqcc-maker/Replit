// @ts-nocheck
import { useParams, Link } from "@/lib/wouter";
import { Dribbble, ChevronRight } from "lucide-react";
import { useMemo, useState, useEffect, useCallback } from "react";
import { PROFILE } from "@/lib/profile";
import { calcGameDay, getWeeklyPlan, DIET_PLAN, SEASON_SCHEDULE, compatLabel as compatTier } from "@/lib/soccer-ai";
import { calcCoreNumbers } from "@/lib/numerology";
import { bestColorsFor } from "@/lib/colorology";
import { brandDecode } from "@/lib/sports-brands";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);
const BLUE  = "hsl(212 95% 65%)";
const YELLOW= "hsl(48 96% 53%)";
const GREEN = "#4ade80";
const ROSE  = "#f472b6";
const PURPLE= "hsl(270 60% 70%)";

// ─── ATHLETICISM DATA ─────────────────────────────────────────────────────────

const GOATA_EXERCISES = [
  "Goata Walk",
  "Bear Crawl",
  "Child Rockers",
  "Pigeon Rock",
  "Goata Squat",
  "Goata Lunge",
];

const FASCIA_LEVELS: Record<number, { weeks: string; duration: string; criteria: string; exercises: string[] }> = {
  1: {
    weeks: "Weeks 1–3", duration: "40 min",
    criteria: "Advance once glute engagement improves and calf/ankle reliance decreases.",
    exercises: [
      "Fascia Adhesion Rolling – 20 min (2 min/spot: feet, calves, TFL, hip flexor, quads)",
      "Towel Curls – 3 min per foot",
      "Retract + Curl – 3 min per foot",
      "Marble Swing – 3 min per leg",
      "Gait Cycle – 3 min per foot",
    ],
  },
  2: {
    weeks: "Weeks 4–6", duration: "50 min",
    criteria: "Move to Level 3 when consistent glute activation is present.",
    exercises: [
      "Fascia Adhesion Rolling – 20 min (2 min/spot: feet, calves, TFL, hip flexor, quads)",
      "Towel Curls – 3 min",
      "Retract + Curl – 3 min",
      "Marble Swing – 3 min per leg",
      "Gait Cycle – 3 min per leg",
      "Hyperarch Hop – 3 min",
      "Hand Curl – 2 min, 1 set",
      "Push Hands – 3 min",
      "Wall Bounce – 3 min",
    ],
  },
  3: {
    weeks: "Weeks 7–9", duration: "1 hr 10 min",
    criteria: "Advance once glutes feel strong.",
    exercises: [
      "Towel Curls – 3 min",
      "Retract + Curl – 3 min",
      "Marble Swing – 3 min per leg",
      "Gait Cycle – 3 min per leg",
      "Hyperarch Hop – 3 min",
      "Hand Curl – 2 min, 1 set",
      "Push Hands – 3 min",
      "Wall Bounce – 3 min",
      "Triangle – 2–3 min per side",
      "Figure 8 – 2–3 min per side",
      "Single Leg Hop – 1–2 min per side",
      "Hyperarch Wall Sit w/ Med Ball – 1 min → build to 1–4 min",
      "Standing Leg Stretch w/ Marble Grip – 2 min, 2 rounds per side",
      "Crescent Walk Forward/Backward – 6–8 steps, 2–3 min",
      "Big Toe Press on Marble – 3 min per foot",
      "Dorsiflexed Toes Walking – 5–10m forward, 2 rounds",
      "Marble Grab + Heel Raise w/ Med Ball – 3 min, 2 rounds",
    ],
  },
  4: {
    weeks: "Weeks 10–12", duration: "1 hr 25 min",
    criteria: "Full fascial system connection, integrated strength + mobility.",
    exercises: [
      "Towel Curls – 3 min",
      "Retract + Curl – 3 min",
      "Marble Swing – 3 min per leg",
      "Gait Cycle – 3 min per leg",
      "Hyperarch Hop – 3 min",
      "Hand Curl – 2 min, 1 set",
      "Push Hands – 3 min",
      "Wall Bounce – 3 min",
      "Triangle – 3 min per side",
      "Figure 8 – 3 min per side",
      "Single Leg Hop – 1–2 min per side",
      "Hyperarch Wall Sit w/ Med Ball – 1 min → build to 1–4 min",
      "Standing Leg Stretch w/ Marble Grip – 2 min, 2 rounds per side",
      "Crescent Walk Forward/Backward – 6–8 steps, 3 min",
      "Big Toe Press on Marble – 3 min per foot",
      "Dorsiflexed Toes Walking – 5–10m, 2–3 rounds",
      "Marble Grab + Heel Raise w/ Med Ball – 2–3 min, 2–3 rounds",
      "HFT Lunge – Bodyweight → 10 lbs, 2–5 min",
      "HFT Bear Walk – 20–30 steps, 2 sets",
      "HFT Towel Sweep – 3 min per side",
    ],
  },
};

function getISOWeek(d: Date): string {
  const tmp = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  tmp.setUTCDate(tmp.getUTCDate() + 4 - (tmp.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((+tmp - +yearStart) / 86400000 + 1) / 7);
  return `${tmp.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

const LS: Storage | null = typeof window === "undefined" ? null : window.localStorage;

const ATHS_LEVEL_KEY    = "ath_level";
const ATHS_CHECKS_KEY   = "ath_checks";
const ATHS_SESSIONS_KEY = "ath_sessions";

function useAthleticism() {
  // ── Level ──
  const [level, setLevelState] = useState<number>(() => {
    return parseInt(LS?.getItem(ATHS_LEVEL_KEY) ?? "1") || 1;
  });
  const setLevel = useCallback((l: number) => {
    setLevelState(l);
    LS?.setItem(ATHS_LEVEL_KEY, String(l));
  }, []);

  // ── Today's exercise checks ──
  const [checks, setChecks] = useState<Record<string, boolean | string>>(() => {
    try {
      const raw = JSON.parse(LS?.getItem(ATHS_CHECKS_KEY) ?? "{}");
      return raw._date === todayISO() ? raw : { _date: todayISO() };
    } catch { return { _date: todayISO() }; }
  });

  const toggleCheck = useCallback((key: string) => {
    setChecks(prev => {
      const today = todayISO();
      const base = (prev._date === today) ? { ...prev } : { _date: today };
      const next = { ...base, [key]: !base[key] };
      LS?.setItem(ATHS_CHECKS_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  // ── Weekly session log ──
  const [sessions, setSessions] = useState<{ week: string; days: string[] }>(() => {
    try {
      const raw = JSON.parse(LS?.getItem(ATHS_SESSIONS_KEY) ?? "{}");
      const thisWeek = getISOWeek(new Date());
      if (raw.week === thisWeek) return raw;
      // New week — check if last week was incomplete and surface that later
      return { week: thisWeek, days: [] };
    } catch { return { week: getISOWeek(new Date()), days: [] }; }
  });

  const logSession = useCallback(() => {
    setSessions(prev => {
      const thisWeek = getISOWeek(new Date());
      const today = todayISO();
      const base = prev.week === thisWeek ? { ...prev } : { week: thisWeek, days: [] };
      if (!base.days.includes(today)) base.days = [...base.days, today];
      LS?.setItem(ATHS_SESSIONS_KEY, JSON.stringify(base));
      return base;
    });
  }, []);

  // ── Refresh checks at midnight ──
  useEffect(() => {
    const id = setInterval(() => {
      const today = todayISO();
      setChecks(prev => {
        if (prev._date !== today) {
          const fresh = { _date: today };
          LS?.setItem(ATHS_CHECKS_KEY, JSON.stringify(fresh));
          return fresh;
        }
        return prev;
      });
      setSessions(prev => {
        const thisWeek = getISOWeek(new Date());
        if (prev.week !== thisWeek) {
          const fresh = { week: thisWeek, days: [] };
          LS?.setItem(ATHS_SESSIONS_KEY, JSON.stringify(fresh));
          return fresh;
        }
        return prev;
      });
    }, 20_000);
    return () => clearInterval(id);
  }, []);

  const fasciaExercises = FASCIA_LEVELS[level].exercises;
  const totalFascia = fasciaExercises.length;
  const totalGoata  = GOATA_EXERCISES.length;
  const doneFascia  = fasciaExercises.filter((_, i) => checks[`f${i}`] === true).length;
  const doneGoata   = GOATA_EXERCISES.filter((_, i) => checks[`g${i}`] === true).length;

  const sessionLoggedToday = sessions.days.includes(todayISO());
  const weekSessions = sessions.days.length;
  const dayOfWeek = new Date().getDay(); // 0=Sun
  const daysLeftInWeek = 7 - dayOfWeek;
  const needsWarning = weekSessions < 3 && daysLeftInWeek <= 2 && !sessionLoggedToday;
  const isBehind = weekSessions < 2 && dayOfWeek >= 5;

  return {
    level, setLevel, checks, toggleCheck,
    logSession, sessionLoggedToday, weekSessions,
    fasciaExercises, totalFascia, totalGoata, doneFascia, doneGoata,
    needsWarning, isBehind,
  };
}

// ─── END ATHLETICISM ──────────────────────────────────────────────────────────

const tabs = [
  { key:"", label:"Game Day", href:"/soccer-ai" },
  { key:"schedule", label:"Schedule", href:"/soccer-ai/schedule" },
  { key:"training", label:"Training", href:"/soccer-ai/training" },
  { key:"diet", label:"Diet", href:"/soccer-ai/diet" },
  { key:"mental", label:"Mental", href:"/soccer-ai/mental" },
  { key:"athleticism", label:"Athleticism", href:"/soccer-ai/athleticism" },
  { key:"routine", label:"Daily Routine", href:"/day-life/routine" },
];

const COMPAT_COLOR = (n:number) => n>=85?GREEN:n>=65?BLUE:n>=40?YELLOW:ROSE;
const BEST_GEMS: Record<number, string[]> = {
  1: ["Ruby", "Citrine"],
  2: ["Moonstone", "Pearl"],
  3: ["Amethyst", "Yellow Sapphire"],
  4: ["Emerald", "Sapphire"],
  5: ["Aquamarine", "Turquoise"],
  6: ["Rose Quartz", "Jade"],
  7: ["Amethyst", "Labradorite"],
  8: ["Black Onyx", "Blue Sapphire"],
  9: ["Garnet", "Bloodstone"],
  10: ["Ruby", "Citrine"],
  11: ["Selenite", "Clear Quartz"],
  22: ["Moldavite", "Diamond"],
  33: ["Rose Quartz", "Diamond"],
};

// ── Color energy mapping ──────────────────────────────────────────────────────
const COLOR_ENERGY_FULL: Record<string, number> = {
  "red":1, "orange":2, "yellow":3, "gold":3, "lime":4, "green":4, "blue":5, "cyan":5,
  "navy":6, "indigo":6, "purple":7, "violet":7, "black":8, "grey":8, "gray":8,
  "white":9, "silver":9, "pink":2, "maroon":1, "brown":4, "teal":5, "magenta":6,
  "burgundy":1, "forest green":4, "charcoal":8, "copper":2, "neon green":4, "hot pink":2,
  "crimson":1, "sky blue":5, "emerald":4, "amber":3, "rose":1, "coral":2, "turquoise":5,
  "royal blue":5, "light blue":5, "light grey":8, "dark blue":6, "dark navy":6,
  "dark green":4, "dark red":1, "iridescent":9, "cream":9,
};

function colorEnergy(c: string): number {
  const full = c.toLowerCase();
  if (full in COLOR_ENERGY_FULL) return COLOR_ENERGY_FULL[full];
  const first = full.split(" ")[0];
  return COLOR_ENERGY_FULL[first] ?? 5;
}

function colorHex(c: string): string {
  const map: Record<string,string> = {
    "Black":"#111","White":"#f8fafc","Navy":"#172554","Blue":"#3b82f6",
    "Sky Blue":"#38bdf8","Royal Blue":"#1d4ed8","Teal":"#14b8a6","Cyan":"#22d3ee",
    "Green":"#22c55e","Lime":"#a3e635","Emerald":"#10b981","Yellow":"#eab308",
    "Gold":"#d97706","Amber":"#f59e0b","Orange":"#f97316","Coral":"#fb7185",
    "Red":"#ef4444","Crimson":"#dc2626","Maroon":"#7f1d1d","Rose":"#f43f5e",
    "Pink":"#f472b6","Magenta":"#d946ef","Purple":"#a855f7","Indigo":"#6366f1",
    "Violet":"#8b5cf6","Silver":"#94a3b8","Grey":"#6b7280","Brown":"#78350f",
    "Turquoise":"#2dd4bf","White & Blue":"#dbeafe",
    "Burgundy":"#7d1128","Forest Green":"#166534","Charcoal":"#374151",
    "Copper":"#b45309","Neon Green":"#84cc16","Hot Pink":"#ec4899",
  };
  return map[c] ?? "#60a5fa";
}

function getComplementaryGearColor(kitColor: string): string[] {
  const e = colorEnergy(kitColor);
  const complement: Record<number,string[]> = {
    1:["White","Gold","Yellow"],
    2:["Gold","White","Royal Blue"],
    3:["Purple","Navy","Black"],
    4:["Orange","Gold","White"],
    5:["Orange","Gold","White"],
    6:["Gold","White","Emerald"],
    7:["Gold","Silver","White"],
    8:["Gold","Royal Blue","White"],
    9:["Gold","Black","Royal Blue"],
  };
  return complement[e] ?? ["Gold","White","Black"];
}

function getBestGearComplement(
  kitPrimary: string, kitSecondary: string,
  todayCleat: string, todayShin: string, todaySock: string,
): { bestColor: string; bestSource: string; kitEnergy: number; gearEnergy: number; reason: string; allOptions: { color: string; source: string; score: number }[] } {
  const kitPE = colorEnergy(kitPrimary);
  const kitSE = colorEnergy(kitSecondary);
  const avgKitE = Math.round((kitPE + kitSE) / 2);
  const kitEnergy = avgKitE === 0 ? kitPE : avgKitE;

  const candidates = [
    { color: todayCleat, source: "Cleat Color" },
    { color: todayShin,  source: "Shin Guard" },
    { color: todaySock,  source: "Grip Socks" },
  ];

  const scored = candidates.map(c => {
    const e = colorEnergy(c.color);
    const harmonic = (kitEnergy + e) > 9 ? (kitEnergy + e) - 9 : kitEnergy + e;
    const diff = Math.abs(kitEnergy - e);
    let score = 0;
    if (harmonic === 1 || harmonic === 8 || harmonic === 9) score += 30;
    if (diff >= 3 && diff <= 6) score += 20;
    if (e !== kitPE && e !== kitSE) score += 15;
    if ([1,3,8,9].includes(harmonic)) score += 10;
    score += e;
    return { ...c, score, energy: e, harmonic };
  }).sort((a, b) => b.score - a.score);

  const best = scored[0];
  const gearEnergy = colorEnergy(best.color);
  const harmonic = (kitEnergy + gearEnergy) > 9 ? (kitEnergy + gearEnergy) - 9 : kitEnergy + gearEnergy;

  const reason = `Your ${kitPrimary} (${kitPE}) + ${kitSecondary} (${kitSE}) kit = energy ${kitEnergy}. ` +
    `Today's best gear color is ${best.color} (${best.source}, energy ${gearEnergy}) — forming a ${harmonic} harmonic with your kit.`;

  return {
    bestColor: best.color,
    bestSource: best.source,
    kitEnergy,
    gearEnergy,
    reason,
    allOptions: scored.map(s => ({ color: s.color, source: s.source, score: s.score })),
  };
}

const COLOR_OPTIONS = [
  "Black","White","Navy","Blue","Sky Blue","Royal Blue","Teal","Cyan",
  "Green","Lime","Emerald","Yellow","Gold","Amber","Orange","Coral",
  "Red","Crimson","Maroon","Rose","Pink","Magenta","Purple","Indigo",
  "Violet","Silver","Grey","Brown","Turquoise","Burgundy","Forest Green",
  "Charcoal","Copper","Neon Green","Hot Pink",
];

const KIT_BRANDS = [
  "Nike","Adidas","Puma","Under Armour","New Balance","Jordan",
  "Umbro","Kappa","Joma","Mizuno","Lotto","Diadora","Macron",
  "Hummel","Jako","Errea","Custom / Other",
];

export default function SoccerAIPage() {
  const params = useParams<{ sub?: string }>();
  const sub = params.sub ?? "";
  const today = new Date();
  const [gMonth, setGMonth] = useState(today.getMonth()+1);
  const [gDay, setGDay]   = useState(today.getDate());
  const [gYear, setGYear] = useState(today.getFullYear());

  const [homeColor1, setHomeColor1] = useState("Blue");
  const [homeColor2, setHomeColor2] = useState("White");
  const [awayColor1, setAwayColor1] = useState("White");
  const [awayColor2, setAwayColor2] = useState("Navy");
  const [kitBrand, setKitBrand] = useState("Nike");
  const [kitSide, setKitSide] = useState<"home" | "away">("home");
  const ath = useAthleticism();

  const gd = useMemo(() => calcGameDay(gMonth, gDay, gYear, N.lifePath, N.birthday), [gMonth, gDay, gYear]);
  const weekPlan = useMemo(() => getWeeklyPlan(N.personalYear, N.lifePath), []);
  const compatColor = COMPAT_COLOR(gd.compatibility);

  const activeKitPrimary = kitSide === "home" ? homeColor1 : awayColor1;
  const activeKitSecondary = kitSide === "home" ? homeColor2 : awayColor2;
  const gearAdvice = useMemo(() =>
    getBestGearComplement(activeKitPrimary, activeKitSecondary, gd.cleatColors[0], gd.shinColors[0], gd.sockColors[0]),
    [activeKitPrimary, activeKitSecondary, gd.cleatColors, gd.shinColors, gd.sockColors]
  );
  const bestGems = BEST_GEMS[gd.personalDay] ?? BEST_GEMS[N.lifePath] ?? ["Clear Quartz"];

  const brandEnergy = useMemo(() => {
    const b = kitBrand.toLowerCase();
    const brandMap: Record<string, number> = {
      nike:1, adidas:5, puma:4, "under armour":7, "new balance":8,
      jordan:4, umbro:3, kappa:2, joma:6, mizuno:5, lotto:3,
      diadora:4, macron:3, hummel:7, jako:6, errea:5,
    };
    return brandMap[b] ?? 5;
  }, [kitBrand]);

  function KitColorPicker({ value, onChange, label }: { value: string; onChange: (v: string) => void; label: string }) {
    return (
      <div>
        <p className="text-[8.5px] uppercase tracking-widest mb-1.5" style={{ color: "rgba(255,255,255,0.3)" }}>{label}</p>
        <div className="relative">
          <div className="w-5 h-5 rounded-full absolute left-2 top-1/2 -translate-y-1/2 shrink-0" style={{ background: colorHex(value), border: "1px solid rgba(255,255,255,0.15)" }} />
          <select value={value} onChange={e => onChange(e.target.value)}
            className="w-full rounded-xl pl-9 pr-3 py-2 text-xs font-semibold text-white appearance-none cursor-pointer"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", outline: "none" }}>
            {COLOR_OPTIONS.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Dribbble size={12} style={{ color:GREEN }} />
          <span>Soccer AI</span><ChevronRight size={10}/><span style={{ color:GREEN }}>Cristian Zavala · Winger · North Grand</span>
        </div>
        <h1 className="page-title">Soccer AI</h1>
        <p className="page-subtitle">Personalized match intelligence · #10 Jersey Recommended</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(74,222,128,0.12)", color:GREEN, border:"1px solid rgba(74,222,128,0.25)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── GAME DAY ── */}
      {sub==="" && (
        <div className="space-y-4">
          <div className="glass-card p-4 flex flex-wrap items-center gap-4" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="flex items-center gap-2">
              {[{label:"Month",v:gMonth,set:setGMonth,min:1,max:12,w:"w-14"},
                {label:"Day",  v:gDay,  set:setGDay,  min:1,max:31,w:"w-14"},
                {label:"Year", v:gYear, set:setGYear, min:2024,max:2030,w:"w-20"}].map(f=>(
                <div key={f.label}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{f.label}</p>
                  <input type="number" min={f.min} max={f.max} value={f.v} onChange={e=>f.set(+e.target.value)}
                    className={`${f.w} text-center rounded-lg px-2 py-1 text-sm font-bold`}
                    style={{ background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", color:GREEN, outline:"none" }} />
                </div>
              ))}
            </div>
            <div>
              <p className="text-xs font-semibold text-white">Game Date Analysis</p>
              <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.4)" }}>{PROFILE.teamName} · North Grand Eagles</p>
            </div>
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }} suppressHydrationWarning>
            <div className="flex items-start gap-5">
              <div className="text-center shrink-0">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Compatibility</p>
                <p className="text-5xl font-black" style={{ color:compatColor }} suppressHydrationWarning>{gd.compatibility}%</p>
                <p className="text-xs font-semibold mt-1" style={{ color:compatColor }}>{gd.compatLabel}</p>
              </div>
              <div className="w-px self-stretch" style={{ background:"rgba(255,255,255,0.06)" }} />
              <div className="flex-1">
                <p className="text-sm font-semibold text-white mb-1">{gd.compatDesc}</p>
                <div className="grid grid-cols-2 gap-3 mt-3">
                  <div>
                    <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Universal Day Energy</p>
                    <p className="text-2xl font-black" style={{ color:GREEN }}>{gd.universalEnergy}</p>
                    <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.35)" }}>Compound: {gd.universalCompound}</p>
                  </div>
                  <div>
                    <p className="text-[9px] uppercase tracking-widest mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Your Personal Day</p>
                    <p className="text-2xl font-black" style={{ color:YELLOW }}>{gd.personalDay}</p>
                    <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.35)" }}>Compound: {gd.personalDayCompound}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="flex items-center justify-between mb-3">
              <p className="text-[10px] uppercase tracking-widest" style={{ color:YELLOW }}>Colors For Today</p>
              <div className="flex items-center gap-1.5">
                <span className="text-[8px] uppercase tracking-widest" style={{ color:"rgba(255,255,255,0.25)" }}>Harmonized with</span>
                {gd.colorHarmonizedWith.map(n => (
                  <span key={n} className="text-[10px] font-black px-1.5 py-0.5 rounded" style={{ background:"rgba(250,204,21,0.1)", color:YELLOW, border:"1px solid rgba(250,204,21,0.15)" }}>#{n}</span>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label:"Cleat Color", colors:gd.cleatColors, emoji:"👟" },
                { label:"Shin Guard",  colors:gd.shinColors,  emoji:"🛡️" },
                { label:"Grip Socks",  colors:gd.sockColors,  emoji:"🧦" },
              ].map(g=>(
                <div key={g.label} className="p-4 text-center rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <p className="text-xl mb-2">{g.emoji}</p>
                  <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>{g.label}</p>
                  {g.colors.map((c,i)=>(
                    <p key={c} className="text-xs font-semibold" style={{ color:i===0?YELLOW:BLUE }}>{i===0?"PRIMARY":"ACCENT"}: {c}</p>
                  ))}
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(96,165,250,0.12)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-4" style={{ color:BLUE }}>Kit Customizer</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
              <KitColorPicker label="Home Primary" value={homeColor1} onChange={setHomeColor1} />
              <KitColorPicker label="Home Secondary" value={homeColor2} onChange={setHomeColor2} />
              <KitColorPicker label="Away Primary" value={awayColor1} onChange={setAwayColor1} />
              <KitColorPicker label="Away Secondary" value={awayColor2} onChange={setAwayColor2} />
            </div>
            <div className="mb-4">
              <p className="text-[8.5px] uppercase tracking-widest mb-1.5" style={{ color:"rgba(255,255,255,0.3)" }}>Playing Side</p>
              <div className="flex gap-2">
                {(["home","away"] as const).map(side => (
                  <button
                    key={side}
                    onClick={() => setKitSide(side)}
                    className="px-3 py-2 rounded-xl text-xs font-semibold"
                    style={kitSide === side
                      ? { background:"rgba(74,222,128,0.12)", color:GREEN, border:"1px solid rgba(74,222,128,0.25)" }
                      : { background:"rgba(255,255,255,0.05)", color:"rgba(255,255,255,0.6)", border:"1px solid rgba(255,255,255,0.1)" }}
                  >
                    {side === "home" ? "Home Kit" : "Away Kit"}
                  </button>
                ))}
              </div>
            </div>
            <div className="mb-4">
              <p className="text-[8.5px] uppercase tracking-widest mb-1.5" style={{ color:"rgba(255,255,255,0.3)" }}>Kit Brand</p>
              <select value={kitBrand} onChange={e => setKitBrand(e.target.value)}
                className="w-full sm:w-48 rounded-xl px-3 py-2 text-xs font-semibold text-white appearance-none cursor-pointer"
                style={{ background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", outline:"none" }}>
                {KIT_BRANDS.map(b => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Kit Energy</p>
                <p className="text-sm font-bold" style={{ color:YELLOW }}>{gearAdvice.kitEnergy}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>{activeKitPrimary} ({colorEnergy(activeKitPrimary)}) + {activeKitSecondary} ({colorEnergy(activeKitSecondary)})</p>
              </div>
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Brand Energy</p>
                <p className="text-sm font-bold" style={{ color:BLUE }}>{brandEnergy}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>{kitBrand} vibrates at {brandEnergy}</p>
              </div>
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Best Gear Color</p>
                <p className="text-sm font-bold" style={{ color:GREEN }}>{gearAdvice.bestColor}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>From {gearAdvice.bestSource}</p>
              </div>
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>PD Harmony</p>
                <p className="text-sm font-bold" style={{ color:PURPLE }}>{Math.abs(gearAdvice.kitEnergy - gd.personalDay) <= 2 ? "Aligned" : "Offset"}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>Kit {gearAdvice.kitEnergy} vs PD {gd.personalDay}</p>
              </div>
            </div>
            <div className="mt-3">
              <p className="text-[8.5px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.25)" }}>Today's Color Options (ranked for your {kitSide} kit)</p>
              <div className="flex gap-2 flex-wrap">
                {gearAdvice.allOptions.map((opt, i) => (
                  <div key={opt.source} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg" style={{ background: i === 0 ? "rgba(74,222,128,0.1)" : "rgba(255,255,255,0.03)", border: i === 0 ? "1px solid rgba(74,222,128,0.2)" : "1px solid rgba(255,255,255,0.06)" }}>
                    <div className="w-3.5 h-3.5 rounded-full" style={{ background: colorHex(opt.color) }} />
                    <span className="text-[10px] font-semibold" style={{ color: i === 0 ? GREEN : "rgba(255,255,255,0.5)" }}>{opt.color}</span>
                    <span className="text-[8px]" style={{ color:"rgba(255,255,255,0.25)" }}>({opt.source})</span>
                    {i === 0 && <span className="text-[8px] font-bold" style={{ color:GREEN }}>BEST</span>}
                  </div>
                ))}
              </div>
            </div>
            <p className="text-[9px] mt-2" style={{ color:"rgba(255,255,255,0.3)" }}>{gearAdvice.reason}</p>
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(74,222,128,0.12)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-4" style={{ color:GREEN }}>Gear Automation</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Sock Height</p>
                <p className="text-sm font-bold text-white">{gd.sockHeight?.toUpperCase?.() ?? "MID"}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>Untouchable automation</p>
              </div>
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Sock Type</p>
                <p className="text-sm font-bold text-white">{gd.sockType === "grip" ? "Grip Sock" : "Regular"}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>{gd.gearFormula}</p>
              </div>
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Jersey Tuck</p>
                <p className="text-sm font-bold text-white">{gd.jerseyTuck === "tucked" ? "Tucked In" : "Untucked"}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>Locked like wrist tape</p>
              </div>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Best Numbers To Use Today</p>
            <div className="flex gap-3 flex-wrap">
              {gd.bestNumbers.map((n,i)=>(
                <div key={n} className="text-center px-4 py-3 rounded-xl" style={{ background:"rgba(250,204,21,0.08)", border:"1px solid rgba(250,204,21,0.15)" }}>
                  <p className="text-3xl font-black" style={{ color:YELLOW }}>{n}</p>
                  <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.35)" }}>{gd.bestNumberReasons[i]}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Wrist Tape / Handwrap */}
          {(() => {
            const pd = gd.personalDay;
            const useWristTape = pd <= 5;
            const wristColor = pd === 1 ? "Red" : pd === 2 ? "Orange" : pd === 3 ? "Gold" : pd === 4 ? "Green" : pd === 5 ? "Blue" : pd === 6 ? "Indigo" : pd === 7 ? "Violet" : pd === 8 ? "Black" : "White";
            return (
              <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Wrist Tape / Handwrap</p>
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl" style={{ background: useWristTape ? "rgba(74,222,128,0.1)" : "rgba(248,113,113,0.1)", border: useWristTape ? "1px solid rgba(74,222,128,0.2)" : "1px solid rgba(248,113,113,0.2)" }}>
                    {useWristTape ? "✅" : "❌"}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-white">{useWristTape ? `Use Wrist Tape — ${wristColor}` : "Skip wrist tape today"}</p>
                    <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>
                      {useWristTape
                        ? `Personal Day ${pd} energy is active — wrist tape in ${wristColor} activates energy code ${pd} through contact with pulse point.`
                        : `Personal Day ${pd} energy is high enough without wrist amplification. Go clean wrists for max mobility.`}
                    </p>
                    {useWristTape && (
                      <div className="flex items-center gap-2 mt-2">
                        <div className="w-5 h-5 rounded-full" style={{ background:colorHex(wristColor), border:"1px solid rgba(255,255,255,0.15)" }} />
                        <p className="text-xs font-semibold" style={{ color:GREEN }}>{wristColor} · Energy {pd}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* How to Score Today */}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>How To Score Today</p>
            {(() => {
              const pd = gd.personalDay;
              const tactics: { tip:string; detail:string }[] = pd === 1
                ? [{tip:"Take shots yourself",detail:"LP 1 day = leader energy. Be selfish in the box."},{tip:"Cut inside from the wing",detail:"Right-footed cut inside from the left, LP1 rewards individual brilliance."},{tip:"First touch finish",detail:"Don't overthink — first-time strikes carry the most 1 energy."}]
                : pd === 2
                ? [{tip:"Assist > Score",detail:"Day 2 = partnership. Set up teammates for easy finishes."},{tip:"One-two passing combinations",detail:"Quick give-and-go near the box activates 2 energy."},{tip:"Near-post runs",detail:"Make back-door runs — let the ball find you through partnership."}]
                : pd === 3
                ? [{tip:"Creative finish",detail:"Chip, backheel, rabona — day 3 rewards flair and style."},{tip:"Long range curler",detail:"Outside foot curving shots carry 3 expression energy."},{tip:"Celebrate big",detail:"Energy 3 means your celebration amplifies the goal's power."}]
                : pd === 4
                ? [{tip:"Work the fundamentals",detail:"Day 4 = discipline. Textbook placement > power."},{tip:"Penalty box positioning",detail:"Get to the right spot. Classic 6-yard box goals carry the energy."},{tip:"Headers from crosses",detail:"4 energy rewards structure — time your runs to meet crosses."}]
                : pd === 5
                ? [{tip:"Counter-attack speed",detail:"Day 5 = speed & change. Transition goals are your weapon."},{tip:"1v1 with keeper",detail:"Use pace to get in behind, then slot it calm."},{tip:"Adapt mid-game",detail:"If plan A fails, switch position. 5 rewards flexibility."}]
                : pd === 6
                ? [{tip:"Team play in the box",detail:"Day 6 = harmony. Goals from team combinations are amplified."},{tip:"Tap-ins from crosses",detail:"Be in the right spot. 6 energy rewards collective effort."},{tip:"Set pieces",detail:"Corners and free kicks — organized play suits 6 energy."}]
                : pd === 7
                ? [{tip:"Placement over power",detail:"Day 7 = precision. Side-netting finishes carry the code."},{tip:"Read the keeper",detail:"Study their positioning. 7 is analytical — pick your corner."},{tip:"Quiet efficiency",detail:"Don't try to be flashy. Clean, composed finishing wins today."}]
                : pd === 8
                ? [{tip:"Power shot from distance",detail:"Day 8 = authority. Hit it hard — Saturn energy rewards force."},{tip:"Bully the defense",detail:"Use physicality. Win aerial duels. Overpower markers."},{tip:"Captain energy",detail:"Lead by example. Score the big goal in the big moment."}]
                : [{tip:"Volleys and acrobatics",detail:"Day 9 = universal energy. Spectacular goals are destined today."},{tip:"Late-game heroics",detail:"9 is completion — decisive goals in the final minutes."},{tip:"Unselfish brilliance",detail:"Score the goal that wins it for everyone, not just yourself."}];
              return (
                <div className="space-y-2">
                  {tactics.map((t,i)=>(
                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg" style={{ background:"rgba(74,222,128,0.04)" }}>
                      <span className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5" style={{ background:"rgba(74,222,128,0.15)", color:GREEN }}>{i+1}</span>
                      <div>
                        <p className="text-sm font-semibold text-white">{t.tip}</p>
                        <p className="text-xs mt-0.5" style={{ color:"rgba(255,255,255,0.4)" }}>{t.detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>

          {/* Best Brands & Colors */}
          {(() => {
            const pd = gd.personalDay;
            const de = gd.universalEnergy;
            const bestBrands: Record<number, { name: string; year: number; energy: number; why: string }[]> = {
              1: [
                { name:"Nike", year:1964, energy:2, why:"2 supports 1 — loyalty fuels leadership" },
                { name:"Jordan", year:1984, energy:4, why:"4 grounds your 1 — structure meets ambition" },
                { name:"Under Armour", year:1996, energy:7, why:"7 adds spiritual depth to your power" },
              ],
              2: [
                { name:"Adidas", year:1949, energy:5, why:"5 activates 2 — movement meets diplomacy" },
                { name:"Puma", year:1948, energy:4, why:"4 stabilizes 2 — grounding for the peacemaker" },
                { name:"Hummel", year:1923, energy:6, why:"6 harmonizes with 2 — balance amplified" },
              ],
              3: [
                { name:"Nike", year:1964, energy:2, why:"2 balances 3 — creative energy channeled" },
                { name:"Adidas", year:1949, energy:5, why:"5 adds freedom to 3 — expression unleashed" },
                { name:"Umbro", year:1924, energy:7, why:"7 deepens 3 — intuition fuels creativity" },
              ],
              4: [
                { name:"Nike", year:1964, energy:2, why:"2 softens 4 — diplomacy meets discipline" },
                { name:"Jordan", year:1984, energy:4, why:"4+4=8 — double structure = power portal" },
                { name:"Macron", year:1971, energy:9, why:"9 completes 4 — builds to mastery" },
              ],
              5: [
                { name:"Adidas", year:1949, energy:5, why:"5+5=10/1 — freedom doubles into leadership" },
                { name:"Nike", year:1964, energy:2, why:"2 anchors 5 — movement with partnership" },
                { name:"Puma", year:1948, energy:4, why:"4 grounds 5 — stability for the traveler" },
              ],
              6: [
                { name:"Adidas", year:1949, energy:5, why:"5 energizes 6 — freedom meets harmony" },
                { name:"Puma", year:1948, energy:4, why:"4 supports 6 — family and foundation" },
                { name:"New Balance", year:1906, energy:7, why:"7 elevates 6 — spiritual harmony" },
              ],
              7: [
                { name:"Nike", year:1964, energy:2, why:"2 partners with 7 — intuition amplified" },
                { name:"Jordan", year:1984, energy:4, why:"4 grounds 7 — spiritual meets physical" },
                { name:"Macron", year:1971, energy:9, why:"9 completes 7 — wisdom reaches harvest" },
              ],
              8: [
                { name:"Adidas", year:1949, energy:5, why:"5 activates 8 — freedom fuels authority" },
                { name:"Under Armour", year:1996, energy:7, why:"7 elevates 8 — power meets wisdom" },
                { name:"New Balance", year:1906, energy:7, why:"7 channels 8 — balanced authority" },
              ],
              9: [
                { name:"Nike", year:1964, energy:2, why:"2 softens 9 — completion with grace" },
                { name:"Jordan", year:1984, energy:4, why:"4 grounds 9 — harvest with structure" },
                { name:"Hummel", year:1923, energy:6, why:"6 harmonizes 9 — love meets completion" },
              ],
            };
            const bestColors = bestColorsFor(pd, 3).map(c => c.name);
            const avoidNums = pd === 1 ? [6,8] : pd === 2 ? [4,8] : pd === 3 ? [6,8] : pd === 4 ? [2,5] : pd === 5 ? [4,7] : pd === 6 ? [1,3] : pd === 7 ? [2,5] : pd === 8 ? [1,4] : [4,5];
            const avoidColors = avoidNums.map(n => n===1?"Red/Crimson":n===2?"Orange/Pink":n===3?"Yellow/Gold":n===4?"Green/Lime":n===5?"Blue/Cyan":n===6?"Navy/Indigo":n===7?"Purple/Violet":n===8?"Black/Grey":"White/Silver");
            const avoidBrands: Record<number,string[]> = {
              1:["Givenchy(1952→3)","Chanel(1910→2)"],2:["Nike(1964→2)","Off-White(2012→5)"],3:["Puma(1948→4)","Ralph Lauren(1967→5)"],
              4:["Adidas(1949→5)","Supreme(1994→5)"],5:["Under Armour(1996→7)","Uniqlo(1984→4)"],6:["Nike(1964→2)","Jordan(1984→4)"],
              7:["Adidas(1949→5)","Reebok(1958→5)"],8:["Nike(1964→2)","Puma(1948→4)"],9:["Supreme(1994→5)","Adidas(1949→5)"]
            };
            const brands = bestBrands[pd] ?? bestBrands[1];
            const avBrands = avoidBrands[pd] ?? [];
            return (
              <>
                <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(74,222,128,0.12)" }}>
                  <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Best Brands & Colors Today</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs font-semibold mb-2" style={{ color:GREEN }}>Best Brands to Wear</p>
                      {brands.map((b, i) => (
                        <div key={b.name} className="flex items-center gap-3 mb-2 p-2.5 rounded-xl" style={{ background: i === 0 ? "rgba(74,222,128,0.08)" : "rgba(255,255,255,0.03)", border: i === 0 ? "1px solid rgba(74,222,128,0.15)" : "1px solid rgba(255,255,255,0.06)" }}>
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-black" style={{ background:"rgba(74,222,128,0.1)", color:GREEN }}>{b.energy}</div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                              <p className="text-xs font-bold text-white">{b.name}</p>
                              <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.35)" }}>{brandDecode(b.name)?.foundedLabel ?? b.year}</p>
                              <span className="text-[8px] px-1 py-0.5 rounded" style={{ background:"rgba(255,255,255,0.06)", color:"rgba(255,255,255,0.35)" }}>{b.year}</span>
                              {i === 0 && <span className="text-[8px] font-bold px-1 py-0.5 rounded" style={{ background:"rgba(74,222,128,0.15)", color:GREEN }}>TOP PICK</span>}
                            </div>
                            <p className="text-[9px] mt-0.5" style={{ color:"rgba(255,255,255,0.35)" }}>{b.why}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div>
                      <p className="text-xs font-semibold mb-2" style={{ color:GREEN }}>Best Colors to Wear</p>
                      <div className="space-y-1.5">
                        {bestColors.map((c, i) => (
                          <div key={c} className="flex items-center gap-2 p-2 rounded-lg" style={{ background: i === 0 ? "rgba(74,222,128,0.08)" : "rgba(255,255,255,0.03)", border: i === 0 ? "1px solid rgba(74,222,128,0.15)" : "1px solid rgba(255,255,255,0.06)" }}>
                            <div className="w-4 h-4 rounded-full" style={{ background: colorHex(c) }} />
                            <p className="text-xs font-semibold text-white">{c}</p>
                            <p className="text-[9px] ml-auto" style={{ color:"rgba(255,255,255,0.3)" }}>Energy {colorEnergy(c)}</p>
                            {i === 0 && <span className="text-[8px] font-bold" style={{ color:GREEN }}>TOP</span>}
                          </div>
                        ))}
                      </div>
                      <p className="text-[9px] mt-2" style={{ color:"rgba(255,255,255,0.25)" }}>PD {pd} energy flows best with these colors and brand frequencies.</p>
                    </div>
                  </div>
                </div>

                <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                  <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:ROSE }}>Brands & Colors To Avoid Today</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <p className="text-xs font-semibold mb-2" style={{ color:ROSE }}>Colors to Avoid</p>
                      {avoidColors.map(c=>(
                        <div key={c} className="flex items-center gap-2 mb-1.5 p-2 rounded-lg" style={{ background:"rgba(248,113,113,0.06)" }}>
                          <span className="text-[10px]">🚫</span>
                          <p className="text-xs text-white">{c}</p>
                          <p className="text-[9px] ml-auto" style={{ color:"rgba(255,255,255,0.3)" }}>Energy {avoidNums[avoidColors.indexOf(c)]}</p>
                        </div>
                      ))}
                    </div>
                    <div>
                      <p className="text-xs font-semibold mb-2" style={{ color:ROSE }}>Brands to Avoid</p>
                      {avBrands.map(b=>(
                        <div key={b} className="flex items-center gap-2 mb-1.5 p-2 rounded-lg" style={{ background:"rgba(248,113,113,0.06)" }}>
                          <span className="text-[10px]">⚠️</span>
                          <p className="text-xs text-white">{b}</p>
                        </div>
                      ))}
                      <p className="text-[9px] mt-2" style={{ color:"rgba(255,255,255,0.25)" }}>These brand imprints clash with today's PD {pd} energy.</p>
                    </div>
                  </div>
                </div>
              </>
            );
          })()}

          {/* Best Jersey Numbers for the Season */}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Best Jersey Numbers — 2025-26 Season</p>
            <p className="text-xs mb-3" style={{ color:"rgba(255,255,255,0.4)" }}>Based on your PY{N.personalYear} + LP{N.lifePath} + Birthday{N.birthday} compound energies</p>
            <div className="space-y-2">
              {gd.rankedNumbers.map((item, i) => (
                <div key={item.number} className="flex items-center justify-between p-3 rounded-xl" style={{ background:i===0?"rgba(250,204,21,0.12)":"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)" }}>
                  <div className="flex items-center gap-3">
                    <div className="w-9 text-center">
                      <p className="text-xl font-black" style={{ color:i===0?YELLOW:GREEN }}>{item.number}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-white">{item.label}</p>
                      <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.35)" }}>{item.reason}</p>
                    </div>
                  </div>
                  <p className="text-[10px] font-bold" style={{ color:i===0?YELLOW:BLUE }}>{item.score}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Good vs Bad Energy Summary */}
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(74,222,128,0.15)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Good Energy Today</p>
              {(() => {
                const pd = gd.personalDay;
                const goodColors = pd===1?"Red, Gold, White":pd===2?"Orange, Gold, Blue":pd===3?"Purple, Yellow, Gold":pd===4?"Green, Orange, White":pd===5?"Blue, Cyan, Gold":pd===6?"Blue, Indigo, Gold":pd===7?"Violet, Silver, White":pd===8?"Black, Gold, Blue":"Gold, White, Red";
                const goodAction = pd<=3?"Be bold and take initiative":pd<=6?"Work with teammates and stay disciplined":"Trust your instincts and finish with precision";
                return (
                  <div className="space-y-2">
                    <p className="text-xs text-white">🎨 Colors: <span style={{ color:GREEN }}>{goodColors}</span></p>
                    <p className="text-xs text-white">⚡ Action: <span style={{ color:GREEN }}>{goodAction}</span></p>
                    <p className="text-xs text-white">🔢 Numbers: <span style={{ color:GREEN }}>{gd.bestNumbers.join(", ")}</span></p>
                  </div>
                );
              })()}
            </div>
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(248,113,113,0.15)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:ROSE }}>Bad Energy to Counter</p>
              {(() => {
                const pd = gd.personalDay;
                const badColors = pd===1?"Navy, Indigo, Black":pd===2?"Green, Brown, Black":pd===3?"Navy, Indigo, Black":pd===4?"Orange, Pink, Blue":pd===5?"Green, Brown, Violet":pd===6?"Red, Crimson, Yellow":pd===7?"Orange, Pink, Cyan":pd===8?"Red, Crimson, Green":"Green, Lime, Cyan";
                const counter = pd<=3?"Wear Gold accessories to neutralize":pd<=6?"Add a White element to balance":"Use Gold or Yellow to counteract darkness";
                return (
                  <div className="space-y-2">
                    <p className="text-xs text-white">🚫 Avoid: <span style={{ color:ROSE }}>{badColors}</span></p>
                    <p className="text-xs text-white">🛡️ Counter: <span style={{ color:YELLOW }}>{counter}</span></p>
                    <p className="text-xs text-white">⏰ Low window: <span style={{ color:ROSE }}>2–4 PM (avoid big plays)</span></p>
                  </div>
                );
              })()}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Best Gems Today</p>
            <div className="flex flex-wrap gap-2">
              {bestGems.map(g=>(
                <div key={g} className="px-3 py-2 rounded-xl" style={{ background:"rgba(250,204,21,0.08)", border:"1px solid rgba(250,204,21,0.15)" }}>
                  <p className="text-xs font-semibold text-white">{g}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}


      {/* ── TRAINING ── */}
      {sub==="training" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Weekly Focus — Personal Year {N.personalYear}</p>
            <p className="text-sm font-semibold" style={{ color:GREEN }}>{weekPlan.focus}</p>
          </div>
          {[{day:"Monday",...weekPlan.mon},{day:"Tuesday",...weekPlan.tue},{day:"Wednesday",...weekPlan.wed},{day:"Thursday",...weekPlan.thu},{day:"Friday",...weekPlan.fri},{day:"Saturday",...weekPlan.sat},{day:"Sunday",...weekPlan.sun}].map(d=>(
            <div key={d.day} className="feature-card">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-white">{d.day}</p>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold" style={{ background:d.type==="MATCH DAY"?"rgba(250,204,21,0.15)":"rgba(96,165,250,0.1)", color:d.type==="MATCH DAY"?YELLOW:BLUE }}>{d.type}</span>
              </div>
              <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{d.desc}</p>
            </div>
          ))}
        </div>
      )}

      {/* ── DIET ── */}
      {sub==="diet" && (
        <div className="space-y-4">
          {[
            { label:"Pre-Match Nutrition", items:DIET_PLAN.preMatch, color:YELLOW },
            { label:"Hydration Strategy",  items:DIET_PLAN.hydration, color:BLUE },
            { label:"Recovery Meals",      items:DIET_PLAN.recovery, color:GREEN },
            { label:"Lucky Foods (Energy Portal Alignment)", items:DIET_PLAN.luckyFoods, color:PURPLE },
          ].map(s=>(
            <div key={s.label} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>{s.label}</p>
              <ul className="space-y-2">
                {s.items.map((item,i)=>(
                  <li key={i} className="flex items-start gap-2 text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>
                    <span style={{ color:s.color }}>→</span>{item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {/* ── MENTAL ── */}
      {sub==="mental" && (
        <div className="space-y-4">
          {[
            { title:"Daily Affirmation",content:`"I am Life Path ${N.lifePath}. My 28/10 wealth portal is always active. I lead, I create, I dominate on the field."`,emoji:"💭" },
            { title:"Pre-Match Visualization (2 hrs before)",content:"Close your eyes for 5 minutes. See yourself making the decisive run down the wing. See the cross landing perfectly. Hear the crowd. Feel the completion.",emoji:"🧠" },
            { title:"Focus Mantra",content:`Repeat: "${N.lifePath} — ${N.birthday} — ${N.expression}" — your three core activation codes. Lock in before entering the pitch.`,emoji:"🔮" },
            { title:"Pressure Management (Life Path 1)",content:"When under pressure, reconnect with your leadership energy. You are a pioneer — tension activates you, not breaks you. Take initiative.",emoji:"⚡" },
            { title:"Post-Match Reset",content:"Win or lose: write 3 things you controlled. Release what you couldn't. Your Personal Year 9 requires completion and release energy.",emoji:"📝" },
          ].map(s=>(
            <div key={s.title} className="feature-card">
              <div className="text-2xl">{s.emoji}</div>
              <div>
                <p className="text-sm font-semibold text-white">{s.title}</p>
                <p className="text-xs mt-1 leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>{s.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── SCHEDULE ── */}
      {sub==="schedule" && (
        <div className="space-y-3">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:YELLOW }}>Season Schedule</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>Life Path {N.lifePath} · Birthday {N.birthday} · compat vs each game's energy</p>
            <div className="space-y-2">
              {SEASON_SCHEDULE.map(g => {
                const tier = compatTier(g.compat);
                const color = tier === "FRIENDLY" ? GREEN : tier === "NEUTRAL" ? YELLOW : ROSE;
                return (
                  <div key={g.date} className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:`1px solid ${color}30` }}>
                    <div className="flex items-start justify-between gap-3 mb-1">
                      <div>
                        <p className="text-sm font-bold" style={{ color:"white" }}>{g.home ? "vs" : "@"} {g.opponent}</p>
                        <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.45)" }}>{g.date} · {g.time} · {g.venue}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-black" style={{ color }}>{g.compat}%</p>
                        <p className="text-[9px] font-bold tracking-widest" style={{ color }}>{tier}</p>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-2 flex-wrap">
                      <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background:"rgba(212,175,55,0.15)", color:YELLOW }}>LP {g.lp}</span>
                      <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background:"rgba(59,130,246,0.15)", color:BLUE }}>Sec {g.secondary}</span>
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="text-[10px] mt-4" style={{ color:"rgba(255,255,255,0.3)" }}>Compat driven by ShemUniverse number matrix: LP↔Universal (25%), Birthday↔Personal Day (25%), LP↔Personal Day (20%), LP↔Regular Day # (30%). 20 is a hidden 11 and never reduces.</p>
          </div>
        </div>
      )}

      {/* ── ATHLETICISM ── */}
      {sub==="athleticism" && (
        <div className="space-y-4">

          {/* ── Weekly Consistency Tracker ── */}
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border: ath.isBehind ? "1px solid #f472b620" : ath.needsWarning ? "1px solid #facc1530" : "1px solid transparent" }}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: YELLOW }}>Weekly Consistency</p>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>Target: 3 sessions per week</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-black" style={{ color: ath.weekSessions >= 3 ? GREEN : ath.weekSessions >= 2 ? YELLOW : ROSE }}>
                  {ath.weekSessions}/3
                </p>
                <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.35)" }}>this week</p>
              </div>
            </div>
            <div className="flex gap-2 mb-3">
              {[0,1,2].map(i => (
                <div key={i} className="flex-1 h-2 rounded-full" style={{ background: i < ath.weekSessions ? (ath.weekSessions >= 3 ? GREEN : YELLOW) : "rgba(255,255,255,0.08)" }} />
              ))}
            </div>
            {ath.isBehind && (
              <div className="flex items-start gap-2 p-3 rounded-xl mb-3" style={{ background:"rgba(244,114,182,0.08)", border:"1px solid rgba(244,114,182,0.2)" }}>
                <span style={{ color:ROSE }}>⚠</span>
                <p className="text-xs leading-relaxed" style={{ color:ROSE }}>You're behind pace — less than 2 sessions and the week ends soon. Get a session in today to stay consistent. Inconsistency resets your progress momentum.</p>
              </div>
            )}
            {!ath.isBehind && ath.needsWarning && (
              <div className="flex items-start gap-2 p-3 rounded-xl mb-3" style={{ background:"rgba(250,204,21,0.08)", border:"1px solid rgba(250,204,21,0.2)" }}>
                <span style={{ color:YELLOW }}>⚡</span>
                <p className="text-xs leading-relaxed" style={{ color:YELLOW }}>Only {3 - ath.weekSessions} more session{3 - ath.weekSessions > 1 ? "s" : ""} needed to hit your 3×/week goal before the week ends.</p>
              </div>
            )}
            {ath.weekSessions >= 3 && (
              <div className="flex items-center gap-2 p-3 rounded-xl" style={{ background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)" }}>
                <span style={{ color:GREEN }}>✓</span>
                <p className="text-xs font-semibold" style={{ color:GREEN }}>Weekly goal locked in. Elite consistency.</p>
              </div>
            )}
            <p className="text-[10px] mt-2" style={{ color:"rgba(255,255,255,0.2)" }}>Tracker resets every Monday · Checks reset at midnight</p>
          </div>

          {/* ── Level Selector ── */}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Fascia Training Level</p>
            <div className="grid grid-cols-4 gap-2">
              {([1,2,3,4] as const).map(l => {
                const lvl = FASCIA_LEVELS[l];
                const active = ath.level === l;
                return (
                  <button key={l} onClick={() => ath.setLevel(l)}
                    className="p-3 rounded-xl text-left transition-all"
                    style={{ background: active ? `rgba(96,165,250,0.12)` : "rgba(255,255,255,0.03)", border: active ? `1px solid ${BLUE}50` : "1px solid rgba(255,255,255,0.06)" }}>
                    <p className="text-base font-black" style={{ color: active ? BLUE : "rgba(255,255,255,0.3)" }}>L{l}</p>
                    <p className="text-[10px]" style={{ color: active ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.25)" }}>{lvl.weeks}</p>
                    <p className="text-[10px] mt-0.5" style={{ color: active ? BLUE : "rgba(255,255,255,0.2)" }}>{lvl.duration}</p>
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] mt-3 leading-relaxed" style={{ color:"rgba(255,255,255,0.35)" }}>
              <span style={{ color:YELLOW }}>Criteria to advance:</span> {FASCIA_LEVELS[ath.level].criteria}
            </p>
          </div>

          {/* ── Fascia Training Exercises ── */}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-[10px] uppercase tracking-widest" style={{ color:BLUE }}>Fascia Training — Level {ath.level}</p>
                <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.3)" }}>{FASCIA_LEVELS[ath.level].duration}</p>
              </div>
              <p className="text-sm font-black" style={{ color: ath.doneFascia === ath.totalFascia ? GREEN : BLUE }}>
                {ath.doneFascia}/{ath.totalFascia}
              </p>
            </div>
            {ath.totalFascia > 0 && (
              <div className="mb-3 h-1 rounded-full overflow-hidden" style={{ background:"rgba(255,255,255,0.06)" }}>
                <div className="h-full rounded-full transition-all duration-500" style={{ width:`${(ath.doneFascia/ath.totalFascia)*100}%`, background: ath.doneFascia === ath.totalFascia ? GREEN : BLUE }} />
              </div>
            )}
            <div className="space-y-1.5">
              {ath.fasciaExercises.map((ex, i) => {
                const key = `f${i}`;
                const done = ath.checks[key] === true;
                return (
                  <button key={key} onClick={() => ath.toggleCheck(key)} className="flex items-start gap-2.5 w-full text-left">
                    <span className="mt-0.5 w-4 h-4 shrink-0 rounded border flex items-center justify-center transition-all" style={{
                      borderColor: done ? GREEN : "rgba(255,255,255,0.2)",
                      background: done ? `${GREEN}20` : "transparent"
                    }}>
                      {done && <span className="text-[10px]" style={{ color:GREEN }}>✓</span>}
                    </span>
                    <p className="text-xs transition-all" style={{
                      color: done ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.65)",
                      textDecoration: done ? "line-through" : "none"
                    }}>{ex}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ── GOATA Training ── */}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-[10px] uppercase tracking-widest" style={{ color:GREEN }}>GOATA Training</p>
                <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.3)" }}>Daily · 30 min</p>
              </div>
              <p className="text-sm font-black" style={{ color: ath.doneGoata === ath.totalGoata ? GREEN : BLUE }}>
                {ath.doneGoata}/{ath.totalGoata}
              </p>
            </div>
            {ath.totalGoata > 0 && (
              <div className="mb-3 h-1 rounded-full overflow-hidden" style={{ background:"rgba(255,255,255,0.06)" }}>
                <div className="h-full rounded-full transition-all duration-500" style={{ width:`${(ath.doneGoata/ath.totalGoata)*100}%`, background: ath.doneGoata === ath.totalGoata ? GREEN : GREEN }} />
              </div>
            )}
            <div className="space-y-1.5">
              {GOATA_EXERCISES.map((ex, i) => {
                const key = `g${i}`;
                const done = ath.checks[key] === true;
                return (
                  <button key={key} onClick={() => ath.toggleCheck(key)} className="flex items-start gap-2.5 w-full text-left">
                    <span className="mt-0.5 w-4 h-4 shrink-0 rounded border flex items-center justify-center transition-all" style={{
                      borderColor: done ? GREEN : "rgba(255,255,255,0.2)",
                      background: done ? `${GREEN}20` : "transparent"
                    }}>
                      {done && <span className="text-[10px]" style={{ color:GREEN }}>✓</span>}
                    </span>
                    <p className="text-xs transition-all" style={{
                      color: done ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.65)",
                      textDecoration: done ? "line-through" : "none"
                    }}>{ex}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ── Log Session Button ── */}
          <button
            onClick={ath.logSession}
            disabled={ath.sessionLoggedToday}
            className="w-full py-4 rounded-2xl font-bold text-sm transition-all"
            style={{
              background: ath.sessionLoggedToday ? "rgba(74,222,128,0.08)" : `rgba(96,165,250,0.12)`,
              border: ath.sessionLoggedToday ? `1px solid ${GREEN}40` : `1px solid ${BLUE}40`,
              color: ath.sessionLoggedToday ? GREEN : BLUE,
              cursor: ath.sessionLoggedToday ? "default" : "pointer",
            }}>
            {ath.sessionLoggedToday ? "✓ Session Logged for Today" : "Log Completed Session (+1 this week)"}
          </button>

        </div>
      )}
    </div>
  );
}
