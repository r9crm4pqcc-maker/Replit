import { Link } from "@/lib/wouter";
import { useMemo, useState, useRef, useEffect } from "react";
import { Bot, Send, Zap, Gem, Palette, TrendingUp, TrendingDown, Minus, ChevronRight } from "lucide-react";
import { PROFILE } from "@/lib/profile";
import { calcCoreNumbers, calcDateEnergy, calcPersonalDay } from "@/lib/numerology";

const NUMBERS = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);

const BLUE   = "hsl(212 95% 65%)";
const YELLOW = "hsl(48 96% 53%)";
const GREEN  = "#4ade80";
const PURPLE = "hsl(270 60% 70%)";
const ROSE   = "#f472b6";

const energyColors: Record<number, string> = {
  1:"#f87171",2:"#fb923c",3:"#facc15",4:"#4ade80",5:"#22d3ee",
  6:"#60a5fa",7:"#a78bfa",8:"#c084fc",9:"#f472b6",
  11:"#e0f2fe",22:"#fde68a",33:"#bbf7d0",
};

const GG33_COLORS: Record<number, string> = {
  1:"Red/Gold",2:"Orange",3:"Purple",4:"Green",5:"Cyan",6:"Blue/Indigo",
  7:"Violet",8:"Black/Gold",9:"Gold/Deep Red",10:"Red/Gold",11:"Silver/White",22:"Yellow/Gold",33:"Orange",
};

const GG33_GEMS: Record<number, string> = {
  1:"Ruby + Citrine",2:"Moonstone + Pearl",3:"Amethyst + Yellow Sapphire",4:"Emerald + Sapphire",
  5:"Aquamarine + Turquoise",6:"Rose Quartz + Jade",7:"Amethyst + Labradorite",8:"Black Onyx + Blue Sapphire",
  9:"Garnet + Bloodstone",11:"Clear Quartz + Selenite",22:"Tiger's Eye + Pyrite",33:"Rose Quartz + Amethyst",
};

const GG33_ACTIONS: Record<number, string> = {
  1:"Initiate. Lead. Start something new. Your 28/10/1 wealth portal activates when you move first.",
  2:"Cooperate. Listen. Build partnerships. Patience is your weapon today.",
  3:"Create. Express yourself. Speak, write, perform. Your Expression 3 doubles today.",
  4:"Build systems. Discipline. Structure. Lay foundations that last.",
  5:"Break routine. Travel. Be spontaneous. Freedom energy is maxed.",
  6:"Nurture relationships. Give back. Harmony and beauty win today.",
  7:"Go inward. Study. Meditate. Trust your gut. Avoid big decisions.",
  8:"Execute. Negotiate. Assert authority. Your Personality 8 fires on all cylinders.",
  9:"Complete things. Release what's dead. Give generously. Clear the slate.",
};

type Module = { href: string; label: string; sublabel: string; emoji: string; bg: string };

const modules: Module[] = [
  { href:"/numerology",       label:"Numerology",        sublabel:"Core · Karmic · Tools",          emoji:"🔢", bg:"linear-gradient(135deg,#1e3a5f,#0f2040)" },
  { href:"/astrology",        label:"Astrology",         sublabel:"Charts · Transits · Vedic",      emoji:"⭐", bg:"linear-gradient(135deg,#2d1b5e,#170c38)" },
  { href:"/gematria",         label:"Gematria",          sublabel:"English · Hebrew · Matrix",      emoji:"📖", bg:"linear-gradient(135deg,#0f3d2e,#07201a)" },
  { href:"/soccer-ai",        label:"Soccer AI",         sublabel:"Gear · Training · Diet",         emoji:"⚽", bg:"linear-gradient(135deg,#0f2d4a,#071828)" },
  { href:"/compatibility",    label:"Compatibility",     sublabel:"People · Places · Brands",       emoji:"💫", bg:"linear-gradient(135deg,#3d1020,#200810)" },
  { href:"/forecasts",        label:"Forecasts",         sublabel:"Daily · Monthly · Yearly",       emoji:"🌙", bg:"linear-gradient(135deg,#1e3a1e,#0f200f)" },
  { href:"/matrix-calendar",  label:"Matrix Calendar",   sublabel:"Live · Energy · Codes",          emoji:"📅", bg:"linear-gradient(135deg,#1a2f4a,#0d1a28)" },
  { href:"/tarot",            label:"Tarot",             sublabel:"Major Arcana · Daily Draw",      emoji:"🃏", bg:"linear-gradient(135deg,#2d1045,#170825)" },
  { href:"/career",           label:"Career",            sublabel:"Life Path · Timing",             emoji:"💼", bg:"linear-gradient(135deg,#2a2000,#181200)" },
  { href:"/trading-ai",       label:"Trading AI",        sublabel:"Signals · Battlefield Mode",     emoji:"📈", bg:"linear-gradient(135deg,#0a2a1a,#051510)" },
  { href:"/sports-prediction",label:"Sports AI",         sublabel:"Cheat Code Picks",               emoji:"🏆", bg:"linear-gradient(135deg,#2a1800,#150c00)" },
  { href:"/rife",             label:"Rife Frequencies",  sublabel:"Condition → Healing Hz",         emoji:"📡", bg:"linear-gradient(135deg,#0a3020,#051810)" },
  { href:"/bazi",             label:"Chinese Astrology", sublabel:"Four Pillars · BaZi",            emoji:"🐂", bg:"linear-gradient(135deg,#2a1a00,#150d00)" },
  { href:"/feng-shui",        label:"Feng Shui",         sublabel:"Kua 9 · Directions · Stars",    emoji:"🧭", bg:"linear-gradient(135deg,#1a2a00,#0d1500)" },
  { href:"/chakra",           label:"Chakra Therapy",    sublabel:"7 Chakras · Color · Rife Hz",    emoji:"🌀", bg:"linear-gradient(135deg,#1a0a2a,#0d0515)" },
  { href:"/day-life",         label:"Day-to-Day AI",     sublabel:"Today · Wardrobe · Hacks",       emoji:"🤖", bg:"linear-gradient(135deg,#0a2a1a,#051510)" },
];

const HOME_STYLES = `
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(14px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes pulse-live {
    0%, 100% { opacity: 1; transform: scale(1); }
    50%       { opacity: 0.4; transform: scale(0.75); }
  }
  @keyframes glow-num {
    0%, 100% { filter: drop-shadow(0 0 8px var(--glow-color,#60a5fa)); }
    50%       { filter: drop-shadow(0 0 20px var(--glow-color,#60a5fa)); }
  }
  @keyframes shimmer {
    0%   { background-position: -200% center; }
    100% { background-position: 200% center; }
  }
  .home-fade-0 { animation: fadeUp 0.45s cubic-bezier(0.16,1,0.3,1) both; }
  .home-fade-1 { animation: fadeUp 0.45s 0.06s cubic-bezier(0.16,1,0.3,1) both; }
  .home-fade-2 { animation: fadeUp 0.45s 0.12s cubic-bezier(0.16,1,0.3,1) both; }
  .home-fade-3 { animation: fadeUp 0.45s 0.18s cubic-bezier(0.16,1,0.3,1) both; }
  .home-fade-4 { animation: fadeUp 0.45s 0.24s cubic-bezier(0.16,1,0.3,1) both; }
  .home-fade-5 { animation: fadeUp 0.45s 0.30s cubic-bezier(0.16,1,0.3,1) both; }
  .home-fade-6 { animation: fadeUp 0.45s 0.36s cubic-bezier(0.16,1,0.3,1) both; }
  .live-dot    { animation: pulse-live 1.8s ease-in-out infinite; }
  .glow-num    { animation: glow-num 3s ease-in-out infinite; }
  .qa-card {
    transition: transform 0.22s cubic-bezier(0.34,1.56,0.64,1),
                box-shadow 0.22s ease,
                border-color 0.2s ease;
  }
  .qa-card:hover {
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 12px 32px rgba(0,0,0,0.5);
  }
  .mod-card {
    transition: transform 0.2s cubic-bezier(0.34,1.56,0.64,1),
                opacity 0.2s ease;
  }
  .mod-card:hover { transform: translateY(-5px) scale(1.04); }
  .mod-icon {
    transition: box-shadow 0.2s ease;
  }
  .mod-card:hover .mod-icon {
    box-shadow: 0 6px 24px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.12) !important;
  }
  .stat-card {
    transition: transform 0.2s cubic-bezier(0.34,1.56,0.64,1),
                border-color 0.2s ease;
  }
  .stat-card:hover { transform: translateY(-3px); }
  .chat-input:focus {
    border-color: rgba(96,165,250,0.35) !important;
    box-shadow: 0 0 0 3px rgba(96,165,250,0.08);
  }
`;

function gg33Respond(q: string, de: ReturnType<typeof calcDateEnergy>): string {
  const low = q.toLowerCase();
  const today = new Date();
  const pd = calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, today.getMonth()+1, today.getDate(), today.getFullYear());
  const pdColor = GG33_COLORS[pd.reduced] ?? "White";

  if (low.includes("wear") || low.includes("color") || low.includes("outfit") || low.includes("wardrobe"))
    return `Today's Personal Day is ${pd.reduced}. Your power color is ${pdColor}. Your Life Path 1 always resonates with Red/Gold — layer that as an accent. Avoid colors that vibrate against your PD. The numbers don't lie — wear ${pdColor} and dominate.`;
  if (low.includes("number") || low.includes("mean") || low.includes("what is") || low.includes("explain"))
    return `Your core code: Life Path 28/10/1 — the wealth portal. Expression 3 — creative genius. Soul Urge 4 — you crave structure. Personality 8 — people see power. Birthday 8 — Saturn authority. Personal Year 9 in 2026 — completion cycle. Everything unfinished gets cleared. This is math, not opinion.`;
  if (low.includes("game") || low.includes("match") || low.includes("soccer") || low.includes("play"))
    return `Universal Day ${de.reduced} + your Personal Day ${pd.reduced} = game energy ${(de.reduced + pd.reduced) > 9 ? (de.reduced + pd.reduced) - 9 : de.reduced + pd.reduced}. Wear ${pdColor} accessories. Your LP 1 means you CREATE the play, don't wait for it. Best jersey: #10 — that's your compound wealth number. Go score.`;
  if (low.includes("action") || low.includes("do today") || low.includes("move") || low.includes("best")) {
    const action = GG33_ACTIONS[pd.reduced] ?? GG33_ACTIONS[1];
    return `Personal Day ${pd.reduced} energy is active. ${action} Universal Day is ${de.reduced} (${de.label}). Combine both: the matrix says MOVE.`;
  }
  if (low.includes("gem") || low.includes("crystal") || low.includes("stone"))
    return `For PD ${pd.reduced}, carry ${GG33_GEMS[pd.reduced] ?? "Clear Quartz"}. Your permanent stones: Ruby (LP 1 — Sun) + Black Onyx (Birthday 8 — Saturn). Stack them. The frequencies compound. This is science, not superstition.`;
  if (low.includes("brand") || low.includes("nike") || low.includes("adidas") || low.includes("puma"))
    return `Your LP 1 resonates with Nike (1→1 direct match). Nike IS the number 1 brand — leadership, victory, the swoosh is literally a checkmark from the universe. Jordan Brand (4) aligns with your Soul Urge. Avoid brands that vibrate at 2 or 6 — they soften your killer instinct.`;
  if (low.includes("chakra") || low.includes("energy") || low.includes("heal")) {
    const chakraName = pd.reduced === 1 ? "Root" : pd.reduced === 2 ? "Sacral" : pd.reduced === 3 ? "Solar Plexus" : pd.reduced === 4 ? "Heart" : pd.reduced === 5 ? "Throat" : pd.reduced === 6 ? "Third Eye" : "Crown";
    return `PD ${pd.reduced} activates your ${chakraName} chakra. Your Birthday 8 means your Soul Star (8th chakra) is naturally strong. Meditate on ${pdColor}. The frequency is ${pd.reduced * 111} Hz. Numbers are frequencies. Frequencies are reality.`;
  }
  if (low.includes("hello") || low.includes("hi") || low.includes("hey") || low.includes("sup") || low.includes("yo"))
    return `What's good, Cristian. Your Personal Day is ${pd.reduced} — that's ${pdColor} energy. Universal Day is ${de.reduced}. Ask me anything — numbers, colors, game day moves, gems, brands. The matrix is always running. Let's decode it.`;
  return `Personal Day ${pd.reduced} (${pdColor}) + Universal Day ${de.reduced} (${de.label}). ${GG33_ACTIONS[pd.reduced] ?? "Stay aligned."} Ask me about colors, numbers, game day, gems, brands, or what to do today. Everything is math. The numbers never lie.`;
}

interface ChatMsg { role: "user" | "gg33"; text: string }

function GG33Chat({ de }: { de: ReturnType<typeof calcDateEnergy> }) {
  const [messages, setMessages] = useState<ChatMsg[]>([
    { role: "gg33", text: "What's good, Cristian. I'm your GG33 AI — I speak numbers, not opinions. Your Personal Day energy is live. Ask me anything — colors, game day, gems, numbers, brands, actions. The matrix doesn't sleep." }
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  function handleSend() {
    const q = input.trim();
    if (!q || sending) return;
    setSending(true);
    const userMsg: ChatMsg = { role: "user", text: q };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setTimeout(() => {
      const reply: ChatMsg = { role: "gg33", text: gg33Respond(q, de) };
      setMessages(prev => [...prev, reply]);
      setSending(false);
    }, 420);
  }

  return (
    <div className="glass-card p-5 home-fade-6" style={{ background:"hsl(228 28% 7%)" }}>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-7 h-7 rounded-xl flex items-center justify-center" style={{ background:"rgba(250,204,21,0.1)", border:"1px solid rgba(250,204,21,0.15)" }}>
          <Bot size={13} style={{ color:YELLOW }} />
        </div>
        <p className="text-[11px] uppercase tracking-wider font-semibold" style={{ color:"rgba(255,255,255,0.38)" }}>GG33 AI Chat</p>
        <div className="flex-1" />
        <Link href="/day-life">
          <button className="px-3 py-1.5 rounded-lg text-[10px] font-semibold transition-all hover:opacity-80"
            style={{ background:"rgba(96,165,250,0.08)", color:BLUE, border:"1px solid rgba(96,165,250,0.15)" }}>
            Full Dashboard →
          </button>
        </Link>
      </div>

      <div ref={scrollRef} className="space-y-2.5 max-h-[260px] overflow-y-auto pr-1 mb-4"
        style={{ scrollbarWidth:"thin", scrollbarColor:"rgba(255,255,255,0.08) transparent" }}>
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
            style={{ animation:"fadeUp 0.25s cubic-bezier(0.16,1,0.3,1) both" }}>
            <div className="max-w-[85%] px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed"
              style={m.role === "gg33"
                ? { background:"rgba(250,204,21,0.06)", border:"1px solid rgba(250,204,21,0.1)", color:"rgba(255,255,255,0.82)" }
                : { background:"rgba(96,165,250,0.1)", border:"1px solid rgba(96,165,250,0.15)", color:"rgba(255,255,255,0.82)" }}>
              {m.role === "gg33" && <span className="text-[9px] font-bold block mb-1" style={{ color:YELLOW }}>GG33 ·</span>}
              {m.text}
            </div>
          </div>
        ))}
        {sending && (
          <div className="flex justify-start">
            <div className="px-4 py-3 rounded-2xl" style={{ background:"rgba(250,204,21,0.06)", border:"1px solid rgba(250,204,21,0.1)" }}>
              <div className="flex gap-1">
                {[0,1,2].map(i => (
                  <div key={i} className="w-1.5 h-1.5 rounded-full" style={{ background:YELLOW, animation:`pulse-live 1.2s ${i*0.2}s ease-in-out infinite` }} />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-2">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleSend()}
          placeholder="Ask GG33 — colors, numbers, game day..."
          className="chat-input flex-1 rounded-2xl px-4 py-2.5 text-xs text-white placeholder:text-white/20 outline-none transition-all"
          style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)" }}
        />
        <button onClick={handleSend}
          className="px-4 py-2.5 rounded-2xl flex items-center gap-1.5 text-xs font-semibold transition-all hover:opacity-80 active:scale-95"
          style={{ background:"rgba(250,204,21,0.12)", color:YELLOW, border:"1px solid rgba(250,204,21,0.2)" }}>
          <Send size={11} /> Send
        </button>
      </div>
    </div>
  );
}

function ModuleCard({ mod, delay }: { mod: Module; delay: number }) {
  return (
    <Link href={mod.href}>
      <div className="mod-card flex flex-col items-center gap-2 cursor-pointer" style={{ animationDelay:`${delay}ms` }}>
        <div className="mod-icon relative w-[58px] h-[58px] rounded-2xl flex items-center justify-center text-2xl"
          style={{ background:mod.bg, border:"1px solid rgba(255,255,255,0.07)", boxShadow:"0 4px 20px rgba(0,0,0,0.5),inset 0 1px 0 rgba(255,255,255,0.07)" }}>
          {mod.emoji}
        </div>
        <div className="text-center">
          <p className="text-xs font-semibold leading-tight" style={{ color:"rgba(255,255,255,0.88)" }}>{mod.label}</p>
          <p className="text-[9px] mt-0.5 leading-tight" style={{ color:"rgba(255,255,255,0.28)" }}>{mod.sublabel}</p>
        </div>
      </div>
    </Link>
  );
}

export default function Home() {
  // Date-driven values differ between the prerendered HTML and the live client
  // clock, so render only after mount to avoid a hydration mismatch.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const today = new Date();
  const de = useMemo(() => calcDateEnergy(today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const pd = useMemo(() => calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const ec = energyColors[de.reduced] ?? "#60a5fa";
  const pdColor = GG33_COLORS[pd.reduced] ?? "White";
  const pdGem   = GG33_GEMS[pd.reduced]   ?? "Clear Quartz";
  const pdec    = energyColors[pd.reduced] ?? "#60a5fa";

  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const deYest = useMemo(() => calcDateEnergy(yesterday.getMonth()+1, yesterday.getDate(), yesterday.getFullYear()), []);
  const pdYest = useMemo(() => calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, yesterday.getMonth()+1, yesterday.getDate(), yesterday.getFullYear()), []);

  const quickAccess = useMemo(() => {
    const day = today.getDay();
    const isSoccerDay = day === 5 || day === 6 || day === 0;
    return [
      { href:"/day-life",       emoji:"🤖", label:"Today's Guide",  desc:`PD ${pd.reduced} actions`,          accent:YELLOW },
      { href:"/soccer-ai",      emoji:"⚽", label:"Game Day",       desc:isSoccerDay ? "MATCH DAY ⚡" : "Training", accent:GREEN },
      { href:"/day-life/routine",emoji:"⏰",label:"Daily Routine",  desc:"Full schedule",                    accent:"#fb923c" },
      { href:"/forecasts",      emoji:"🌙", label:"Forecasts",      desc:"Daily outlook",                    accent:PURPLE },
    ];
  }, [pd.reduced]);

  const coreStats = [
    { label:"Life Path",    value:NUMBERS.lifePath,    compound:`${NUMBERS.lifePathCompound}/${NUMBERS.lifePath}`,       color:YELLOW,           why:"Wealth portal" },
    { label:"Expression",   value:NUMBERS.expression,  compound:`${NUMBERS.expressionCompound}/${NUMBERS.expression}`,   color:BLUE,             why:"How you express" },
    { label:"Soul Urge",    value:NUMBERS.soulUrge,    compound:`${NUMBERS.soulUrgeCompound}/${NUMBERS.soulUrge}`,       color:PURPLE,           why:"Deepest desire" },
    { label:"Personality",  value:NUMBERS.personality, compound:`${NUMBERS.personalityCompound}/${NUMBERS.personality}`, color:GREEN,            why:"How world sees you" },
    { label:"Birthday",     value:NUMBERS.birthday,    compound:`${NUMBERS.birthdayReduced}`,                            color:ROSE,             why:"Natural gift" },
    { label:"Personal Year",value:NUMBERS.personalYear,compound:`${NUMBERS.personalYearCompound}/${NUMBERS.personalYear}`,color:"hsl(28 95% 60%)",why:"2026 cycle" },
  ];

  const udShift = de.reduced - deYest.reduced;
  const pdShift = pd.reduced - pdYest.reduced;

  if (!mounted) return null;

  return (
    <>
      <style>{HOME_STYLES}</style>
      <div className="max-w-4xl space-y-4">

        {/* ── LIVE HEADER ── */}
        <div className="glass-card overflow-hidden home-fade-0" style={{ background:"hsl(228 28% 7%)", position:"relative" }}>
          {/* Ambient glow behind the big number */}
          <div style={{ position:"absolute", top:"-40px", left:"-40px", width:"220px", height:"220px", borderRadius:"50%", background:ec, opacity:0.06, filter:"blur(60px)", pointerEvents:"none" }} />

          <div className="p-5 relative">
            <div className="flex items-center gap-2 mb-5">
              <span className="live-dot w-2 h-2 rounded-full shrink-0" style={{ background:"#4ade80" }} />
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color:"rgba(255,255,255,0.35)" }}>
                {today.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}
              </span>
            </div>

            <div className="flex items-start gap-6">
              {/* Big UD number */}
              <div className="text-center shrink-0">
                <p className="text-[11px] uppercase tracking-wider mb-2 font-medium" style={{ color:"rgba(255,255,255,0.35)" }}>Universal Day</p>
                <div className="glow-num text-7xl font-black leading-none select-none" style={{ color:ec, ["--glow-color" as string]:ec }}>
                  {de.reduced}
                </div>
                <p className="text-[10px] mt-2" style={{ color:"rgba(255,255,255,0.3)" }}>Compound {de.compound}</p>
              </div>

              <div className="w-px self-stretch mx-1" style={{ background:"rgba(255,255,255,0.06)" }} />

              {/* Right side */}
              <div className="flex-1 min-w-0">
                <p className="text-lg font-bold mb-1 truncate" style={{ color:ec }}>{de.label}</p>
                <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>
                  {de.isMaster ? "⚡ Master Number Active" : `${de.fullSum} → ${de.compound} → ${de.reduced}`}
                </p>

                <div className="grid grid-cols-5 gap-3">
                  {[
                    { label:"LP",       val:String(NUMBERS.lifePath),    color:YELLOW  },
                    { label:"PD",       val:String(pd.reduced),          color:pdec    },
                    { label:"PY",       val:String(NUMBERS.personalYear), color:BLUE   },
                    { label:"Planet",   val:NUMBERS.planet ?? "Saturn",  color:PURPLE  },
                    { label:"Jersey",   val:"#10",                       color:GREEN   },
                  ].map(item => (
                    <div key={item.label}>
                      <p className="text-[10px] uppercase tracking-wider mb-1 font-medium" style={{ color:"rgba(255,255,255,0.32)" }}>{item.label}</p>
                      <p className="text-xl font-black leading-none" style={{ color:item.color }}>{item.val}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── QUICK ACCESS + TODAY'S LOOK ── */}
        <div className="grid grid-cols-3 gap-3 home-fade-1">
          {/* Quick access (2/3 width) */}
          <div className="col-span-2">
            <p className="text-[11px] uppercase tracking-wider mb-2.5 px-0.5 font-medium" style={{ color:"rgba(255,255,255,0.3)" }}>Quick Access</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {quickAccess.map(qa => (
                <Link key={qa.href} href={qa.href}>
                  <div className="qa-card glass-card p-4 cursor-pointer text-center h-full"
                    style={{ background:"hsl(228 28% 7%)", borderColor:"rgba(255,255,255,0.06)" }}>
                    <p className="text-2xl mb-2.5">{qa.emoji}</p>
                    <p className="text-xs font-bold text-white leading-tight">{qa.label}</p>
                    <p className="text-[10px] mt-1.5 font-semibold" style={{ color:qa.accent }}>{qa.desc}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Today's look (1/3 width) */}
          <div>
            <p className="text-[11px] uppercase tracking-wider mb-2.5 px-0.5 font-medium" style={{ color:"rgba(255,255,255,0.3)" }}>Today's Look</p>
            <div className="glass-card p-4 h-[calc(100%-1.625rem)]"
              style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(96,165,250,0.1)" }}>
              <div className="flex items-center gap-2 mb-3">
                <Palette size={12} style={{ color:BLUE }} />
                <p className="text-[10px] font-bold uppercase tracking-wider" style={{ color:BLUE }}>Wardrobe</p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full shrink-0" style={{ background:pdec, boxShadow:`0 0 12px ${pdec}50`, border:"1px solid rgba(255,255,255,0.12)" }} />
                  <div>
                    <p className="text-xs font-semibold text-white">{pdColor}</p>
                    <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.35)" }}>Power color</p>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <Gem size={14} style={{ color:PURPLE }} />
                  <div>
                    <p className="text-xs font-semibold text-white leading-snug">{pdGem}</p>
                    <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.35)" }}>Carry today</p>
                  </div>
                </div>
              </div>
              <Link href="/day-life/wardrobe">
                <div className="flex items-center gap-1 mt-4 cursor-pointer transition-opacity hover:opacity-70" style={{ color:BLUE }}>
                  <span className="text-[10px] font-semibold">Full wardrobe</span>
                  <ChevronRight size={10} />
                </div>
              </Link>
            </div>
          </div>
        </div>

        {/* ── ENERGY SHIFT ── */}
        <div className="glass-card p-4 home-fade-2" style={{ background:"hsl(228 28% 7%)" }}>
          <div className="flex items-center gap-2 mb-3">
            <Zap size={12} style={{ color:YELLOW }} />
            <p className="text-[11px] uppercase tracking-wider font-semibold" style={{ color:"rgba(255,255,255,0.32)" }}>Energy Shift · Yesterday vs Today</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {[
              { label:"Yesterday UD", val:deYest.reduced, sub:deYest.label,  accent:"rgba(255,255,255,0.3)", shift:0,       active:false },
              { label:"Today UD",     val:de.reduced,     sub:de.label,       accent:ec,                      shift:udShift, active:true  },
              { label:"Yesterday PD", val:pdYest.reduced, sub:"Personal Day", accent:"rgba(255,255,255,0.3)", shift:0,       active:false },
              { label:"Today PD",     val:pd.reduced,     sub:"Personal Day", accent:pdec,                    shift:pdShift, active:true  },
            ].map((row, i) => (
              <div key={i} className="p-3.5 rounded-xl" style={{
                background: row.active && row.shift > 0 ? "rgba(74,222,128,0.05)" : row.active && row.shift < 0 ? "rgba(248,113,113,0.05)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${row.active ? (row.shift > 0 ? "rgba(74,222,128,0.12)" : row.shift < 0 ? "rgba(248,113,113,0.12)" : "rgba(255,255,255,0.06)") : "rgba(255,255,255,0.04)"}`,
              }}>
                <p className="text-[10px] uppercase tracking-wider mb-2 font-medium" style={{ color:"rgba(255,255,255,0.28)" }}>{row.label}</p>
                <div className="flex items-center gap-1.5">
                  <p className="text-2xl font-black" style={{ color:row.accent }}>{row.val}</p>
                  {row.active && row.shift !== 0 && (
                    <div className="flex items-center gap-0.5" style={{ color: row.shift > 0 ? GREEN : ROSE }}>
                      {row.shift > 0 ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
                      <span className="text-[10px] font-bold">{row.shift > 0 ? "+" : ""}{row.shift}</span>
                    </div>
                  )}
                  {row.active && row.shift === 0 && <Minus size={12} style={{ color:"rgba(255,255,255,0.18)" }} />}
                </div>
                <p className="text-[10px] mt-1 truncate" style={{ color: row.active ? row.accent : "rgba(255,255,255,0.22)" }}>{row.sub}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── CORE NUMBERS ── */}
        <div className="home-fade-3">
          <p className="text-[11px] uppercase tracking-wider mb-2.5 px-0.5 font-medium" style={{ color:"rgba(255,255,255,0.3)" }}>
            Cristian Zavala · Born 9/8/2009 · Chicago, IL
          </p>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {coreStats.map(s => (
              <div key={s.label} className="stat-card glass-card p-3.5 text-center" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(255,255,255,0.05)" }}>
                <p className="text-[10px] uppercase tracking-wider mb-2 font-medium" style={{ color:"rgba(255,255,255,0.32)" }}>{s.label}</p>
                <p className="text-3xl font-black leading-none" style={{ color:s.color }}>{s.value}</p>
                <p className="text-[10px] mt-1.5" style={{ color:"rgba(255,255,255,0.28)" }}>{s.compound}</p>
                <p className="text-[9px] mt-1 leading-tight" style={{ color:"rgba(255,255,255,0.22)" }}>{s.why}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── DAILY CHEAT CODE ── */}
        <div className="home-fade-4 glass-card px-5 py-4 flex items-center gap-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(255,255,255,0.05)" }}>
          <div className="shrink-0">
            <p className="text-[10px] uppercase tracking-wider mb-1.5 font-medium" style={{ color:"rgba(255,255,255,0.32)" }}>Cheat Code · UD {de.reduced}</p>
            <p className="text-base font-bold" style={{ color:ec }}>{de.label}</p>
          </div>
          <div className="w-px self-stretch" style={{ background:"rgba(255,255,255,0.06)" }} />
          <p className="flex-1 text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>
            {de.reduced===1&&"Take initiative. Lead. Start something new. Your 28/10/1 wealth portal is active."}
            {de.reduced===2&&"Collaborate, listen, be patient. Build partnerships. Avoid confrontation."}
            {de.reduced===3&&"Create, express, communicate. Your Expression 3 doubles today."}
            {de.reduced===4&&"Plan, organize, build. Focus on discipline, structure, solid foundations."}
            {de.reduced===5&&"Break routine. Try something different. Freedom energy is maxed."}
            {de.reduced===6&&"Nurture relationships. Give back and beautify. Harmony energy for teamwork."}
            {de.reduced===7&&"Go inward. Study, meditate, trust your intuition. Avoid major decisions."}
            {de.reduced===8&&"Your 8 personality activates. Negotiate, close deals, assert authority."}
            {de.reduced===9&&"Complete unfinished business. Release what no longer serves. Compassion day."}
            {de.reduced===11&&"⚡ Master 11 Portal — Illumination day. Heightened intuition and spiritual downloads."}
            {de.reduced===22&&"⚡ Master 22 Portal — Manifestation day. Build something that lasts."}
          </p>
          <Link href="/matrix-calendar/cheat-codes">
            <button className="shrink-0 px-3.5 py-2 rounded-xl text-[10px] font-semibold transition-all hover:opacity-75"
              style={{ background:"rgba(96,165,250,0.1)", color:BLUE, border:"1px solid rgba(96,165,250,0.18)" }}>
              All Codes
            </button>
          </Link>
        </div>

        {/* ── ALL MODULES ── */}
        <div className="home-fade-5">
          <div className="flex items-center justify-between mb-2.5 px-0.5">
            <p className="text-[11px] uppercase tracking-wider font-medium" style={{ color:"rgba(255,255,255,0.3)" }}>All Modules</p>
            <div className="flex items-center gap-1.5">
              <span className="live-dot w-1.5 h-1.5 rounded-full" style={{ background:GREEN }} />
              <span className="text-[10px] font-medium" style={{ color:"rgba(255,255,255,0.28)" }}>16 Active</span>
            </div>
          </div>
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-x-3 gap-y-5">
              {modules.map((mod, i) => <ModuleCard key={mod.href} mod={mod} delay={i * 15} />)}
            </div>
          </div>
        </div>

        {/* ── GG33 CHAT ── */}
        <GG33Chat de={de} />

      </div>
    </>
  );
}
