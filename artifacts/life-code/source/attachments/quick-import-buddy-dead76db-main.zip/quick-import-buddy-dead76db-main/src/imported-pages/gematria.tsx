import { useParams, Link } from "@/lib/wouter";
import { Book, ChevronRight } from "lucide-react";
import { useState, useMemo } from "react";
import { gematria, reduce, hebrewGematria, NUMBER_MEANINGS_FULL } from "@/lib/numerology";
import { PROFILE } from "@/lib/profile";

const BLUE  = "hsl(212 95% 65%)";
const YELLOW= "hsl(48 96% 53%)";
const PURPLE= "hsl(270 60% 70%)";
const GREEN = "#4ade80";

const PRESETS = [
  { label:"Full Name", value:"Cristian Zavala" },
  { label:"First Name", value:"Cristian" },
  { label:"Last Name", value:"Zavala" },
  { label:"God", value:"God" },
  { label:"Bible", value:"Bible" },
  { label:"Jesus", value:"Jesus" },
  { label:"Matrix", value:"Matrix" },
  { label:"Truth", value:"Truth" },
  { label:"Eagle Owl", value:"Eagle Owl" },
];

const CIPHER_LABELS = [
  { key:"englishOrdinal",        label:"English Ordinal",         desc:"A=1 … Z=26" },
  { key:"fullReduction",         label:"Full Reduction",           desc:"Reduced to single digit" },
  { key:"reverseOrdinal",        label:"Reverse Ordinal",          desc:"A=26 … Z=1" },
  { key:"reverseFullReduction",  label:"Reverse Full Reduction",   desc:"Reverse reduced" },
  { key:"sumerian",              label:"Sumerian",                  desc:"Ordinal × 6" },
];

const tabs = [
  { key:"", label:"Calculator", href:"/gematria" },
  { key:"name", label:"Name Analysis", href:"/gematria/name" },
  { key:"hebrew", label:"Hebrew & Chaldean", href:"/gematria/hebrew" },
  { key:"cross", label:"Cross Reference", href:"/gematria/cross" },
  { key:"date", label:"Date Codes", href:"/gematria/date" },
  { key:"matrix", label:"Matrix Words", href:"/gematria/matrix" },
];

export default function GematriaPage() {
  const params = useParams<{ sub?:string }>();
  const sub = params.sub ?? "";
  const [input, setInput] = useState("Cristian Zavala");

  const result = useMemo(() => gematria(input), [input]);
  const hebrewResult = useMemo(() => hebrewGematria(input), [input]);
  const nameResult = useMemo(() => gematria(PROFILE.fullName), []);

  const matrixWords = useMemo(() => [
    "God","Matrix","Money","Jesus","Cristian","Zavala","Eagle Owl","North Grand","Winger","Chicago","Soccer","Truth","Power","Gold","Saturn"
  ].map(word=>({ word, g:gematria(word), h:hebrewGematria(word) })), []);

  const crossRefWords = useMemo(() => {
    const allWords = ["God","Jesus","Christ","Matrix","Money","Power","Truth","Love","Faith","Light","Dark","Angel","Devil","Heaven","Earth","Sun","Moon","Star","King","Queen","Gold","Silver","Cristian","Zavala","Eagle","Owl","Soccer","Winger","Chicago","Saturn","Jupiter","Mercury","Venus","Mars","Neptune","Pluto","Uranus","Bible","Torah","Quran","Dharma","Karma","Spirit","Soul","Mind","Body","Heart","Blood","Fire","Water","Air","North","South","East","West","Grand","Alpha","Omega","Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"];
    const wordData = allWords.map(w => ({ word: w, g: gematria(w) }));
    const targetOrd = gematria(PROFILE.fullName).englishOrdinal;
    const targetRed = gematria(PROFILE.fullName).fullReduction;
    return {
      ordinalMatches: wordData.filter(w => w.g.englishOrdinal === targetOrd).map(w => w.word),
      reductionMatches: wordData.filter(w => w.g.fullReduction === targetRed).map(w => w.word),
      sumerianMatches: wordData.filter(w => w.g.sumerian === gematria(PROFILE.fullName).sumerian).map(w => w.word),
    };
  }, []);

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Book size={12} style={{ color:YELLOW }} />
          <span>Gematria</span><ChevronRight size={10} /><span style={{ color:YELLOW }}>Matrix Cipher Tool</span>
        </div>
        <h1 className="page-title">Gematria</h1>
        <p className="page-subtitle">English · Reverse · Sumerian · Hebrew · Chaldean · Atbash</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(250,204,21,0.12)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {sub==="" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Enter Any Word, Name or Phrase</p>
            <input type="text" value={input} onChange={e=>setInput(e.target.value)} placeholder="Type anything..."
              className="w-full px-4 py-3 rounded-xl text-sm font-medium"
              style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.2)", color:"white", outline:"none" }} />
            <div className="flex gap-2 mt-3 flex-wrap">
              {PRESETS.map(p=>(
                <button key={p.label} onClick={()=>setInput(p.value)}
                  className="px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all"
                  style={input===p.value
                    ? { background:"rgba(250,204,21,0.15)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
                    : { color:"rgba(255,255,255,0.4)", border:"1px solid rgba(255,255,255,0.06)" }}>
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {CIPHER_LABELS.map(c=>(
              <div key={c.key} className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>{c.label}</p>
                <p className="text-4xl font-black" style={{ color:BLUE }}>{result[c.key as keyof typeof result]}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>{c.desc}</p>
              </div>
            ))}
            <div className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p>
              <p className="text-4xl font-black" style={{ color:YELLOW }}>{reduce(result.englishOrdinal)}</p>
              <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Ordinal → single digit</p>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Letter Values (English Ordinal)</p>
            <div className="flex flex-wrap gap-1.5">
              {[...input.toUpperCase()].filter(c=>/[A-Z]/.test(c)).map((c,i)=>(
                <div key={i} className="text-center px-2 py-1.5 rounded-lg" style={{ background:"rgba(96,165,250,0.07)", border:"1px solid rgba(96,165,250,0.12)" }}>
                  <p className="text-sm font-black" style={{ color:BLUE }}>{c}</p>
                  <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>{c.charCodeAt(0)-64}</p>
                </div>
              ))}
            </div>
          </div>

          {reduce(result.englishOrdinal) <= 33 && NUMBER_MEANINGS_FULL[reduce(result.englishOrdinal)] && (
            <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:YELLOW }}>Reduced Value {reduce(result.englishOrdinal)} — {NUMBER_MEANINGS_FULL[reduce(result.englishOrdinal)].title}</p>
              <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{NUMBER_MEANINGS_FULL[reduce(result.englishOrdinal)].meaning}</p>
            </div>
          )}
        </div>
      )}

      {sub==="name" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Cristian Zavala — Full Cipher Profile</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {CIPHER_LABELS.map(c=>(
                <div key={c.key} className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{c.label}</p>
                  <p className="text-3xl font-black" style={{ color:YELLOW }}>{nameResult[c.key as keyof typeof nameResult]}</p>
                </div>
              ))}
              <div className="text-center p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p>
                <p className="text-3xl font-black" style={{ color:BLUE }}>{reduce(nameResult.englishOrdinal)}</p>
              </div>
            </div>
          </div>
          {["Cristian","Zavala"].map(name=>{
            const g = gematria(name);
            return (
              <div key={name} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>{name}</p>
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center"><p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Ordinal</p><p className="text-2xl font-black" style={{ color:BLUE }}>{g.englishOrdinal}</p></div>
                  <div className="text-center"><p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p><p className="text-2xl font-black" style={{ color:YELLOW }}>{g.fullReduction}</p></div>
                  <div className="text-center"><p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Sumerian</p><p className="text-2xl font-black" style={{ color:PURPLE }}>{g.sumerian}</p></div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {sub==="hebrew" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Hebrew & Chaldean Calculator</p>
            <input type="text" value={input} onChange={e=>setInput(e.target.value)} placeholder="Type anything..."
              className="w-full px-4 py-3 rounded-xl text-sm font-medium mb-3"
              style={{ background:"rgba(96,165,250,0.06)", border:"1px solid rgba(96,165,250,0.2)", color:"white", outline:"none" }} />
            <div className="flex gap-2 flex-wrap">
              {PRESETS.map(p=>(
                <button key={p.label} onClick={()=>setInput(p.value)}
                  className="px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all"
                  style={input===p.value
                    ? { background:"rgba(250,204,21,0.15)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
                    : { color:"rgba(255,255,255,0.4)", border:"1px solid rgba(255,255,255,0.06)" }}>
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Mispar Gadol</p>
              <p className="text-4xl font-black" style={{ color:YELLOW }}>{hebrewResult.misparGadol}</p>
              <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Standard Hebrew value</p>
            </div>
            <div className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Mispar Katan</p>
              <p className="text-4xl font-black" style={{ color:BLUE }}>{hebrewResult.misparKatan}</p>
              <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Small value (reduced digits)</p>
            </div>
            <div className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Mispar Hekhrakhi</p>
              <p className="text-4xl font-black" style={{ color:PURPLE }}>{hebrewResult.misparHekhrakhi}</p>
              <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Gadol reduced to single</p>
            </div>
            <div className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Chaldean</p>
              <p className="text-4xl font-black" style={{ color:GREEN }}>{hebrewResult.chaldean}</p>
              <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Ancient Babylonian cipher</p>
            </div>
            <div className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Chaldean Reduced</p>
              <p className="text-4xl font-black" style={{ color:"#f472b6" }}>{hebrewResult.chaldeanReduced}</p>
              <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Core Chaldean vibration</p>
            </div>
            <div className="glass-card p-4 text-center" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Atbash Ordinal</p>
              <p className="text-4xl font-black" style={{ color:"#22d3ee" }}>{hebrewResult.atbashOrdinal}</p>
              <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>Mirror cipher (A↔Z)</p>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Atbash Mirror — "{input}"</p>
            <div className="flex items-center gap-3 flex-wrap">
              <div>
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Original</p>
                <p className="text-sm font-bold tracking-widest" style={{ color:BLUE }}>{input.toUpperCase().replace(/[^A-Z]/g,"")}</p>
              </div>
              <span className="text-lg" style={{ color:"rgba(255,255,255,0.2)" }}>→</span>
              <div>
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Atbash Mirror</p>
                <p className="text-sm font-bold tracking-widest" style={{ color:YELLOW }}>{hebrewResult.atbashText}</p>
              </div>
            </div>
            <p className="text-[9px] mt-3" style={{ color:"rgba(255,255,255,0.3)" }}>Atbash reverses the alphabet: A↔Z, B↔Y, C↔X, etc. Used in ancient Hebrew mysticism to reveal hidden meanings.</p>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Cipher Comparison — "{input}"</p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b" style={{ borderColor:"rgba(255,255,255,0.06)" }}>
                    <th className="text-left py-2 font-normal" style={{ color:"rgba(255,255,255,0.3)" }}>Cipher</th>
                    <th className="text-center py-2 font-normal" style={{ color:"rgba(255,255,255,0.3)" }}>Value</th>
                    <th className="text-center py-2 font-normal" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name:"English Ordinal", val:result.englishOrdinal, red:result.fullReduction, c:BLUE },
                    { name:"Reverse Ordinal", val:result.reverseOrdinal, red:result.reverseFullReduction, c:PURPLE },
                    { name:"Sumerian", val:result.sumerian, red:reduce(result.sumerian), c:YELLOW },
                    { name:"Mispar Gadol", val:hebrewResult.misparGadol, red:hebrewResult.misparHekhrakhi, c:GREEN },
                    { name:"Mispar Katan", val:hebrewResult.misparKatan, red:reduce(hebrewResult.misparKatan), c:"#f472b6" },
                    { name:"Chaldean", val:hebrewResult.chaldean, red:hebrewResult.chaldeanReduced, c:"#22d3ee" },
                    { name:"Atbash", val:hebrewResult.atbashOrdinal, red:hebrewResult.atbashReduced, c:"#fb923c" },
                  ].map(r=>(
                    <tr key={r.name} className="border-b" style={{ borderColor:"rgba(255,255,255,0.04)" }}>
                      <td className="py-2 text-white font-medium">{r.name}</td>
                      <td className="py-2 text-center font-black" style={{ color:r.c }}>{r.val}</td>
                      <td className="py-2 text-center font-bold" style={{ color:"rgba(255,255,255,0.5)" }}>{r.red}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {sub==="cross" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:YELLOW }}>Cross Reference — Cristian Zavala</p>
            <p className="text-xs mb-3" style={{ color:"rgba(255,255,255,0.4)" }}>Words that share the same gematria values as your name — connected through number resonance</p>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div className="text-center">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Ordinal</p>
                <p className="text-2xl font-black" style={{ color:BLUE }}>{gematria(PROFILE.fullName).englishOrdinal}</p>
              </div>
              <div className="text-center">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p>
                <p className="text-2xl font-black" style={{ color:YELLOW }}>{gematria(PROFILE.fullName).fullReduction}</p>
              </div>
              <div className="text-center">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Sumerian</p>
                <p className="text-2xl font-black" style={{ color:PURPLE }}>{gematria(PROFILE.fullName).sumerian}</p>
              </div>
            </div>
          </div>

          {[
            { title:`Ordinal Matches (=${gematria(PROFILE.fullName).englishOrdinal})`, words:crossRefWords.ordinalMatches, color:BLUE },
            { title:`Reduction Matches (=${gematria(PROFILE.fullName).fullReduction})`, words:crossRefWords.reductionMatches, color:YELLOW },
            { title:`Sumerian Matches (=${gematria(PROFILE.fullName).sumerian})`, words:crossRefWords.sumerianMatches, color:PURPLE },
          ].map(section=>(
            <div key={section.title} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>{section.title}</p>
              {section.words.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {section.words.map(w=>(
                    <span key={w} className="px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background:`rgba(255,255,255,0.04)`, color:section.color, border:`1px solid rgba(255,255,255,0.08)` }}>
                      {w}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.3)" }}>No matches in current word bank</p>
              )}
            </div>
          ))}

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>What Cross-Referencing Reveals</p>
            <div className="space-y-2">
              {[
                "Words with the same gematria value are believed to share energetic resonance",
                "In Kabbalistic tradition, this indicates hidden connections between concepts",
                "Your name's number connects you to every word with the same vibration",
                "This is how ancient mystics found hidden meanings in sacred texts",
              ].map((note, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span style={{ color:YELLOW }}>→</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{note}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {sub==="matrix" && (
        <div className="glass-card overflow-hidden" style={{ background:"hsl(228 28% 7%)" }}>
          <div className="grid grid-cols-8 gap-2 px-4 py-2 text-[9px] uppercase tracking-widest border-b" style={{ color:"rgba(255,255,255,0.3)", borderColor:"rgba(255,255,255,0.06)" }}>
            <span className="col-span-2">Word</span>
            <span className="text-center">Ordinal</span>
            <span className="text-center">Reduced</span>
            <span className="text-center">Reverse</span>
            <span className="text-center">Chaldean</span>
            <span className="text-center">Hebrew</span>
            <span className="text-center">Sumerian</span>
          </div>
          {matrixWords.map(({word,g,h})=>(
            <div key={word} className="grid grid-cols-8 gap-2 px-4 py-2.5 items-center border-b hover:bg-white/[0.02]"
              style={{ borderColor:"rgba(255,255,255,0.04)" }}>
              <p className="col-span-2 text-xs font-semibold text-white">{word}</p>
              <p className="text-center text-sm font-black" style={{ color:BLUE }}>{g.englishOrdinal}</p>
              <p className="text-center text-sm font-black" style={{ color:YELLOW }}>{g.fullReduction}</p>
              <p className="text-center text-sm font-black" style={{ color:PURPLE }}>{g.reverseOrdinal}</p>
              <p className="text-center text-sm font-black" style={{ color:GREEN }}>{h.chaldean}</p>
              <p className="text-center text-sm font-black" style={{ color:"#f472b6" }}>{h.misparGadol}</p>
              <p className="text-center text-sm font-black" style={{ color:"rgba(255,255,255,0.5)" }}>{g.sumerian}</p>
            </div>
          ))}
        </div>
      )}

      {sub==="date" && (
        <div className="space-y-4">
          {[
            { label:"Cristian's Birthday", date:"09/08/2009" },
            { label:"Today", date:(() => { const d=new Date(); return `${String(d.getMonth()+1).padStart(2,"0")}/${String(d.getDate()).padStart(2,"0")}/${d.getFullYear()}`; })() },
            { label:"S&P 500 Anchor", date:"03/04/1957" },
          ].map(({label,date})=>{
            const g = gematria(date.replace(/\//g,""));
            return (
              <div key={label} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{label}</p>
                <p className="text-sm font-bold text-white mb-3">{date}</p>
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center"><p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Ordinal</p><p className="text-2xl font-black" style={{ color:BLUE }}>{g.englishOrdinal}</p></div>
                  <div className="text-center"><p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Sumerian</p><p className="text-2xl font-black" style={{ color:YELLOW }}>{g.sumerian}</p></div>
                  <div className="text-center"><p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p><p className="text-2xl font-black" style={{ color:GREEN }}>{g.fullReduction}</p></div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
