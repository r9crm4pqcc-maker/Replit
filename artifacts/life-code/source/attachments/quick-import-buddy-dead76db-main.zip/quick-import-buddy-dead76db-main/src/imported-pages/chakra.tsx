import { Link } from "@/lib/wouter";
import { useParams } from "@/lib/wouter";
import { Activity, ChevronRight } from "lucide-react";
import { CHAKRAS, COLOR_THERAPY, DAILY_COLOR_WEAR, RIFE_CHAKRA } from "@/lib/chakra";
import { LearnTheCode, OutputTags } from "@/components/LearnTheCode";

const YELLOW = "#facc15";
const BLUE   = "#60a5fa";
const GREEN  = "#4ade80";
const PURPLE = "#a855f7";
const ROSE   = "#fb7185";

const STATUS_COLOR = (s: string) =>
  s === "Dominant" ? GREEN :
  s === "Balanced" ? BLUE :
  s === "Overactive" ? YELLOW :
  s === "Underactive" ? "#fb923c" :
  s === "Blocked" ? ROSE : BLUE;

const tabs = [
  { key: "",       label: "Chakra Scan",    href: "/chakra" },
  { key: "heal",   label: "Healing Plan",   href: "/chakra/heal" },
  { key: "colors", label: "Color Therapy",  href: "/chakra/colors" },
  { key: "daily",  label: "Daily Wearables",href: "/chakra/daily" },
  { key: "rife",   label: "Rife Hz",        href: "/chakra/rife" },
];

export default function ChakraPage() {
  const params = useParams<{ sub?: string }>();
  const sub = params.sub ?? "";

  return (
    <div className="max-w-4xl space-y-5">
      {/* Header */}
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>
          <Activity size={12} style={{ color: PURPLE }} />
          <span>Chakra Analysis</span>
          <ChevronRight size={10} />
          <span style={{ color: PURPLE }}>Cristian Zavala · Missing 6+7 · Third Eye + Crown blocked</span>
        </div>
        <h1 className="page-title">Chakra Analysis & Color Therapy</h1>
        <p className="page-subtitle">7+ Chakra Scan · Karmic Lessons 6 & 7 · GG33 Color Prescriptions</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t => (
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub === t.key
                ? { background: "rgba(168,85,247,0.12)", color: PURPLE, border: "1px solid rgba(168,85,247,0.25)" }
                : { color: "rgba(255,255,255,0.4)", border: "1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── CHAKRA SCAN ── */}
      {sub === "" && (
        <div className="space-y-4">
          <LearnTheCode
            title="Chakra Analysis Formula"
            steps={[
              { step: "Identify karmic lessons", formula: "Missing digits 1–9 from full name = karmic lessons", example: "CRISTIAN ZAVALA missing 6 and 7 → Third Eye + Crown blocked" },
              { step: "Map chakras to numbers", formula: "1=Root, 2=Sacral, 3=Solar Plexus, 4=Heart, 5=Throat, 6=Third Eye, 7=Crown, 8=Soul Star", example: "Missing 6 = Third Eye underactive / Missing 7 = Crown underactive" },
              { step: "Core number overlay", formula: "LP + Birthday + Expression + PY → map to chakra dominance", example: "LP1=Root dominant, Birthday8=Soul Star dominant, Expression3=Solar Plexus" },
              { step: "PY tension", formula: "Personal Year number maps to chakra tension zone", example: "PY9 = completion/release tension in Root and Crown" },
            ]}
            confidenceTag="High"
            sourceLabel="Per GG33 Academy"
          />

          {/* Scan overview card */}
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>Full Chakra Scan — Cristian Zavala</p>
            <div className="space-y-2">
              {CHAKRAS.map(c => {
                const col = STATUS_COLOR(c.status);
                return (
                  <div key={c.name} className="flex items-center gap-3 p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.02)" }}>
                    <div className="w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-xs font-black" style={{ background: c.colorHex + "22", color: c.colorHex }}>
                      {c.number}
                    </div>
                    <p className="text-xs font-semibold flex-1" style={{ color: "rgba(255,255,255,0.8)" }}>{c.name}</p>
                    <div className="w-24 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
                      <div className="h-full rounded-full" style={{
                        width: c.status === "Dominant" ? "90%" : c.status === "Balanced" ? "70%" : c.status === "Underactive" ? "40%" : c.status === "Blocked" ? "15%" : "85%",
                        background: col,
                      }} />
                    </div>
                    <span className="text-[9px] font-bold w-20 text-right" style={{ color: col }}>{c.status}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Highlighted blocked chakras */}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${ROSE}25` }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: ROSE }}>⚠ Priority: Karmic Lessons 6 & 7 — Blocked Chakras</p>
            {CHAKRAS.filter(c => c.status === "Blocked" || c.status === "Underactive").map(c => (
              <div key={c.name} className="mb-4 p-3 rounded-xl" style={{ background: "rgba(251,113,133,0.06)" }}>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-black" style={{ background: c.colorHex + "22", color: c.colorHex }}>{c.number}</div>
                  <p className="text-sm font-bold text-white">{c.name}</p>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded ml-auto" style={{ background: `${ROSE}15`, color: ROSE }}>{c.status}</span>
                </div>
                <p className="text-xs mb-2" style={{ color: "rgba(255,255,255,0.6)" }}>{c.userRelevance}</p>
                <p className="text-xs font-semibold" style={{ color: c.colorHex }}>→ {c.activationPractice.slice(0, 100)}…</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── HEALING PLAN ── */}
      {sub === "heal" && (
        <div className="space-y-3">
          {CHAKRAS.map(c => {
            const col = STATUS_COLOR(c.status);
            return (
              <div key={c.name} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${c.colorHex}18` }}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-base font-black shrink-0" style={{ background: c.colorHex + "22", color: c.colorHex }}>
                    {c.number}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold text-white">{c.name}</p>
                      <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background: `${col}15`, color: col }}>{c.status}</span>
                    </div>
                    <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.3)" }}>{c.sanskrit} · {c.location} · {c.element} · Note {c.note}</p>
                  </div>
                </div>
                <p className="text-xs mb-3 leading-relaxed" style={{ color: "rgba(255,255,255,0.6)" }}>{c.userRelevance}</p>
                <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.25)" }}>Activation Practice</p>
                <p className="text-xs mb-3" style={{ color: "rgba(255,255,255,0.55)" }}>{c.activationPractice}</p>
                <div className="flex flex-wrap gap-1.5">
                  {c.crystals.map(cr => (
                    <span key={cr} className="text-[9px] px-2 py-0.5 rounded" style={{ background: `${c.colorHex}12`, color: c.colorHex }}>{cr}</span>
                  ))}
                </div>
                {c.status === "Blocked" || c.status === "Underactive" ? (
                  <div className="mt-3 p-2 rounded-lg" style={{ background: "rgba(251,113,133,0.06)" }}>
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color: ROSE }}>Block Symptoms</p>
                    {c.blockSymptoms.map(s => (
                      <p key={s} className="text-[10px]" style={{ color: "rgba(255,255,255,0.4)" }}>→ {s}</p>
                    ))}
                  </div>
                ) : null}
                <p className="text-[9px] mt-2" style={{ color: "rgba(255,255,255,0.25)" }}>Affirmation: "{c.affirmations[0]}"</p>
              </div>
            );
          })}
        </div>
      )}

      {/* ── COLOR THERAPY ── */}
      {sub === "colors" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${PURPLE}20` }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: PURPLE }}>Personalized Color Therapy — Cristian Zavala</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>LP 1 + Expression 3 + Birthday 8 + Missing 6,7 → tailored color prescriptions for energy, confidence, stress reduction, and spiritual growth.</p>
          </div>

          {COLOR_THERAPY.map(ct => (
            <div key={ct.purpose} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
              <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.3)" }}>{ct.purpose}</p>
              <div className="flex flex-wrap gap-2 mb-3">
                {ct.colors.map(c => (
                  <div key={c.name} className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: c.hex + "18", border: `1px solid ${c.hex}30` }}>
                    <div className="w-3 h-3 rounded-full shrink-0" style={{ background: c.hex }} />
                    <div>
                      <p className="text-xs font-semibold" style={{ color: c.hex }}>{c.name}</p>
                      <p className="text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>{c.why}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: YELLOW }}>Goal-Based Color Recommendations</p>
            {[
              { goal:"Confidence Before a Game", colors:"Red (#dc2626) + Gold (#d97706)", detail:"LP1 fire + Saturn authority. Wear red base layer under your kit, gold accessories." },
              { goal:"Focus for Study/Homework", colors:"Indigo (#4338ca) + Purple (#7c3aed)", detail:"Third Eye activation (your missing 6). Sit near indigo light while studying." },
              { goal:"Stress Relief", colors:"Green (#16a34a) + Turquoise (#0891b2)", detail:"Heart chakra calming + throat opening. Wear green when you feel overwhelmed." },
              { goal:"Social Confidence", colors:"Purple (#7c3aed) + Orange (#ea580c)", detail:"Expression 3 amplifier. Orange warms your social energy, purple adds creative charisma." },
              { goal:"Better Sleep", colors:"Violet (#6d28d9) + Silver (#94a3b8)", detail:"Crown chakra soothing (your missing 7). Use violet sheets or silver pajamas." },
              { goal:"Attracting Opportunities", colors:"Gold (#d97706) + Black (#111827)", detail:"Birthday 8 power combo. Gold attracts, black grounds. PY9 wealth harvest activation." },
            ].map(g=>(
              <div key={g.goal} className="p-3 rounded-lg mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold text-white">{g.goal}</p>
                  <p className="text-[9px] ml-auto" style={{ color:YELLOW }}>{g.colors}</p>
                </div>
                <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.45)" }}>{g.detail}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: GREEN }}>Room & Environment Color Plan</p>
            {[
              { room:"Bedroom", palette:"Navy blue walls + white bedding + violet accent pillows", why:"Crown chakra healing (missing 7) + restful sleep. Navy grounds, violet opens spiritual channels." },
              { room:"Study/Desk Area", palette:"Indigo accent wall + gold desk lamp + green plant", why:"Third Eye activation (missing 6) for focus. Gold lamp = LP1 success energy. Green = grounding." },
              { room:"Living Room", palette:"Charcoal base + red and gold accents + emerald plants", why:"LP1 Red/Gold leadership energy in your main space. Emerald for Heart chakra balance." },
              { room:"Bathroom", palette:"Turquoise/teal tiles + white fixtures + silver accents", why:"Water element (your Gui DM) amplification. Cleansing energy for daily reset rituals." },
            ].map(r=>(
              <div key={r.room} className="p-3 rounded-lg mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-xs font-bold text-white mb-0.5">{r.room}</p>
                <p className="text-[10px] font-semibold mb-1" style={{ color:GREEN }}>{r.palette}</p>
                <p className="text-[10px]" style={{ color:"rgba(255,255,255,0.4)" }}>{r.why}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: ROSE }}>Wardrobe Color Palette</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs font-semibold mb-2" style={{ color:"rgba(255,255,255,0.6)" }}>Best Neutrals</p>
                {[{n:"Black",h:"#111827",w:"Saturn 8 authority"},{n:"Charcoal",h:"#374151",w:"Subtle power"},{n:"Navy",h:"#172554",w:"Depth + trust"},{n:"White",h:"#f0f0f0",w:"Clean energy reset"}].map(c=>(
                  <div key={c.n} className="flex items-center gap-2 mb-1.5">
                    <div className="w-4 h-4 rounded-full shrink-0" style={{ background:c.h, border:"1px solid rgba(255,255,255,0.1)" }} />
                    <p className="text-[10px] text-white">{c.n} <span style={{ color:"rgba(255,255,255,0.3)" }}>— {c.w}</span></p>
                  </div>
                ))}
              </div>
              <div>
                <p className="text-xs font-semibold mb-2" style={{ color:"rgba(255,255,255,0.6)" }}>Best Accents</p>
                {[{n:"Red",h:"#dc2626",w:"LP 1 fire"},{n:"Gold",h:"#d97706",w:"Wealth activator"},{n:"Purple",h:"#7c3aed",w:"Expression 3"},{n:"Emerald",h:"#10b981",w:"Heart balance"}].map(c=>(
                  <div key={c.n} className="flex items-center gap-2 mb-1.5">
                    <div className="w-4 h-4 rounded-full shrink-0" style={{ background:c.h }} />
                    <p className="text-[10px] text-white">{c.n} <span style={{ color:"rgba(255,255,255,0.3)" }}>— {c.w}</span></p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color: PURPLE }}>Color Reflection Reading</p>
            <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.55)" }}>
              Your chart reveals a deep connection to the Red-Gold-Purple spectrum. Red (LP 1) is your foundation color — it grounds you in leadership and confidence. Gold (Birthday 8) carries Saturn's authority — it attracts material success and commands respect. Purple (Expression 3) is your creative channel — it opens self-expression and artistic vision.
            </p>
            <p className="text-xs leading-relaxed mt-3" style={{ color: "rgba(255,255,255,0.55)" }}>
              The colors missing from your energy field are Indigo (6 - Third Eye) and Violet (7 - Crown). Deliberately introducing these colors into your wardrobe, room, and accessories will help heal your karmic lessons 6 and 7, opening intuition and spiritual awareness. In your PY 9 completion year, Gold becomes especially powerful — it closes karmic cycles and harvests the seeds you've planted.
            </p>
          </div>
        </div>
      )}

      {/* ── DAILY WEARABLES ── */}
      {sub === "daily" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: "rgba(255,255,255,0.3)" }}>Daily Color Prescriptions by Day of Week</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>Each day of the week is governed by a planet. Wearing the planetary color activates that energy in your body and field.</p>
          </div>
          {Object.entries(DAILY_COLOR_WEAR).map(([day, info]) => {
            const today = new Date().toLocaleDateString("en-US", { weekday: "long" });
            const isToday = today === day;
            return (
              <div key={day} className="glass-card p-4" style={{ background: isToday ? "rgba(250,204,21,0.04)" : "hsl(228 28% 7%)", border: isToday ? `1px solid ${YELLOW}25` : "1px solid transparent" }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: info.hex + "20" }}>
                    <div className="w-5 h-5 rounded-full" style={{ background: info.hex }} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold text-white">{day}</p>
                      {isToday && <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background: `${YELLOW}15`, color: YELLOW }}>TODAY</span>}
                    </div>
                    <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.3)" }}>Chakra: {info.chakra}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold" style={{ color: info.hex }}>{info.color}</p>
                  </div>
                </div>
                <p className="text-xs mt-2" style={{ color: "rgba(255,255,255,0.5)" }}>{info.why}</p>
              </div>
            );
          })}
        </div>
      )}

      {/* ── RIFE HZ ── */}
      {sub === "rife" && (
        <div className="space-y-3">
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: `1px solid ${PURPLE}20` }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: PURPLE }}>Chakra Rife Frequencies</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
              GG33 formula: LP × 111 = base activation (1 × 111 = 111 Hz). Each chakra has a specific Rife frequency for clearing and balancing.
            </p>
            <OutputTags
              calculated="LP1 × 111 = 111 Hz (base activation)"
              interpretive="Tune to blocked chakras (6+7) daily for karmic lesson healing"
              confidence="High"
            />
          </div>
          {CHAKRAS.map(c => {
            const col = STATUS_COLOR(c.status);
            const isPriority = c.status === "Blocked" || c.status === "Underactive";
            return (
              <div key={c.name} className="glass-card p-4" style={{ background: "hsl(228 28% 7%)", border: isPriority ? `1px solid ${ROSE}20` : "1px solid transparent" }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-black shrink-0" style={{ background: c.colorHex + "20", color: c.colorHex }}>
                    {c.number}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold text-white">{c.name}</p>
                      {isPriority && <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background: `${ROSE}15`, color: ROSE }}>PRIORITY</span>}
                    </div>
                    <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.3)" }}>{c.status} · Note: {c.note}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-black" style={{ color: c.colorHex }}>{c.rifeHz}</p>
                    <p className="text-[9px]" style={{ color: "rgba(255,255,255,0.3)" }}>Hz</p>
                  </div>
                </div>
                <p className="text-[10px] mt-2" style={{ color: "rgba(255,255,255,0.4)" }}>
                  {c.status === "Blocked" || c.status === "Underactive"
                    ? `⚡ Listen for 20–30 min daily — this is your priority frequency for karmic lesson ${c.number} healing.`
                    : `Maintenance: 10–15 min weekly to keep ${c.name.split(" ")[0]} balanced.`}
                </p>
              </div>
            );
          })}
          <div className="glass-card p-4" style={{ background: "hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color: YELLOW }}>LP1 × 111 = 111 Hz — Personal Activation Frequency</p>
            <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.5)" }}>
              Your personal base Rife frequency is Life Path 1 × 111 = <strong style={{ color: YELLOW }}>111 Hz</strong>. Listen to 111 Hz binaural beats every morning for 5 minutes to activate your solar/pioneer energy before training or school. For master number 33 users: 33 × 333 = 10,989 Hz (upper octave activation).
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
