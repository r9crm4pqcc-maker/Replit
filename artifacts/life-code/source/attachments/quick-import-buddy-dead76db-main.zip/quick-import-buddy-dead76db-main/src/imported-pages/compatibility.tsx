// @ts-nocheck
import { useParams, Link } from "@/lib/wouter";
import { Heart, ChevronRight, ArrowUpDown } from "lucide-react";
import { useState, useMemo } from "react";
import { calcCoreNumbers, calcCompatibility, calcDateEnergy } from "@/lib/numerology";
import { PROFILE } from "@/lib/profile";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);

const BLUE  = "hsl(212 95% 65%)";
const YELLOW= "hsl(48 96% 53%)";
const GREEN = "#4ade80";
const ROSE  = "#f87171";
const PURPLE= "#a855f7";
const PINK  = "#f472b6";

const SCORE_COLOR = (s:number) => s>=85?GREEN:s>=70?BLUE:s>=55?YELLOW:ROSE;

function reduceToSingle(n:number):number { let r=n; while(r>9&&r!==11&&r!==22&&r!==33) r=[...String(r)].reduce((a,d)=>a+(+d),0); return r; }
function yearReduce(year:number):number { const s=[...String(year)].reduce((a,d)=>a+(+d),0); return reduceToSingle(s); }
function compatScore(n1:number,n2:number):number { const d=Math.abs(n1-n2); return d===0?96:d===1?84:d===2?72:d===3?62:d===4?55:48; }

const tabs = [
  { key:"",         label:"Person to Person",  href:"/compatibility" },
  { key:"calendar", label:"Day & Month",       href:"/compatibility/calendar" },
  { key:"vehicle",  label:"Vehicle",           href:"/compatibility/vehicle" },
  { key:"house",    label:"House Numbers",     href:"/compatibility/house" },
  { key:"brands",   label:"Brands",            href:"/compatibility/brands" },
  { key:"places",   label:"Places to Live",    href:"/compatibility/places" },
];

const ALL_BRANDS: { name:string; year:number; category:string }[] = [
  { name:"Nike", year:1964, category:"Sports" },
  { name:"Adidas", year:1949, category:"Sports" },
  { name:"Puma", year:1948, category:"Sports" },
  { name:"Under Armour", year:1996, category:"Sports" },
  { name:"New Balance", year:1906, category:"Sports" },
  { name:"Reebok", year:1958, category:"Sports" },
  { name:"Jordan Brand", year:1984, category:"Sports" },
  { name:"Umbro", year:1924, category:"Sports" },
  { name:"Mizuno", year:1906, category:"Sports" },
  { name:"ASICS", year:1949, category:"Sports" },
  { name:"Lotto", year:1973, category:"Sports" },
  { name:"Diadora", year:1948, category:"Sports" },
  { name:"Kappa", year:1967, category:"Sports" },
  { name:"Joma", year:1965, category:"Sports" },
  { name:"Hummel", year:1923, category:"Sports" },
  { name:"Fila", year:1911, category:"Sports" },
  { name:"Champion", year:1919, category:"Sports" },
  { name:"Apple", year:1976, category:"Tech" },
  { name:"Google", year:1998, category:"Tech" },
  { name:"Microsoft", year:1975, category:"Tech" },
  { name:"Amazon", year:1994, category:"Tech" },
  { name:"Tesla", year:2003, category:"Tech" },
  { name:"NVIDIA", year:1993, category:"Tech" },
  { name:"Samsung", year:1938, category:"Tech" },
  { name:"Sony", year:1946, category:"Tech" },
  { name:"Meta", year:2004, category:"Tech" },
  { name:"Netflix", year:1997, category:"Tech" },
  { name:"Spotify", year:2006, category:"Tech" },
  { name:"Nintendo", year:1889, category:"Tech" },
  { name:"PlayStation", year:1994, category:"Tech" },
  { name:"Xbox", year:2001, category:"Tech" },
  { name:"Louis Vuitton", year:1854, category:"Fashion" },
  { name:"Gucci", year:1921, category:"Fashion" },
  { name:"Chanel", year:1910, category:"Fashion" },
  { name:"Prada", year:1913, category:"Fashion" },
  { name:"Dior", year:1946, category:"Fashion" },
  { name:"Versace", year:1978, category:"Fashion" },
  { name:"Burberry", year:1856, category:"Fashion" },
  { name:"Balenciaga", year:1919, category:"Fashion" },
  { name:"Givenchy", year:1952, category:"Fashion" },
  { name:"Ralph Lauren", year:1967, category:"Fashion" },
  { name:"Tommy Hilfiger", year:1985, category:"Fashion" },
  { name:"Calvin Klein", year:1968, category:"Fashion" },
  { name:"Supreme", year:1994, category:"Fashion" },
  { name:"Off-White", year:2012, category:"Fashion" },
  { name:"Zara", year:1975, category:"Fashion" },
  { name:"H&M", year:1947, category:"Fashion" },
  { name:"Uniqlo", year:1984, category:"Fashion" },
  { name:"GAP", year:1969, category:"Fashion" },
  { name:"Levi's", year:1853, category:"Fashion" },
  { name:"Coca-Cola", year:1886, category:"Food" },
  { name:"Pepsi", year:1898, category:"Food" },
  { name:"McDonald's", year:1940, category:"Food" },
  { name:"Starbucks", year:1971, category:"Food" },
  { name:"Chipotle", year:1993, category:"Food" },
  { name:"Gatorade", year:1965, category:"Food" },
  { name:"Red Bull", year:1987, category:"Food" },
  { name:"BMW", year:1916, category:"Auto" },
  { name:"Mercedes-Benz", year:1926, category:"Auto" },
  { name:"Lamborghini", year:1963, category:"Auto" },
  { name:"Ferrari", year:1947, category:"Auto" },
  { name:"Porsche", year:1931, category:"Auto" },
  { name:"Audi", year:1909, category:"Auto" },
  { name:"Toyota", year:1937, category:"Auto" },
  { name:"Honda", year:1948, category:"Auto" },
  { name:"Ford", year:1903, category:"Auto" },
  { name:"Chevrolet", year:1911, category:"Auto" },
  { name:"Dodge", year:1900, category:"Auto" },
  { name:"Jeep", year:1941, category:"Auto" },
  { name:"Chicago Fire FC", year:1997, category:"Teams" },
  { name:"Chicago Bears", year:1920, category:"Teams" },
  { name:"Chicago Bulls", year:1966, category:"Teams" },
  { name:"Chicago Cubs", year:1876, category:"Teams" },
  { name:"Chicago White Sox", year:1900, category:"Teams" },
  { name:"Chicago Blackhawks", year:1926, category:"Teams" },
  { name:"Real Madrid", year:1902, category:"Teams" },
  { name:"FC Barcelona", year:1899, category:"Teams" },
  { name:"Manchester United", year:1878, category:"Teams" },
  { name:"Liverpool FC", year:1892, category:"Teams" },
  { name:"Chelsea FC", year:1905, category:"Teams" },
  { name:"Arsenal", year:1886, category:"Teams" },
  { name:"LA Galaxy", year:1994, category:"Teams" },
  { name:"Inter Miami", year:2018, category:"Teams" },
  { name:"Club América", year:1916, category:"Teams" },
  { name:"Manchester City", year:1880, category:"Teams" },
  { name:"Paris Saint-Germain", year:1970, category:"Teams" },
  { name:"Juventus", year:1897, category:"Teams" },
  { name:"Bayern Munich", year:1900, category:"Teams" },
  { name:"AC Milan", year:1899, category:"Teams" },
].map(b => {
  const reduced = yearReduce(b.year);
  const score = compatScore(N.lifePath, reduced);
  return { ...b, reduced, score };
});

const ALL_PLACES: { city:string; country:string; year:number; note:string }[] = [
  { city:"Chicago, IL", country:"USA", year:1837, note:"Birth city" },
  { city:"New York, NY", country:"USA", year:1624, note:"Financial capital" },
  { city:"Los Angeles, CA", country:"USA", year:1850, note:"Entertainment hub" },
  { city:"Miami, FL", country:"USA", year:1896, note:"Latin energy" },
  { city:"Las Vegas, NV", country:"USA", year:1905, note:"Energy city" },
  { city:"Houston, TX", country:"USA", year:1836, note:"Energy industry" },
  { city:"Dallas, TX", country:"USA", year:1841, note:"Business hub" },
  { city:"Phoenix, AZ", country:"USA", year:1881, note:"Desert energy" },
  { city:"San Diego, CA", country:"USA", year:1769, note:"Coastal calm" },
  { city:"Denver, CO", country:"USA", year:1858, note:"Mountain energy" },
  { city:"Atlanta, GA", country:"USA", year:1837, note:"Southern hub" },
  { city:"Seattle, WA", country:"USA", year:1851, note:"Tech & innovation" },
  { city:"Austin, TX", country:"USA", year:1839, note:"Creative tech" },
  { city:"Portland, OR", country:"USA", year:1845, note:"Alternative energy" },
  { city:"San Francisco, CA", country:"USA", year:1776, note:"Innovation capital" },
  { city:"Boston, MA", country:"USA", year:1630, note:"Academic power" },
  { city:"Nashville, TN", country:"USA", year:1779, note:"Music energy" },
  { city:"Detroit, MI", country:"USA", year:1701, note:"Resilience city" },
  { city:"London", country:"UK", year:47, note:"Historic power" },
  { city:"Madrid", country:"Spain", year:852, note:"Passion energy" },
  { city:"Barcelona", country:"Spain", year:230, note:"Creative fire" },
  { city:"Paris", country:"France", year:250, note:"Art & beauty" },
  { city:"Tokyo", country:"Japan", year:1457, note:"Discipline" },
  { city:"Dubai", country:"UAE", year:1833, note:"Wealth energy" },
  { city:"Mexico City", country:"Mexico", year:1325, note:"Ancient power" },
  { city:"Guadalajara", country:"Mexico", year:1542, note:"Culture hub" },
  { city:"Monterrey", country:"Mexico", year:1596, note:"Industry" },
  { city:"São Paulo", country:"Brazil", year:1554, note:"Mega energy" },
  { city:"Buenos Aires", country:"Argentina", year:1580, note:"Passion" },
  { city:"Toronto", country:"Canada", year:1793, note:"Multicultural" },
].map(p => {
  const reduced = yearReduce(p.year);
  const score = compatScore(N.lifePath, reduced);
  return { ...p, reduced, score };
});

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export default function CompatibilityPage() {
  const params = useParams<{ sub?:string }>();
  const sub = params.sub ?? "";
  const today = new Date();

  const [name2, setName2]   = useState("");
  const [month2, setMonth2] = useState<number|"">("");
  const [day2, setDay2]     = useState<number|"">("");
  const [year2, setYear2]   = useState<number|"">("");

  const [brandSort, setBrandSort] = useState<"high"|"low">("high");
  const [brandCat, setBrandCat]   = useState("All");
  const [placeSort, setPlaceSort] = useState<"high"|"low">("high");

  const [houseNum, setHouseNum]    = useState("1234");
  const [vehicleYear, setVehicleYear] = useState("2024");
  const [vehicleName, setVehicleName] = useState("");

  const n2 = useMemo(() => {
    if (!name2 || !month2 || !day2 || !year2) return null;
    const [first, ...rest] = name2.trim().split(" ");
    const last = rest.join(" ") || first;
    try { return calcCoreNumbers(first, "", last, Number(month2), Number(day2), Number(year2)); } catch { return null; }
  }, [name2, month2, day2, year2]);

  const compat = useMemo(() => n2 ? calcCompatibility(N.lifePath, N.expression, n2.lifePath, n2.expression) : null, [n2]);
  const scoreColor = compat ? SCORE_COLOR(compat.score) : YELLOW;

  const sortedBrands = useMemo(() => {
    let list = brandCat==="All" ? ALL_BRANDS : ALL_BRANDS.filter(b=>b.category===brandCat);
    return brandSort==="high" ? [...list].sort((a,b)=>b.score-a.score) : [...list].sort((a,b)=>a.score-b.score);
  }, [brandSort, brandCat]);

  const sortedPlaces = useMemo(() =>
    placeSort==="high" ? [...ALL_PLACES].sort((a,b)=>b.score-a.score) : [...ALL_PLACES].sort((a,b)=>a.score-b.score),
    [placeSort]);

  const houseResult = useMemo(() => {
    const digits = houseNum.replace(/\D/g,"");
    if(!digits) return null;
    const compound = [...digits].reduce((a,d)=>a+(+d),0);
    const reduced = reduceToSingle(compound);
    const lpScore = compatScore(N.lifePath, reduced);
    const bdScore = compatScore(N.birthday, reduced);
    const avgScore = Math.round((lpScore+bdScore)/2);
    return { compound, reduced, lpScore, bdScore, avgScore };
  }, [houseNum]);

  const vehicleResult = useMemo(() => {
    const yr = parseInt(vehicleYear);
    if(isNaN(yr)) return null;
    const reduced = yearReduce(yr);
    const score = compatScore(N.lifePath, reduced);
    return { reduced, score, year: yr };
  }, [vehicleYear]);

  const monthData = useMemo(() =>
    MONTHS.map((name,i) => {
      const monthNum = i+1;
      const reduced = reduceToSingle(monthNum);
      const score = compatScore(N.lifePath, reduced);
      return { name, monthNum, reduced, score };
    }), []);

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Heart size={12} style={{ color:PINK }} />
          <span>Compatibility</span><ChevronRight size={10} /><span style={{ color:PINK }}>Cristian Zavala</span>
        </div>
        <h1 className="page-title">Compatibility</h1>
        <p className="page-subtitle">Life Path × Expression harmony analysis</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(244,114,182,0.12)", color:PINK, border:"1px solid rgba(244,114,182,0.25)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {sub==="" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:YELLOW }}>Person 1 — You</p>
            <p className="text-sm font-bold text-white">{PROFILE.fullName}</p>
            <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{PROFILE.birthDateStr} · Chicago, IL</p>
            <div className="flex gap-3 mt-2">
              {[{l:"Life Path",v:N.lifePath,c:YELLOW},{l:"Expression",v:N.expression,c:BLUE},{l:"Soul Urge",v:N.soulUrge,c:PURPLE},{l:"Personality",v:N.personality,c:GREEN}].map(s=>(
                <div key={s.l}><p className="text-[9px] mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>{s.l}</p><p className="text-xl font-black" style={{ color:s.c }}>{s.v}</p></div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Person 2 — Enter Anyone</p>
            <div className="space-y-3">
              <input type="text" placeholder="Full Name (First Last)" value={name2} onChange={e=>setName2(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl text-sm"
                style={{ background:"rgba(244,114,182,0.06)", border:"1px solid rgba(244,114,182,0.2)", color:"white", outline:"none" }} />
              <div className="flex gap-2">
                {[{p:"Month",v:month2,s:setMonth2,mn:1,mx:12,w:"w-20"},{p:"Day",v:day2,s:setDay2,mn:1,mx:31,w:"w-20"},{p:"Year",v:year2,s:setYear2,mn:1900,mx:2025,w:"w-24"}].map(f=>(
                  <div key={f.p} className={f.w}>
                    <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{f.p}</p>
                    <input type="number" min={f.mn} max={f.mx} placeholder={f.p} value={f.v} onChange={e=>f.s(+e.target.value as any)}
                      className="w-full text-center rounded-lg px-2 py-1.5 text-sm font-bold"
                      style={{ background:"rgba(244,114,182,0.06)", border:"1px solid rgba(244,114,182,0.2)", color:PINK, outline:"none" }} />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {compat && n2 && (
            <>
              <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:`1px solid ${scoreColor}30` }}>
                <div className="flex items-center gap-5">
                  <div className="text-center shrink-0">
                    <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Harmony</p>
                    <p className="text-5xl font-black" style={{ color:scoreColor }}>{compat.score}%</p>
                    <p className="text-xs font-semibold mt-1" style={{ color:scoreColor }}>{compat.label}</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">{compat.detail}</p>
                    <div className="grid grid-cols-2 gap-3 mt-3">
                      <div><p className="text-[9px] mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Their Life Path</p><p className="text-2xl font-black" style={{ color:BLUE }}>{n2.lifePath}</p></div>
                      <div><p className="text-[9px] mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Their Expression</p><p className="text-2xl font-black" style={{ color:YELLOW }}>{n2.expression}</p></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label:"Soul Urge Harmony", score:compatScore(N.soulUrge,n2.soulUrge), desc:`Your ${N.soulUrge} + Their ${n2.soulUrge}` },
                  { label:"Personality Match", score:compatScore(N.personality,n2.personality), desc:`Your ${N.personality} + Their ${n2.personality}` },
                  { label:"Birthday Sync", score:compatScore(N.birthday,n2.birthday), desc:`Your ${N.birthday} + Their ${n2.birthday}` },
                  { label:"Overall Harmony", score:Math.round((compat.score+compatScore(N.soulUrge,n2.soulUrge)+compatScore(N.personality,n2.personality))/3), desc:"Average of all metrics" },
                ].map(r=>(
                  <div key={r.label} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
                    <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>{r.label}</p>
                    <p className="text-2xl font-black" style={{ color:SCORE_COLOR(r.score) }}>{r.score}%</p>
                    <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>{r.desc}</p>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {sub==="calendar" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PINK }}>Monthly Compatibility — Life Path {N.lifePath}</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>How each month's energy aligns with your LP {N.lifePath}. Plan big moves in your best months.</p>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
              {monthData.map(m=>(
                <div key={m.name} className="p-3 rounded-xl text-center" style={{ background:`${SCORE_COLOR(m.score)}08`, border:`1px solid ${SCORE_COLOR(m.score)}20` }}>
                  <p className="text-xs font-bold text-white">{m.name}</p>
                  <p className="text-2xl font-black mt-1" style={{ color:SCORE_COLOR(m.score) }}>{m.score}%</p>
                  <p className="text-[9px] mt-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Energy {m.reduced}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Daily Compatibility — {MONTHS[today.getMonth()]} {today.getFullYear()}</p>
            <div className="grid grid-cols-7 gap-1.5">
              {["Su","Mo","Tu","We","Th","Fr","Sa"].map(d=>(
                <div key={d} className="text-center text-[9px] font-semibold py-1" style={{ color:"rgba(255,255,255,0.3)" }}>{d}</div>
              ))}
              {Array.from({length:new Date(today.getFullYear(),today.getMonth(),1).getDay()},(_,i)=>(
                <div key={`pad-${i}`} />
              ))}
              {Array.from({length:new Date(today.getFullYear(),today.getMonth()+1,0).getDate()},(_,i)=>{
                const dayNum = i+1;
                const de = calcDateEnergy(today.getMonth()+1, dayNum, today.getFullYear());
                const score = compatScore(N.lifePath, de.reduced);
                const isToday = dayNum === today.getDate();
                return (
                  <div key={dayNum} className="p-1.5 rounded-lg text-center" style={{
                    background: isToday ? `${BLUE}20` : `${SCORE_COLOR(score)}06`,
                    border: isToday ? `1px solid ${BLUE}40` : "1px solid rgba(255,255,255,0.04)",
                  }}>
                    <p className="text-xs font-bold" style={{ color:isToday?"white":"rgba(255,255,255,0.7)" }}>{dayNum}</p>
                    <div className="w-2 h-2 rounded-full mx-auto mt-0.5" style={{ background:SCORE_COLOR(score) }} />
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-4 mt-3 justify-center">
              {[{l:"Great",c:GREEN},{l:"Good",c:BLUE},{l:"OK",c:YELLOW},{l:"Tough",c:ROSE}].map(x=>(
                <div key={x.l} className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full" style={{ background:x.c }} />
                  <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.4)" }}>{x.l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {sub==="vehicle" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PINK }}>Vehicle Compatibility Calculator</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>Enter your vehicle's model year (or the brand's founding year) to check alignment with your Life Path {N.lifePath}.</p>
            <div className="flex gap-3 mb-4">
              <div className="flex-1">
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Vehicle Name</p>
                <input type="text" placeholder="e.g. BMW M4" value={vehicleName} onChange={e=>setVehicleName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg text-sm"
                  style={{ background:"rgba(244,114,182,0.06)", border:"1px solid rgba(244,114,182,0.15)", color:"white", outline:"none" }} />
              </div>
              <div className="w-28">
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Year</p>
                <input type="number" value={vehicleYear} onChange={e=>setVehicleYear(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg text-sm text-center font-bold"
                  style={{ background:"rgba(244,114,182,0.06)", border:"1px solid rgba(244,114,182,0.15)", color:PINK, outline:"none" }} />
              </div>
            </div>
            {vehicleResult && (
              <div className="p-4 rounded-xl" style={{ background:`${SCORE_COLOR(vehicleResult.score)}08`, border:`1px solid ${SCORE_COLOR(vehicleResult.score)}20` }}>
                <div className="flex items-center gap-5">
                  <div className="text-center shrink-0">
                    <p className="text-5xl font-black" style={{ color:SCORE_COLOR(vehicleResult.score) }}>{vehicleResult.score}%</p>
                    <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>Compatibility</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-white">{vehicleName || `${vehicleResult.year} Vehicle`}</p>
                    <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.5)" }}>
                      Year {vehicleResult.year} → digits sum → reduced to {vehicleResult.reduced}
                    </p>
                    <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.5)" }}>
                      Your LP {N.lifePath} vs Vehicle Energy {vehicleResult.reduced} → {vehicleResult.score >= 84 ? "Excellent match! This vehicle amplifies your energy." : vehicleResult.score >= 72 ? "Good alignment. This vehicle supports your path." : vehicleResult.score >= 55 ? "Moderate fit. Not ideal but workable." : "Low compatibility. This vehicle's energy conflicts with yours."}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Best Vehicle Years for LP {N.lifePath}</p>
            <div className="grid grid-cols-5 gap-2">
              {[2024,2023,2022,2021,2020,2019,2018,2017,2016,2015].map(yr=>{
                const r = yearReduce(yr);
                const sc = compatScore(N.lifePath, r);
                return (
                  <div key={yr} className="p-2 rounded-lg text-center" style={{ background:`${SCORE_COLOR(sc)}08` }}>
                    <p className="text-xs font-bold text-white">{yr}</p>
                    <p className="text-lg font-black" style={{ color:SCORE_COLOR(sc) }}>{sc}%</p>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Auto Brand Compatibility</p>
            {ALL_BRANDS.filter(b=>b.category==="Auto").sort((a,b)=>b.score-a.score).map(b=>(
              <div key={b.name} className="flex items-center justify-between p-2.5 rounded-lg mb-1.5" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div>
                  <p className="text-sm font-semibold text-white">{b.name}</p>
                  <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>Est. {b.year} → Energy {b.reduced}</p>
                </div>
                <p className="text-xl font-black shrink-0" style={{ color:SCORE_COLOR(b.score) }}>{b.score}%</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {sub==="house" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PINK }}>House Number Calculator</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>
              Enter your house or apartment number. We reduce it to a single digit and compare to your Life Path {N.lifePath} and Birthday {N.birthday}.
            </p>
            <div className="flex gap-3 items-end mb-4">
              <div className="flex-1">
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>House / Apt Number</p>
                <input type="text" value={houseNum} onChange={e=>setHouseNum(e.target.value)} placeholder="e.g. 1234"
                  className="w-full px-4 py-3 rounded-xl text-lg font-bold text-center"
                  style={{ background:"rgba(244,114,182,0.06)", border:"1px solid rgba(244,114,182,0.2)", color:"white", outline:"none" }} />
              </div>
            </div>
            {houseResult && (
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="p-3 rounded-xl text-center" style={{ background:"rgba(96,165,250,0.08)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Compound</p>
                  <p className="text-3xl font-black" style={{ color:BLUE }}>{houseResult.compound}</p>
                </div>
                <div className="p-3 rounded-xl text-center" style={{ background:"rgba(250,204,21,0.08)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Reduced</p>
                  <p className="text-3xl font-black" style={{ color:YELLOW }}>{houseResult.reduced}</p>
                </div>
                <div className="p-3 rounded-xl text-center" style={{ background:`${SCORE_COLOR(houseResult.avgScore)}10` }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Match</p>
                  <p className="text-3xl font-black" style={{ color:SCORE_COLOR(houseResult.avgScore) }}>{houseResult.avgScore}%</p>
                </div>
              </div>
            )}
            {houseResult && (
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <div><p className="text-xs font-semibold text-white">Life Path Alignment</p><p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>House {houseResult.reduced} vs LP {N.lifePath}</p></div>
                  <p className="text-xl font-black" style={{ color:SCORE_COLOR(houseResult.lpScore) }}>{houseResult.lpScore}%</p>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <div><p className="text-xs font-semibold text-white">Birthday Alignment</p><p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>House {houseResult.reduced} vs Birthday {N.birthday}</p></div>
                  <p className="text-xl font-black" style={{ color:SCORE_COLOR(houseResult.bdScore) }}>{houseResult.bdScore}%</p>
                </div>
              </div>
            )}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Best House Numbers for Cristian</p>
            <div className="grid grid-cols-3 gap-2">
              {[1,8,9,10,19,28].map(n=>{
                const r = reduceToSingle(n);
                const sc = compatScore(N.lifePath, r);
                return (
                  <div key={n} className="p-3 rounded-lg text-center" style={{ background:`${SCORE_COLOR(sc)}08` }}>
                    <p className="text-2xl font-black" style={{ color:SCORE_COLOR(sc) }}>{n}</p>
                    <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>→ {r} · {sc}%</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {sub==="brands" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="flex items-center justify-between mb-4">
              <p className="text-[10px] uppercase tracking-widest" style={{ color:PINK }}>All Brands — LP {N.lifePath} Compatibility</p>
              <div className="flex items-center gap-2">
                <button onClick={()=>setBrandSort(s=>s==="high"?"low":"high")} className="flex items-center gap-1 px-2 py-1 rounded text-[10px] font-semibold"
                  style={{ background:"rgba(244,114,182,0.1)", color:PINK, border:"1px solid rgba(244,114,182,0.2)" }}>
                  <ArrowUpDown size={10} /> {brandSort==="high"?"Highest":"Lowest"} First
                </button>
              </div>
            </div>
            <div className="flex gap-1.5 flex-wrap mb-4">
              {["All","Sports","Tech","Fashion","Food","Auto","Teams"].map(c=>(
                <button key={c} onClick={()=>setBrandCat(c)} className="px-2.5 py-1 rounded-lg text-[10px] font-medium"
                  style={brandCat===c
                    ? { background:"rgba(244,114,182,0.12)", color:PINK, border:"1px solid rgba(244,114,182,0.2)" }
                    : { color:"rgba(255,255,255,0.4)", border:"1px solid rgba(255,255,255,0.06)" }}>
                  {c}
                </button>
              ))}
            </div>
            <p className="text-[9px] mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>{sortedBrands.length} brands</p>
            <div className="space-y-1.5" style={{ maxHeight:"500px", overflowY:"auto" }}>
              {sortedBrands.map(b=>(
                <div key={b.name} className="flex items-center justify-between p-2.5 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-white">{b.name}</p>
                      <span className="text-[8px] px-1.5 py-0.5 rounded" style={{ background:"rgba(255,255,255,0.05)", color:"rgba(255,255,255,0.35)" }}>{b.category}</span>
                    </div>
                    <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>Est. {b.year} → Energy {b.reduced}</p>
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    <p className="text-xl font-black" style={{ color:SCORE_COLOR(b.score) }}>{b.score}%</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {sub==="places" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="flex items-center justify-between mb-4">
              <p className="text-[10px] uppercase tracking-widest" style={{ color:PINK }}>Places to Live — LP {N.lifePath} Compatibility</p>
              <button onClick={()=>setPlaceSort(s=>s==="high"?"low":"high")} className="flex items-center gap-1 px-2 py-1 rounded text-[10px] font-semibold"
                style={{ background:"rgba(244,114,182,0.1)", color:PINK, border:"1px solid rgba(244,114,182,0.2)" }}>
                <ArrowUpDown size={10} /> {placeSort==="high"?"Highest":"Lowest"} First
              </button>
            </div>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>
              Based on each city's founding year reduced to a single digit compared to your Life Path {N.lifePath}.
            </p>
            <div className="space-y-1.5">
              {sortedPlaces.map(p=>(
                <div key={p.city} className="flex items-center justify-between p-3 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                  <div>
                    <p className="text-sm font-semibold text-white">{p.city}</p>
                    <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.35)" }}>{p.country} · Est. {p.year} → Energy {p.reduced} · {p.note}</p>
                  </div>
                  <p className="text-xl font-black ml-4 shrink-0" style={{ color:SCORE_COLOR(p.score) }}>{p.score}%</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
