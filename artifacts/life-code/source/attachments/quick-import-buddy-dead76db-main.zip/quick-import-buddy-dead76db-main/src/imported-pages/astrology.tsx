import { useParams, Link } from "@/lib/wouter";
import { Star, ChevronRight } from "lucide-react";
import {
  WESTERN_CHART, ASPECTS, HOUSES, MOON_NAKSHATRA, VEDIC_SUMMARY,
  VIRGO_SUN, SAGITTARIUS_RISING,
  DIGNITIES, CHART_RULERS, ASPECT_PATTERNS, MINOR_ASPECTS,
  ASTEROIDS, FIXED_STARS, MIDPOINTS, DEGREE_ANALYSIS,
  SECONDARY_PROGRESSIONS, SOLAR_RETURN, PROFECTIONS,
  ZODIACAL_RELEASING, LUNAR_NODES_DETAIL, LOCATIONAL_ASTROLOGY,
  DRACONIC_CHART, DIVISIONAL_CHARTS, DASHAS, YOGAS, REMEDIAL_MEASURES,
} from "@/lib/astrology";

const YELLOW = "hsl(48 96% 53%)";
const BLUE   = "hsl(212 95% 65%)";
const PURPLE = "hsl(270 60% 70%)";
const GREEN  = "#4ade80";
const ROSE   = "#f472b6";

const SIGN_COLORS: Record<string,string> = {
  Aries:"#f87171", Taurus:"#4ade80", Gemini:"#facc15", Cancer:"#60a5fa",
  Leo:"#fb923c", Virgo:"#a3e635", Libra:"#f472b6", Scorpio:"#c084fc",
  Sagittarius:"#22d3ee", Capricorn:"#94a3b8", Aquarius:"#60a5fa", Pisces:"#818cf8",
};

const tabs = [
  { key:"", label:"Birth Chart", href:"/astrology" },
  { key:"aspects", label:"Aspects", href:"/astrology/aspects" },
  { key:"houses", label:"Houses", href:"/astrology/houses" },
  { key:"dignities", label:"Dignities", href:"/astrology/dignities" },
  { key:"vedic", label:"Vedic", href:"/astrology/vedic" },
  { key:"timing", label:"Timing", href:"/astrology/timing" },
  { key:"nodes", label:"Nodes & Karma", href:"/astrology/nodes" },
  { key:"locational", label:"Locational", href:"/astrology/locational" },
  { key:"advanced", label:"Deep Chart", href:"/astrology/advanced" },
  { key:"remedies", label:"Remedies", href:"/astrology/remedies" },
];

export default function AstrologyPage() {
  const params = useParams<{ sub?: string }>();
  const sub = params.sub ?? "";

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <Star size={12} style={{ color:YELLOW }} />
          <span>Astrology</span><ChevronRight size={10} /><span style={{ color:YELLOW }}>Cristian Zavala</span>
        </div>
        <h1 className="page-title">Astrology</h1>
        <p className="page-subtitle">September 8, 2009 · 11:18 AM CDT · Chicago, IL 41.88°N 87.63°W</p>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(250,204,21,0.12)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {sub==="" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-4" style={{ color:"rgba(255,255,255,0.3)" }}>Western Tropical Chart Summary</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
              {[
                { label:"Sun Sign",  value:"Virgo",        degree:"15°48'", color:SIGN_COLORS["Virgo"] },
                { label:"Moon Sign", value:"Taurus",       degree:"18°22'", color:SIGN_COLORS["Taurus"] },
                { label:"Rising",   value:"Sagittarius",  degree:"≈20°",   color:SIGN_COLORS["Sagittarius"] },
                { label:"Midheaven",value:"Virgo",        degree:"≈15°",   color:SIGN_COLORS["Virgo"] },
              ].map(s=>(
                <div key={s.label} className="text-center p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{s.label}</p>
                  <p className="text-lg font-black" style={{ color:s.color }}>{s.value}</p>
                  <p className="text-[9px] mt-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>{s.degree}</p>
                </div>
              ))}
            </div>
            <div className="divider-blue" />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
              <div>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Chart Ruler</p>
                <p style={{ color:YELLOW }}>{CHART_RULERS.chartRuler.planet} in {CHART_RULERS.chartRuler.sign}</p>
              </div>
              <div>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Final Dispositor</p>
                <p style={{ color:BLUE }}>Mercury in Virgo (own sign)</p>
              </div>
              <div>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Chart Signature</p>
                <p style={{ color:PURPLE }}>Sun+Saturn+Mercury in 10th Virgo</p>
              </div>
            </div>
          </div>

          <div className="glass-card overflow-hidden" style={{ background:"hsl(228 28% 7%)" }}>
            <div className="grid grid-cols-12 gap-2 px-4 py-2 text-[9px] uppercase tracking-widest border-b" style={{ color:"rgba(255,255,255,0.3)", borderColor:"rgba(255,255,255,0.06)" }}>
              <span className="col-span-4">Planet</span>
              <span className="col-span-2">Sign</span>
              <span className="col-span-2 text-center">Degree</span>
              <span className="col-span-1 text-center">House</span>
              <span className="col-span-3">Vedic Sign</span>
            </div>
            {WESTERN_CHART.map(p=>(
              <div key={p.name} className="grid grid-cols-12 gap-2 px-4 py-2.5 items-start border-b hover:bg-white/[0.02] transition-colors"
                style={{ borderColor:"rgba(255,255,255,0.04)" }}>
                <div className="col-span-4 flex items-center gap-2">
                  <span className="text-lg leading-none">{p.symbol}</span>
                  <div>
                    <p className="text-xs font-semibold text-white">{p.name}{p.retrograde?" ℞":""}</p>
                    {p.retrograde && <span className="text-[8px] px-1 rounded" style={{ background:"rgba(248,113,113,0.15)", color:"#f87171" }}>Retrograde</span>}
                  </div>
                </div>
                <p className="col-span-2 text-xs font-semibold" style={{ color:SIGN_COLORS[p.sign]??"#fff" }}>{p.sign}</p>
                <p className="col-span-2 text-center text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{p.degree}</p>
                <p className="col-span-1 text-center text-xs font-bold" style={{ color:BLUE }}>{p.house}</p>
                <p className="col-span-3 text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{p.signVedic}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Standout Placements</p>
            <div className="space-y-3">
              {[
                { label:"Sun conjunct Saturn in Virgo 10th", detail:"The single most powerful career indicator. Born to achieve publicly.", tag:"CAREER", color:YELLOW },
                { label:"Sun opposite Uranus in Pisces 4th", detail:"Revolutionary tension — traditional authority meets disruptive innovation.", tag:"TENSION", color:ROSE },
                { label:"Jupiter conjunct Neptune conjunct Chiron in Aquarius 3rd", detail:"The rare 2009 triple conjunction. Visionary mind, spiritual healing.", tag:"RARE", color:PURPLE },
                { label:"Moon in Taurus 5th (exalted in Vedic)", detail:"Emotional security through sports and creativity. Natural athlete.", tag:"SPORTS", color:GREEN },
                { label:"Mars conjunct South Node in Cancer 8th", detail:"Past life warrior. Hidden intensity and reserves of power.", tag:"POWER", color:ROSE },
              ].map(r=>(
                <div key={r.label} className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)" }}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background:`${r.color}15`, color:r.color, border:`1px solid ${r.color}30` }}>{r.tag}</span>
                    <p className="text-xs font-semibold" style={{ color:r.color }}>{r.label}</p>
                  </div>
                  <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>{r.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {sub==="aspects" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Aspect Patterns</p>
            {ASPECT_PATTERNS.map(ap=>(
              <div key={ap.name} className="p-3 rounded-xl mb-3" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background:"rgba(250,204,21,0.12)", color:YELLOW }}>{ap.type}</span>
                  <p className="text-xs font-semibold text-white">{ap.name}</p>
                </div>
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Planets: {ap.planets.join(", ")}</p>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{ap.interpretation}</p>
              </div>
            ))}
          </div>

          <p className="text-[10px] uppercase tracking-widest" style={{ color:"rgba(255,255,255,0.3)" }}>Major Aspects</p>
          {ASPECTS.map(a=>(
            <div key={`${a.planet1}-${a.planet2}`} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ background:"rgba(96,165,250,0.12)", color:BLUE, border:"1px solid rgba(96,165,250,0.2)" }}>{a.type}</span>
                <p className="text-sm font-semibold text-white">{a.planet1} — {a.planet2}</p>
                <span className="text-xs ml-auto" style={{ color:"rgba(255,255,255,0.3)" }}>orb {a.orb}</span>
              </div>
              <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{a.interpretation}</p>
            </div>
          ))}

          <p className="text-[10px] uppercase tracking-widest mt-4" style={{ color:"rgba(255,255,255,0.3)" }}>Minor Aspects</p>
          {MINOR_ASPECTS.map(a=>(
            <div key={`${a.planet1}-${a.planet2}-minor`} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ background:"rgba(168,85,247,0.12)", color:PURPLE, border:"1px solid rgba(168,85,247,0.2)" }}>{a.type}</span>
                <p className="text-sm font-semibold text-white">{a.planet1} — {a.planet2}</p>
                <span className="text-xs ml-auto" style={{ color:"rgba(255,255,255,0.3)" }}>orb {a.orb}</span>
              </div>
              <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{a.interpretation}</p>
            </div>
          ))}
        </div>
      )}

      {sub==="houses" && (
        <div className="space-y-3">
          {Object.entries(HOUSES).map(([num, h])=>(
            <div key={num} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <div className="flex items-center gap-3 mb-1.5">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-black shrink-0" style={{ background:"rgba(96,165,250,0.12)", color:BLUE }}>{num}</div>
                <div>
                  <p className="text-xs font-semibold text-white">{h.name}</p>
                  <p className="text-[9px]" style={{ color:SIGN_COLORS[h.sign]??"#fff" }}>{h.sign}{h.planets.length>0?` · ${h.planets.join(", ")}`:""}</p>
                </div>
                {h.planets.length>0 && <span className="ml-auto text-[9px] px-2 py-0.5 rounded font-bold" style={{ background:"rgba(250,204,21,0.12)", color:YELLOW }}>OCCUPIED</span>}
              </div>
              <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>{h.meaning}</p>
            </div>
          ))}
        </div>
      )}

      {sub==="dignities" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Essential Dignities & Debilities</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>How strong each planet is based on its sign placement</p>
            {DIGNITIES.map(d=>(
              <div key={d.planet} className="p-3 rounded-xl mb-3" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)" }}>
                <div className="flex items-center gap-3 mb-1">
                  <p className="text-sm font-bold text-white">{d.planet}</p>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{
                    background: d.strength > 0 ? "rgba(74,222,128,0.12)" : d.strength < 0 ? "rgba(248,113,113,0.12)" : "rgba(255,255,255,0.06)",
                    color: d.strength > 0 ? GREEN : d.strength < 0 ? "#f87171" : "rgba(255,255,255,0.4)",
                  }}>{d.type} ({d.strength > 0 ? `+${d.strength}` : d.strength})</span>
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{d.note}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Chart Rulers & Dispositors</p>
            {[CHART_RULERS.chartRuler, CHART_RULERS.sunRuler, CHART_RULERS.moonRuler].map(r=>(
              <div key={r.planet} className="p-3 rounded-xl mb-3" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-xs font-bold mb-1" style={{ color:BLUE }}>{r.planet} in {r.sign} (House {r.house})</p>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{r.note}</p>
              </div>
            ))}
            <div className="p-3 rounded-xl" style={{ background:"rgba(250,204,21,0.05)", border:"1px solid rgba(250,204,21,0.15)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:YELLOW }}>Final Dispositor</p>
              <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{CHART_RULERS.finalDispositor}</p>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Midpoints</p>
            {MIDPOINTS.map(mp=>(
              <div key={mp.point} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold" style={{ color:PURPLE }}>{mp.point}</p>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{mp.degree}</span>
                </div>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{mp.meaning}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Degree Analysis (Sabian Symbols)</p>
            {DEGREE_ANALYSIS.map(da=>(
              <div key={da.planet} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold" style={{ color:BLUE }}>{da.planet} — {da.degree}</p>
                </div>
                <p className="text-[9px] italic mb-1" style={{ color:YELLOW }}>"{da.sabian}"</p>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{da.interpretation}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Asteroids</p>
            {ASTEROIDS.map(a=>(
              <div key={a.name} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold text-white">{a.name}</p>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{a.sign} {a.degree} · House {a.house}</span>
                </div>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{a.interpretation}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Fixed Stars</p>
            {FIXED_STARS.map(fs=>(
              <div key={fs.name} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold" style={{ color:YELLOW }}>{fs.name}</p>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{fs.degree} · {fs.conjunct}</span>
                </div>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{fs.interpretation}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {sub==="vedic" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-4" style={{ color:"rgba(255,255,255,0.3)" }}>Vedic / Jyotish Chart — Sidereal (Lahiri Ayanamsa 23°51')</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { label:"Lagna (ASC)", value:VEDIC_SUMMARY.lagna, color:YELLOW },
                { label:"Sun Rashi", value:VEDIC_SUMMARY.sunRashi, color:"#fb923c" },
                { label:"Moon Rashi", value:VEDIC_SUMMARY.moonRashi, color:BLUE },
                { label:"Nakshatra", value:VEDIC_SUMMARY.nakshatra, color:PURPLE },
                { label:"Yoga", value:VEDIC_SUMMARY.yoga.split(" (")[0], color:GREEN },
              ].map(s=>(
                <div key={s.label} className="p-3 rounded-xl text-center" style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)" }}>
                  <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>{s.label}</p>
                  <p className="text-sm font-bold" style={{ color:s.color }}>{s.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Nakshatra — {MOON_NAKSHATRA.name}</p>
            <p className="text-xs font-semibold text-white mb-1">{MOON_NAKSHATRA.name} · Lord: {MOON_NAKSHATRA.lord} · Deity: {MOON_NAKSHATRA.deity}</p>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{MOON_NAKSHATRA.interpretation}</p>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PURPLE }}>Yogas (Vedic Combinations)</p>
            {YOGAS.map(y=>(
              <div key={y.name} className="p-3 rounded-xl mb-3" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold text-white">{y.name}</p>
                  <span className="text-[9px] px-2 py-0.5 rounded" style={{ background:"rgba(168,85,247,0.12)", color:PURPLE }}>{y.type}</span>
                </div>
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Planets: {y.planets.join(", ")}</p>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{y.interpretation}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:BLUE }}>Vimshottari Dasha System</p>
            <p className="text-xs mb-3" style={{ color:"rgba(255,255,255,0.4)" }}>{DASHAS.method}</p>
            {DASHAS.sequence.map(d=>(
              <div key={d.planet} className="p-3 rounded-xl mb-2" style={{ background: d.current ? "rgba(250,204,21,0.05)" : "rgba(255,255,255,0.03)", border: d.current ? "1px solid rgba(250,204,21,0.2)" : "1px solid rgba(255,255,255,0.06)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold text-white">{d.planet} Mahadasha</p>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{d.from}–{d.to} ({d.years} years)</span>
                  {d.current && <span className="text-[8px] px-1.5 py-0.5 rounded font-bold ml-auto" style={{ background:"rgba(250,204,21,0.15)", color:YELLOW }}>CURRENT</span>}
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>{d.note}</p>
              </div>
            ))}
            <div className="p-3 rounded-xl mt-3" style={{ background:"rgba(96,165,250,0.05)", border:"1px solid rgba(96,165,250,0.2)" }}>
              <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:BLUE }}>Current Sub-Period: {DASHAS.currentSubPeriod.major}-{DASHAS.currentSubPeriod.sub}</p>
              <p className="text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>{DASHAS.currentSubPeriod.note}</p>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Divisional Charts</p>
            {Object.entries(DIVISIONAL_CHARTS).map(([key, chart])=>(
              <div key={key} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold" style={{ color:YELLOW }}>{chart.name} ({key})</span>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{chart.purpose}</span>
                </div>
                <p className="text-xs mb-1" style={{ color:"rgba(255,255,255,0.4)" }}>{chart.key}</p>
                {"interpretation" in chart && <p className="text-xs" style={{ color:"rgba(255,255,255,0.55)" }}>{(chart as typeof DIVISIONAL_CHARTS.D9).interpretation}</p>}
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Special Vedic Notes</p>
            <div className="space-y-2">
              {VEDIC_SUMMARY.specialNotes.map((n,i)=>(
                <div key={i} className="flex items-start gap-2">
                  <span style={{ color:YELLOW }}>→</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.65)" }}>{n}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {sub==="timing" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Profections — Age {PROFECTIONS.currentAge}</p>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Profected House</p>
                <p className="text-3xl font-black" style={{ color:YELLOW }}>{PROFECTIONS.profectedHouse}</p>
              </div>
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Sign</p>
                <p className="text-lg font-black" style={{ color:SIGN_COLORS[PROFECTIONS.profectedSign] }}>{PROFECTIONS.profectedSign}</p>
              </div>
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Lord of Year</p>
                <p className="text-lg font-black" style={{ color:ROSE }}>{PROFECTIONS.lordOfYear}</p>
              </div>
            </div>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{PROFECTIONS.interpretation}</p>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Upcoming Profection Years</p>
            {PROFECTIONS.nextYears.map(ny=>(
              <div key={ny.age} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold" style={{ color:BLUE }}>Age {ny.age}</span>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>House {ny.house} · {ny.sign} · {ny.lord}</span>
                </div>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{ny.theme}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PURPLE }}>Secondary Progressions (Age 16)</p>
            <p className="text-xs mb-3" style={{ color:"rgba(255,255,255,0.4)" }}>{SECONDARY_PROGRESSIONS.method}</p>
            {Object.entries(SECONDARY_PROGRESSIONS).filter(([k]) => k !== "method").map(([key, val])=>(
              <div key={key} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold" style={{ color:PURPLE }}>{(val as {sign:string}).sign}</p>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{(val as {degree:string}).degree}</span>
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>{(val as {note:string}).note}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:BLUE }}>Solar Return 2025-2026</p>
            <p className="text-xs mb-3" style={{ color:"rgba(255,255,255,0.4)" }}>{SOLAR_RETURN.year}</p>
            <div className="space-y-2 mb-4">
              {SOLAR_RETURN.themes.map((t,i)=>(
                <div key={i} className="flex items-start gap-2">
                  <span style={{ color:BLUE }}>→</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>{t}</p>
                </div>
              ))}
            </div>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:YELLOW }}>Key Dates</p>
            {SOLAR_RETURN.keyDates.map(kd=>(
              <div key={kd.date} className="flex items-start gap-3 mb-2">
                <span className="text-xs font-bold shrink-0" style={{ color:YELLOW, minWidth:70 }}>{kd.date}</span>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{kd.event}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Zodiacal Releasing</p>
            <p className="text-xs mb-3" style={{ color:"rgba(255,255,255,0.4)" }}>{ZODIACAL_RELEASING.method}</p>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Lot of Fortune</p>
                <p className="text-xs font-bold" style={{ color:GREEN }}>{ZODIACAL_RELEASING.lotOfFortune.sign} {ZODIACAL_RELEASING.lotOfFortune.degree}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>{ZODIACAL_RELEASING.lotOfFortune.note}</p>
              </div>
              <div className="p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Lot of Spirit</p>
                <p className="text-xs font-bold" style={{ color:PURPLE }}>{ZODIACAL_RELEASING.lotOfSpirit.sign} {ZODIACAL_RELEASING.lotOfSpirit.degree}</p>
                <p className="text-[9px] mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>{ZODIACAL_RELEASING.lotOfSpirit.note}</p>
              </div>
            </div>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.55)" }}>{ZODIACAL_RELEASING.interpretation}</p>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Current Transit Analysis — 2026</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>How the current sky interacts with your natal chart</p>
            {[
              { transit:"Saturn in Pisces (2023–2026)", natal:"Natal Virgo Sun/Saturn (10th house)", type:"Opposition", strength:"MAJOR", color:YELLOW, detail:"Saturn opposing your natal Sun AND Saturn simultaneously — a critical restructuring period. Karmic contracts come due." },
              { transit:"Jupiter in Cancer (2025)", natal:"Natal Mars/South Node Cancer (8th house)", type:"Conjunction", strength:"POWERFUL", color:GREEN, detail:"Jupiter expands your transformation zone and hidden talents. Athletic breakthroughs." },
              { transit:"Pluto in Aquarius (2024–2043)", natal:"Natal Jupiter/Neptune/Chiron (3rd house)", type:"Conjunction", strength:"GENERATIONAL", color:PURPLE, detail:"Pluto transforming your communications and thought systems. Generational spiritual awakening." },
              { transit:"North Node in Pisces (2025–2026)", natal:"Natal Uranus Pisces (4th house)", type:"Conjunction", strength:"DESTINY", color:BLUE, detail:"Destiny point activating your Uranus — revolutionary breakthroughs in home and foundations." },
            ].map(t=>(
              <div key={t.transit} className="p-3 rounded-xl mb-3" style={{ background:"rgba(255,255,255,0.03)", border:`1px solid ${t.color}20` }}>
                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ background:`${t.color}15`, color:t.color }}>{t.strength}</span>
                  <span className="text-xs font-semibold text-white">{t.transit}</span>
                  <span className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>{t.type}</span>
                </div>
                <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.5)" }}>{t.detail}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {sub==="nodes" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>North Node — Your Destiny</p>
            <div className="flex items-center gap-3 mb-3">
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-lg font-black" style={{ color:YELLOW }}>{LUNAR_NODES_DETAIL.northNode.sign}</p>
                <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>House {LUNAR_NODES_DETAIL.northNode.house} · {LUNAR_NODES_DETAIL.northNode.degree}</p>
              </div>
            </div>
            <p className="text-xs leading-relaxed mb-3" style={{ color:"rgba(255,255,255,0.6)" }}>{LUNAR_NODES_DETAIL.northNode.meaning}</p>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Lessons to Master</p>
            {LUNAR_NODES_DETAIL.northNode.lessons.map((l,i)=>(
              <div key={i} className="flex items-start gap-2 mb-1">
                <span style={{ color:YELLOW }}>→</span>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.55)" }}>{l}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(168,85,247,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:PURPLE }}>South Node — Past Life Gifts</p>
            <div className="flex items-center gap-3 mb-3">
              <div className="text-center p-3 rounded-xl" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-lg font-black" style={{ color:PURPLE }}>{LUNAR_NODES_DETAIL.southNode.sign}</p>
                <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>House {LUNAR_NODES_DETAIL.southNode.house} · {LUNAR_NODES_DETAIL.southNode.degree}</p>
              </div>
            </div>
            <p className="text-xs leading-relaxed mb-3" style={{ color:"rgba(255,255,255,0.6)" }}>{LUNAR_NODES_DETAIL.southNode.meaning}</p>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Gifts You Were Born With</p>
            {LUNAR_NODES_DETAIL.southNode.pastLifeGifts.map((g,i)=>(
              <div key={i} className="flex items-start gap-2 mb-1">
                <span style={{ color:PURPLE }}>→</span>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.55)" }}>{g}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:BLUE }}>Nodal Axis Summary</p>
            <p className="text-xs leading-relaxed mb-3" style={{ color:"rgba(255,255,255,0.6)" }}>{LUNAR_NODES_DETAIL.axis}</p>
            <div className="p-3 rounded-xl" style={{ background:"rgba(250,204,21,0.05)", border:"1px solid rgba(250,204,21,0.15)" }}>
              <p className="text-xs font-bold" style={{ color:YELLOW }}>Nodal Return</p>
              <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{LUNAR_NODES_DETAIL.nodalReturn}</p>
            </div>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Draconic Chart (Soul Blueprint)</p>
            <p className="text-xs mb-3" style={{ color:"rgba(255,255,255,0.4)" }}>{DRACONIC_CHART.method}</p>
            {DRACONIC_CHART.planets.map(p=>(
              <div key={p.name} className="p-3 rounded-xl mb-2" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold" style={{ color:ROSE }}>{p.name}</p>
                  <span className="text-[9px]" style={{ color:SIGN_COLORS[p.sign] ?? "rgba(255,255,255,0.4)" }}>{p.sign} {p.degree}</span>
                </div>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{p.note}</p>
              </div>
            ))}
            <div className="p-3 rounded-xl mt-3" style={{ background:"rgba(250,204,21,0.05)", border:"1px solid rgba(250,204,21,0.15)" }}>
              <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{DRACONIC_CHART.interpretation}</p>
            </div>
          </div>
        </div>
      )}

      {sub==="locational" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Astrocartography — Power Lines</p>
            <p className="text-xs mb-4" style={{ color:"rgba(255,255,255,0.4)" }}>{LOCATIONAL_ASTROLOGY.method}</p>
            {LOCATIONAL_ASTROLOGY.powerLines.map(pl=>(
              <div key={pl.planet} className="p-3 rounded-xl mb-3" style={{ background:"rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-bold" style={{ color:BLUE }}>{pl.planet}</p>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {pl.regions.map(r=>(
                    <span key={r} className="text-[9px] px-2 py-0.5 rounded" style={{ background:"rgba(250,204,21,0.1)", color:YELLOW }}>{r}</span>
                  ))}
                </div>
                <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{pl.note}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:GREEN }}>Best Locations By Purpose</p>
            {Object.entries(LOCATIONAL_ASTROLOGY.bestFor).map(([purpose, cities])=>(
              <div key={purpose} className="mb-3">
                <p className="text-xs font-bold capitalize mb-1.5" style={{ color:purpose === "soccer" ? YELLOW : purpose === "career" ? BLUE : purpose === "love" ? ROSE : PURPLE }}>{purpose}</p>
                <div className="flex flex-wrap gap-1.5">
                  {cities.map(c=>(
                    <span key={c} className="text-[9px] px-2 py-1 rounded-lg" style={{ background:"rgba(255,255,255,0.04)", color:"rgba(255,255,255,0.6)" }}>{c}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Birth Location</p>
            <p className="text-sm font-bold text-white">{LOCATIONAL_ASTROLOGY.birthLocation.city}</p>
            <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>{LOCATIONAL_ASTROLOGY.birthLocation.coords}</p>
            <p className="text-xs mt-2" style={{ color:"rgba(255,255,255,0.5)" }}>{LOCATIONAL_ASTROLOGY.birthLocation.note}</p>
          </div>
        </div>
      )}

      {sub==="advanced" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:YELLOW }}>Virgo Sun — Deep Profile</p>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div className="text-center p-2 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Element</p>
                <p className="text-sm font-bold" style={{ color:GREEN }}>{VIRGO_SUN.element}</p>
              </div>
              <div className="text-center p-2 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Modality</p>
                <p className="text-sm font-bold" style={{ color:BLUE }}>{VIRGO_SUN.modality}</p>
              </div>
              <div className="text-center p-2 rounded-lg" style={{ background:"rgba(255,255,255,0.03)" }}>
                <p className="text-[9px] mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Ruler</p>
                <p className="text-sm font-bold" style={{ color:PURPLE }}>{VIRGO_SUN.ruler}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {VIRGO_SUN.traits.map(t=>(
                <span key={t} className="text-[9px] px-2 py-1 rounded-lg" style={{ background:"rgba(96,165,250,0.08)", color:BLUE }}>{t}</span>
              ))}
            </div>
            <p className="text-xs leading-relaxed mb-2" style={{ color:"rgba(255,255,255,0.6)" }}>{VIRGO_SUN.strengths}</p>
            <p className="text-xs leading-relaxed mb-2" style={{ color:"rgba(255,255,255,0.5)" }}>{VIRGO_SUN.shadows}</p>
            <p className="text-xs leading-relaxed" style={{ color:GREEN }}>{VIRGO_SUN.inSports}</p>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(96,165,250,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:BLUE }}>Sagittarius Rising</p>
            <p className="text-xs mb-2" style={{ color:"rgba(255,255,255,0.6)" }}>{SAGITTARIUS_RISING.appearance}</p>
            <p className="text-xs mb-2" style={{ color:"rgba(255,255,255,0.5)" }}>{SAGITTARIUS_RISING.firstImpression}</p>
            <p className="text-xs mb-2" style={{ color:"rgba(255,255,255,0.5)" }}>{SAGITTARIUS_RISING.lifeTheme}</p>
            <p className="text-xs" style={{ color:GREEN }}>{SAGITTARIUS_RISING.athleticsNote}</p>
          </div>

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Dispositor Chain</p>
            <p className="text-xs leading-relaxed" style={{ color:"rgba(255,255,255,0.6)" }}>{CHART_RULERS.dispositorChain}</p>
          </div>
        </div>
      )}

      {sub==="remedies" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(250,204,21,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:YELLOW }}>Vedic Remedial Measures</p>
            <p className="text-xs" style={{ color:"rgba(255,255,255,0.4)" }}>Strengthen weak planets and harmonize challenging aspects</p>
          </div>

          {[
            { data: REMEDIAL_MEASURES.forMarsInFall, color: ROSE },
            { data: REMEDIAL_MEASURES.forSaturnConjunctSun, color: YELLOW },
            { data: REMEDIAL_MEASURES.forMercuryRetrograde, color: GREEN },
            { data: REMEDIAL_MEASURES.forJupiterInDetriment, color: PURPLE },
          ].map(({ data, color }) => (
            <div key={data.issue} className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
              <p className="text-xs font-bold mb-3" style={{ color }}>{data.issue}</p>
              <div className="space-y-2">
                {data.remedies.map((r,i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-[9px] font-bold shrink-0 mt-0.5" style={{ color }}>●</span>
                    <p className="text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>{r}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}

          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)", border:"1px solid rgba(96,165,250,0.15)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:BLUE }}>General Strengthening Practices</p>
            <div className="space-y-2">
              {REMEDIAL_MEASURES.generalStrengthening.map((r,i) => (
                <div key={i} className="flex items-start gap-2">
                  <span style={{ color:BLUE }}>→</span>
                  <p className="text-xs" style={{ color:"rgba(255,255,255,0.6)" }}>{r}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
