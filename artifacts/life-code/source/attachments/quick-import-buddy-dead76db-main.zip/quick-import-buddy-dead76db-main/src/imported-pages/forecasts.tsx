import { useParams, Link } from "@/lib/wouter";
import { CalendarDays, ChevronRight } from "lucide-react";
import { useMemo } from "react";
import { PROFILE } from "@/lib/profile";
import { calcCoreNumbers, calcDateEnergy, calcPersonalDay } from "@/lib/numerology";

const N = calcCoreNumbers(
  PROFILE.firstName, PROFILE.middleName, PROFILE.lastName,
  PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear,
);
const BLUE  = "hsl(212 95% 65%)";
const YELLOW= "hsl(48 96% 53%)";

const energyColors: Record<number,string> = {
  1:"#f87171",2:"#fb923c",3:"#facc15",4:"#4ade80",5:"#22d3ee",
  6:"#60a5fa",7:"#a78bfa",8:"#c084fc",9:"#f472b6",
  11:"#e0f2fe",22:"#fde68a",
};
const MONTHLY_THEMES: Record<number,{ theme:string; focus:string; avoid:string }> = {
  1:{theme:"New Beginnings",focus:"Start new projects, make bold moves, lead",avoid:"Waiting for permission"},
  2:{theme:"Cooperation",focus:"Build alliances, listen deeply, be patient",avoid:"Confrontation and impatience"},
  3:{theme:"Creative Expansion",focus:"Express yourself, network, create content",avoid:"Scattered energy — stay focused"},
  4:{theme:"Foundation Building",focus:"Discipline, structure, hard work, planning",avoid:"Shortcuts and rushing"},
  5:{theme:"Freedom & Change",focus:"Try new things, travel, be flexible",avoid:"Rigid attachment to old patterns"},
  6:{theme:"Harmony & Service",focus:"Relationships, family, beauty, giving",avoid:"Neglecting personal needs"},
  7:{theme:"Inner Wisdom",focus:"Study, meditate, research, trust intuition",avoid:"Isolation and overthinking"},
  8:{theme:"Power & Achievement",focus:"Business, finance, leadership, negotiation",avoid:"Arrogance and power struggles"},
  9:{theme:"Completion & Release",focus:"Finish what you started, let go, heal",avoid:"Clinging to the past"},
  11:{theme:"Illumination",focus:"Spiritual insight, creativity, inspiration",avoid:"Anxiety and oversensitivity"},
  22:{theme:"Manifestation",focus:"Large-scale action, legacy building",avoid:"Overwhelm from too much ambition"},
};

const tabs = [
  { key:"", label:"Daily", href:"/forecasts" },
  { key:"monthly", label:"Monthly", href:"/forecasts/monthly" },
  { key:"yearly", label:"Yearly", href:"/forecasts/yearly" },
];

export default function ForecastsPage() {
  const params = useParams<{ sub?:string }>();
  const sub = params.sub ?? "";
  const today = new Date();

  const de = useMemo(() => calcDateEnergy(today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const pd = useMemo(() => calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, today.getMonth()+1, today.getDate(), today.getFullYear()), []);
  const ec = energyColors[de.reduced] ?? BLUE;
  const pc = energyColors[pd.reduced] ?? YELLOW;

  // Next 7 days
  const week = useMemo(() => Array.from({length:7},(_,i)=>{
    const d = new Date(today); d.setDate(today.getDate()+i);
    const dde = calcDateEnergy(d.getMonth()+1, d.getDate(), d.getFullYear());
    const dpd = calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, d.getMonth()+1, d.getDate(), d.getFullYear());
    return { date:d, de:dde, pd:dpd };
  }), []);

  // Monthly: all days of current month
  const monthDays = useMemo(()=>{
    const year = today.getFullYear(), month = today.getMonth();
    const days = new Date(year, month+1, 0).getDate();
    return Array.from({length:days},(_,i)=>{
      const d = new Date(year,month,i+1);
      const dde = calcDateEnergy(d.getMonth()+1,d.getDate(),d.getFullYear());
      const dpd = calcPersonalDay(PROFILE.birthMonth,PROFILE.birthDay,d.getMonth()+1,d.getDate(),d.getFullYear());
      return { day:i+1, de:dde, pd:dpd };
    });
  },[]);

  return (
    <div className="max-w-4xl space-y-5">
      <div>
        <div className="flex items-center gap-1.5 text-xs mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
          <CalendarDays size={12} style={{ color:YELLOW }} />
          <span>Forecasts</span><ChevronRight size={10} /><span style={{ color:YELLOW }}>Cristian Zavala</span>
        </div>
        <h1 className="page-title">Forecasts</h1>
        <p className="page-subtitle">Personalized energy — Universal day × Your personal cycles</p>
      </div>

      <div className="flex gap-1.5">
        {tabs.map(t=>(
          <Link key={t.key} href={t.href}>
            <button className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={sub===t.key
                ? { background:"rgba(250,204,21,0.12)", color:YELLOW, border:"1px solid rgba(250,204,21,0.25)" }
                : { color:"rgba(255,255,255,0.4)", border:"1px solid transparent" }}>
              {t.label}
            </button>
          </Link>
        ))}
      </div>

      {/* ── DAILY ── */}
      {sub==="" && (
        <div className="space-y-4">
          {/* Today hero */}
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>
              {today.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}
            </p>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Universal</p>
                <p className="text-5xl font-black" style={{ color:ec }}>{de.reduced}</p>
                <p className="text-[10px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>{de.compound}</p>
              </div>
              <div className="text-center">
                <p className="text-[9px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>Your Day</p>
                <p className="text-5xl font-black" style={{ color:pc }}>{pd.reduced}</p>
                <p className="text-[10px] mt-1" style={{ color:"rgba(255,255,255,0.3)" }}>{pd.compound}</p>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold" style={{ color:ec }}>{de.label}</p>
                <p className="text-xs mt-1" style={{ color:"rgba(255,255,255,0.4)" }}>
                  {pd.reduced===de.reduced?"⚡ Your personal day matches universal energy — amplified day!":
                   Math.abs(pd.reduced-de.reduced)<=2?"✓ Good flow — personal and universal in harmony":
                   "Neutral — navigate consciously today"}
                </p>
              </div>
            </div>
          </div>

          {/* Next 7 days */}
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-3" style={{ color:"rgba(255,255,255,0.3)" }}>Next 7 Days</p>
            <div className="space-y-2">
              {week.map(({date,de:d,pd:p},i) => {
                const dc=energyColors[d.reduced]??"#60a5fa";
                const pc2=energyColors[p.reduced]??"#facc15";
                return (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-lg" style={{ background:i===0?"rgba(250,204,21,0.06)":"rgba(255,255,255,0.02)" }}>
                    <p className="text-xs w-24" style={{ color:i===0?YELLOW:"rgba(255,255,255,0.5)" }}>
                      {i===0?"Today":date.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}
                    </p>
                    <div className="flex items-center gap-3">
                      <div className="text-center">
                        <p className="text-[8px] mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Universal</p>
                        <p className="text-base font-black" style={{ color:dc }}>{d.reduced}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-[8px] mb-0.5" style={{ color:"rgba(255,255,255,0.3)" }}>Personal</p>
                        <p className="text-base font-black" style={{ color:pc2 }}>{p.reduced}</p>
                      </div>
                      <div className="w-24 text-right">
                        <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.35)" }}>{MONTHLY_THEMES[d.reduced]?.theme}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── MONTHLY ── */}
      {sub==="monthly" && (
        <div className="space-y-4">
          <div className="glass-card p-4" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color:"rgba(255,255,255,0.3)" }}>
              {today.toLocaleDateString("en-US",{month:"long",year:"numeric"})} — Full Energy Map
            </p>
            <div className="grid grid-cols-7 gap-1 mt-3">
              {["Su","Mo","Tu","We","Th","Fr","Sa"].map(d=>(
                <p key={d} className="text-center text-[9px] font-semibold py-1" style={{ color:"rgba(255,255,255,0.3)" }}>{d}</p>
              ))}
              {Array.from({length:new Date(today.getFullYear(),today.getMonth(),1).getDay()}).map((_,i)=>(
                <div key={`e${i}`} />
              ))}
              {monthDays.map(({day,de:d,pd:p})=>{
                const isToday = day===today.getDate();
                const col=energyColors[d.reduced]??"#60a5fa";
                return (
                  <div key={day} className="aspect-square flex flex-col items-center justify-center rounded-lg text-xs font-medium"
                    style={{ background:isToday?"hsl(212 95% 55%)":"rgba(255,255,255,0.03)", color:isToday?"#000":col, border:isToday?"none":"1px solid rgba(255,255,255,0.05)" }}>
                    <span className="text-xs font-bold">{day}</span>
                    <span className="text-[8px] opacity-70">{d.reduced}/{p.reduced}</span>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-3 mt-3 flex-wrap">
              <p className="text-[9px]" style={{ color:"rgba(255,255,255,0.3)" }}>Legend: Universal/Personal energy numbers</p>
            </div>
          </div>
        </div>
      )}

      {/* ── YEARLY ── */}
      {sub==="yearly" && (
        <div className="space-y-4">
          <div className="glass-card p-5" style={{ background:"hsl(228 28% 7%)" }}>
            <p className="text-[10px] uppercase tracking-widest mb-2" style={{ color:"rgba(255,255,255,0.3)" }}>Personal Year 2026</p>
            <p className="text-6xl font-black" style={{ color:YELLOW }}>{N.personalYear}</p>
            <p className="text-sm font-semibold mt-2" style={{ color:"rgba(255,255,255,0.7)" }}>
              {MONTHLY_THEMES[N.personalYear]?.theme} — Completion & Universal Love
            </p>
            <p className="text-xs mt-2" style={{ color:"rgba(255,255,255,0.45)" }}>
              This is the final year of your 9-year cycle. A year of endings, release and preparation for a powerful new beginning in 2027 (Personal Year 1). Complete old projects, release people and patterns that no longer align, and practice compassion — for yourself and others.
            </p>
          </div>
          {[{q:"Q1 (Jan–Mar)",theme:"Completion begins",desc:"Focus on wrapping up long-standing projects. Release old habits. Start reviewing what to take into your next cycle."},
            {q:"Q2 (Apr–Jun)",theme:"Peak release",desc:"Highest-intensity completion energy. Major endings and breakthroughs happen here. Be willing to let go completely."},
            {q:"Q3 (Jul–Sep)",theme:"Transition",desc:"The new cycle begins to whisper. Some new seeds planted now won't bloom until 2027 — plant them anyway."},
            {q:"Q4 (Oct–Dec)",theme:"Preparation for Year 1",desc:"Cleanse, rest and prepare. 2027 is a Personal Year 1 — a brand new 9-year cycle starts. Your biggest chapter yet."},
          ].map(q=>(
            <div key={q.q} className="feature-card">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold" style={{ color:YELLOW }}>{q.q}</span>
                <span className="pill-blue">{q.theme}</span>
              </div>
              <p className="text-xs" style={{ color:"rgba(255,255,255,0.5)" }}>{q.desc}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
