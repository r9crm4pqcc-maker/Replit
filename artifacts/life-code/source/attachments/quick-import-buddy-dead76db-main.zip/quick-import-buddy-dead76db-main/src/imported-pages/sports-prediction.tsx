// @ts-nocheck
import { useState, useMemo, useEffect, useCallback, useRef } from "react";
import { ChevronDown, ChevronUp, RefreshCw, Loader2, AlertCircle, Calendar, Globe, Hash, Lock, Users, Activity } from "lucide-react";
import { fetchESPNGames, getLeagueInfo, fetchFighterDob, type ESPNGame } from "@/lib/espn";
import { getTeamMeta } from "@/lib/sports-data";
import { fetchAutoMatchup, type AutoMatchup } from "@/lib/espn-auto";
import { recordPick, recordOutcome, accuracy, getBias, logStepPick, scoreStepPick, stepHitRates } from "@/lib/sports-learning";
import { calcAthletePersonalDay } from "@/lib/numerology";
import { runVotes, TEAM_COLORS, fmt, colorNumsLabel, type VoteResult } from "@/lib/vote-decode";
import { FullDecode, SavedEdits, computeFullDecode, parseDob, type DecodeEntity } from "@/components/FullDecode";
import type { Tri } from "@/lib/full-decode";
import { useOverrides } from "@/lib/date-overrides";


// ─── palette ───────────────────────────────────────────────────────────────
const YELLOW = "#FF6A00";
const BLUE   = "#60A5FA";
const GREEN  = "#4ade80";
const ROSE   = "#f472b6";
const PURPLE = "#a78bfa";

const LEAGUE_GROUPS = [
  { label: "FIFA World Cup 2026", leagues: ["World Cup"] },
  { label: "US Major", leagues: ["NBA", "NFL", "MLB", "NHL", "UFC"] },
  { label: "Soccer", leagues: ["MLS", "Premier League", "La Liga", "Bundesliga", "Serie A", "Ligue 1"] },
  { label: "European Cups", leagues: ["UCL", "UEL", "UECL"] },
  { label: "More", leagues: ["Liga MX", "WNBA", "College Football", "College Basketball"] },
];

// ─── atoms ─────────────────────────────────────────────────────────────────
function Mini({ label, value, accent = "white" }: { label: string; value: React.ReactNode; accent?: string }) {
  return (
    <div>
      <p className="text-[8px] uppercase tracking-widest font-bold mb-0.5" style={{ color: "rgba(96,165,250,0.7)" }}>{label}</p>
      <p className="text-[13px] font-bold" style={{ color: accent, fontFamily: "ui-monospace, monospace" }}>{value}</p>
    </div>
  );
}

function Section({ n, title, icon, children }: { n: number; title: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="mx-5 mt-3 rounded-xl p-4" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <p className="text-[10px] font-bold tracking-[0.15em] mb-2 flex items-center gap-1.5" style={{ color: YELLOW }}>
        {icon} SECTION {n} · {title}
      </p>
      {children}
    </div>
  );
}

function StatusBadge({ status, detail }: { status: string; detail: string }) {
  if (status === "in")   return <span className="inline-flex items-center gap-1 text-[9px] font-bold px-2 py-0.5 rounded-full animate-pulse" style={{ background: "rgba(239,68,68,0.15)", color: "#ef4444" }}><span className="w-1.5 h-1.5 rounded-full bg-red-500" /> LIVE</span>;
  if (status === "post") return <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ background: "rgba(74,222,128,0.12)", color: GREEN }}>FINAL ✓</span>;
  return <span className="text-[9px] font-medium px-2 py-0.5 rounded-full" style={{ background: "rgba(96,165,250,0.10)", color: BLUE }}>{detail || "Scheduled"}</span>;
}


// ─── Date numerology block ─────────────────────────────────────────────────
function Pill({ children, tone = "muted" }: { children: React.ReactNode; tone?: "muted" | "primary" | "danger" }) {
  const cls = tone === "primary" ? "bg-primary/15 text-primary border-primary/30" : tone === "danger" ? "bg-destructive/15 text-destructive border-destructive/40" : "bg-muted text-muted-foreground border-border";
  return <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold ${cls}`}>{children}</span>;
}

function TeamReadCol({ name, r, colors, record, fight }: { fight?: boolean; name: string; r: VoteResult["reads"]["home"]; colors?: string[]; record?: string }) {
  const row = (k: string, v: React.ReactNode) => <div className="flex justify-between gap-2 text-xs py-0.5"><span className="text-muted-foreground">{k}</span><span className="text-foreground font-semibold text-right">{v}</span></div>;
  return (
    <div className="rounded-lg bg-muted/40 p-3">
      <p className="text-sm font-black text-foreground mb-1">{name}</p>
      {row("Life Path", r.lp ? fmt(r.lp) : "—")}
      {row(fight ? "Born day" : "Founded day", r.foundedDay ? fmt(r.foundedDay) : "—")}
      {row("Chinese sign", r.sign ?? "—")}
      {row("Letterology", fmt(r.name))}
      {row("Colors", colors?.length ? colors.map(c => `${c} ${colorNumsLabel(c)}`).join(", ") : "—")}
      {row("Record", record ?? "—")}
      {r.enemyYear && <p className="mt-1 text-[10px] font-bold text-destructive">IN ENEMY YEAR</p>}
      {r.hits.length > 0 && <p className="mt-1 text-[10px] text-primary">Touches today: {r.hits.join(", ")}</p>}
    </div>
  );
}

function GameCard({ game, year, month, day, idx, league }: { game: ESPNGame; year: number; month: number; day: number; idx: number; league: string }) {
  const [auto, setAuto] = useState<AutoMatchup | null>(null);
  const [autoLoading, setAutoLoading] = useState(true);
  const isFight = league === "UFC";
  const [dobs, setDobs] = useState<{ home?: string; away?: string }>({});
  useEffect(() => {
    if (!isFight) return;
    let alive = true;
    Promise.all([fetchFighterDob(game.homeTeamId), fetchFighterDob(game.awayTeamId)]).then(([h, a]) => { if (alive) { setDobs({ home: h, away: a }); setAutoLoading(false); } });
    return () => { alive = false; };
  }, [game.id, isFight]);
  useEffect(() => {
    if (isFight) return;
    let alive = true;
    setAutoLoading(true);
    fetchAutoMatchup(league, game.id)
      .then(a => { if (alive) { setAuto(a); setAutoLoading(false); } })
      .catch(() => { if (alive) setAutoLoading(false); });
    return () => { alive = false; };
  }, [game.id, league]);

  const homeMeta = getTeamMeta(game.homeTeam);
  const awayMeta = getTeamMeta(game.awayTeam);
  const starterRole = league === "NFL" || league === "College Football" ? "quarterback" : league === "MLB" ? "pitcher" : "player";
  const v = useMemo(() => {
    const person = (p: any, role: any) => p?.common ? [{ name: p.common, role, dob: p.dob, jersey: p.jersey }] : [];
    const team = (name: string, meta: any, side: any, rec?: string | null) => ({
      name, founded: meta?.founded ? [meta.founded[0], meta.founded[1], meta.founded[2]] as [number, number, number] : undefined,
      colors: TEAM_COLORS[name], record: side?.record ?? rec ?? undefined,
      people: [...person(side?.starter, starterRole), ...person(side?.manager, "coach")],
    });
    if (isFight) {
      const dt = (d?: string) => { const m = d?.match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? [+m[1], +m[2], +m[3]] as [number, number, number] : undefined; };
      return runVotes({ year, month, day, league, individual: true,
        home: { name: game.homeTeam, founded: dt(dobs.home), record: game.homeRecord, people: [] },
        away: { name: game.awayTeam, founded: dt(dobs.away), record: game.awayRecord, people: [] } });
    }
    return runVotes({
      year, month, day, league,
      home: team(game.homeTeam, homeMeta, auto?.home, game.homeRecord),
      away: team(game.awayTeam, awayMeta, auto?.away, game.awayRecord),
      stadiumOpened: homeMeta?.stadiumOpened, cityFounded: homeMeta?.cityFounded,
      stadium: homeMeta?.stadium, city: homeMeta?.city,
    });
  }, [game.id, year, month, day, auto, league, dobs]);

  const kickoff = useMemo(() => { const t = new Date(game.startTime); return isNaN(t.getTime()) ? 19 : t.getHours(); }, [game.startTime]);
  const ov = useOverrides();
  const full = useMemo(() => {
    const tri = (t?: readonly number[]) => (t ? [t[0], t[1], t[2]] as Tri : undefined);
    const rec = (s?: AutoMatchup["home"], base?: string | null) => [s?.record ?? base, s?.streak && `Streak ${s.streak}`, s?.homeRecord && `Home ${s.homeRecord}`, s?.roadRecord && `Away ${s.roadRecord}`].filter(Boolean).join(" · ") || undefined;
    const ents: DecodeEntity[] = isFight ? [
      { kind: "player", side: "away", name: game.awayTeam, role: "fighter", date: parseDob(dobs.away), record: game.awayRecord },
      { kind: "player", side: "home", name: game.homeTeam, role: "fighter", date: parseDob(dobs.home), record: game.homeRecord },
    ] : [
      { kind: "team", side: "away", name: game.awayTeam, date: tri(awayMeta?.founded), record: rec(auto?.away, game.awayRecord) },
      { kind: "team", side: "home", name: game.homeTeam, date: tri(homeMeta?.founded), record: rec(auto?.home, game.homeRecord) },
      ...(["away", "home"] as const).flatMap(s => {
        const a = auto?.[s]; const out: DecodeEntity[] = [];
        out.push(a?.starter ? { kind: "player", side: s, name: a.starter.common, role: starterRole, date: parseDob(a.starter.dob), jersey: a.starter.jersey } : { kind: "player", side: s, name: `${s === "home" ? game.homeTeam : game.awayTeam} starter`, role: "not posted yet" });
        out.push(a?.manager ? { kind: "player", side: s, name: a.manager.common, role: "coach", date: parseDob(a.manager.dob), jersey: a.manager.jersey } : { kind: "player", side: s, name: `${s === "home" ? game.homeTeam : game.awayTeam} coach`, role: "not in feed" });
        return out;
      }),
      { kind: "city", side: "venue", name: homeMeta?.city ?? "Host city", date: tri(homeMeta?.cityFounded) },
      { kind: "stadium", side: "venue", name: game.venue ?? homeMeta?.stadium ?? "Stadium", date: tri(homeMeta?.stadiumOpened) },
    ];
    return computeFullDecode(ents, [year, month, day], kickoff, ov);
  }, [game.id, year, month, day, auto, dobs, kickoff, isFight, ov]);

  const totalHome = v.home + full.home, totalAway = v.away + full.away;
  const finalPick: "home" | "away" = totalHome === totalAway ? v.pick : totalHome > totalAway ? "home" : "away";
  const pickName = finalPick === "home" ? game.homeTeam : game.awayTeam;
  const strength = v.noPlay ? `NO PLAY · ${v.band}` : v.band;
  const verdict = v.noPlay ? `9 Universal Day — no sports picks today. Leaning ${pickName} only for tracking.`
    : `Checking every component independently, ${pickName} holds the stronger alignment: 7-step votes ${game.awayTeam} ${v.away.toFixed(2)} / ${game.homeTeam} ${v.home.toFixed(2)} plus full-decode ${full.away.toFixed(2)} / ${full.home.toFixed(2)} → ${pickName} at ${v.confidence}% (${v.band}).`;
  const isFinal = game.status === "post";
  const logId = `${year}-${month}-${day}|${game.id}`;

  useEffect(() => {
    if (autoLoading) return;
    logStepPick({ id: logId, date: `${year}-${month}-${day}`, home: game.homeTeam, away: game.awayTeam, pick: finalPick, confidence: v.confidence, votes: v.votes.map(x => ({ side: x.side, layer: x.layer, weight: x.weight })) });
    if (isFinal) {
      const h = Number(game.homeScore), a = Number(game.awayScore);
      scoreStepPick(logId, h > a ? "home" : a > h ? "away" : "draw");
    }
  }, [autoLoading, isFinal, logId, v]);

  const result = isFinal ? `${game.awayAbbr} ${game.awayScore} – ${game.homeScore} ${game.homeAbbr}` : null;
  const hit = isFinal ? ((Number(game.homeScore) > Number(game.awayScore) ? "home" : "away") === finalPick) : null;

  return (
    <div className="rounded-2xl border border-border bg-card overflow-hidden">
      <div className="p-5">
        <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
          <p className="text-[10px] font-bold tracking-[0.18em] text-primary">{isFight ? "FIGHT" : "GAME"} {idx + 1} · {(game.venue ?? homeMeta?.stadium ?? "").toUpperCase()}</p>
          {result ? <Pill tone={hit ? "primary" : "danger"}>FINAL {result} · {hit ? "HIT" : "MISS"}</Pill> : <StatusBadge status={game.status} detail={game.statusDetail} />}
        </div>
        <div className="flex items-end justify-between gap-3 mb-3">
          <div className="min-w-0"><p className="text-xs text-muted-foreground">Away</p><p className="text-lg font-black text-foreground truncate">{game.awayTeam}</p>{game.awayRecord && <p className="text-xs text-muted-foreground">{game.awayRecord}</p>}</div>
          <div className="text-center shrink-0">
            <p className="text-[10px] text-muted-foreground">PICK</p>
            <p className="text-base font-black text-primary">{pickName.toUpperCase()}</p>
            <p className="text-4xl font-black text-foreground leading-none my-1">{v.confidence}%</p>
            <Pill tone={v.noPlay ? "danger" : "primary"}>{strength}</Pill>
          </div>
          <div className="min-w-0 text-right"><p className="text-xs text-muted-foreground">Home</p><p className="text-lg font-black text-foreground truncate">{game.homeTeam}</p>{game.homeRecord && <p className="text-xs text-muted-foreground">{game.homeRecord}</p>}</div>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden mb-1">
          <div className="h-full bg-primary" style={{ width: `${v.confidence}%` }} />
        </div>
        <div className="flex justify-between text-[9px] text-muted-foreground mb-4"><span>0 Challenging</span><span>30 Mixed</span><span>50 Good</span><span>70 Strong</span><span>85 Exceptional</span></div>

        {v.alerts.length > 0 && (
          <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 mb-3 space-y-1">
            {v.alerts.map((a, i) => <p key={i} className="text-xs font-bold text-destructive">⚠ {a}</p>)}
          </div>
        )}

        <FullDecode title={`${game.awayTeam} @ ${game.homeTeam} · ${month}/${day}/${year}`} data={full} homeName={game.homeTeam} awayName={game.awayTeam} verdict={verdict} />

        <p className="text-[10px] font-bold tracking-[0.18em] text-primary mb-2">FULL SIDE-BY-SIDE DECODE · Game day #{v.gameDayOfYear} · {v.gameDaySign} day</p>
        <div className="overflow-x-auto mb-4 rounded-lg border border-border">
          <table className="w-full text-[11px]">
            <thead className="bg-muted/40 text-muted-foreground">
              <tr>{["Side", "Role", "Name", "Date", "Life Path", "Day #", "Day energy", "Lucky", "Year / Month / Day animal", "Personal Day"].map(h => <th key={h} className="text-left font-semibold px-2 py-1.5 whitespace-nowrap">{h}</th>)}</tr>
            </thead>
            <tbody>
              {v.entities.map((e, i) => (
                <tr key={i} className="border-t border-border">
                  <td className="px-2 py-1.5 whitespace-nowrap">{e.side === "venue" ? "Venue" : e.side === "home" ? game.homeTeam : game.awayTeam}</td>
                  <td className="px-2 py-1.5">{e.role}</td>
                  <td className="px-2 py-1.5 font-semibold text-foreground whitespace-nowrap">{e.name}</td>
                  {e.date ? <>
                    <td className="px-2 py-1.5 whitespace-nowrap">{e.date}</td>
                    <td className="px-2 py-1.5">{e.lp && fmt(e.lp)}</td>
                    <td className="px-2 py-1.5">{e.dayOfYear}</td>
                    <td className="px-2 py-1.5">{e.dayEnergy && fmt(e.dayEnergy)}</td>
                    <td className="px-2 py-1.5">{e.lucky}</td>
                    <td className="px-2 py-1.5 whitespace-nowrap">{e.yearSign} / {e.monthSign} / {e.daySign}</td>
                    <td className="px-2 py-1.5 whitespace-nowrap">{e.pd && fmt(e.pd)} <span className={e.pdRel === "enemy" || e.pdRel === "worst" ? "text-destructive" : e.pdRel === "neutral" ? "text-muted-foreground" : "text-primary"}>({e.pdRel})</span></td>
                  </> : <td colSpan={7} className="px-2 py-1.5 text-muted-foreground">Birth / founding date not available yet</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {autoLoading
          ? <p className="text-[10px] mt-3 text-muted-foreground">Loading starters, coaches and birthdays…</p>
          : v.missing.length > 0 && <p className="text-[10px] mt-3 text-muted-foreground">Not available yet: {[...new Set(v.missing)].join(" · ")}</p>}
      </div>
    </div>
  );
}

function HitRatePanel() {
  const [r, setR] = useState<ReturnType<typeof stepHitRates> | null>(null);
  useEffect(() => { setR(stepHitRates()); const t = setInterval(() => setR(stepHitRates()), 5000); return () => clearInterval(t); }, []);
  if (!r) return null;
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <p className="text-[10px] font-bold tracking-[0.18em] text-primary mb-2">SIGNAL HIT RATE</p>
      <p className="text-sm text-foreground mb-3">Overall: <b>{r.hits}/{r.total}</b>{r.total ? ` (${Math.round(100 * r.hits / r.total)}%)` : ""} · {r.total < 30 ? `${30 - r.total} more scored picks until this is reliable` : "reliable sample reached"}</p>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {Object.entries(r.steps).map(([k, s]) => (
          <div key={k} className="rounded-lg bg-muted/40 p-2"><p className="text-[10px] text-muted-foreground">{k}</p><p className="text-sm font-bold text-foreground">{s.hits}/{s.total} · {Math.round(100 * s.hits / s.total)}%</p></div>
        ))}
        {Object.entries(r.bands).map(([k, s]) => (
          <div key={k} className="rounded-lg border border-primary/30 p-2"><p className="text-[10px] text-primary">{k} picks</p><p className="text-sm font-bold text-foreground">{s.hits}/{s.total} · {Math.round(100 * s.hits / s.total)}%</p></div>
        ))}
        {Object.keys(r.steps).length === 0 && <p className="text-xs text-muted-foreground col-span-full">Finished games are scored automatically — check back after games end.</p>}
      </div>
    </div>
  );
}

function NumInput({ label, value, set, min, max, w = "w-14", readOnly }: { label: string; value: number; set: (n: number) => void; min: number; max: number; w?: string; readOnly?: boolean }) {
  return (
    <div>
      <p className="text-[7px] uppercase tracking-widest mb-1 text-center" style={{ color: "rgba(255,255,255,0.3)" }}>{label}</p>
      <input type="number" min={min} max={max} value={value} readOnly={readOnly} onChange={e => set(+e.target.value)}
        className={`${w} text-center rounded-lg px-1.5 py-1.5 text-xs font-bold`}
        style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "white", outline: "none", opacity: readOnly ? 0.55 : 1 }} />
    </div>
  );
}

function AthletePersonalDayCard({ month, day, year }: { month: number; day: number; year: number }) {
  const [name, setName] = useState("");
  const [bm, setBm] = useState(1);
  const [bd, setBd] = useState(1);
  const [by, setBy] = useState(2000);
  const pd = useMemo(
    () => calcAthletePersonalDay(bm, bd, month, day, year),
    [bm, bd, month, day, year]
  );
  return (
    <div className="rounded-2xl p-5" style={{ background: "linear-gradient(135deg, hsl(228 35% 6%), hsl(228 30% 9%))", border: "1px solid rgba(96,165,250,0.18)" }}>
      <p className="text-[10px] font-bold tracking-[0.2em] mb-1" style={{ color: BLUE }}>ATHLETE PERSONAL DAY CALCULATOR</p>
      <p className="text-[9px] mb-3" style={{ color: "rgba(255,255,255,0.4)" }}>
        Personal Year cycle + calendar month + digit sum of the day (the 30th counts as 3+0 = 3, not 30). Target date follows the game date selected above.
      </p>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Athlete name (optional)"
        className="w-full mb-3 rounded-lg px-3 py-2 text-xs font-semibold"
        style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "white", outline: "none" }} />
      <div className="flex items-end gap-2 flex-wrap mb-4">
        <div className="flex gap-2">
          <NumInput label="Birth M" value={bm} set={setBm} min={1} max={12} />
          <NumInput label="Birth D" value={bd} set={setBd} min={1} max={31} />
          <NumInput label="Birth Y" value={by} set={setBy} min={1900} max={2020} w="w-16" />
        </div>
        <span className="text-[10px] font-bold px-2" style={{ color: "rgba(255,255,255,0.3)" }}>→</span>
        <div className="flex gap-2">
          <NumInput label="Game M" value={month} set={() => {}} min={1} max={12} readOnly />
          <NumInput label="Game D" value={day} set={() => {}} min={1} max={31} readOnly />
          <NumInput label="Game Y" value={year} set={() => {}} min={2020} max={2030} w="w-16" readOnly />
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
        <Mini label="Personal year" value={`${pd.personalYearCompound}/${pd.personalYear} (${pd.cycleYear})`} accent={PURPLE} />
        <Mini label="Day sum" value={`${day} → ${pd.daySum}`} accent={BLUE} />
        <Mini label="Personal day" value={`${pd.compound}/${pd.reduced}`} accent={YELLOW} />
        <Mini label="Master" value={pd.isMaster ? "YES" : "—"} accent={GREEN} />
      </div>
      <p className="text-[11px] font-bold mb-1" style={{ color: "white", fontFamily: "ui-monospace, monospace" }}>
        {name ? `${name} — ` : ""}PY {pd.personalYear} + Month {month} + Day {pd.daySum} = {pd.compound}{pd.compound !== pd.reduced ? ` → ${pd.reduced}` : ""}
      </p>
      <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.6)" }}>{pd.meaning}</p>
    </div>
  );
}

export default function SportsPredictionPage() {
  const [mounted, setMounted] = useState(false);
  const today = new Date();
  const [month, setMonth] = useState(today.getMonth() + 1);
  const [day, setDay]     = useState(today.getDate());
  const [year, setYear]   = useState(today.getFullYear());
  const [league, setLeague] = useState("MLB");
  const userPicked = useRef(false);
  const [games, setGames] = useState<ESPNGame[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [allGames, setAllGames] = useState<Record<string, ESPNGame[]>>({});
  const fetchVersion = useRef(0);

  useEffect(() => { setMounted(true); }, []);

  const leagueInfo = getLeagueInfo(league);

  const fetchGames = useCallback(async () => {
    const v = ++fetchVersion.current;
    setLoading(true); setError(null);
    try {
      const r = await fetchESPNGames(league, month, day, year);
      if (fetchVersion.current !== v) return;
      setGames(r);
    } catch {
      if (fetchVersion.current !== v) return;
      setError("Failed to fetch games"); setGames([]);
    } finally {
      if (fetchVersion.current === v) setLoading(false);
    }
  }, [league, month, day, year]);
  useEffect(() => { fetchGames(); }, [fetchGames]);

  const fetchAll = useCallback(async () => {
    const majors = ["World Cup","NBA","NFL","MLB","NHL","MLS","Premier League","La Liga","UFC"];
    const out: Record<string, ESPNGame[]> = {};
    await Promise.all(majors.map(async lg => {
      try { out[lg] = await fetchESPNGames(lg, month, day, year); }
      catch { out[lg] = []; }
    }));
    setAllGames(out);
    const order = ["World Cup","NBA","MLB","NHL","NFL","MLS","Premier League","La Liga"];
    if (!userPicked.current && (out[league]?.length ?? 0) === 0) {
      const first = order.find(lg => (out[lg]?.length ?? 0) > 0);
      if (first) setLeague(first);
    }
  }, [month, day, year]);
  useEffect(() => { fetchAll(); }, [fetchAll]);

  const leagueCounts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const [lg, lgg] of Object.entries(allGames)) if (lgg.length) c[lg] = lgg.length;
    return c;
  }, [allGames]);

  if (!mounted) return <div className="max-w-6xl" />;

  const displayDate = new Date(year, month - 1, day).toLocaleDateString("en-US", {
    weekday: "long", month: "long", day: "numeric", year: "numeric",
  });

  return (
    <div className="max-w-6xl space-y-6">
      <div className="rounded-2xl p-6 relative overflow-hidden" style={{
        background: "hsl(var(--card))",
        border: "1px solid rgba(250,204,21,0.15)",
      }}>
        <p className="text-[10px] font-bold tracking-[0.25em] mb-2 flex items-center gap-2" style={{ color: BLUE }}>
          <Globe size={12} /> 7-STEP DECODE · {leagueInfo.label.toUpperCase()}
        </p>
        <h1 className="text-5xl md:text-6xl font-black leading-none tracking-tight">
          <span className="text-white">SPORTS</span><br />
          <span style={{ color: YELLOW }}>CODE CARD</span>
        </h1>
        <p className="text-[11px] mt-3 tracking-widest" style={{ color: "rgba(96,165,250,0.7)", fontFamily: "ui-monospace, monospace" }}>
          {displayDate.toUpperCase()}
        </p>
        <div className="mt-3"><SavedEdits /></div>
        <div className="mt-4 flex items-end gap-2">
          {[
            { l: "Month", v: month, s: setMonth, min: 1, max: 12, w: "w-16" },
            { l: "Day",   v: day,   s: setDay,   min: 1, max: 31, w: "w-16" },
            { l: "Year",  v: year,  s: setYear,  min: 2020, max: 2030, w: "w-20" },
          ].map(f => (
            <div key={f.l}>
              <p className="text-[8px] uppercase tracking-widest mb-1 text-center" style={{ color: "rgba(255,255,255,0.3)" }}>{f.l}</p>
              <input type="number" min={f.min} max={f.max} value={f.v} onChange={e => f.s(+e.target.value)}
                className={`${f.w} text-center rounded-xl px-2 py-2 text-sm font-bold`}
                style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "white", outline: "none" }} />
            </div>
          ))}
          <button onClick={fetchGames} disabled={loading}
            className="ml-2 flex items-center gap-1.5 text-[10px] px-3 py-2 rounded-xl"
            style={{ background: "rgba(96,165,250,0.12)", color: BLUE, border: "1px solid rgba(96,165,250,0.25)" }}>
            <RefreshCw size={11} className={loading ? "animate-spin" : ""} /> Refresh
          </button>
        </div>
      </div>

      {/* League selector */}
      <div>
        <p className="text-[9px] uppercase tracking-[0.2em] mb-3 font-semibold" style={{ color: "rgba(255,255,255,0.35)" }}>Select League</p>
        <div className="space-y-3">
          {LEAGUE_GROUPS.map(group => (
            <div key={group.label}>
              <p className="text-[7px] uppercase tracking-widest mb-1.5" style={{ color: "rgba(255,255,255,0.25)" }}>{group.label}</p>
              <div className="flex flex-wrap gap-1.5">
                {group.leagues.map(l => {
                  const info = getLeagueInfo(l);
                  const active = league === l;
                  const count = leagueCounts[l];
                  return (
                    <button key={l} onClick={() => {
                      userPicked.current = true;
                      setLeague(l);
                      if (l === "UFC") {
                        // UFC cards run on Saturdays: Sunday → last night's card, otherwise the coming Saturday.
                        const d = new Date(); const dow = d.getDay();
                        d.setDate(d.getDate() + (dow === 0 ? -1 : 6 - dow));
                        setYear(d.getFullYear()); setMonth(d.getMonth() + 1); setDay(d.getDate());
                      }
                    }}
                      className="px-3 py-1.5 rounded-xl text-[9px] font-semibold flex items-center gap-1.5"
                      style={active
                        ? { background: "rgba(96,165,250,0.18)", color: BLUE, border: "1px solid rgba(96,165,250,0.35)" }
                        : { background: "rgba(255,255,255,0.03)", color: count ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.25)", border: "1px solid rgba(255,255,255,0.06)" }}>
                      {info.emoji} {l}
                      {count !== undefined && <span className="text-[7px] px-1 rounded-full" style={{ background: active ? "rgba(96,165,250,0.25)" : "rgba(74,222,128,0.12)", color: active ? BLUE : GREEN }}>{count}</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="rounded-2xl p-12 text-center" style={{ background: "hsl(228 28% 7%)", border: "1px solid rgba(255,255,255,0.05)" }}>
          <Loader2 size={28} className="animate-spin mx-auto mb-3" style={{ color: BLUE }} />
          <p className="text-sm font-semibold text-white">Loading {leagueInfo.label}…</p>
        </div>
      ) : error ? (
        <div className="rounded-2xl p-8 text-center" style={{ background: "hsl(228 28% 7%)", border: "1px solid rgba(239,68,68,0.15)" }}>
          <AlertCircle size={24} className="mx-auto mb-2" style={{ color: ROSE }} />
          <p className="text-sm font-semibold text-white mb-1">Connection Error</p>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{error}</p>
        </div>
      ) : games.length === 0 ? (
        <div className="rounded-2xl p-10 text-center" style={{ background: "hsl(228 28% 7%)", border: "1px solid rgba(255,255,255,0.05)" }}>
          <Calendar size={28} className="mx-auto mb-3" style={{ color: "rgba(255,255,255,0.15)" }} />
          <p className="text-sm font-semibold text-white mb-1">No {leagueInfo.label} games</p>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>Try another league with games today.</p>
        </div>
      ) : (
        <div className="space-y-6">
          <HitRatePanel />
          {games.map((g, i) => <GameCard key={g.id} game={g} year={year} month={month} day={day} idx={i} league={league} />)}
        </div>
      )}


      <p className="text-[8px] text-center" style={{ color: "rgba(255,255,255,0.2)" }}>
        Live schedules from ESPN · 7-step numerology decode · For entertainment — bet responsibly.
      </p>
    </div>
  );
}
