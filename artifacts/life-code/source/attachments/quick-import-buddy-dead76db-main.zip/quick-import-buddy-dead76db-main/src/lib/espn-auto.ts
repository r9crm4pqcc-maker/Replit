import { espnFetch } from "./espn";
// Fully automated matchup data retrieval for the gematria decode protocol.
// Pulls starters, managers, birthdays, records and splits straight from ESPN —
// there is no manual entry anywhere in the pipeline.

import { getLeagueInfo } from "./espn";

const SITE = "https://site.api.espn.com/apis/site/v2/sports";
const WEB = "https://site.web.api.espn.com/apis/common/v3/sports";
const CORE = "https://sports.core.api.espn.com/v2/sports";
/** Core API paths need a `leagues` segment: baseball/mlb → baseball/leagues/mlb. */
function corePath(path: string): string {
  const [sport, ...rest] = path.split("/");
  return rest.length ? `${sport}/leagues/${rest.join("/")}` : sport;
}

async function j<T = any>(url: string): Promise<T | null> {
  try {
    const r = await espnFetch(url);
    if (!r.ok) return null;
    return (await r.json()) as T;
  } catch {
    return null;
  }
}

export interface AutoPerson {
  common: string;
  full?: string;
  dob?: string;              // YYYY-MM-DD
  jersey?: string;
  record?: string;           // season W-L
  careerRecord?: string;     // career W-L
  homeRecord?: string;
  roadRecord?: string;
  vsOpponentRecord?: string;
  era?: string;
  whip?: string;
  strikeouts?: string;
  teamRecordInStarts?: string;
}

export interface AutoSide {
  teamId?: string;
  shortName?: string;
  longName?: string;
  record?: string;
  homeRecord?: string;
  roadRecord?: string;
  last10?: string;
  streak?: string;
  monthRecord?: string;
  manager?: AutoPerson;
  starter?: AutoPerson;
}

export interface AutoMatchup {
  retrievedAt: string;
  home: AutoSide;
  away: AutoSide;
  venue?: string;
  venueCity?: string;
  venueState?: string;
  seriesGame?: number;
  seriesRecord?: string;
  seasonSeries?: string;
  allTimeSeries?: string;
  pitchersConfirmed: boolean;
  gaps: string[];
}

const iso = (s?: string) => (s ? s.slice(0, 10) : undefined);

function findRecord(list: any[] | undefined, type: string): string | undefined {
  const r = list?.find((x) => (x.type ?? x.name ?? "").toLowerCase() === type);
  return r?.summary ?? r?.displayValue ?? undefined;
}

/** Season + career pitching lines from the athlete stats endpoint. */
async function pitcherStats(path: string, athleteId: string, season: number) {
  const s = await j<any>(`${WEB}/${path}/athletes/${athleteId}/stats`);
  const cat = s?.categories?.find((c: any) => c.name === "pitching");
  if (!cat) return null;
  const labels: string[] = cat.labels ?? [];
  const idx = (l: string) => labels.indexOf(l);
  const rows: any[] = (cat.statistics ?? []).filter((r: any) => r?.stats?.length);
  const num = (row: any, l: string) => Number(row.stats[idx(l)] ?? 0) || 0;
  let cw = 0, cl = 0;
  for (const r of rows) { cw += num(r, "W"); cl += num(r, "L"); }
  const cur = rows.find((r: any) => String(r?.season?.year ?? r?.season?.displayName ?? "") === String(season)) ?? rows[rows.length - 1];
  return {
    season: cur ? `${num(cur, "W")}-${num(cur, "L")}` : undefined,
    career: rows.length ? `${cw}-${cl}` : undefined,
    era: cur ? String(cur.stats[idx("ERA")] ?? "") : undefined,
    whip: cur ? String(cur.stats[idx("WHIP")] ?? "") : undefined,
    strikeouts: cur ? String(cur.stats[idx("K")] ?? "") : undefined,
  };
}

async function buildStarter(path: string, prob: any, season: number): Promise<AutoPerson | undefined> {
  const ath = prob?.athlete;
  const id = String(prob?.playerId ?? ath?.id ?? "");
  if (!ath?.displayName && !ath?.fullName) return undefined;
  const [core, stats] = await Promise.all([
    id ? j<any>(`${CORE}/${corePath(path)}/athletes/${id}?lang=en&region=us`) : Promise.resolve(null),
    id ? pitcherStats(path, id, season) : Promise.resolve(null),
  ]);
  return {
    common: ath.displayName ?? ath.fullName,
    full: core?.fullName ?? ath.fullName,
    dob: iso(core?.dateOfBirth),
    jersey: ath.jersey,
    record: stats?.season,
    careerRecord: stats?.career,
    era: stats?.era,
    whip: stats?.whip,
    strikeouts: stats?.strikeouts,
  };
}

async function buildManager(path: string, teamId: string, season: number): Promise<AutoPerson | undefined> {
  let list = await j<any>(`${CORE}/${corePath(path)}/seasons/${season}/teams/${teamId}/coaches?lang=en&region=us`);
  if (!list?.items?.length) {
    list = await j<any>(`${CORE}/${corePath(path)}/seasons/${season - 1}/teams/${teamId}/coaches?lang=en&region=us`);
  }
  const ref = list?.items?.[0]?.$ref;
  if (!ref) return undefined;
  const c = await j<any>(ref.replace("http://", "https://"));
  if (!c) return undefined;
  const common = `${(c.firstName ?? "").trim()} ${(c.lastName ?? "").trim()}`.trim();
  if (!common) return undefined;
  let record: string | undefined;
  const rref = c.records?.[0]?.record?.$ref;
  if (rref) {
    const rec = await j<any>(rref.replace("http://", "https://"));
    record = rec?.summary ?? rec?.displayValue;
  }
  return {
    common,
    full: c.person?.fullName ?? common,
    dob: iso(c.dateOfBirth),
    record,
  };
}

/** One call → every participant number the protocol needs, no manual entry. */
export async function fetchAutoMatchup(league: string, gameId: string): Promise<AutoMatchup> {
  const cfg = getLeagueInfo(league);
  const path = cfg.espnPath;
  const gaps: string[] = [];
  const out: AutoMatchup = {
    retrievedAt: new Date().toISOString(),
    home: {}, away: {},
    pitchersConfirmed: false,
    gaps,
  };
  if (!path || !gameId) { gaps.push("league feed unavailable"); return out; }

  const s = await j<any>(`${SITE}/${path}/summary?event=${gameId}`);
  if (!s) { gaps.push("ESPN summary unreachable"); return out; }

  const comp = s.header?.competitions?.[0];
  const season = Number(s.header?.season?.year ?? new Date().getFullYear());
  const competitors: any[] = comp?.competitors ?? [];

  out.venue = s.gameInfo?.venue?.fullName;
  out.venueCity = s.gameInfo?.venue?.address?.city;
  out.venueState = s.gameInfo?.venue?.address?.state;

  // Season series / current series / all-time
  const series: any[] = s.seasonseries ?? [];
  const current = series.find((x) => x.type === "current") ?? series[0];
  if (current) {
    out.seriesRecord = current.seriesScore ?? current.summary;
    out.seriesGame = (current.events?.filter((e: any) => e.status === "post").length ?? 0) + 1;
  }
  const seasonSer = series.find((x) => x.type === "season") ?? series.find((x) => /season/i.test(x.title ?? ""));
  out.seasonSeries = seasonSer?.summary ?? current?.summary;

  const sides = await Promise.all(
    competitors.map(async (c: any) => {
      const teamId = String(c.team?.id ?? c.id ?? "");
      const side: AutoSide = {
        teamId,
        shortName: c.team?.shortDisplayName ?? c.team?.name ?? c.team?.abbreviation,
        longName: c.team?.displayName ?? c.team?.shortDisplayName,
        record: findRecord(c.record, "total") ?? c.record?.[0]?.summary,
        homeRecord: findRecord(c.record, "home"),
        roadRecord: findRecord(c.record, "road") ?? findRecord(c.record, "away"),
      };
      const prob = c.probables?.[0];
      const [starter, manager] = await Promise.all([
        prob ? buildStarter(path, prob, season) : Promise.resolve(undefined),
        teamId ? buildManager(path, teamId, season) : Promise.resolve(undefined),
      ]);
      side.starter = starter;
      side.manager = manager;
      return { homeAway: c.homeAway, side };
    }),
  );

  for (const { homeAway, side } of sides) {
    if (homeAway === "home") out.home = side; else out.away = side;
  }

  // last five games → last-10-ish form line
  for (const block of s.lastFiveGames ?? []) {
    const id = String(block.team?.id ?? "");
    const wins = (block.events ?? []).filter((e: any) => /W/.test(e.gameResult ?? "")).length;
    const games = (block.events ?? []).length;
    if (!games) continue;
    const line = `${wins}-${games - wins}`;
    if (out.home.teamId === id) out.home.last10 = line;
    if (out.away.teamId === id) out.away.last10 = line;
  }

  out.pitchersConfirmed = !!(out.home.starter && out.away.starter);
  if (!out.home.starter || !out.away.starter) gaps.push("starters not yet posted by the league");
  if (!out.home.manager || !out.away.manager) gaps.push("head coach/manager feed unavailable for this league");
  if (!out.home.starter?.careerRecord && !out.away.starter?.careerRecord) gaps.push("career pitching lines unavailable");
  return out;
}
