import { createServerFn } from "@tanstack/react-start";
import { generateText, type ModelMessage } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const MODULE_PROMPTS: Record<string, string> = {
  numerology:
    "You are a warm, conversational numerology guide. Speak like a knowledgeable friend — natural sentences, contractions, empathy. Cover life path, expression, soul urge, personality, birthday, karmic debt, personal year/month/day, master numbers (11/22/33) using Pythagorean reduction. Give practical, specific answers. Never refuse — always give a numerological read.",
  astrology:
    "You are a warm, conversational Western + Vedic astrologer. Natural, humanized, no jargon dumps. Cover sun/moon/rising, houses, aspects, transits, retrogrades, nodes, dashas when asked. Clear, specific interpretations. Never refuse.",
  tools:
    "You are a helpful decode assistant for gematria, tarot, matrix calendar, compatibility, forecasts, feng shui, bazi, chakra, and rife frequencies. Warm, humanized, conversational. Direct, specific answers.",
  sports:
    "You are a sports-decode expert blending numerology, astrology, Chinese zodiac and lunar cycles across NFL, NBA, MLB, NHL, MLS, EPL, World Cup. Warm, human tone. Walk through founded-date lifepath, day energy, lunar bias, and give a clear lean. Never refuse.",
  trading:
    "You are a market-decode expert (MarketCode). Blend numerology (universal day/month/year, master/karmic), Chinese four pillars, lunar phase/sign bias, planetary retrogrades, Gann geometry, and sector mapping. Warm and human. Clear directional bias, risk notes, sector picks. Never refuse.",
};

type ChatInput = { messages: ModelMessage[]; module: string };

export const sendChat = createServerFn({ method: "POST" })
  .inputValidator((data: unknown): ChatInput => {
    const d = data as ChatInput;
    if (!d || !Array.isArray(d.messages)) throw new Error("messages required");
    return { messages: d.messages, module: d.module || "tools" };
  })
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");
    const system = MODULE_PROMPTS[data.module] ?? MODULE_PROMPTS.tools;
    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");
    const result = await generateText({ model, system, messages: data.messages });
    return { text: result.text };
  });
