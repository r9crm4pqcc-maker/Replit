import { calcPersonalDay } from "./numerology";
import { compat, COMPAT, GG33_COLORS, colorNumbers, colorFit } from "./gg33";
// 7-step vote decoder (user's method). Numbers outrank astrology; colors and
// records only break ties. Pure functions only.
import { pythagoreanValue } from "./numerology";
import { moonPhase } from "./sports-decode";

export type Side = "home" | "away";
export type Step = "Game-day energy" | "Team core" | "Number pairs" | "Chinese zodiac" | "Stars & venue" | "Colors" | "Records";
export interface Vote { side: Side; weight: number; layer: Step; reason: string }

const MASTERS = new Set([11, 22, 33]);
const sumDigits = (n: number) => String(Math.abs(n)).split("").reduce((a, d) => a + Number(d), 0);
export function reduceNum(n: number): number {
  let x = n;
  while (x > 9 && !MASTERS.has(x)) x = sumDigits(x);
  return x;
}
export interface Num { compound: number; reduced: number }
export function lifePath(y: number, m: number, d: number): Num {
  const compound = sumDigits(y) + sumDigits(m) + sumDigits(d);
  return { compound, reduced: reduceNum(compound) };
}
/** Day-of-month energy: the 8th = 8, the 19th = 19/1, the 28th = 28/1. */
export const dayEnergy = (d: number): Num => ({ compound: d, reduced: reduceNum(d) });
export const ord = (n: number) => `${n}${[11,12,13].includes(n % 100) ? "th" : ["th","st","nd","rd"][n % 10] ?? "th"}`;
export const fmt = (n: Num) => (n.compound === n.reduced ? `${n.reduced}` : `${n.compound}/${n.reduced}`);

/** Does a number touch any of the day's energies? 28 carries both 8 (wealth) and 1. */
function touches(n: Num, day: number[]): boolean {
  const vals = new Set([n.reduced, n.compound]);
  if (n.compound === 28) { vals.add(8); vals.add(1); }
  return day.some(d => vals.has(d));
}

// ── Number pairs ────────────────────────────────────────────────────────────
export function numberRelation(a: number, b: number): "worst" | "enemy" | "soulmate" | "friend" | "same" | "neutral" {
  const p = (x: number, y: number) => (a === x && b === y) || (a === y && b === x);
  if (p(1, 9)) return "worst";
  if (p(3, 4)) return "enemy";
  if (p(7, 11)) return "soulmate";
  if (p(3, 5) || p(3, 7)) return "friend";
  if (a === b) return "same";
  // GG33 compatibility chart
  const x = compat(a, b).rel, y = compat(b, a).rel;
  if (x === "enemy" || y === "enemy") return "enemy";
  if (x === "friendly") return "friend";
  return "neutral";
}

// ── Chinese zodiac ──────────────────────────────────────────────────────────
export const SIGNS = ["Rat", "Ox", "Tiger", "Cat", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig"] as const;
export type Sign = typeof SIGNS[number];
export const chineseSign = (year: number): Sign => SIGNS[(((year - 4) % 12) + 12) % 12];
/** Animal months run from the 6th to the 5th (Jan 6 – Feb 5 = Ox … Dec 6 – Jan 5 = Rat). */
export function chineseMonthSign(month: number, day: number): Sign {
  const m = day >= 6 ? month : month - 1; // 0 = December of prior year
  return SIGNS[(((m % 12) + 12) % 12)];
}
export const TRINES: Sign[][] = [["Rat", "Monkey", "Dragon"], ["Ox", "Rooster", "Snake"], ["Horse", "Dog", "Tiger"], ["Cat", "Pig", "Goat"]];
export const CLASHES: [Sign, Sign][] = [["Rat", "Horse"], ["Ox", "Goat"], ["Tiger", "Monkey"], ["Cat", "Rooster"], ["Dragon", "Dog"], ["Snake", "Pig"]];
export function signRelation(a: Sign, b: Sign): "friend" | "enemy" | "neutral" {
  if (CLASHES.some(([x, y]) => (x === a && y === b) || (x === b && y === a))) return "enemy";
  if (TRINES.some(t => t.includes(a) && t.includes(b))) return "friend";
  return "neutral";
}

// ── Colors (GG33 colorology only) ───────────────────────────────────────────
export const COLOR_NUMBERS = GG33_COLORS;
/** Primary GG33 number of a color (first listed), or null. */
export function colorNum(name: string): number | null {
  return colorNumbers(name)[0] ?? null;
}
export const colorNumsLabel = (name: string) => colorNumbers(name).join("/") || "?";
export const isWorstPair = (a: number, b: number) => numberRelation(reduceNum(a), reduceNum(b)) === "worst";

// ── Special numbers ─────────────────────────────────────────────────────────
export const SPECIAL_NUMBERS: Record<number, string> = {
  27: "27 is an important number in sports (baseball)",
  18: "18 is a very important number in gambling",
  3: "3 is luck",
  12: "12 is beginner's luck that can't be repeated",
};

// ── Inputs ──────────────────────────────────────────────────────────────────
export interface VotePerson { name: string; role: "pitcher" | "manager" | "coach" | "quarterback" | "player"; dob?: string; jersey?: string }
export interface VoteTeam { name: string; founded?: [number, number, number]; colors?: string[]; record?: string; people: VotePerson[] }
export interface VoteInput {
  year: number; month: number; day: number; league?: string;
  home: VoteTeam; away: VoteTeam;
  stadiumOpened?: [number, number, number]; cityFounded?: [number, number, number];
  stadium?: string; city?: string;
  /** Individual sport (UFC): `founded` is the fighter's birth date. */
  individual?: boolean;
}
export interface TeamRead { lp?: Num; foundedDay?: Num; sign?: Sign; name: Num; enemyYear: boolean; hits: string[] }
export interface EntityProfile {
  side: Side | "venue"; role: string; name: string; date?: string;
  lp?: Num; dayOfYear?: number; dayEnergy?: Num; yearSign?: Sign; monthSign?: Sign; daySign?: Sign;
  pd?: Num; pdRel?: string; lucky?: number;
}
/** Chinese day animal (60-day cycle branch). */
export function chineseDaySign(y: number, m: number, d: number): Sign {
  const days = Math.floor(Date.UTC(y, m - 1, d) / 86400000) + 719163; // proleptic ordinal
  return SIGNS[(((days + 2) % 12) + 12) % 12];
}
/** CUE Lucky Number: first digit of birth month + last non-zero digit of birth year, kept whole. */
export function luckyNumber(year: number, month: number): number {
  const m = String(month)[0];
  const y = [...String(year)].reverse().find(c => c !== "0") ?? "0";
  return Number(m + y);
}
export function dayOfYear(y: number, m: number, d: number): number {
  return Math.round((Date.UTC(y, m - 1, d) - Date.UTC(y, 0, 1)) / 86400000) + 1;
}
export function personalDayFor(b: readonly [number, number, number], y: number, m: number, d: number): Num {
  const p = calcPersonalDay(b[1], b[2], m, d, y); return { compound: p.compound, reduced: p.reduced };
}
export interface VoteResult {
  entities: EntityProfile[]; gameDayOfYear: number; gameDaySign: Sign;
  votes: Vote[]; home: number; away: number; pick: Side; tiebreak: boolean;
  universalDay: Num; dayOfMonth: Num; yearSign: Sign; monthSign: Sign;
  noPlay: boolean; alerts: string[]; notes: string[]; missing: string[];
  reads: Record<Side, TeamRead>;
  steps: StepRow[]; confidence: number; band: Band;
}
export const STEP_ORDER: Step[] = ["Team core", "Game-day energy", "Number pairs", "Chinese zodiac", "Stars & venue", "Colors", "Records"];
export const STEP_LABELS: Record<Step, string> = {
  "Team core": "1 · Identity", "Game-day energy": "2 · Game-day energy", "Number pairs": "3 · Number pairs",
  "Chinese zodiac": "4 · Chinese zodiac", "Stars & venue": "5 · Stars, venue & moon", "Colors": "6 · Colors (tiebreak)", "Records": "7 · Records (tiebreak)",
};
export interface StepRow { step: Step; label: string; edge: Side | null; reason: string }
export type Band = "Challenging" | "Mixed" | "Good" | "Strong" | "Exceptional";
export function confidenceBand(c: number): Band {
  if (c >= 85) return "Exceptional";
  if (c >= 70) return "Strong";
  if (c >= 50) return "Good";
  if (c >= 30) return "Mixed";
  return "Challenging";
}
/** Picked side's share of votes, minus penalties, clamped 0–100. */
export function computeConfidence(o: { winner: number; loser: number; noPlay: boolean; alerts: number; missing: number; tiebreakOnly: boolean }): number {
  const tot = o.winner + o.loser;
  let c = tot ? (100 * o.winner) / tot : 50;
  if (o.noPlay) c -= 30;
  c -= 10 * o.alerts;
  c -= 5 * o.missing;
  if (o.tiebreakOnly) c -= 10;
  return Math.max(0, Math.min(100, Math.round(c)));
}

const winPct = (r?: string) => {
  const m = r?.match(/(\d+)-(\d+)/); if (!m) return null;
  const w = +m[1], l = +m[2]; return w + l ? w / (w + l) : null;
};
const parseDob = (s?: string) => { const m = s?.match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? [+m[1], +m[2], +m[3]] as const : null; };

function coreStrength(r: TeamRead): number {
  if (!r.lp) return 0;
  if (r.lp.compound === 28 || r.foundedDay?.compound === 28) return 3;
  if ([8, 1, 11, 22, 33].includes(r.lp.reduced)) return 2;
  return 1;
}

/** Championship rules: never back these to win it all. */
export function championshipAlerts(p: VotePerson, league?: string): string[] {
  const d = parseDob(p.dob); if (!d) return [];
  const lp = lifePath(d[0], d[1], d[2]); const sg = chineseSign(d[0]); const out: string[] = [];
  if (league === "NFL" && p.role === "quarterback") {
    if (lp.reduced === 9 || reduceNum(d[2]) === 9) out.push(`Never bet on ${p.name} (9 Life Path / 9 day QB) to win the Super Bowl`);
    if (["Cat", "Goat", "Tiger"].includes(sg)) out.push(`Never bet on ${p.name} (${sg}-year QB) to win the Super Bowl`);
  }
  if (league === "NBA" && lp.reduced === 9) out.push(`Never bet on ${p.name} (9 Life Path) to win the title`);
  return out;
}

export function runVotes(inp: VoteInput): VoteResult {
  const ud = lifePath(inp.year, inp.month, inp.day);
  const dom = dayEnergy(inp.day);
  const dayNums = [...new Set([ud.reduced, dom.reduced, ...(dom.compound === 28 ? [8, 1] : [])])];
  const yearSign = chineseSign(inp.year);
  const monthSign = chineseMonthSign(inp.month, inp.day);
  const votes: Vote[] = []; const alerts: string[] = []; const notes: string[] = []; const missing: string[] = [];
  const add = (side: Side, weight: number, layer: Step, reason: string) => votes.push({ side, weight, layer, reason });
  const other = (s: Side): Side => (s === "home" ? "away" : "home");
  const teams: [Side, VoteTeam][] = [["home", inp.home], ["away", inp.away]];

  const reads = {} as Record<Side, TeamRead>;
  for (const [s, t] of teams) {
    const name = pythagoreanValue(t.name);
    const r: TeamRead = { name: { compound: name.compound, reduced: name.reduced }, enemyYear: false, hits: [] };
    if (t.founded) {
      const [y, m, d] = t.founded;
      r.lp = lifePath(y, m, d); r.foundedDay = dayEnergy(d); r.sign = chineseSign(y);
      r.enemyYear = signRelation(r.sign, yearSign) === "enemy";
      if (touches(r.lp, dayNums)) r.hits.push(`Life Path ${fmt(r.lp)}`);
      if (touches(r.foundedDay, dayNums)) r.hits.push(`${inp.individual ? "born" : "founded"} on the ${ord(d)} (${fmt(r.foundedDay)})`);
    } else missing.push(`${t.name} ${inp.individual ? "birth date" : "founding date"}`);
    if (touches(r.name, dayNums)) r.hits.push(`letterology ${fmt(r.name)}`);
    reads[s] = r;
  }
  const dayLabel = `${fmt(ud)} & ${dom.reduced}`;
  const entities: EntityProfile[] = [];
  const pdRelTo = (pd: Num) => { const r = pd.reduced === ud.reduced ? "same" : numberRelation(pd.reduced, ud.reduced); return r; };
  const profile = (side: EntityProfile["side"], role: string, name: string, b?: readonly [number, number, number]) => {
    if (!b) { entities.push({ side, role, name }); return undefined; }
    const [y, m, d] = b; const pd = personalDayFor(b, inp.year, inp.month, inp.day);
    const e: EntityProfile = { side, role, name, date: `${m}/${d}/${y}`, lp: lifePath(y, m, d), dayOfYear: dayOfYear(y, m, d), dayEnergy: dayEnergy(d),
      yearSign: chineseSign(y), monthSign: chineseMonthSign(m, d), daySign: chineseDaySign(y, m, d), lucky: luckyNumber(y, m), pd, pdRel: pdRelTo(pd) };
    entities.push(e); return e;
  };
  const pdVote = (s: Side, e: EntityProfile | undefined, w: number, layer: Step) => {
    if (!e?.pd) return;
    const r = e.pdRel;
    if (r === "same" || r === "friend" || r === "soulmate") add(s, w, layer, `${e.name} is in a Personal ${fmt(e.pd)} Day — ${r === "same" ? "matches" : "friendly with"} the ${ud.reduced} Universal Day`);
    else if (r === "enemy" || r === "worst") add(other(s), w, layer, `${e.name} is in a Personal ${fmt(e.pd)} Day — enemy of the ${ud.reduced} Universal Day`);
  };
  for (const [s, t] of teams) {
    pdVote(s, profile(s, inp.individual ? "Fighter" : "Team", t.name, t.founded), 1, "Game-day energy");
    for (const p of t.people) pdVote(s, profile(s, p.role === "pitcher" ? "Pitcher" : p.role === "quarterback" ? "QB" : p.role === "coach" || p.role === "manager" ? "Coach" : "Player", p.name, parseDob(p.dob) ?? undefined), 0.5, "Stars & venue");
  }
  if (!inp.individual) {
    if (inp.stadium || inp.stadiumOpened) pdVote("home", profile("venue", "Stadium", inp.stadium ?? "Stadium", inp.stadiumOpened), 0.5, "Stars & venue");
    if (inp.city || inp.cityFounded) pdVote("home", profile("venue", "City", inp.city ?? "City", inp.cityFounded), 0.25, "Stars & venue");
  }

  // Step 1+2: game-day energy (×2)
  const hh = reads.home.hits.length, ah = reads.away.hits.length;
  if (hh !== ah) {
    const s: Side = hh > ah ? "home" : "away";
    add(s, 2, "Game-day energy", `${(s === "home" ? inp.home : inp.away).name} touches today's ${dayLabel}: ${reads[s].hits.join(", ")}${reads[other(s)].hits.length ? "" : " — the other side touches nothing"}`);
  }
  // Team core (×2)
  const hc = coreStrength(reads.home), ac = coreStrength(reads.away);
  if (hc !== ac && hc && ac) {
    const s: Side = hc > ac ? "home" : "away";
    add(s, 2, "Team core", `${(s === "home" ? inp.home : inp.away).name} carries the stronger signature (Life Path ${fmt(reads[s].lp!)}${reads[s].foundedDay?.compound === 28 ? ", founded on the 28th" : ""})`);
  }
  // Step 3: number pairs vs the day
  for (const [s, t] of teams) {
    const lp = reads[s].lp; if (!lp) continue;
    const rel = numberRelation(lp.reduced, ud.reduced);
    if (rel === "worst" || rel === "enemy") add(other(s), 1, "Number pairs", `${t.name} Life Path ${lp.reduced} vs ${ud.reduced} Universal Day — ${rel === "worst" ? "worst-enemy pair" : "enemies"}`);
    if (rel === "soulmate" || rel === "friend") add(s, 1, "Number pairs", `${t.name} Life Path ${lp.reduced} is ${rel === "soulmate" ? "soulmates" : "best friends"} with the ${ud.reduced} day`);
  }
  // Step 4: Chinese year / month
  const hs = reads.home.sign, as = reads.away.sign;
  if (hs && as && hs === as) notes.push(`Both teams are ${hs} — zodiac is a wash`);
  else for (const [s, t] of teams) {
    const sg = reads[s].sign; if (!sg) continue;
    if (reads[s].enemyYear) add(other(s), 1, "Chinese zodiac", `${t.name} (${sg}) is in its enemy year — ${yearSign} year strains it`);
    const yr = signRelation(sg, yearSign) === "friend", mo = signRelation(sg, monthSign) === "friend";
    if (yr || mo) add(s, 1, "Chinese zodiac", `${t.name} (${sg}) shares a trine with the ${[yr && `${yearSign} year`, mo && `${monthSign} month`].filter(Boolean).join(" and ")}`);
  }
  // Step 5: stars, coaches, venue (small)
  for (const [s, t] of teams) {
    const oppSign = reads[other(s)].sign;
    if (!t.people.length && !inp.individual) missing.push(`${t.name} starters/coach birthdays`);
    for (const p of t.people) {
      alerts.push(...championshipAlerts(p, inp.league));
      const d = parseDob(p.dob); if (!d) { missing.push(`${p.name} birth date`); continue; }
      const lp = lifePath(d[0], d[1], d[2]); const ps = chineseSign(d[0]);
      if (oppSign) {
        const rel = signRelation(ps, oppSign);
        if (rel === "enemy") add(other(s), 0.5, "Stars & venue", `${p.name} (${ps}) clashes with ${oppSign} opponent`);
        if (rel === "friend") add(s, 0.5, "Stars & venue", `${p.name} (${ps}) is friendly with ${oppSign} opponent`);
      }
      if (touches(lp, dayNums) || touches(dayEnergy(d[2]), dayNums)) add(s, 0.5, "Stars & venue", `${p.name} (LP ${fmt(lp)}, born the ${ord(d[2])}) matches today`);
      const j = Number(p.jersey);
      if (j && (j === d[2] || j === lp.compound || j === lp.reduced)) add(s, 0.25, "Stars & venue", `${p.name} wears #${j} — repeats birth numbers`);
    }
  }
  for (const [label, dt, nm] of [["Stadium", inp.stadiumOpened, inp.stadium], ["City", inp.cityFounded, inp.city]] as const) {
    if (!dt || inp.individual) continue;
    const lp = lifePath(dt[0], dt[1], dt[2]);
    if (touches(lp, dayNums)) add("home", 0.5, "Stars & venue", `${label} ${nm ?? ""} (${dt[1]}/${dt[2]}/${dt[0]} → ${fmt(lp)}) matches today`);
  }

  // Lunar phase (secondary): new moon backs the starter (road attacker), full moon the finisher (home)
  const moon = moonPhase(inp.year, inp.month, inp.day).phase;
  if (moon === "New Moon") add("away", 0.25, "Stars & venue", "New moon (secondary) — starting energy backs the road attacker");
  if (moon === "Full Moon") add("home", 0.25, "Stars & venue", "Full moon (secondary) — finishing energy backs the home side");
  notes.push(`Moon: ${moon}`);

  // Special-day notes + hard rule
  for (const n of [ud.compound, inp.day]) if (SPECIAL_NUMBERS[n] && !notes.includes(SPECIAL_NUMBERS[n])) notes.push(SPECIAL_NUMBERS[n]);
  const noPlay = ud.reduced === 9;
  if (noPlay) alerts.unshift("9 Universal Day — no sports picks today");

  const total = (s: Side) => +votes.filter(v => v.side === s).reduce((a, v) => a + v.weight, 0).toFixed(2);
  let home = total("home"), away = total("away"); let tiebreak = false;
  // Step 6: colors — tiebreaker only
  if (home === away) {
    tiebreak = true;
    const score = (t: VoteTeam) => (t.colors ?? []).reduce((acc, c) => acc + colorFit(c, ud.compound in COMPAT && ud.compound > 9 ? ud.compound : ud.reduced), 0);
    const hc2 = score(inp.home), ac2 = score(inp.away);
    if (hc2 !== ac2) {
      const s: Side = hc2 > ac2 ? "home" : "away"; const t = s === "home" ? inp.home : inp.away;
      add(s, 0.5, "Colors", `Tiebreaker: ${t.name} colors (${(t.colors ?? []).map(c => `${c} ${colorNumsLabel(c)}`).join(", ")}) fit the ${ud.reduced} day better (GG33 colorology)`);
    } else {
      // Step 7: records
      const h = winPct(inp.home.record), a = winPct(inp.away.record);
      const s: Side = h != null && a != null && a > h ? "away" : "home";
      add(s, 0.1, "Records", h != null && a != null && h !== a ? `Tiebreaker: better record (${s === "home" ? inp.home.record : inp.away.record})` : "Tiebreaker: home field");
    }
    home = total("home"); away = total("away");
  }
  const pick: Side = home >= away ? "home" : "away";
  const name = (sd: Side) => (sd === "home" ? inp.home : inp.away).name;
  const noEdge: Record<Step, string> = {
    "Team core": !reads.home.lp || !reads.away.lp ? `${inp.individual ? "Birth" : "Founding"} date missing for one side` : `Equal core signatures (${fmt(reads.home.lp)} vs ${fmt(reads.away.lp)})`,
    "Game-day energy": hh || ah ? `Both sides touch today's ${dayLabel} equally` : `Neither side touches today's ${dayLabel}`,
    "Number pairs": `No enemy or friend pair with the ${ud.reduced} day`,
    "Chinese zodiac": hs && as && hs === as ? `Both are ${hs} — a wash` : `No enemy year or trine with the ${yearSign} year / ${monthSign} month`,
    "Stars & venue": missing.some(m => /birth|starters/.test(m)) ? "No matches — some birth dates not available yet" : "No player, venue or moon matches today",
    "Colors": tiebreak ? "Colors fit the day equally" : "Not needed — no tie",
    "Records": tiebreak && !votes.some(x => x.layer === "Colors") ? "Records equal" : "Not needed — no tie",
  };
  const steps: StepRow[] = STEP_ORDER.map(st => {
    const vs = votes.filter(x => x.layer === st);
    const w = { home: 0, away: 0 }; vs.forEach(x => (w[x.side] += x.weight));
    const edge: Side | null = w.home === w.away ? null : w.home > w.away ? "home" : "away";
    return { step: st, label: STEP_LABELS[st], edge, reason: vs.length ? vs.map(x => `${name(x.side)}: ${x.reason}`).join(" · ") : noEdge[st] };
  });
  const coreMissing = new Set(missing.filter(m => /date/.test(m))).size;
  const confidence = computeConfidence({
    winner: pick === "home" ? home : away, loser: pick === "home" ? away : home,
    noPlay, alerts: alerts.filter(a => !a.startsWith("9 Universal")).length, missing: coreMissing,
    tiebreakOnly: tiebreak,
  });
  return { entities, gameDayOfYear: dayOfYear(inp.year, inp.month, inp.day), gameDaySign: chineseDaySign(inp.year, inp.month, inp.day), votes, home, away, pick, tiebreak, universalDay: ud, dayOfMonth: dom, yearSign, monthSign, noPlay, alerts, notes, missing, reads, steps, confidence, band: confidenceBand(confidence) };
}

/** Team colors (primary first). */
export const TEAM_COLORS: Record<string, string[]> = {
  "Arizona Diamondbacks": ["Red", "Black"], "Atlanta Braves": ["Navy", "Red"], "Baltimore Orioles": ["Orange", "Black"], "Boston Red Sox": ["Red", "Navy"],
  "Chicago Cubs": ["Blue", "Red"], "Chicago White Sox": ["Black", "White"], "Cincinnati Reds": ["Red", "White"], "Cleveland Guardians": ["Navy", "Red"],
  "Colorado Rockies": ["Purple", "Black"], "Detroit Tigers": ["Navy", "Orange"], "Houston Astros": ["Navy", "Orange"], "Kansas City Royals": ["Blue", "Gold"],
  "Los Angeles Angels": ["Red", "Navy"], "Los Angeles Dodgers": ["Blue", "White"], "Miami Marlins": ["Black", "Blue"], "Milwaukee Brewers": ["Navy", "Gold"],
  "Minnesota Twins": ["Navy", "Red"], "New York Mets": ["Blue", "Orange"], "New York Yankees": ["Navy", "White"], "Athletics": ["Green", "Gold"],
  "Oakland Athletics": ["Green", "Gold"], "Philadelphia Phillies": ["Red", "Blue"], "Pittsburgh Pirates": ["Black", "Gold"], "San Diego Padres": ["Brown", "Gold"],
  "San Francisco Giants": ["Orange", "Black"], "Seattle Mariners": ["Navy", "Teal"], "St. Louis Cardinals": ["Red", "Navy"], "Tampa Bay Rays": ["Navy", "Blue"],
  "Texas Rangers": ["Blue", "Red"], "Toronto Blue Jays": ["Blue", "Navy"], "Washington Nationals": ["Red", "Navy"],
  "Dallas Cowboys": ["Navy", "Silver"], "Tampa Bay Buccaneers": ["Red", "Pewter"], "Kansas City Chiefs": ["Red", "Gold"], "Philadelphia Eagles": ["Green", "Silver"],
  "Green Bay Packers": ["Green", "Gold"], "San Francisco 49ers": ["Red", "Gold"], "Pittsburgh Steelers": ["Black", "Gold"], "Baltimore Ravens": ["Purple", "Black"],
  "Las Vegas Raiders": ["Black", "Silver"], "Minnesota Vikings": ["Purple", "Gold"], "New England Patriots": ["Navy", "Red"], "Buffalo Bills": ["Blue", "Red"],
  "Chicago Bears": ["Navy", "Orange"], "Detroit Lions": ["Blue", "Silver"], "New York Giants": ["Blue", "Red"], "New York Jets": ["Green", "White"],
  "Miami Dolphins": ["Aqua", "Orange"], "Denver Broncos": ["Orange", "Navy"], "Seattle Seahawks": ["Navy", "Green"], "Los Angeles Rams": ["Blue", "Yellow"],
  "Los Angeles Chargers": ["Blue", "Gold"], "Cincinnati Bengals": ["Orange", "Black"], "Cleveland Browns": ["Brown", "Orange"], "Houston Texans": ["Navy", "Red"],
  "Indianapolis Colts": ["Blue", "White"], "Jacksonville Jaguars": ["Teal", "Black"], "Tennessee Titans": ["Navy", "Blue"], "Atlanta Falcons": ["Red", "Black"],
  "Carolina Panthers": ["Blue", "Black"], "New Orleans Saints": ["Gold", "Black"], "Arizona Cardinals": ["Red", "White"], "Washington Commanders": ["Burgundy", "Gold"],
};
