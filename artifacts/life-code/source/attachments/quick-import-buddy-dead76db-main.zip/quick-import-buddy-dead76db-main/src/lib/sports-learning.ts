// Auto-learning: records past picks + outcomes and biases future scores.
// Purely client-side (localStorage). Bias is capped so it never dominates decode.

const KEY = "shem-sports-learning-v1";

interface PickRecord {
  date: string;
  home: string;
  away: string;
  pick: "home" | "away" | "draw";
  actual?: "home" | "away" | "draw";
  homeScore: number;
  awayScore: number;
}

interface Store {
  records: PickRecord[];
  bias: Record<string, number>;
}

function read(): Store {
  if (typeof window === "undefined") return { records: [], bias: {} };
  try { return JSON.parse(localStorage.getItem(KEY) || "") as Store; } catch { return { records: [], bias: {} }; }
}
function write(s: Store) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(s));
}
function clamp(n: number) { return Math.max(-1, Math.min(1, n)); }

export function recordPick(p: Omit<PickRecord, "actual">) {
  const s = read();
  s.records = s.records.filter(r => !(r.date === p.date && r.home === p.home && r.away === p.away));
  s.records.push(p);
  write(s);
}

export function recordOutcome(date: string, home: string, away: string, actual: "home" | "away" | "draw") {
  const s = read();
  const r = s.records.find(r => r.date === date && r.home === home && r.away === away);
  if (r) r.actual = actual;
  if (r && r.pick !== actual) {
    const wrong = r.pick === "home" ? home : r.pick === "away" ? away : null;
    const right = actual === "home" ? home : actual === "away" ? away : null;
    if (right) s.bias[right] = clamp((s.bias[right] ?? 0) + 0.15);
    if (wrong) s.bias[wrong] = clamp((s.bias[wrong] ?? 0) - 0.10);
  } else if (r && r.pick === actual) {
    const t = actual === "home" ? home : actual === "away" ? away : null;
    if (t) s.bias[t] = clamp((s.bias[t] ?? 0) + 0.03);
  }
  write(s);
}

export function getBias(team: string): number { return read().bias[team] ?? 0; }

export function accuracy(): { picks: number; hits: number; pct: number } {
  const s = read();
  const scored = s.records.filter(r => r.actual);
  const hits = scored.filter(r => r.pick === r.actual).length;
  return { picks: scored.length, hits, pct: scored.length ? Math.round(100 * hits / scored.length) : 0 };
}

export function resetLearning() { write({ records: [], bias: {} }); }

// ── Per-step pick log (7-step method) ───────────────────────────────────────
const LOG_KEY = "shem-sports-steplog-v1";
export interface StepVote { side: "home" | "away"; layer: string; weight: number }
export interface StepLogEntry { id: string; date: string; home: string; away: string; pick: "home" | "away"; confidence?: number; votes: StepVote[]; actual?: "home" | "away" | "draw" }
function readLog(): StepLogEntry[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(LOG_KEY) || "[]"); } catch { return []; }
}
function writeLog(l: StepLogEntry[]) { if (typeof window !== "undefined") localStorage.setItem(LOG_KEY, JSON.stringify(l)); }
export function logStepPick(e: Omit<StepLogEntry, "actual">) {
  const l = readLog(); const ex = l.find(x => x.id === e.id);
  if (ex) { if (!ex.actual) { ex.pick = e.pick; ex.votes = e.votes; ex.confidence = e.confidence; } } else l.push(e);
  writeLog(l);
}
export function scoreStepPick(id: string, actual: "home" | "away" | "draw") {
  const l = readLog(); const ex = l.find(x => x.id === id);
  if (ex && !ex.actual) { ex.actual = actual; writeLog(l); }
}
export function stepHitRates() {
  const scored = readLog().filter(e => e.actual && e.actual !== "draw");
  const steps: Record<string, { hits: number; total: number }> = {};
  for (const e of scored) for (const layer of new Set(e.votes.map(v => v.layer))) {
    const w = { home: 0, away: 0 };
    e.votes.filter(v => v.layer === layer).forEach(v => (w[v.side] += v.weight));
    if (w.home === w.away) continue;
    const s = (steps[layer] ??= { hits: 0, total: 0 });
    s.total++; if ((w.home > w.away ? "home" : "away") === e.actual) s.hits++;
  }
  const hits = scored.filter(e => e.pick === e.actual).length;
  const bands: Record<string, { hits: number; total: number }> = {};
  for (const e of scored) {
    if (e.confidence == null) continue;
    const c = e.confidence, k = c >= 85 ? "Exceptional" : c >= 70 ? "Strong" : c >= 50 ? "Good" : c >= 30 ? "Mixed" : "Challenging";
    const b = (bands[k] ??= { hits: 0, total: 0 }); b.total++; if (e.pick === e.actual) b.hits++;
  }
  return { total: scored.length, hits, steps, bands };
}
