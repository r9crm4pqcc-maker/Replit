# Finish the revamp: remaining work

The new 7-step pick logic is built but not yet shown in the app. This plan finishes the rest.

## Step A: Sports AI uses your method only
- Remove every gematria piece from the Sports AI page: cipher tables, date equations, 365-day chart, entity lists and the old "convergence" verdict.
- Each game card shows, in your order:
  - The pick, with "Lean" or "Strong" and the weighted count (e.g. "Bucs 3, Cowboys 2").
  - Red alerts: 9 day = "No sports picks today", plus the Super Bowl / NBA "never bet" rules.
  - Today's energy: Universal Day & day of month, year animal, month animal, and 27/18/3/12 notes.
  - Side-by-side team reads: Life Path, founding day, Chinese sign, letterology, colors, enemy-year flag.
  - Every vote with its step and reason, ending with the tiebreaker (colors, then records) if one was needed.
  - Missing data in plain words (e.g. "starting pitchers not announced").
- Lunar phase is added as a small vote (new moon helps the starter side; full moon helps the finisher). It's labeled secondary.

## Step B: Pick log and hit rates
- Every pick is saved automatically with its votes.
- Finished games are scored on their own from the final score.
- A "Signal Hit Rate" panel shows each step's accuracy and the overall record, with a note that it becomes reliable after 30 picks.

## Step C: Numerology page revamp (daily hub with tabs)
- **Today:** Personal Year, Month and Day with "why this number" math; Universal Day, Month and Year; solar and lunar birthday numbers; lucky numbers; daily color; Gary's day alerts.
- **Alerts:** Personal Year and Month begin/end dates; enemy year, month and day with the next Chinese New Year date; master days (11/22/33), 888, Peak Alignment, 28/19 markers, repeating numbers; new and full moon rituals.
- **Calendar:** a month grid with each day's Universal Day and day of month, plus friendly or challenging animal months.
- **Compatibility:** Life Path pair map for people, brands, cities and teams; best days for money, meetings and first dates.
- **Tools:** letterology name and business check, a lucky-price picker (prices reducing to 8), and places, cars and travel by number.
- **Forecasts and Learn:** daily, monthly and yearly forecasts and a career consultant through the AI chat; Gary's teachings; an outcome journal.
- Western and Vedic astrology stay on the existing Astrology page, linked from the hub.

## Open question (doesn't block the work)
Your Guardians read uses Life Path 8 and a founding on the 19th. The app has the Guardians at April 24, 1901 (21/3). I'll keep that date until you send yours.

## Technical details
- `sports-prediction.tsx`: drop the `gematria-code` imports and components (DateBlock, YearChart, CipherTable, ConnList, PeopleBlock), and rewrite GameCard around `runVotes`. Map ESPN starters to the pitcher/quarterback role and managers to the coach role, and pass the league.
- `vote-decode.ts`: add a lunar vote using the existing moon phase helper in `sports-decode.ts`. Set `TEAM_COLORS` as the color source.
- `sports-learning.ts`: store `votes[]` per pick; add `autoScore(final)` and `stepHitRates()`.
- New `src/components/numerology/*` tab files; `imported-pages/numerology.tsx` becomes the tab shell. Reuse `numerology.ts`, `bazi.ts` and `colorology.ts`, and update the colorology map to pink 5 and grey 28. The journal uses local storage.
- Run the existing vitest file and fix failures; add tests for the 20-handling rule and for lucky prices reducing to 8.
- Record the decoder and learning-store decisions in `AGENTS.md`; save the user's rules (color map, number pairs, hard rules) to memory.
