# Sports Decoder + App Revamp

## 1. New look: "Bold Blaze" black and orange
- Whole app restyled: near-black background (#0a0a0a), card surfaces #161616, bright orange accent (#ff6a00), soft orange highlights (#ffa34d).
- Replaces the current Noir & Gold everywhere: sidebar, dashboard, Numerology, Astrology, Tools, Sports AI, Stock Market AI, chat.
- Cleaner, less crowded screens: bigger headings, fewer boxes, key results up top, details tucked behind "Show more".

## 2. New sports decoder: vote counting
Every factor casts a vote for one team. Votes are added up; the team with more weight gets the pick. Numbers outrank astrology, records only break ties.

| Vote | What it checks | Weight |
|---|---|---|
| Team founding date | Full month/day/year franchise founding → Life Path; 28 = wealth bonus | Highest |
| Game day match | Universal Day vs each team's numbers; 8/28 days favor money teams, 1 days the aggressor | High |
| Chinese signs | Founding-year signs: same trine = friends, clash pairs = enemies; enemy of the current year (2026 Horse → Rat teams weighed down) | Medium |
| Pitchers and coaches | Birth date Life Path, birth-day number, Chinese sign vs opposing team's sign; jersey-number repeats (Klay 11 pattern) | Medium |
| Colors | Your map: Red 9, Blue/Green 4, Purple 7, Black/White/Yellow/Gold 11; 1 vs 9 = worst-enemy pair | Medium-low |
| Stadium and city | Stadium opening date and city founding date | Low |
| Records | Win/loss form | Tiebreaker only |

- Trines: Rat/Monkey/Dragon, Ox/Rooster/Snake, Horse/Dog/Tiger, Cat(Rabbit)/Pig/Goat.
- Clashes: Rat-Horse, Ox-Goat, Tiger-Monkey, Cat-Rooster, Dragon-Dog, Snake-Pig.
- Each game card shows a vote tally (e.g. "Rangers 5 votes vs Angels 2"), every vote with its reason, and the final pick. Still a play every game.
- Games stay automatic from ESPN (pitchers, managers, birthdays); founding, stadium and city dates come from a built-in reference list.

## 3. Resources
- A "Resources" page inside Sports AI listing the reference tables (founding dates, trines/clashes, color map, sport founding years like football 1920 Monkey / America 1776 Monkey). You can send more resources later and they get added here.

## Questions I'll need answered later (not blocking)
- Stadium opening and city founding dates: I'll fill in documented dates for MLB first; tell me if you have your own list.
- Which other sports (NFL, NBA, soccer) should get founding-date lists next.

## Technical details
- `src/styles.css`: swap tokens to the orange palette (oklch), update gradients/shadows; components keep semantic tokens.
- New `src/lib/vote-decode.ts`: pure functions per vote type returning `{side, weight, reason}`, plus `tallyVotes`. Uses existing `numerology.ts` reductions and a new color map honoring the user's values.
- `src/lib/sports-data.ts`: ensure full founding dates, add stadium opening + city founding fields.
- `src/imported-pages/sports-prediction.tsx`: replace gematria verdict panel with vote tally UI; keep gematria tables as an optional detail section.
- Vitest tests for the rules: trine friends, clash enemies, Horse-year Rat penalty, color values (Red 9, Black 11), 1 vs 9 worst pair, records only break ties.
