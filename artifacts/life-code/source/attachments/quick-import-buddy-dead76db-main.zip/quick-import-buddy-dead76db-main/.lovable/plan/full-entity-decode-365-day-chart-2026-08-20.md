# Full Entity Decode + 365-Day Chart

Make every required entity visible in the decode, and add a Gematrinator-style day-of-year chart.

## What you'll see

A new "ENTITY GEMATRIA" section in each game's full decode listing every required item side by side, each with all five ciphers and a check when a value matches a date number:

- Team names — short form (e.g. Rangers, Texas) and long/official form (Texas Rangers), for both teams
- Both managers — common name and full name
- Both starting pitchers — common name and full name
- Stadium — name, stadium + city, stadium + city + state
- Location — host city, host state, city + state
- Matchup line and weekday/written date

Rows are grouped Away / Home / Neutral (game) so nothing is buried.

A new "365-DAY CHART" panel showing, for the game date:

- Day of year N of 365/366, days remaining (exclusive and inclusive), ISO week
- The mirrored day (same day counted from year end) and its date
- A compact 12-month strip highlighting the current day-of-year position
- Which entity phrases on this card match the day-of-year, days-remaining, or week numbers — the same convergence the engine already scores, shown explicitly

## Technical notes

- `src/lib/espn-auto.ts`: capture `abbreviation`, `shortDisplayName`, `displayName`, `location`, and `name` per competitor, plus venue city/state (already partly captured), so short and long team names come straight from the feed — no manual entry.
- `src/lib/gematria-code.ts`: extend `TeamInput` with `shortName`/`longName`; add those rows to `teamPhrases` (deduped against nickname/geographic). Expose the grouped phrase rows on `ProtocolResult` so the UI can render them. Add `mirrorDayOfYear` + mirror date to `DateCode`.
- `src/imported-pages/sports-prediction.tsx`: add the two new sections inside the existing "Show full decode" area, styled like the current `Section`/`CipherTable` components. No changes to scoring weights or the decision logic.
