# Sports decoder on your 7-step method + Numerology revamp

Built in two phases so each piece can be tested before moving on.

## Phase 1: Sports Prediction AI

### Remove gematria entirely
- Remove the cipher tables, date equations, 365-day chart, entity gematria and the "convergence" logic from Sports AI. The page shows only your method.

### Game card follows your 7 steps (same as the Guardians and Bucs reads)
1. **Team identity (×2):** founding date gives the Life Path, day-of-month energy and Chinese sign; plus the team name's letterology total.
2. **Game day (×2):** Universal Day plus the day of the month (e.g. 1 & 8). 1 = aggressors, 3 = reactive, 4 = structure, 8 = power/karma. 27 counts as a baseball number, 18 as a gambling number, 3 as luck, and 12 as beginner's luck.
3. **Number pairs:** 1–9 worst enemies, 3–4 enemies, 7–11 soulmates, 3–5 best friends.
4. **Chinese year, month and day:** for teams and coaches. Enemy year = strained side (Rat in a Horse year); trine bonuses; a shared sign is a wash. Animal months run from the 6th to the 5th.
5. **Stars, coaches, stadium, city, lunar phase:** small extra votes.
6. **Colors (tiebreaker only):** red 9, blue/green/navy 4, purple 7, pink 5, grey 28/1, black/white/yellow/gold 11.
7. **Records:** break a tie only after colors.

### Hard rules (shown as red alerts)
- **9 Universal Day:** "No sports picks today". The card still shows the read, but marks it no-play.
- Never back a QB with a 9 Life Path, or born on a 9 day, to win the Super Bowl.
- Never back a QB born in a Cat, Goat or Tiger year to win the Super Bowl.
- Never back an NBA star with a 9 Life Path to win the title.

### Pick log
Each pick is saved with its reasons and scored automatically after the final. The Signal Hit Rate per step becomes meaningful after 30 picks.

### Data
- NFL founding dates (Cowboys 1/28/1960, etc.) alongside MLB.
- Two colors per team.
- QB and coach birthdays come from the live game feed when it has them; missing ones are listed on the card.

## Phase 2: Numerology page revamp
Rebuilt as a daily hub, organized in tabs:
- **Today:** solar and lunar birthday numbers; Personal Year/Month/Day with "why this number" math (masters kept, 28/19 kept, 20 shown as hidden 11 but added as 2+0); Universal Day/Month/Year; daily color; lucky numbers (solar, lunar, Gary's method); and Gary's day alerts (4 days = seatbelt, no flying on the 11th/29th, no marrying on a 7, haircut on 8/17/26/28).
- **Alerts and special days:** Personal Year and Month begins/ends; enemy year, month and day alerts with the next Chinese New Year date; 888, 11/22/33 master days and Peak Alignment days; 28/19 wealth and karmic markers; repeating numbers; and the lunar cycle (new moon starts, full moon releases).
- **Calendar:** each day shows the Universal Day and the day of the month, with the Personal Month and Year underneath; friendly and challenging animal months.
- **Compatibility:** Life Path pair map for people, brands, cities and teams; best days for money, meetings and first dates.
- **Tools:** letterology name check (first letter + first vowel); business-name check; lucky-price picker (prices reducing to 8); places to live, cars and travel by number.
- **Forecasts:** daily, monthly and yearly forecasts plus a career consultant, using the existing AI chat with your numbers as context.
- **Astrology:** Western, Vedic and Chinese year/month/day, with optional birth time and place for the hour pillar and rising sign. Eclipses and Saturn notes.
- **Learn and journal:** Gary's teachings (enemy pairs, why 3 is luck and 7 is the gamble), an outcome journal with your own patterns, a Sunday weekly preview, and share cards.

## Technical details
- Delete gematria usage from `src/imported-pages/sports-prediction.tsx`; leave `gematria-code.ts` unused, or remove it.
- Rewrite `src/lib/vote-decode.ts` as step functions: `dayOfMonthEnergy`, Pythagorean name totals, a `NUMBER_RELATIONS` table, a Chinese month sign from 6th-to-5th boundaries, a day pillar via the existing `bazi.ts`, a no-play rule on a 9 day, and championship rule flags.
- `sports-data.ts`: NFL dates; `TEAM_COLORS` as `string[]`.
- `sports-learning.ts`: per-step vote logging and hit rates.
- Numerology page split into tab components under `src/components/numerology/`, reusing `numerology.ts`, `astrology.ts`, `bazi.ts` and `colorology.ts` (colorology updated to your map: pink 5, grey 28).
- Journal and log stay on the device (local storage) for now.
- Vitest checks: the Guardians and Bucs examples, 9-day no-play, each pair rule, color values, and 20 handling.
