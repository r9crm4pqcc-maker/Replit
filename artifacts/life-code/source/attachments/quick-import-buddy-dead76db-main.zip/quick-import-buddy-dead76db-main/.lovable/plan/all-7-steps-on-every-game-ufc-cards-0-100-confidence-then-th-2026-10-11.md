# All 7 steps on every game, UFC cards, 0–100% confidence, then the Numerology hub

## 1. Every game runs all 7 steps
Each game card lists all 7 steps in order, every time. Each step shows who gets the edge and why, or "No edge" with the reason (for example "both teams are Ox", or "starters not announced yet"). No step is skipped silently anymore.

1. Team identity (founding Life Path, founded day, sign, letterology)
2. Game-day energy (Universal Day and day of month)
3. Number pairs (1–9, 3–4, 7–11, 3–5)
4. Chinese year, month and enemy year
5. Stars, coaches, stadium, city, moon (small)
6. Colors (decide the pick only when the game is tied)
7. Records (decide the pick only when still tied), plus the pick log result after the final

## 2. Confidence from 0 to 100% instead of points
Points stay hidden in the background; the card shows one big percentage and its label:

| Confidence | Label |
|---|---|
| 0–29% | Challenging |
| 30–49% | Mixed |
| 50–69% | Good |
| 70–84% | Strong |
| 85–100% | Exceptional |

How it's worked out:
- **Starting point:** the picked side's share of all the votes. 3 votes vs 2 gives 60%; 4 vs 0 gives 100%; 0 vs 0 gives 50%.
- **Lowered by:**
  - A 9 Universal Day (no-play day): −30
  - Each "never bet" alert: −10
  - A missing founding date or birth date: −5 each
  - A pick decided only by colors or records: −10
- The result is kept between 0% and 100%.
- The hit-rate panel also shows how often picks hit within each confidence band.

## 3. UFC fight cards
- A new UFC option in the league list pulls the full card (main card and prelims) from the live ESPN feed. Saturdays are picked by default.
- Fighters have no founding date, so a fighter's **birth date is their identity**: Life Path, birth-day energy, Chinese sign and name letterology. All 7 steps still run:
  - Steps 1 and 2 use the fighter's birth numbers against the fight day.
  - Step 3 uses the number pairs between the fighter and the day.
  - Step 4 checks the fighter's sign, enemy year and the sign matchup against the opponent.
  - Step 5 uses the moon and the event city.
  - Step 6 uses fight-short colors only if the feed lists them; otherwise "No edge".
  - Step 7 uses fight records (W-L) as the final tiebreaker.
- If a fighter's birth date isn't in the feed, the card says so and confidence drops.

## 4. Numerology hub (from the approved plan, still to build)
The tabs are Today, Alerts, Calendar, Compatibility, Tools, and Forecasts & Learn, as already approved. The current Numerology page is kept as a "Full Profile" tab so nothing is lost.

## Technical details
- `vote-decode.ts`: `runVotes` returns `steps: { step, edge: Side | null, reason }[]` for all 7 steps, plus `confidence` (0–100) and `band`. Add `runFightVotes` for individuals, reusing the same step functions with a birth date instead of a founding date.
- `espn.ts` / `espn-auto.ts`: add the `mma/ufc` scoreboard; map each competition into a fight with fighter names, records, birth dates (athlete endpoint) and card segment.
- `sports-prediction.tsx`: add UFC to the "US Major" group; the card shows the confidence gauge, the band label and a 7-row step list; points are hidden.
- `sports-learning.ts`: store confidence per pick; add a per-band hit rate.
- Vitest: band boundaries (29 → Challenging, 30 → Mixed, 50 → Good, 70 → Strong, 85 → Exceptional), 3 vs 2 = 60%, 9-day penalty, all 7 steps always present, and a fighter read from a birth date.
- Numerology hub files under `src/components/numerology/`, as previously planned.
