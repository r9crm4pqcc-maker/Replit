# SportsCode: HTML rules, editable founding dates, complete cards

## 1. Bring in everything from the HTML predictor
Added to each game card as extra checks inside the existing 7 steps (numbers still outrank everything; colors and records still only break ties):

- **Game start time + enemy hours** — start time from ESPN, converted to the Chinese 2-hour animal. Each team's animal vs the hour animal: Clash, Harm, Punishment, Destruction = enemy; trine/six-harmony = friendly. Card lists each side's enemy hours and warns "stop extra risk once enemy time begins".
- **Chinese relationship types** — Clash, Harm, Punishment, Destruction shown by name (not just "enemy") in step 4.
- **Personal Week** — per team/person (Option A / Option B), shown in the side-by-side table and as a small vote in step 2.
- **Personal Month vs Personal Year** and **Birth Day vs day of month** — friendly/enemy check per side.
- **Life Path vs Universal Day** shown explicitly per side.
- **Lucky number hits** — lucky number matching jersey, day of month, Universal Day or Life Path now casts a small vote; halved ("cooling off") during an enemy period.
- **Jersey match** — jersey equal to Life Path or birth day flagged.
- **Streak rule** — current win/lose streak from ESPN; a 9-energy side is flagged as the streak-ender.
- **11-day spread** — flags when teams' key numbers sit 11 apart.
- **Travel alerts** — 4-days (4th, 13th, 31st) "cops are out"; 11th / 29th "do not fly" warning for the road team.
- **Day-energy guide** — the Do / Avoid text for the day's number shown at the top of the card.
- **Versus sheet** — Life Path vs Life Path between the two teams' carriers (team, QB/pitcher, star) scored from the GG33 chart.

## 2. Founding date editor
New "Team Dates" tab in Sports AI:
- Pick a league, see every team with its founding date, stadium and city.
- Edit any date; saved on this device and used immediately in every decode. "Reset to default" per team.
- Teams without a date (soccer, college) can be filled in here, which removes the missing-date penalty.
- Edited teams show a small "custom date" mark on game cards.

## 3. Complete card — nothing missed
Every card always lists both teams, both starters (pitcher / QB / goalie / main fighter), both head coaches, and the venue + city. For each:
- Data pulled from ESPN; if the birth date isn't in the feed, a second ESPN lookup by player/coach ID is tried.
- If still missing, the row stays visible marked "date missing — add it" with an inline field to enter it (saved like team dates), so nothing silently drops.
- Venue always shows stadium opening date and city founding date when known (editable the same way).

## Technical notes
- `vote-decode.ts`: hourAnimal, relation types, enemyHours, personalWeek, pmVsPy, birthDayVsDay, luckyHits, streak/11-spread/travel alerts; small weights inside existing steps; new vitest cases per rule.
- `espn.ts`/`espn-auto.ts`: game start time, streak, star player, goalie for NHL, coach/athlete DOB fallback via core athlete endpoint.
- New `src/lib/date-overrides.ts` (localStorage, SSR-safe) merged into `sports-data` lookups; new tab in `sports-prediction.tsx`.
