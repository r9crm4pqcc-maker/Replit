import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, p as useRouterState, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wouter-CfVlts7N.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Link$1 = import_react.forwardRef(function Link({ href, onClick, children, ...rest }, ref) {
	const navigate = useNavigate();
	const handleClick = (e) => {
		onClick?.(e);
		if (e.defaultPrevented) return;
		if (e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey && !rest.target) {
			e.preventDefault();
			navigate({ to: href });
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		ref,
		href,
		onClick: handleClick,
		...rest,
		children
	});
});
function useParams() {
	const parts = useRouterState({ select: (s) => s.location.pathname }).split("/").filter(Boolean);
	return { sub: parts.length >= 2 ? parts.slice(1).join("/") : void 0 };
}
//#endregion
export { useParams as n, Link$1 as t };
