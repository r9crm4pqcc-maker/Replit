import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as listDates, o as LIST_LABEL, r as useLife } from "./router-Da7lqNNo.mjs";
import { a as Tag, r as Page, t as Card } from "./kit-sB4xIagL.mjs";
import { n as useParams, t as Link$1 } from "./wouter-CfVlts7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dates-uPVY2408.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KINDS = Object.keys(LIST_LABEL);
function DatesPage() {
	const { sub } = useParams();
	const kind = KINDS.includes(sub) ? sub : null;
	const { profile } = useLife();
	const [year, setYear] = (0, import_react.useState)(2026);
	(0, import_react.useEffect)(() => {
		setYear((/* @__PURE__ */ new Date()).getFullYear());
	}, []);
	const rows = kind ? listDates(profile, kind, year) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		kicker: "Date library",
		title: kind ? LIST_LABEL[kind] : "Every marked date",
		lede: "Soulmate, fatal, challenging, love, and beneficial dates repeat every year from your birthday chart. Wealth, 28, and master days are listed for this year and the next.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
					href: "/dates",
					className: `rounded-full border px-3 py-1 text-xs ${!kind ? "border-primary text-primary" : "border-border text-muted-foreground"}`,
					children: "All lists"
				}), KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
					href: `/dates/${k}`,
					className: `rounded-full border px-3 py-1 text-xs ${kind === k ? "border-primary text-primary" : "border-border text-muted-foreground"}`,
					children: LIST_LABEL[k]
				}, k))]
			}),
			!kind && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 gap-3",
				children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$1, {
					href: `/dates/${k}`,
					className: "glass-card p-4 block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg",
						children: LIST_LABEL[k]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground mt-1",
						children: [listDates(profile, k, year).length, " dates"]
					})]
				}, k))
			}),
			kind && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border",
				children: [rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-3 flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: `/day/${r.iso}`,
						className: "text-foreground hover:text-primary",
						children: r.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-1",
						children: r.headline
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1",
						children: r.tones.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
							tone: t === "fatal" || t === "challenging" ? "bad" : "good",
							children: LIST_LABEL[t]
						}, t))
					})]
				}, r.iso + r.label)), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted-foreground py-4",
					children: "None in this window."
				})]
			}) })
		]
	});
}
//#endregion
export { DatesPage as t };
