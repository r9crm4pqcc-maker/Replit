import { i as __toESM } from "../_runtime.mjs";
import { a as calcDateEnergy, c as calcPersonalYear, f as dayNumber, h as reduce, i as calcCoreNumbers, o as calcPersonalDay, p as digitSum } from "./numerology-tNoiBxGA.mjs";
import { n as bestColorsFor, t as PROFILE } from "./colorology-kzI1lXuK.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ChevronRight, b as Dribbble } from "../_libs/lucide-react.mjs";
import { n as useParams, t as Link$1 } from "./wouter-CfVlts7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/soccer-ai-CrMOYICB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ENERGY_COLORS = {
	"1": {
		cleat: [
			"Gold",
			"Yellow",
			"Orange"
		],
		shin: ["Red", "Orange"],
		sock: ["Black", "Navy"]
	},
	"8": {
		cleat: [
			"Gold",
			"Yellow",
			"Royal Blue"
		],
		shin: ["Black", "Dark Blue"],
		sock: ["Black", "Dark Green"]
	},
	"10": {
		cleat: [
			"Gold",
			"Yellow",
			"Orange",
			"Royal Blue"
		],
		shin: ["Orange", "Gold"],
		sock: ["Black", "Dark Navy"]
	},
	"28": {
		cleat: [
			"Gold",
			"Yellow",
			"Royal Blue"
		],
		shin: ["Gold", "Orange"],
		sock: ["Black", "Dark Navy"]
	},
	"6": {
		cleat: ["Green", "Light Blue"],
		shin: ["Green", "Teal"],
		sock: ["White", "Light Blue"]
	},
	"42": {
		cleat: ["Green", "Light Blue"],
		shin: ["Green", "Teal"],
		sock: ["White", "Silver"]
	},
	"7": {
		cleat: ["Purple", "Indigo"],
		shin: ["Purple", "Violet"],
		sock: ["Dark Navy", "Black"]
	},
	"16": {
		cleat: ["Purple", "Indigo"],
		shin: ["Indigo", "Dark Blue"],
		sock: ["Black", "Dark Navy"]
	},
	"9": {
		cleat: ["Red", "Black"],
		shin: ["Red", "Crimson"],
		sock: ["Black", "Dark Red"]
	},
	"18": {
		cleat: ["Red", "Black"],
		shin: ["Red", "Black"],
		sock: ["Black", "Charcoal"]
	},
	"11": {
		cleat: ["White", "Silver"],
		shin: ["White", "Silver"],
		sock: ["White", "Light Grey"]
	},
	"22": {
		cleat: ["Iridescent", "Gold"],
		shin: ["White", "Gold"],
		sock: ["Silver", "White"]
	},
	"2": {
		cleat: ["Silver", "Cream"],
		shin: ["Silver", "Light Blue"],
		sock: ["White", "Silver"]
	},
	"3": {
		cleat: ["Yellow", "Gold"],
		shin: ["Yellow", "Orange"],
		sock: ["White", "Gold"]
	},
	"4": {
		cleat: ["Blue", "Grey"],
		shin: ["Navy", "Grey"],
		sock: ["Dark Blue", "Black"]
	},
	"5": {
		cleat: ["Turquoise", "Light Blue"],
		shin: ["Turquoise", "Cyan"],
		sock: ["White", "Light Blue"]
	}
};
function getColorConfig(energy, compound) {
	return ENERGY_COLORS[String(compound) in ENERGY_COLORS ? String(compound) : String(energy) in ENERGY_COLORS ? String(energy) : String(energy)] ?? ENERGY_COLORS["1"];
}
var ZODIAC_SIGNS = [
	"Rat",
	"Ox",
	"Tiger",
	"Rabbit",
	"Dragon",
	"Snake",
	"Horse",
	"Goat",
	"Monkey",
	"Rooster",
	"Dog",
	"Pig"
];
var ZODIAC_COMPATIBILITY = {
	Rat: [
		"Ox",
		"Dragon",
		"Monkey"
	],
	Ox: [
		"Rat",
		"Snake",
		"Rooster"
	],
	Tiger: [
		"Horse",
		"Dog",
		"Pig"
	],
	Rabbit: [
		"Goat",
		"Dog",
		"Pig"
	],
	Dragon: [
		"Rat",
		"Monkey",
		"Rooster"
	],
	Snake: [
		"Ox",
		"Rooster",
		"Monkey"
	],
	Horse: [
		"Tiger",
		"Goat",
		"Dog"
	],
	Goat: [
		"Rabbit",
		"Horse",
		"Pig"
	],
	Monkey: [
		"Rat",
		"Dragon",
		"Snake"
	],
	Rooster: [
		"Ox",
		"Dragon",
		"Snake"
	],
	Dog: [
		"Tiger",
		"Rabbit",
		"Horse"
	],
	Pig: [
		"Tiger",
		"Rabbit",
		"Goat"
	]
};
function getChineseYearCompatibility(birthYear, gameYear) {
	const birthSign = ZODIAC_SIGNS[(birthYear - 4) % 12];
	const yearSign = ZODIAC_SIGNS[(gameYear - 4) % 12];
	const isSame = birthSign === yearSign;
	const compatible = ZODIAC_COMPATIBILITY[birthSign]?.includes(yearSign) ?? false;
	return {
		birthSign,
		yearSign,
		score: isSame ? 95 : compatible ? 82 : 58,
		label: isSame ? "Same Zodiac" : compatible ? "Compatible Zodiac" : "Challenging Zodiac"
	};
}
var COMPAT = {
	1: {
		friendly: {
			11: 93,
			7: 90,
			28: 80,
			8: 80,
			2: 80,
			1: 80
		},
		neutral: [
			3,
			4,
			5,
			6,
			22,
			33
		],
		enemy: [9]
	},
	2: {
		friendly: {
			8: 85,
			28: 80,
			1: 80,
			3: 80
		},
		neutral: [
			4,
			5,
			6,
			7,
			11,
			22,
			33
		],
		enemy: [9]
	},
	3: {
		friendly: {
			5: 91,
			8: 88,
			6: 80,
			28: 80,
			11: 80,
			33: 80,
			3: 80,
			2: 80
		},
		neutral: [
			1,
			7,
			9,
			22
		],
		enemy: [4]
	},
	4: {
		friendly: {
			6: 96,
			9: 80,
			8: 80,
			7: 80,
			4: 80,
			2: 80
		},
		neutral: [
			1,
			11,
			22,
			28,
			33
		],
		enemy: [3, 5]
	},
	5: {
		friendly: {
			3: 91,
			33: 85,
			5: 85,
			7: 80,
			9: 80,
			8: 80
		},
		neutral: [
			1,
			2,
			11,
			28
		],
		enemy: [
			4,
			6,
			22
		]
	},
	6: {
		friendly: {
			4: 96,
			9: 80,
			8: 80,
			22: 80,
			3: 80
		},
		neutral: [
			1,
			11,
			28,
			33
		],
		enemy: [5, 7]
	},
	7: {
		friendly: {
			11: 99,
			28: 93,
			1: 90,
			5: 80,
			4: 80,
			22: 80
		},
		neutral: [
			2,
			7,
			33
		],
		enemy: [
			6,
			8,
			9
		]
	},
	8: {
		friendly: {
			1: 82,
			2: 82,
			3: 82,
			4: 82,
			5: 82,
			6: 82,
			8: 82,
			22: 82,
			28: 82,
			33: 82
		},
		neutral: [9, 11],
		enemy: [7]
	},
	9: {
		friendly: {
			4: 80,
			5: 80,
			6: 80
		},
		neutral: [3, 8],
		enemy: [
			1,
			2,
			7,
			11,
			22,
			28,
			33
		]
	},
	11: {
		friendly: {
			7: 99,
			1: 93,
			3: 80
		},
		neutral: [
			2,
			4,
			5,
			6,
			8,
			22,
			28,
			33
		],
		enemy: [9]
	},
	22: {
		friendly: {
			8: 85,
			6: 80,
			7: 80
		},
		neutral: [
			1,
			2,
			3,
			4,
			11,
			22,
			28,
			33
		],
		enemy: [5, 9]
	},
	28: {
		friendly: {
			1: 93,
			8: 86,
			7: 80,
			28: 80,
			2: 80,
			3: 80
		},
		neutral: [
			4,
			6,
			11,
			22,
			33,
			5
		],
		enemy: [9]
	},
	33: {
		friendly: {
			8: 90,
			5: 85,
			3: 80
		},
		neutral: [
			1,
			2,
			4,
			6,
			7,
			11,
			22,
			28,
			33
		],
		enemy: [9]
	}
};
function compatPct(a, b) {
	const lookup = (x, y) => {
		const row = COMPAT[x];
		if (!row) return null;
		if (row.friendly?.[y] != null) return row.friendly[y];
		if (row.neutral?.includes(y)) return 60;
		if (row.enemy?.includes(y)) return 25;
		return null;
	};
	const v1 = lookup(a, b);
	const v2 = lookup(b, a);
	if (v1 != null && v2 != null) return Math.round((v1 + v2) / 2);
	return v1 ?? v2 ?? 55;
}
function compatLabel(pct) {
	if (pct >= 75) return "FRIENDLY";
	if (pct >= 50) return "NEUTRAL";
	return "ENEMY";
}
var SEASON_SCHEDULE = [
	{
		date: "8/25/26",
		month: 8,
		day: 25,
		year: 2026,
		lp: 7,
		secondary: 7,
		compat: 59,
		opponent: "Prosser",
		venue: "Hanson Stadium",
		time: "4:30 PM",
		home: false
	},
	{
		date: "8/28/26",
		month: 8,
		day: 28,
		year: 2026,
		lp: 28,
		secondary: 28,
		compat: 79,
		opponent: "Steinmetz",
		venue: "Home",
		time: "4:30 PM",
		home: true
	},
	{
		date: "9/1/26",
		month: 9,
		day: 1,
		year: 2026,
		lp: 11,
		secondary: 1,
		compat: 79,
		opponent: "Clemente",
		venue: "Home",
		time: "4:30 PM",
		home: true
	},
	{
		date: "9/3/26",
		month: 9,
		day: 3,
		year: 2026,
		lp: 22,
		secondary: 3,
		compat: 69,
		opponent: "Farragut (NC)",
		venue: "Away",
		time: "4:30 PM",
		home: false
	},
	{
		date: "9/8/26",
		month: 9,
		day: 8,
		year: 2026,
		lp: 9,
		secondary: 8,
		compat: 41,
		opponent: "Foreman",
		venue: "Hanson Stadium",
		time: "4:30 PM",
		home: false
	},
	{
		date: "9/15/26",
		month: 9,
		day: 15,
		year: 2026,
		lp: 7,
		secondary: 6,
		compat: 66,
		opponent: "Kelvyn Park",
		venue: "Home",
		time: "4:30 PM",
		home: true
	},
	{
		date: "9/17/26",
		month: 9,
		day: 17,
		year: 2026,
		lp: 9,
		secondary: 8,
		compat: 41,
		opponent: "Phase 4 vs TBD",
		venue: "Home",
		time: "4:30 PM",
		home: true
	},
	{
		date: "9/22/26",
		month: 9,
		day: 22,
		year: 2026,
		lp: 5,
		secondary: 22,
		compat: 62,
		opponent: "Phase 5 @ TBD",
		venue: "Away",
		time: "4:30 PM",
		home: false
	},
	{
		date: "9/29/26",
		month: 9,
		day: 29,
		year: 2026,
		lp: 3,
		secondary: 11,
		compat: 47,
		opponent: "Phoenix Military",
		venue: "Away",
		time: "5:00 PM",
		home: false
	},
	{
		date: "10/9/26",
		month: 10,
		day: 9,
		year: 2026,
		lp: 11,
		secondary: 9,
		compat: 60,
		opponent: "Northside (NC)",
		venue: "Away",
		time: "4:30 PM",
		home: false
	}
];
function reduceToNine(n) {
	return n <= 9 ? n : n % 9 || 9;
}
function scoreNumber(n, de, pd, lifePath, birthdayNum) {
	const targets = [
		lifePath,
		birthdayNum,
		de,
		pd,
		10,
		28,
		8,
		1,
		9
	];
	let score = 0;
	if (n === 10) score += 100;
	if (n === 28) score += 96;
	if (n === lifePath) score += 90;
	if (n === birthdayNum) score += 88;
	if (n === de) score += 84;
	if (n === pd) score += 82;
	if (n === reduce(digitSum(lifePath + birthdayNum + pd))) score += 14;
	if (n === reduce(digitSum(pd + de))) score += 10;
	if (n === 8 && lifePath === 1) score += 12;
	if (n === 1 && pd === 1) score += 10;
	if (n === 9 && pd === 9) score += 12;
	score += Math.max(0, 60 - targets.indexOf(n) * 5);
	return score;
}
function calcGameDay(gameMonth, gameDay, gameYear, lifePath, birthdayNum) {
	const de = calcDateEnergy(gameMonth, gameDay, gameYear);
	const personalYear = calcPersonalYear(PROFILE.birthMonth, PROFILE.birthDay, gameMonth, gameDay, gameYear).reduced;
	const zodiac = getChineseYearCompatibility(PROFILE.birthYear, gameYear);
	const pd = calcPersonalDay(PROFILE.birthMonth, PROFILE.birthDay, gameMonth, gameDay, gameYear);
	const dayNum = dayNumber(gameDay);
	const lpVsUniv = compatPct(lifePath, de.reduced);
	const bdayVsPd = compatPct(birthdayNum, pd.reduced);
	const lpVsPd = compatPct(lifePath, pd.reduced);
	const lpVsDay = compatPct(lifePath, dayNum);
	const compat = Math.round(lpVsUniv * .25 + bdayVsPd * .25 + lpVsPd * .2 + lpVsDay * .3);
	const tier = compatLabel(compat);
	const compatLabelStr = tier === "FRIENDLY" ? "Strong Flow" : tier === "NEUTRAL" ? "Neutral" : "Tension";
	const compatDesc = `${compat}% — LP ${lifePath} ↔ Universal ${de.reduced} (${lpVsUniv}%), Birthday ${birthdayNum} ↔ Personal Day ${pd.reduced} (${bdayVsPd}%), LP ${lifePath} ↔ Day ${gameDay}/${dayNum} (${lpVsDay}%)`;
	const rankedNumbers = [
		10,
		28,
		lifePath,
		birthdayNum,
		de.reduced,
		pd.reduced,
		personalYear,
		8,
		1,
		9,
		11,
		22
	].filter((n, i, a) => a.indexOf(n) === i).map((n) => ({
		number: n,
		score: scoreNumber(n, de.reduced, pd.reduced, lifePath, birthdayNum) + (n === personalYear ? 86 : 0) + (n === zodiac.score ? 0 : 0),
		label: n === 10 ? "Primary" : n === 28 ? "Compound" : n === lifePath ? "Life Path" : n === birthdayNum ? "Birthday" : n === de.reduced ? "Universal" : n === pd.reduced ? "Personal Day" : n === personalYear ? "Personal Year" : n === 8 ? "Power" : n === 1 ? "Leader" : n === 9 ? "Completion" : n === 11 ? "Master 11" : "Master 22",
		reason: n === 10 ? "Strongest current jersey portal" : n === 28 ? "Life Path compound portal" : n === lifePath ? "Core identity number" : n === birthdayNum ? "Birthday gift" : n === de.reduced ? "Today's universal energy" : n === pd.reduced ? "Today's personal energy" : n === personalYear ? "Your current year cycle" : n === 8 ? "Authority and power" : n === 1 ? "Initiation and leadership" : n === 9 ? "Completion and harvest" : n === 11 ? "Intuition portal" : "Builder portal"
	})).sort((a, b) => b.score - a.score);
	const top3Numbers = rankedNumbers.slice(0, 3).map((r) => r.number);
	const baseColors = getColorConfig(de.reduced, de.compound);
	const top3ColorSets = top3Numbers.map((n) => {
		return getColorConfig(n > 9 && !(n === 10 || n === 11 || n === 22 || n === 28) ? reduceToNine(n) : n, n);
	});
	function pickBestColor(slot, base) {
		const allCandidates = /* @__PURE__ */ new Map();
		base.forEach((c, i) => allCandidates.set(c, (allCandidates.get(c) ?? 0) + (i === 0 ? 10 : 5)));
		top3ColorSets.forEach((cs, rank) => {
			const weight = rank === 0 ? 8 : rank === 1 ? 5 : 3;
			cs[slot].forEach((c, i) => allCandidates.set(c, (allCandidates.get(c) ?? 0) + (i === 0 ? weight : Math.ceil(weight / 2))));
		});
		const result = [...allCandidates.entries()].sort((a, b) => b[1] - a[1]).map((s) => s[0]);
		return result.length >= 2 ? result.slice(0, 2) : [...result, ...base.slice(0, 2 - result.length)];
	}
	const colors = {
		cleat: pickBestColor("cleat", baseColors.cleat),
		shin: pickBestColor("shin", baseColors.shin),
		sock: pickBestColor("sock", baseColors.sock)
	};
	const bestNums = [.../* @__PURE__ */ new Set([
		lifePath,
		birthdayNum,
		de.reduced,
		pd.reduced,
		personalYear,
		de.compound
	])].slice(0, 5);
	const bestReasons = [
		`${lifePath} — your Life Path power number`,
		`${birthdayNum} — your Birthday Number gift`,
		`${de.reduced} — today's universal energy`,
		`${personalYear} — your Personal Year cycle`,
		`${de.compound} — compound activation`,
		`${zodiac.birthSign} ↔ ${zodiac.yearSign} — ${zodiac.label}`
	];
	const jersey = lifePath === 1 ? 10 : lifePath === 8 ? 8 : lifePath === 3 ? 3 : lifePath * 10 <= 99 ? lifePath * 10 : lifePath;
	const jerseyReason = `#${jersey} carries your Life Path ${lifePath} compound energy — activates your wealth/power portal`;
	const fusion = reduceToNine(de.reduced + pd.reduced + lifePath + birthdayNum);
	const sockType = fusion <= 4 || lifePath === 1 || birthdayNum === 8 ? "grip" : "regular";
	const sockHeight = fusion <= 3 ? "low" : fusion <= 6 ? "mid" : fusion <= 8 ? "high" : "otk";
	const jerseyTuck = [
		1,
		4,
		8,
		10,
		22
	].includes(jersey) || de.reduced >= 8 ? "tucked" : "untucked";
	const gearFormula = `Fusion ${fusion} = reduce(${de.reduced}+${pd.reduced}+${lifePath}+${birthdayNum}) → ${sockType}, ${sockHeight}, ${jerseyTuck}`;
	return {
		gameDate: `${String(gameMonth).padStart(2, "0")}/${String(gameDay).padStart(2, "0")}/${gameYear}`,
		universalEnergy: de.reduced,
		universalCompound: de.compound,
		universalLabel: de.label,
		personalDay: pd.reduced,
		personalDayCompound: pd.compound,
		compatibility: compat,
		compatLabel: compatLabelStr,
		compatDesc,
		cleatColors: colors.cleat,
		shinColors: colors.shin,
		sockColors: colors.sock,
		bestNumbers: bestNums,
		bestNumberReasons: bestReasons,
		jerseyRecommendation: jersey,
		jerseyReason,
		sockType,
		sockHeight,
		jerseyTuck,
		gearFormula,
		rankedNumbers,
		colorHarmonizedWith: top3Numbers
	};
}
function getWeeklyPlan(personalYear, lifePath) {
	const energy = personalYear;
	return {
		focus: energy <= 3 ? "Speed & Creativity" : energy <= 6 ? "Tactical & Teamwork" : "Power & Finishing",
		mon: {
			type: "Technical",
			desc: "Ball mastery — 500 touches, first touch control, weak foot work"
		},
		tue: {
			type: "Speed & Agility",
			desc: "Shuttle runs, ladder drills, explosive start bursts"
		},
		wed: {
			type: "Tactical",
			desc: "Video review + position-specific movement patterns (winger runs)"
		},
		thu: {
			type: "Strength",
			desc: "Gym — legs (squats, lunges), core stability, rotational power"
		},
		fri: {
			type: "Match Prep",
			desc: "Light training, mental visualization, gear selection ritual"
		},
		sat: {
			type: "MATCH DAY",
			desc: "Check game day energy, cleat colors, jersey number before kickoff"
		},
		sun: {
			type: "Recovery",
			desc: "Active recovery — walk, stretch, foam roll. Reflect on your numbers"
		}
	};
}
var DIET_PLAN = {
	preMatch: [
		"3–4 hrs before: Complex carbs — pasta, rice, sweet potato",
		"1–2 hrs before: Banana + peanut butter (fast energy)",
		"30 min before: Small handful of dates (natural sugar spike)"
	],
	hydration: [
		"Morning: 16–20 oz water immediately on waking",
		"Training: 8 oz every 20 min",
		"Post-match: Electrolyte drink + 24 oz water within 30 min"
	],
	recovery: [
		"Within 30 min post-match: Protein shake + fruit",
		"Dinner: Lean protein (chicken, fish), rice, vegetables",
		"Before bed: Casein protein or cottage cheese"
	],
	luckyFoods: [
		"Dates (energy portal food — 28/10 vibration)",
		"Bananas (3 energy — creative power)",
		"Almonds (grounding — 4 vibration)"
	]
};
var BRAND_FOUNDINGS = {
	nike: {
		name: "Nike",
		founded: {
			year: 1964,
			month: 1,
			day: 25
		}
	},
	adidas: {
		name: "Adidas",
		founded: {
			year: 1949,
			month: 8,
			day: 18
		}
	},
	jordan: {
		name: "Air Jordan",
		founded: {
			year: 1985,
			month: 4,
			day: 1
		}
	},
	"jordan brand": {
		name: "Air Jordan",
		founded: {
			year: 1985,
			month: 4,
			day: 1
		}
	},
	"air jordan": {
		name: "Air Jordan",
		founded: {
			year: 1985,
			month: 4,
			day: 1
		}
	},
	puma: {
		name: "Puma",
		founded: {
			year: 1948,
			month: 10,
			day: 1
		}
	},
	"new balance": {
		name: "New Balance",
		founded: {
			year: 1906,
			month: 4,
			day: 5
		}
	},
	"under armour": {
		name: "Under Armour",
		founded: {
			year: 1996,
			month: 9,
			day: 25
		}
	},
	reebok: {
		name: "Reebok",
		founded: {
			year: 1958,
			month: 8,
			day: 19
		}
	},
	mizuno: {
		name: "Mizuno",
		founded: {
			year: 1906,
			month: 4,
			day: 1
		}
	},
	asics: {
		name: "ASICS",
		founded: {
			year: 1977,
			month: 7,
			day: 21
		}
	},
	umbro: {
		name: "Umbro",
		founded: {
			year: 1924,
			month: 5,
			day: 23
		}
	},
	diadora: {
		name: "Diadora",
		founded: {
			year: 1948,
			month: 9,
			day: 1
		}
	},
	supreme: {
		name: "Supreme",
		founded: {
			year: 1994,
			month: 4,
			day: 20
		}
	},
	bape: {
		name: "A Bathing Ape",
		founded: {
			year: 1993,
			month: 4,
			day: 1
		}
	},
	"a bathing ape": {
		name: "A Bathing Ape",
		founded: {
			year: 1993,
			month: 4,
			day: 1
		}
	},
	"bathing ape": {
		name: "A Bathing Ape",
		founded: {
			year: 1993,
			month: 4,
			day: 1
		}
	}
};
function brandDecode(brandName) {
	const brand = BRAND_FOUNDINGS[brandName.trim().toLowerCase()];
	if (!brand) return null;
	const { year, month, day } = brand.founded;
	return {
		name: brand.name,
		foundedLabel: `${month}/${day}/${year}`,
		year,
		month,
		day
	};
}
var N = calcCoreNumbers(PROFILE.firstName, PROFILE.middleName, PROFILE.lastName, PROFILE.birthMonth, PROFILE.birthDay, PROFILE.birthYear);
var BLUE = "hsl(212 95% 65%)";
var YELLOW = "hsl(48 96% 53%)";
var GREEN = "#4ade80";
var ROSE = "#f472b6";
var PURPLE = "hsl(270 60% 70%)";
var GOATA_EXERCISES = [
	"Goata Walk",
	"Bear Crawl",
	"Child Rockers",
	"Pigeon Rock",
	"Goata Squat",
	"Goata Lunge"
];
var FASCIA_LEVELS = {
	1: {
		weeks: "Weeks 1–3",
		duration: "40 min",
		criteria: "Advance once glute engagement improves and calf/ankle reliance decreases.",
		exercises: [
			"Fascia Adhesion Rolling – 20 min (2 min/spot: feet, calves, TFL, hip flexor, quads)",
			"Towel Curls – 3 min per foot",
			"Retract + Curl – 3 min per foot",
			"Marble Swing – 3 min per leg",
			"Gait Cycle – 3 min per foot"
		]
	},
	2: {
		weeks: "Weeks 4–6",
		duration: "50 min",
		criteria: "Move to Level 3 when consistent glute activation is present.",
		exercises: [
			"Fascia Adhesion Rolling – 20 min (2 min/spot: feet, calves, TFL, hip flexor, quads)",
			"Towel Curls – 3 min",
			"Retract + Curl – 3 min",
			"Marble Swing – 3 min per leg",
			"Gait Cycle – 3 min per leg",
			"Hyperarch Hop – 3 min",
			"Hand Curl – 2 min, 1 set",
			"Push Hands – 3 min",
			"Wall Bounce – 3 min"
		]
	},
	3: {
		weeks: "Weeks 7–9",
		duration: "1 hr 10 min",
		criteria: "Advance once glutes feel strong.",
		exercises: [
			"Towel Curls – 3 min",
			"Retract + Curl – 3 min",
			"Marble Swing – 3 min per leg",
			"Gait Cycle – 3 min per leg",
			"Hyperarch Hop – 3 min",
			"Hand Curl – 2 min, 1 set",
			"Push Hands – 3 min",
			"Wall Bounce – 3 min",
			"Triangle – 2–3 min per side",
			"Figure 8 – 2–3 min per side",
			"Single Leg Hop – 1–2 min per side",
			"Hyperarch Wall Sit w/ Med Ball – 1 min → build to 1–4 min",
			"Standing Leg Stretch w/ Marble Grip – 2 min, 2 rounds per side",
			"Crescent Walk Forward/Backward – 6–8 steps, 2–3 min",
			"Big Toe Press on Marble – 3 min per foot",
			"Dorsiflexed Toes Walking – 5–10m forward, 2 rounds",
			"Marble Grab + Heel Raise w/ Med Ball – 3 min, 2 rounds"
		]
	},
	4: {
		weeks: "Weeks 10–12",
		duration: "1 hr 25 min",
		criteria: "Full fascial system connection, integrated strength + mobility.",
		exercises: [
			"Towel Curls – 3 min",
			"Retract + Curl – 3 min",
			"Marble Swing – 3 min per leg",
			"Gait Cycle – 3 min per leg",
			"Hyperarch Hop – 3 min",
			"Hand Curl – 2 min, 1 set",
			"Push Hands – 3 min",
			"Wall Bounce – 3 min",
			"Triangle – 3 min per side",
			"Figure 8 – 3 min per side",
			"Single Leg Hop – 1–2 min per side",
			"Hyperarch Wall Sit w/ Med Ball – 1 min → build to 1–4 min",
			"Standing Leg Stretch w/ Marble Grip – 2 min, 2 rounds per side",
			"Crescent Walk Forward/Backward – 6–8 steps, 3 min",
			"Big Toe Press on Marble – 3 min per foot",
			"Dorsiflexed Toes Walking – 5–10m, 2–3 rounds",
			"Marble Grab + Heel Raise w/ Med Ball – 2–3 min, 2–3 rounds",
			"HFT Lunge – Bodyweight → 10 lbs, 2–5 min",
			"HFT Bear Walk – 20–30 steps, 2 sets",
			"HFT Towel Sweep – 3 min per side"
		]
	}
};
function getISOWeek(d) {
	const tmp = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
	tmp.setUTCDate(tmp.getUTCDate() + 4 - (tmp.getUTCDay() || 7));
	const yearStart = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 1));
	const week = Math.ceil(((+tmp - +yearStart) / 864e5 + 1) / 7);
	return `${tmp.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}
function todayISO() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
var LS = typeof window === "undefined" ? null : window.localStorage;
var ATHS_LEVEL_KEY = "ath_level";
var ATHS_CHECKS_KEY = "ath_checks";
var ATHS_SESSIONS_KEY = "ath_sessions";
function useAthleticism() {
	const [level, setLevelState] = (0, import_react.useState)(() => {
		return parseInt(LS?.getItem(ATHS_LEVEL_KEY) ?? "1") || 1;
	});
	const setLevel = (0, import_react.useCallback)((l) => {
		setLevelState(l);
		LS?.setItem(ATHS_LEVEL_KEY, String(l));
	}, []);
	const [checks, setChecks] = (0, import_react.useState)(() => {
		try {
			const raw = JSON.parse(LS?.getItem(ATHS_CHECKS_KEY) ?? "{}");
			return raw._date === todayISO() ? raw : { _date: todayISO() };
		} catch {
			return { _date: todayISO() };
		}
	});
	const toggleCheck = (0, import_react.useCallback)((key) => {
		setChecks((prev) => {
			const today = todayISO();
			const base = prev._date === today ? { ...prev } : { _date: today };
			const next = {
				...base,
				[key]: !base[key]
			};
			LS?.setItem(ATHS_CHECKS_KEY, JSON.stringify(next));
			return next;
		});
	}, []);
	const [sessions, setSessions] = (0, import_react.useState)(() => {
		try {
			const raw = JSON.parse(LS?.getItem(ATHS_SESSIONS_KEY) ?? "{}");
			const thisWeek = getISOWeek(/* @__PURE__ */ new Date());
			if (raw.week === thisWeek) return raw;
			return {
				week: thisWeek,
				days: []
			};
		} catch {
			return {
				week: getISOWeek(/* @__PURE__ */ new Date()),
				days: []
			};
		}
	});
	const logSession = (0, import_react.useCallback)(() => {
		setSessions((prev) => {
			const thisWeek = getISOWeek(/* @__PURE__ */ new Date());
			const today = todayISO();
			const base = prev.week === thisWeek ? { ...prev } : {
				week: thisWeek,
				days: []
			};
			if (!base.days.includes(today)) base.days = [...base.days, today];
			LS?.setItem(ATHS_SESSIONS_KEY, JSON.stringify(base));
			return base;
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => {
			const today = todayISO();
			setChecks((prev) => {
				if (prev._date !== today) {
					const fresh = { _date: today };
					LS?.setItem(ATHS_CHECKS_KEY, JSON.stringify(fresh));
					return fresh;
				}
				return prev;
			});
			setSessions((prev) => {
				const thisWeek = getISOWeek(/* @__PURE__ */ new Date());
				if (prev.week !== thisWeek) {
					const fresh = {
						week: thisWeek,
						days: []
					};
					LS?.setItem(ATHS_SESSIONS_KEY, JSON.stringify(fresh));
					return fresh;
				}
				return prev;
			});
		}, 2e4);
		return () => clearInterval(id);
	}, []);
	const fasciaExercises = FASCIA_LEVELS[level].exercises;
	const totalFascia = fasciaExercises.length;
	const totalGoata = GOATA_EXERCISES.length;
	const doneFascia = fasciaExercises.filter((_, i) => checks[`f${i}`] === true).length;
	const doneGoata = GOATA_EXERCISES.filter((_, i) => checks[`g${i}`] === true).length;
	const sessionLoggedToday = sessions.days.includes(todayISO());
	const weekSessions = sessions.days.length;
	const dayOfWeek = (/* @__PURE__ */ new Date()).getDay();
	const daysLeftInWeek = 7 - dayOfWeek;
	return {
		level,
		setLevel,
		checks,
		toggleCheck,
		logSession,
		sessionLoggedToday,
		weekSessions,
		fasciaExercises,
		totalFascia,
		totalGoata,
		doneFascia,
		doneGoata,
		needsWarning: weekSessions < 3 && daysLeftInWeek <= 2 && !sessionLoggedToday,
		isBehind: weekSessions < 2 && dayOfWeek >= 5
	};
}
var tabs = [
	{
		key: "",
		label: "Game Day",
		href: "/soccer-ai"
	},
	{
		key: "schedule",
		label: "Schedule",
		href: "/soccer-ai/schedule"
	},
	{
		key: "training",
		label: "Training",
		href: "/soccer-ai/training"
	},
	{
		key: "diet",
		label: "Diet",
		href: "/soccer-ai/diet"
	},
	{
		key: "mental",
		label: "Mental",
		href: "/soccer-ai/mental"
	},
	{
		key: "athleticism",
		label: "Athleticism",
		href: "/soccer-ai/athleticism"
	},
	{
		key: "routine",
		label: "Daily Routine",
		href: "/day-life/routine"
	}
];
var COMPAT_COLOR = (n) => n >= 85 ? GREEN : n >= 65 ? BLUE : n >= 40 ? YELLOW : ROSE;
var BEST_GEMS = {
	1: ["Ruby", "Citrine"],
	2: ["Moonstone", "Pearl"],
	3: ["Amethyst", "Yellow Sapphire"],
	4: ["Emerald", "Sapphire"],
	5: ["Aquamarine", "Turquoise"],
	6: ["Rose Quartz", "Jade"],
	7: ["Amethyst", "Labradorite"],
	8: ["Black Onyx", "Blue Sapphire"],
	9: ["Garnet", "Bloodstone"],
	10: ["Ruby", "Citrine"],
	11: ["Selenite", "Clear Quartz"],
	22: ["Moldavite", "Diamond"],
	33: ["Rose Quartz", "Diamond"]
};
var COLOR_ENERGY_FULL = {
	"red": 1,
	"orange": 2,
	"yellow": 3,
	"gold": 3,
	"lime": 4,
	"green": 4,
	"blue": 5,
	"cyan": 5,
	"navy": 6,
	"indigo": 6,
	"purple": 7,
	"violet": 7,
	"black": 8,
	"grey": 8,
	"gray": 8,
	"white": 9,
	"silver": 9,
	"pink": 2,
	"maroon": 1,
	"brown": 4,
	"teal": 5,
	"magenta": 6,
	"burgundy": 1,
	"forest green": 4,
	"charcoal": 8,
	"copper": 2,
	"neon green": 4,
	"hot pink": 2,
	"crimson": 1,
	"sky blue": 5,
	"emerald": 4,
	"amber": 3,
	"rose": 1,
	"coral": 2,
	"turquoise": 5,
	"royal blue": 5,
	"light blue": 5,
	"light grey": 8,
	"dark blue": 6,
	"dark navy": 6,
	"dark green": 4,
	"dark red": 1,
	"iridescent": 9,
	"cream": 9
};
function colorEnergy(c) {
	const full = c.toLowerCase();
	if (full in COLOR_ENERGY_FULL) return COLOR_ENERGY_FULL[full];
	return COLOR_ENERGY_FULL[full.split(" ")[0]] ?? 5;
}
function colorHex(c) {
	return {
		"Black": "#111",
		"White": "#f8fafc",
		"Navy": "#172554",
		"Blue": "#3b82f6",
		"Sky Blue": "#38bdf8",
		"Royal Blue": "#1d4ed8",
		"Teal": "#14b8a6",
		"Cyan": "#22d3ee",
		"Green": "#22c55e",
		"Lime": "#a3e635",
		"Emerald": "#10b981",
		"Yellow": "#eab308",
		"Gold": "#d97706",
		"Amber": "#f59e0b",
		"Orange": "#f97316",
		"Coral": "#fb7185",
		"Red": "#ef4444",
		"Crimson": "#dc2626",
		"Maroon": "#7f1d1d",
		"Rose": "#f43f5e",
		"Pink": "#f472b6",
		"Magenta": "#d946ef",
		"Purple": "#a855f7",
		"Indigo": "#6366f1",
		"Violet": "#8b5cf6",
		"Silver": "#94a3b8",
		"Grey": "#6b7280",
		"Brown": "#78350f",
		"Turquoise": "#2dd4bf",
		"White & Blue": "#dbeafe",
		"Burgundy": "#7d1128",
		"Forest Green": "#166534",
		"Charcoal": "#374151",
		"Copper": "#b45309",
		"Neon Green": "#84cc16",
		"Hot Pink": "#ec4899"
	}[c] ?? "#60a5fa";
}
function getBestGearComplement(kitPrimary, kitSecondary, todayCleat, todayShin, todaySock) {
	const kitPE = colorEnergy(kitPrimary);
	const kitSE = colorEnergy(kitSecondary);
	const avgKitE = Math.round((kitPE + kitSE) / 2);
	const kitEnergy = avgKitE === 0 ? kitPE : avgKitE;
	const scored = [
		{
			color: todayCleat,
			source: "Cleat Color"
		},
		{
			color: todayShin,
			source: "Shin Guard"
		},
		{
			color: todaySock,
			source: "Grip Socks"
		}
	].map((c) => {
		const e = colorEnergy(c.color);
		const harmonic = kitEnergy + e > 9 ? kitEnergy + e - 9 : kitEnergy + e;
		const diff = Math.abs(kitEnergy - e);
		let score = 0;
		if (harmonic === 1 || harmonic === 8 || harmonic === 9) score += 30;
		if (diff >= 3 && diff <= 6) score += 20;
		if (e !== kitPE && e !== kitSE) score += 15;
		if ([
			1,
			3,
			8,
			9
		].includes(harmonic)) score += 10;
		score += e;
		return {
			...c,
			score,
			energy: e,
			harmonic
		};
	}).sort((a, b) => b.score - a.score);
	const best = scored[0];
	const gearEnergy = colorEnergy(best.color);
	const harmonic = kitEnergy + gearEnergy > 9 ? kitEnergy + gearEnergy - 9 : kitEnergy + gearEnergy;
	const reason = `Your ${kitPrimary} (${kitPE}) + ${kitSecondary} (${kitSE}) kit = energy ${kitEnergy}. Today's best gear color is ${best.color} (${best.source}, energy ${gearEnergy}) — forming a ${harmonic} harmonic with your kit.`;
	return {
		bestColor: best.color,
		bestSource: best.source,
		kitEnergy,
		gearEnergy,
		reason,
		allOptions: scored.map((s) => ({
			color: s.color,
			source: s.source,
			score: s.score
		}))
	};
}
var COLOR_OPTIONS = [
	"Black",
	"White",
	"Navy",
	"Blue",
	"Sky Blue",
	"Royal Blue",
	"Teal",
	"Cyan",
	"Green",
	"Lime",
	"Emerald",
	"Yellow",
	"Gold",
	"Amber",
	"Orange",
	"Coral",
	"Red",
	"Crimson",
	"Maroon",
	"Rose",
	"Pink",
	"Magenta",
	"Purple",
	"Indigo",
	"Violet",
	"Silver",
	"Grey",
	"Brown",
	"Turquoise",
	"Burgundy",
	"Forest Green",
	"Charcoal",
	"Copper",
	"Neon Green",
	"Hot Pink"
];
var KIT_BRANDS = [
	"Nike",
	"Adidas",
	"Puma",
	"Under Armour",
	"New Balance",
	"Jordan",
	"Umbro",
	"Kappa",
	"Joma",
	"Mizuno",
	"Lotto",
	"Diadora",
	"Macron",
	"Hummel",
	"Jako",
	"Errea",
	"Custom / Other"
];
function SoccerAIPage() {
	const sub = useParams().sub ?? "";
	const today = /* @__PURE__ */ new Date();
	const [gMonth, setGMonth] = (0, import_react.useState)(today.getMonth() + 1);
	const [gDay, setGDay] = (0, import_react.useState)(today.getDate());
	const [gYear, setGYear] = (0, import_react.useState)(today.getFullYear());
	const [homeColor1, setHomeColor1] = (0, import_react.useState)("Blue");
	const [homeColor2, setHomeColor2] = (0, import_react.useState)("White");
	const [awayColor1, setAwayColor1] = (0, import_react.useState)("White");
	const [awayColor2, setAwayColor2] = (0, import_react.useState)("Navy");
	const [kitBrand, setKitBrand] = (0, import_react.useState)("Nike");
	const [kitSide, setKitSide] = (0, import_react.useState)("home");
	const ath = useAthleticism();
	const gd = (0, import_react.useMemo)(() => calcGameDay(gMonth, gDay, gYear, N.lifePath, N.birthday), [
		gMonth,
		gDay,
		gYear
	]);
	const weekPlan = (0, import_react.useMemo)(() => getWeeklyPlan(N.personalYear, N.lifePath), []);
	const compatColor = COMPAT_COLOR(gd.compatibility);
	const activeKitPrimary = kitSide === "home" ? homeColor1 : awayColor1;
	const activeKitSecondary = kitSide === "home" ? homeColor2 : awayColor2;
	const gearAdvice = (0, import_react.useMemo)(() => getBestGearComplement(activeKitPrimary, activeKitSecondary, gd.cleatColors[0], gd.shinColors[0], gd.sockColors[0]), [
		activeKitPrimary,
		activeKitSecondary,
		gd.cleatColors,
		gd.shinColors,
		gd.sockColors
	]);
	const bestGems = BEST_GEMS[gd.personalDay] ?? BEST_GEMS[N.lifePath] ?? ["Clear Quartz"];
	const brandEnergy = (0, import_react.useMemo)(() => {
		return {
			nike: 1,
			adidas: 5,
			puma: 4,
			"under armour": 7,
			"new balance": 8,
			jordan: 4,
			umbro: 3,
			kappa: 2,
			joma: 6,
			mizuno: 5,
			lotto: 3,
			diadora: 4,
			macron: 3,
			hummel: 7,
			jako: 6,
			errea: 5
		}[kitBrand.toLowerCase()] ?? 5;
	}, [kitBrand]);
	function KitColorPicker({ value, onChange, label }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[8.5px] uppercase tracking-widest mb-1.5",
			style: { color: "rgba(255,255,255,0.3)" },
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-5 h-5 rounded-full absolute left-2 top-1/2 -translate-y-1/2 shrink-0",
				style: {
					background: colorHex(value),
					border: "1px solid rgba(255,255,255,0.15)"
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				value,
				onChange: (e) => onChange(e.target.value),
				className: "w-full rounded-xl pl-9 pr-3 py-2 text-xs font-semibold text-white appearance-none cursor-pointer",
				style: {
					background: "rgba(255,255,255,0.06)",
					border: "1px solid rgba(255,255,255,0.12)",
					outline: "none"
				},
				children: COLOR_OPTIONS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: c,
					children: c
				}, c))
			})]
		})] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-4xl space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 text-xs mb-3",
					style: { color: "rgba(255,255,255,0.3)" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dribbble, {
							size: 12,
							style: { color: GREEN }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Soccer AI" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 10 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: { color: GREEN },
							children: "Cristian Zavala · Winger · North Grand"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "page-title",
					children: "Soccer AI"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "page-subtitle",
					children: "Personalized match intelligence · #10 Jersey Recommended"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5 flex-wrap",
				children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
					href: t.href,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
						style: sub === t.key ? {
							background: "rgba(74,222,128,0.12)",
							color: GREEN,
							border: "1px solid rgba(74,222,128,0.25)"
						} : {
							color: "rgba(255,255,255,0.4)",
							border: "1px solid transparent"
						},
						children: t.label
					})
				}, t.key))
			}),
			sub === "" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4 flex flex-wrap items-center gap-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2",
							children: [
								{
									label: "Month",
									v: gMonth,
									set: setGMonth,
									min: 1,
									max: 12,
									w: "w-14"
								},
								{
									label: "Day",
									v: gDay,
									set: setGDay,
									min: 1,
									max: 31,
									w: "w-14"
								},
								{
									label: "Year",
									v: gYear,
									set: setGYear,
									min: 2024,
									max: 2030,
									w: "w-20"
								}
							].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] uppercase tracking-widest mb-1",
								style: { color: "rgba(255,255,255,0.3)" },
								children: f.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: f.min,
								max: f.max,
								value: f.v,
								onChange: (e) => f.set(+e.target.value),
								className: `${f.w} text-center rounded-lg px-2 py-1 text-sm font-bold`,
								style: {
									background: "rgba(74,222,128,0.08)",
									border: "1px solid rgba(74,222,128,0.2)",
									color: GREEN,
									outline: "none"
								}
							})] }, f.label))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-white",
							children: "Game Date Analysis"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px]",
							style: { color: "rgba(255,255,255,0.4)" },
							children: [PROFILE.teamName, " · North Grand Eagles"]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "glass-card p-5",
						style: { background: "hsl(228 28% 7%)" },
						suppressHydrationWarning: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center shrink-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] uppercase tracking-widest mb-1",
											style: { color: "rgba(255,255,255,0.3)" },
											children: "Compatibility"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-5xl font-black",
											style: { color: compatColor },
											suppressHydrationWarning: true,
											children: [gd.compatibility, "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold mt-1",
											style: { color: compatColor },
											children: gd.compatLabel
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-px self-stretch",
									style: { background: "rgba(255,255,255,0.06)" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-white mb-1",
										children: gd.compatDesc
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3 mt-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] uppercase tracking-widest mb-0.5",
												style: { color: "rgba(255,255,255,0.3)" },
												children: "Universal Day Energy"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-2xl font-black",
												style: { color: GREEN },
												children: gd.universalEnergy
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px]",
												style: { color: "rgba(255,255,255,0.35)" },
												children: ["Compound: ", gd.universalCompound]
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] uppercase tracking-widest mb-0.5",
												style: { color: "rgba(255,255,255,0.3)" },
												children: "Your Personal Day"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-2xl font-black",
												style: { color: YELLOW },
												children: gd.personalDay
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px]",
												style: { color: "rgba(255,255,255,0.35)" },
												children: ["Compound: ", gd.personalDayCompound]
											})
										] })]
									})]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest",
								style: { color: YELLOW },
								children: "Colors For Today"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[8px] uppercase tracking-widest",
									style: { color: "rgba(255,255,255,0.25)" },
									children: "Harmonized with"
								}), gd.colorHarmonizedWith.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] font-black px-1.5 py-0.5 rounded",
									style: {
										background: "rgba(250,204,21,0.1)",
										color: YELLOW,
										border: "1px solid rgba(250,204,21,0.15)"
									},
									children: ["#", n]
								}, n))]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-3",
							children: [
								{
									label: "Cleat Color",
									colors: gd.cleatColors,
									emoji: "👟"
								},
								{
									label: "Shin Guard",
									colors: gd.shinColors,
									emoji: "🛡️"
								},
								{
									label: "Grip Socks",
									colors: gd.sockColors,
									emoji: "🧦"
								}
							].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 text-center rounded-xl",
								style: { background: "rgba(255,255,255,0.03)" },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xl mb-2",
										children: g.emoji
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[9px] uppercase tracking-widest mb-2",
										style: { color: "rgba(255,255,255,0.3)" },
										children: g.label
									}),
									g.colors.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold",
										style: { color: i === 0 ? YELLOW : BLUE },
										children: [
											i === 0 ? "PRIMARY" : "ACCENT",
											": ",
											c
										]
									}, c))
								]
							}, g.label))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-5",
						style: {
							background: "hsl(228 28% 7%)",
							border: "1px solid rgba(96,165,250,0.12)"
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-4",
								style: { color: BLUE },
								children: "Kit Customizer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitColorPicker, {
										label: "Home Primary",
										value: homeColor1,
										onChange: setHomeColor1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitColorPicker, {
										label: "Home Secondary",
										value: homeColor2,
										onChange: setHomeColor2
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitColorPicker, {
										label: "Away Primary",
										value: awayColor1,
										onChange: setAwayColor1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitColorPicker, {
										label: "Away Secondary",
										value: awayColor2,
										onChange: setAwayColor2
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[8.5px] uppercase tracking-widest mb-1.5",
									style: { color: "rgba(255,255,255,0.3)" },
									children: "Playing Side"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-2",
									children: ["home", "away"].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setKitSide(side),
										className: "px-3 py-2 rounded-xl text-xs font-semibold",
										style: kitSide === side ? {
											background: "rgba(74,222,128,0.12)",
											color: GREEN,
											border: "1px solid rgba(74,222,128,0.25)"
										} : {
											background: "rgba(255,255,255,0.05)",
											color: "rgba(255,255,255,0.6)",
											border: "1px solid rgba(255,255,255,0.1)"
										},
										children: side === "home" ? "Home Kit" : "Away Kit"
									}, side))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[8.5px] uppercase tracking-widest mb-1.5",
									style: { color: "rgba(255,255,255,0.3)" },
									children: "Kit Brand"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: kitBrand,
									onChange: (e) => setKitBrand(e.target.value),
									className: "w-full sm:w-48 rounded-xl px-3 py-2 text-xs font-semibold text-white appearance-none cursor-pointer",
									style: {
										background: "rgba(255,255,255,0.06)",
										border: "1px solid rgba(255,255,255,0.12)",
										outline: "none"
									},
									children: KIT_BRANDS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: b,
										children: b
									}, b))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl",
										style: { background: "rgba(255,255,255,0.03)" },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] uppercase tracking-widest mb-2",
												style: { color: "rgba(255,255,255,0.3)" },
												children: "Kit Energy"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold",
												style: { color: YELLOW },
												children: gearAdvice.kitEnergy
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] mt-1",
												style: { color: "rgba(255,255,255,0.35)" },
												children: [
													activeKitPrimary,
													" (",
													colorEnergy(activeKitPrimary),
													") + ",
													activeKitSecondary,
													" (",
													colorEnergy(activeKitSecondary),
													")"
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl",
										style: { background: "rgba(255,255,255,0.03)" },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] uppercase tracking-widest mb-2",
												style: { color: "rgba(255,255,255,0.3)" },
												children: "Brand Energy"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold",
												style: { color: BLUE },
												children: brandEnergy
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] mt-1",
												style: { color: "rgba(255,255,255,0.35)" },
												children: [
													kitBrand,
													" vibrates at ",
													brandEnergy
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl",
										style: { background: "rgba(255,255,255,0.03)" },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] uppercase tracking-widest mb-2",
												style: { color: "rgba(255,255,255,0.3)" },
												children: "Best Gear Color"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold",
												style: { color: GREEN },
												children: gearAdvice.bestColor
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] mt-1",
												style: { color: "rgba(255,255,255,0.35)" },
												children: ["From ", gearAdvice.bestSource]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl",
										style: { background: "rgba(255,255,255,0.03)" },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] uppercase tracking-widest mb-2",
												style: { color: "rgba(255,255,255,0.3)" },
												children: "PD Harmony"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold",
												style: { color: PURPLE },
												children: Math.abs(gearAdvice.kitEnergy - gd.personalDay) <= 2 ? "Aligned" : "Offset"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] mt-1",
												style: { color: "rgba(255,255,255,0.35)" },
												children: [
													"Kit ",
													gearAdvice.kitEnergy,
													" vs PD ",
													gd.personalDay
												]
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[8.5px] uppercase tracking-widest mb-2",
									style: { color: "rgba(255,255,255,0.25)" },
									children: [
										"Today's Color Options (ranked for your ",
										kitSide,
										" kit)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-2 flex-wrap",
									children: gearAdvice.allOptions.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg",
										style: {
											background: i === 0 ? "rgba(74,222,128,0.1)" : "rgba(255,255,255,0.03)",
											border: i === 0 ? "1px solid rgba(74,222,128,0.2)" : "1px solid rgba(255,255,255,0.06)"
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-3.5 h-3.5 rounded-full",
												style: { background: colorHex(opt.color) }
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-semibold",
												style: { color: i === 0 ? GREEN : "rgba(255,255,255,0.5)" },
												children: opt.color
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[8px]",
												style: { color: "rgba(255,255,255,0.25)" },
												children: [
													"(",
													opt.source,
													")"
												]
											}),
											i === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[8px] font-bold",
												style: { color: GREEN },
												children: "BEST"
											})
										]
									}, opt.source))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] mt-2",
								style: { color: "rgba(255,255,255,0.3)" },
								children: gearAdvice.reason
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-5",
						style: {
							background: "hsl(228 28% 7%)",
							border: "1px solid rgba(74,222,128,0.12)"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-widest mb-4",
							style: { color: GREEN },
							children: "Gear Automation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl",
									style: { background: "rgba(255,255,255,0.03)" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] uppercase tracking-widest mb-2",
											style: { color: "rgba(255,255,255,0.3)" },
											children: "Sock Height"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-white",
											children: gd.sockHeight?.toUpperCase?.() ?? "MID"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] mt-1",
											style: { color: "rgba(255,255,255,0.35)" },
											children: "Untouchable automation"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl",
									style: { background: "rgba(255,255,255,0.03)" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] uppercase tracking-widest mb-2",
											style: { color: "rgba(255,255,255,0.3)" },
											children: "Sock Type"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-white",
											children: gd.sockType === "grip" ? "Grip Sock" : "Regular"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] mt-1",
											style: { color: "rgba(255,255,255,0.35)" },
											children: gd.gearFormula
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl",
									style: { background: "rgba(255,255,255,0.03)" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] uppercase tracking-widest mb-2",
											style: { color: "rgba(255,255,255,0.3)" },
											children: "Jersey Tuck"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-white",
											children: gd.jerseyTuck === "tucked" ? "Tucked In" : "Untucked"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] mt-1",
											style: { color: "rgba(255,255,255,0.35)" },
											children: "Locked like wrist tape"
										})
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-widest mb-3",
							style: { color: "rgba(255,255,255,0.3)" },
							children: "Best Numbers To Use Today"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-3 flex-wrap",
							children: gd.bestNumbers.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center px-4 py-3 rounded-xl",
								style: {
									background: "rgba(250,204,21,0.08)",
									border: "1px solid rgba(250,204,21,0.15)"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-3xl font-black",
									style: { color: YELLOW },
									children: n
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[9px] mt-1",
									style: { color: "rgba(255,255,255,0.35)" },
									children: gd.bestNumberReasons[i]
								})]
							}, n))
						})]
					}),
					(() => {
						const pd = gd.personalDay;
						const useWristTape = pd <= 5;
						const wristColor = pd === 1 ? "Red" : pd === 2 ? "Orange" : pd === 3 ? "Gold" : pd === 4 ? "Green" : pd === 5 ? "Blue" : pd === 6 ? "Indigo" : pd === 7 ? "Violet" : pd === 8 ? "Black" : "White";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-4",
							style: { background: "hsl(228 28% 7%)" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: "rgba(255,255,255,0.3)" },
								children: "Wrist Tape / Handwrap"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-14 h-14 rounded-xl flex items-center justify-center text-2xl",
									style: {
										background: useWristTape ? "rgba(74,222,128,0.1)" : "rgba(248,113,113,0.1)",
										border: useWristTape ? "1px solid rgba(74,222,128,0.2)" : "1px solid rgba(248,113,113,0.2)"
									},
									children: useWristTape ? "✅" : "❌"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-white",
											children: useWristTape ? `Use Wrist Tape — ${wristColor}` : "Skip wrist tape today"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs mt-1",
											style: { color: "rgba(255,255,255,0.4)" },
											children: useWristTape ? `Personal Day ${pd} energy is active — wrist tape in ${wristColor} activates energy code ${pd} through contact with pulse point.` : `Personal Day ${pd} energy is high enough without wrist amplification. Go clean wrists for max mobility.`
										}),
										useWristTape && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 mt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-5 h-5 rounded-full",
												style: {
													background: colorHex(wristColor),
													border: "1px solid rgba(255,255,255,0.15)"
												}
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs font-semibold",
												style: { color: GREEN },
												children: [
													wristColor,
													" · Energy ",
													pd
												]
											})]
										})
									]
								})]
							})]
						});
					})(),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-widest mb-3",
							style: { color: GREEN },
							children: "How To Score Today"
						}), (() => {
							const pd = gd.personalDay;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: (pd === 1 ? [
									{
										tip: "Take shots yourself",
										detail: "LP 1 day = leader energy. Be selfish in the box."
									},
									{
										tip: "Cut inside from the wing",
										detail: "Right-footed cut inside from the left, LP1 rewards individual brilliance."
									},
									{
										tip: "First touch finish",
										detail: "Don't overthink — first-time strikes carry the most 1 energy."
									}
								] : pd === 2 ? [
									{
										tip: "Assist > Score",
										detail: "Day 2 = partnership. Set up teammates for easy finishes."
									},
									{
										tip: "One-two passing combinations",
										detail: "Quick give-and-go near the box activates 2 energy."
									},
									{
										tip: "Near-post runs",
										detail: "Make back-door runs — let the ball find you through partnership."
									}
								] : pd === 3 ? [
									{
										tip: "Creative finish",
										detail: "Chip, backheel, rabona — day 3 rewards flair and style."
									},
									{
										tip: "Long range curler",
										detail: "Outside foot curving shots carry 3 expression energy."
									},
									{
										tip: "Celebrate big",
										detail: "Energy 3 means your celebration amplifies the goal's power."
									}
								] : pd === 4 ? [
									{
										tip: "Work the fundamentals",
										detail: "Day 4 = discipline. Textbook placement > power."
									},
									{
										tip: "Penalty box positioning",
										detail: "Get to the right spot. Classic 6-yard box goals carry the energy."
									},
									{
										tip: "Headers from crosses",
										detail: "4 energy rewards structure — time your runs to meet crosses."
									}
								] : pd === 5 ? [
									{
										tip: "Counter-attack speed",
										detail: "Day 5 = speed & change. Transition goals are your weapon."
									},
									{
										tip: "1v1 with keeper",
										detail: "Use pace to get in behind, then slot it calm."
									},
									{
										tip: "Adapt mid-game",
										detail: "If plan A fails, switch position. 5 rewards flexibility."
									}
								] : pd === 6 ? [
									{
										tip: "Team play in the box",
										detail: "Day 6 = harmony. Goals from team combinations are amplified."
									},
									{
										tip: "Tap-ins from crosses",
										detail: "Be in the right spot. 6 energy rewards collective effort."
									},
									{
										tip: "Set pieces",
										detail: "Corners and free kicks — organized play suits 6 energy."
									}
								] : pd === 7 ? [
									{
										tip: "Placement over power",
										detail: "Day 7 = precision. Side-netting finishes carry the code."
									},
									{
										tip: "Read the keeper",
										detail: "Study their positioning. 7 is analytical — pick your corner."
									},
									{
										tip: "Quiet efficiency",
										detail: "Don't try to be flashy. Clean, composed finishing wins today."
									}
								] : pd === 8 ? [
									{
										tip: "Power shot from distance",
										detail: "Day 8 = authority. Hit it hard — Saturn energy rewards force."
									},
									{
										tip: "Bully the defense",
										detail: "Use physicality. Win aerial duels. Overpower markers."
									},
									{
										tip: "Captain energy",
										detail: "Lead by example. Score the big goal in the big moment."
									}
								] : [
									{
										tip: "Volleys and acrobatics",
										detail: "Day 9 = universal energy. Spectacular goals are destined today."
									},
									{
										tip: "Late-game heroics",
										detail: "9 is completion — decisive goals in the final minutes."
									},
									{
										tip: "Unselfish brilliance",
										detail: "Score the goal that wins it for everyone, not just yourself."
									}
								]).map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3 p-3 rounded-lg",
									style: { background: "rgba(74,222,128,0.04)" },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5",
										style: {
											background: "rgba(74,222,128,0.15)",
											color: GREEN
										},
										children: i + 1
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-white",
										children: t.tip
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs mt-0.5",
										style: { color: "rgba(255,255,255,0.4)" },
										children: t.detail
									})] })]
								}, i))
							});
						})()]
					}),
					(() => {
						const pd = gd.personalDay;
						gd.universalEnergy;
						const bestBrands = {
							1: [
								{
									name: "Nike",
									year: 1964,
									energy: 2,
									why: "2 supports 1 — loyalty fuels leadership"
								},
								{
									name: "Jordan",
									year: 1984,
									energy: 4,
									why: "4 grounds your 1 — structure meets ambition"
								},
								{
									name: "Under Armour",
									year: 1996,
									energy: 7,
									why: "7 adds spiritual depth to your power"
								}
							],
							2: [
								{
									name: "Adidas",
									year: 1949,
									energy: 5,
									why: "5 activates 2 — movement meets diplomacy"
								},
								{
									name: "Puma",
									year: 1948,
									energy: 4,
									why: "4 stabilizes 2 — grounding for the peacemaker"
								},
								{
									name: "Hummel",
									year: 1923,
									energy: 6,
									why: "6 harmonizes with 2 — balance amplified"
								}
							],
							3: [
								{
									name: "Nike",
									year: 1964,
									energy: 2,
									why: "2 balances 3 — creative energy channeled"
								},
								{
									name: "Adidas",
									year: 1949,
									energy: 5,
									why: "5 adds freedom to 3 — expression unleashed"
								},
								{
									name: "Umbro",
									year: 1924,
									energy: 7,
									why: "7 deepens 3 — intuition fuels creativity"
								}
							],
							4: [
								{
									name: "Nike",
									year: 1964,
									energy: 2,
									why: "2 softens 4 — diplomacy meets discipline"
								},
								{
									name: "Jordan",
									year: 1984,
									energy: 4,
									why: "4+4=8 — double structure = power portal"
								},
								{
									name: "Macron",
									year: 1971,
									energy: 9,
									why: "9 completes 4 — builds to mastery"
								}
							],
							5: [
								{
									name: "Adidas",
									year: 1949,
									energy: 5,
									why: "5+5=10/1 — freedom doubles into leadership"
								},
								{
									name: "Nike",
									year: 1964,
									energy: 2,
									why: "2 anchors 5 — movement with partnership"
								},
								{
									name: "Puma",
									year: 1948,
									energy: 4,
									why: "4 grounds 5 — stability for the traveler"
								}
							],
							6: [
								{
									name: "Adidas",
									year: 1949,
									energy: 5,
									why: "5 energizes 6 — freedom meets harmony"
								},
								{
									name: "Puma",
									year: 1948,
									energy: 4,
									why: "4 supports 6 — family and foundation"
								},
								{
									name: "New Balance",
									year: 1906,
									energy: 7,
									why: "7 elevates 6 — spiritual harmony"
								}
							],
							7: [
								{
									name: "Nike",
									year: 1964,
									energy: 2,
									why: "2 partners with 7 — intuition amplified"
								},
								{
									name: "Jordan",
									year: 1984,
									energy: 4,
									why: "4 grounds 7 — spiritual meets physical"
								},
								{
									name: "Macron",
									year: 1971,
									energy: 9,
									why: "9 completes 7 — wisdom reaches harvest"
								}
							],
							8: [
								{
									name: "Adidas",
									year: 1949,
									energy: 5,
									why: "5 activates 8 — freedom fuels authority"
								},
								{
									name: "Under Armour",
									year: 1996,
									energy: 7,
									why: "7 elevates 8 — power meets wisdom"
								},
								{
									name: "New Balance",
									year: 1906,
									energy: 7,
									why: "7 channels 8 — balanced authority"
								}
							],
							9: [
								{
									name: "Nike",
									year: 1964,
									energy: 2,
									why: "2 softens 9 — completion with grace"
								},
								{
									name: "Jordan",
									year: 1984,
									energy: 4,
									why: "4 grounds 9 — harvest with structure"
								},
								{
									name: "Hummel",
									year: 1923,
									energy: 6,
									why: "6 harmonizes 9 — love meets completion"
								}
							]
						};
						const bestColors = bestColorsFor(pd, 3).map((c) => c.name);
						const avoidNums = pd === 1 ? [6, 8] : pd === 2 ? [4, 8] : pd === 3 ? [6, 8] : pd === 4 ? [2, 5] : pd === 5 ? [4, 7] : pd === 6 ? [1, 3] : pd === 7 ? [2, 5] : pd === 8 ? [1, 4] : [4, 5];
						const avoidColors = avoidNums.map((n) => n === 1 ? "Red/Crimson" : n === 2 ? "Orange/Pink" : n === 3 ? "Yellow/Gold" : n === 4 ? "Green/Lime" : n === 5 ? "Blue/Cyan" : n === 6 ? "Navy/Indigo" : n === 7 ? "Purple/Violet" : n === 8 ? "Black/Grey" : "White/Silver");
						const avoidBrands = {
							1: ["Givenchy(1952→3)", "Chanel(1910→2)"],
							2: ["Nike(1964→2)", "Off-White(2012→5)"],
							3: ["Puma(1948→4)", "Ralph Lauren(1967→5)"],
							4: ["Adidas(1949→5)", "Supreme(1994→5)"],
							5: ["Under Armour(1996→7)", "Uniqlo(1984→4)"],
							6: ["Nike(1964→2)", "Jordan(1984→4)"],
							7: ["Adidas(1949→5)", "Reebok(1958→5)"],
							8: ["Nike(1964→2)", "Puma(1948→4)"],
							9: ["Supreme(1994→5)", "Adidas(1949→5)"]
						};
						const brands = bestBrands[pd] ?? bestBrands[1];
						const avBrands = avoidBrands[pd] ?? [];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-4",
							style: {
								background: "hsl(228 28% 7%)",
								border: "1px solid rgba(74,222,128,0.12)"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: GREEN },
								children: "Best Brands & Colors Today"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold mb-2",
									style: { color: GREEN },
									children: "Best Brands to Wear"
								}), brands.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 mb-2 p-2.5 rounded-xl",
									style: {
										background: i === 0 ? "rgba(74,222,128,0.08)" : "rgba(255,255,255,0.03)",
										border: i === 0 ? "1px solid rgba(74,222,128,0.15)" : "1px solid rgba(255,255,255,0.06)"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-8 h-8 rounded-lg flex items-center justify-center text-sm font-black",
										style: {
											background: "rgba(74,222,128,0.1)",
											color: GREEN
										},
										children: b.energy
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-bold text-white",
													children: b.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[9px]",
													style: { color: "rgba(255,255,255,0.35)" },
													children: brandDecode(b.name)?.foundedLabel ?? b.year
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[8px] px-1 py-0.5 rounded",
													style: {
														background: "rgba(255,255,255,0.06)",
														color: "rgba(255,255,255,0.35)"
													},
													children: b.year
												}),
												i === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[8px] font-bold px-1 py-0.5 rounded",
													style: {
														background: "rgba(74,222,128,0.15)",
														color: GREEN
													},
													children: "TOP PICK"
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] mt-0.5",
											style: { color: "rgba(255,255,255,0.35)" },
											children: b.why
										})]
									})]
								}, b.name))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold mb-2",
										style: { color: GREEN },
										children: "Best Colors to Wear"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-1.5",
										children: bestColors.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 p-2 rounded-lg",
											style: {
												background: i === 0 ? "rgba(74,222,128,0.08)" : "rgba(255,255,255,0.03)",
												border: i === 0 ? "1px solid rgba(74,222,128,0.15)" : "1px solid rgba(255,255,255,0.06)"
											},
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-4 h-4 rounded-full",
													style: { background: colorHex(c) }
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold text-white",
													children: c
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[9px] ml-auto",
													style: { color: "rgba(255,255,255,0.3)" },
													children: ["Energy ", colorEnergy(c)]
												}),
												i === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[8px] font-bold",
													style: { color: GREEN },
													children: "TOP"
												})
											]
										}, c))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[9px] mt-2",
										style: { color: "rgba(255,255,255,0.25)" },
										children: [
											"PD ",
											pd,
											" energy flows best with these colors and brand frequencies."
										]
									})
								] })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-4",
							style: { background: "hsl(228 28% 7%)" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: ROSE },
								children: "Brands & Colors To Avoid Today"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold mb-2",
									style: { color: ROSE },
									children: "Colors to Avoid"
								}), avoidColors.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mb-1.5 p-2 rounded-lg",
									style: { background: "rgba(248,113,113,0.06)" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px]",
											children: "🚫"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-white",
											children: c
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[9px] ml-auto",
											style: { color: "rgba(255,255,255,0.3)" },
											children: ["Energy ", avoidNums[avoidColors.indexOf(c)]]
										})
									]
								}, c))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold mb-2",
										style: { color: ROSE },
										children: "Brands to Avoid"
									}),
									avBrands.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 mb-1.5 p-2 rounded-lg",
										style: { background: "rgba(248,113,113,0.06)" },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px]",
											children: "⚠️"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-white",
											children: b
										})]
									}, b)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[9px] mt-2",
										style: { color: "rgba(255,255,255,0.25)" },
										children: [
											"These brand imprints clash with today's PD ",
											pd,
											" energy."
										]
									})
								] })]
							})]
						})] });
					})(),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: YELLOW },
								children: "Best Jersey Numbers — 2025-26 Season"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs mb-3",
								style: { color: "rgba(255,255,255,0.4)" },
								children: [
									"Based on your PY",
									N.personalYear,
									" + LP",
									N.lifePath,
									" + Birthday",
									N.birthday,
									" compound energies"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: gd.rankedNumbers.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between p-3 rounded-xl",
									style: {
										background: i === 0 ? "rgba(250,204,21,0.12)" : "rgba(255,255,255,0.04)",
										border: "1px solid rgba(255,255,255,0.08)"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-9 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xl font-black",
												style: { color: i === 0 ? YELLOW : GREEN },
												children: item.number
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-white",
											children: item.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px]",
											style: { color: "rgba(255,255,255,0.35)" },
											children: item.reason
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-bold",
										style: { color: i === 0 ? YELLOW : BLUE },
										children: item.score
									})]
								}, item.number))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-4",
							style: {
								background: "hsl(228 28% 7%)",
								border: "1px solid rgba(74,222,128,0.15)"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: GREEN },
								children: "Good Energy Today"
							}), (() => {
								const pd = gd.personalDay;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-white",
											children: ["🎨 Colors: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: { color: GREEN },
												children: pd === 1 ? "Red, Gold, White" : pd === 2 ? "Orange, Gold, Blue" : pd === 3 ? "Purple, Yellow, Gold" : pd === 4 ? "Green, Orange, White" : pd === 5 ? "Blue, Cyan, Gold" : pd === 6 ? "Blue, Indigo, Gold" : pd === 7 ? "Violet, Silver, White" : pd === 8 ? "Black, Gold, Blue" : "Gold, White, Red"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-white",
											children: ["⚡ Action: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: { color: GREEN },
												children: pd <= 3 ? "Be bold and take initiative" : pd <= 6 ? "Work with teammates and stay disciplined" : "Trust your instincts and finish with precision"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-white",
											children: ["🔢 Numbers: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: { color: GREEN },
												children: gd.bestNumbers.join(", ")
											})]
										})
									]
								});
							})()]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-4",
							style: {
								background: "hsl(228 28% 7%)",
								border: "1px solid rgba(248,113,113,0.15)"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: ROSE },
								children: "Bad Energy to Counter"
							}), (() => {
								const pd = gd.personalDay;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-white",
											children: ["🚫 Avoid: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: { color: ROSE },
												children: pd === 1 ? "Navy, Indigo, Black" : pd === 2 ? "Green, Brown, Black" : pd === 3 ? "Navy, Indigo, Black" : pd === 4 ? "Orange, Pink, Blue" : pd === 5 ? "Green, Brown, Violet" : pd === 6 ? "Red, Crimson, Yellow" : pd === 7 ? "Orange, Pink, Cyan" : pd === 8 ? "Red, Crimson, Green" : "Green, Lime, Cyan"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-white",
											children: ["🛡️ Counter: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: { color: YELLOW },
												children: pd <= 3 ? "Wear Gold accessories to neutralize" : pd <= 6 ? "Add a White element to balance" : "Use Gold or Yellow to counteract darkness"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-white",
											children: ["⏰ Low window: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: { color: ROSE },
												children: "2–4 PM (avoid big plays)"
											})]
										})
									]
								});
							})()]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-widest mb-3",
							style: { color: YELLOW },
							children: "Best Gems Today"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: bestGems.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-3 py-2 rounded-xl",
								style: {
									background: "rgba(250,204,21,0.08)",
									border: "1px solid rgba(250,204,21,0.15)"
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-white",
									children: g
								})
							}, g))
						})]
					})
				]
			}),
			sub === "training" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card p-4",
					style: { background: "hsl(228 28% 7%)" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10px] uppercase tracking-widest mb-1",
						style: { color: "rgba(255,255,255,0.3)" },
						children: ["Weekly Focus — Personal Year ", N.personalYear]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						style: { color: GREEN },
						children: weekPlan.focus
					})]
				}), [
					{
						day: "Monday",
						...weekPlan.mon
					},
					{
						day: "Tuesday",
						...weekPlan.tue
					},
					{
						day: "Wednesday",
						...weekPlan.wed
					},
					{
						day: "Thursday",
						...weekPlan.thu
					},
					{
						day: "Friday",
						...weekPlan.fri
					},
					{
						day: "Saturday",
						...weekPlan.sat
					},
					{
						day: "Sunday",
						...weekPlan.sun
					}
				].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "feature-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold text-white",
							children: d.day
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "px-2 py-0.5 rounded text-[10px] font-semibold",
							style: {
								background: d.type === "MATCH DAY" ? "rgba(250,204,21,0.15)" : "rgba(96,165,250,0.1)",
								color: d.type === "MATCH DAY" ? YELLOW : BLUE
							},
							children: d.type
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs",
						style: { color: "rgba(255,255,255,0.5)" },
						children: d.desc
					})]
				}, d.day))]
			}),
			sub === "diet" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: [
					{
						label: "Pre-Match Nutrition",
						items: DIET_PLAN.preMatch,
						color: YELLOW
					},
					{
						label: "Hydration Strategy",
						items: DIET_PLAN.hydration,
						color: BLUE
					},
					{
						label: "Recovery Meals",
						items: DIET_PLAN.recovery,
						color: GREEN
					},
					{
						label: "Lucky Foods (Energy Portal Alignment)",
						items: DIET_PLAN.luckyFoods,
						color: PURPLE
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card p-4",
					style: { background: "hsl(228 28% 7%)" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-widest mb-3",
						style: { color: "rgba(255,255,255,0.3)" },
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: s.items.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2 text-xs",
							style: { color: "rgba(255,255,255,0.6)" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: { color: s.color },
								children: "→"
							}), item]
						}, i))
					})]
				}, s.label))
			}),
			sub === "mental" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: [
					{
						title: "Daily Affirmation",
						content: `"I am Life Path ${N.lifePath}. My 28/10 wealth portal is always active. I lead, I create, I dominate on the field."`,
						emoji: "💭"
					},
					{
						title: "Pre-Match Visualization (2 hrs before)",
						content: "Close your eyes for 5 minutes. See yourself making the decisive run down the wing. See the cross landing perfectly. Hear the crowd. Feel the completion.",
						emoji: "🧠"
					},
					{
						title: "Focus Mantra",
						content: `Repeat: "${N.lifePath} — ${N.birthday} — ${N.expression}" — your three core activation codes. Lock in before entering the pitch.`,
						emoji: "🔮"
					},
					{
						title: "Pressure Management (Life Path 1)",
						content: "When under pressure, reconnect with your leadership energy. You are a pioneer — tension activates you, not breaks you. Take initiative.",
						emoji: "⚡"
					},
					{
						title: "Post-Match Reset",
						content: "Win or lose: write 3 things you controlled. Release what you couldn't. Your Personal Year 9 requires completion and release energy.",
						emoji: "📝"
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "feature-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-2xl",
						children: s.emoji
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-white",
						children: s.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs mt-1 leading-relaxed",
						style: { color: "rgba(255,255,255,0.5)" },
						children: s.content
					})] })]
				}, s.title))
			}),
			sub === "schedule" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card p-5",
					style: { background: "hsl(228 28% 7%)" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-widest mb-1",
							style: { color: YELLOW },
							children: "Season Schedule"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs mb-4",
							style: { color: "rgba(255,255,255,0.4)" },
							children: [
								"Life Path ",
								N.lifePath,
								" · Birthday ",
								N.birthday,
								" · compat vs each game's energy"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: SEASON_SCHEDULE.map((g) => {
								const tier = compatLabel(g.compat);
								const color = tier === "FRIENDLY" ? GREEN : tier === "NEUTRAL" ? YELLOW : ROSE;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl",
									style: {
										background: "rgba(255,255,255,0.03)",
										border: `1px solid ${color}30`
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-3 mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm font-bold",
											style: { color: "white" },
											children: [
												g.home ? "vs" : "@",
												" ",
												g.opponent
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px]",
											style: { color: "rgba(255,255,255,0.45)" },
											children: [
												g.date,
												" · ",
												g.time,
												" · ",
												g.venue
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-lg font-black",
												style: { color },
												children: [g.compat, "%"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] font-bold tracking-widest",
												style: { color },
												children: tier
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2 mt-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[9px] px-2 py-0.5 rounded-full",
											style: {
												background: "rgba(212,175,55,0.15)",
												color: YELLOW
											},
											children: ["LP ", g.lp]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[9px] px-2 py-0.5 rounded-full",
											style: {
												background: "rgba(59,130,246,0.15)",
												color: BLUE
											},
											children: ["Sec ", g.secondary]
										})]
									})]
								}, g.date);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] mt-4",
							style: { color: "rgba(255,255,255,0.3)" },
							children: "Compat driven by ShemUniverse number matrix: LP↔Universal (25%), Birthday↔Personal Day (25%), LP↔Personal Day (20%), LP↔Regular Day # (30%). 20 is a hidden 11 and never reduces."
						})
					]
				})
			}),
			sub === "athleticism" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-5",
						style: {
							background: "hsl(228 28% 7%)",
							border: ath.isBehind ? "1px solid #f472b620" : ath.needsWarning ? "1px solid #facc1530" : "1px solid transparent"
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-widest mb-1",
									style: { color: YELLOW },
									children: "Weekly Consistency"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs",
									style: { color: "rgba(255,255,255,0.4)" },
									children: "Target: 3 sessions per week"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-2xl font-black",
										style: { color: ath.weekSessions >= 3 ? GREEN : ath.weekSessions >= 2 ? YELLOW : ROSE },
										children: [ath.weekSessions, "/3"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px]",
										style: { color: "rgba(255,255,255,0.35)" },
										children: "this week"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 mb-3",
								children: [
									0,
									1,
									2
								].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 h-2 rounded-full",
									style: { background: i < ath.weekSessions ? ath.weekSessions >= 3 ? GREEN : YELLOW : "rgba(255,255,255,0.08)" }
								}, i))
							}),
							ath.isBehind && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-2 p-3 rounded-xl mb-3",
								style: {
									background: "rgba(244,114,182,0.08)",
									border: "1px solid rgba(244,114,182,0.2)"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									style: { color: ROSE },
									children: "⚠"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs leading-relaxed",
									style: { color: ROSE },
									children: "You're behind pace — less than 2 sessions and the week ends soon. Get a session in today to stay consistent. Inconsistency resets your progress momentum."
								})]
							}),
							!ath.isBehind && ath.needsWarning && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-2 p-3 rounded-xl mb-3",
								style: {
									background: "rgba(250,204,21,0.08)",
									border: "1px solid rgba(250,204,21,0.2)"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									style: { color: YELLOW },
									children: "⚡"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs leading-relaxed",
									style: { color: YELLOW },
									children: [
										"Only ",
										3 - ath.weekSessions,
										" more session",
										3 - ath.weekSessions > 1 ? "s" : "",
										" needed to hit your 3×/week goal before the week ends."
									]
								})]
							}),
							ath.weekSessions >= 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 p-3 rounded-xl",
								style: {
									background: "rgba(74,222,128,0.08)",
									border: "1px solid rgba(74,222,128,0.2)"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									style: { color: GREEN },
									children: "✓"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold",
									style: { color: GREEN },
									children: "Weekly goal locked in. Elite consistency."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] mt-2",
								style: { color: "rgba(255,255,255,0.2)" },
								children: "Tracker resets every Monday · Checks reset at midnight"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: YELLOW },
								children: "Fascia Training Level"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-2",
								children: [
									1,
									2,
									3,
									4
								].map((l) => {
									const lvl = FASCIA_LEVELS[l];
									const active = ath.level === l;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => ath.setLevel(l),
										className: "p-3 rounded-xl text-left transition-all",
										style: {
											background: active ? `rgba(96,165,250,0.12)` : "rgba(255,255,255,0.03)",
											border: active ? `1px solid ${BLUE}50` : "1px solid rgba(255,255,255,0.06)"
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-base font-black",
												style: { color: active ? BLUE : "rgba(255,255,255,0.3)" },
												children: ["L", l]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px]",
												style: { color: active ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.25)" },
												children: lvl.weeks
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] mt-0.5",
												style: { color: active ? BLUE : "rgba(255,255,255,0.2)" },
												children: lvl.duration
											})
										]
									}, l);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] mt-3 leading-relaxed",
								style: { color: "rgba(255,255,255,0.35)" },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										style: { color: YELLOW },
										children: "Criteria to advance:"
									}),
									" ",
									FASCIA_LEVELS[ath.level].criteria
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] uppercase tracking-widest",
									style: { color: BLUE },
									children: ["Fascia Training — Level ", ath.level]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px]",
									style: { color: "rgba(255,255,255,0.3)" },
									children: FASCIA_LEVELS[ath.level].duration
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-black",
									style: { color: ath.doneFascia === ath.totalFascia ? GREEN : BLUE },
									children: [
										ath.doneFascia,
										"/",
										ath.totalFascia
									]
								})]
							}),
							ath.totalFascia > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-3 h-1 rounded-full overflow-hidden",
								style: { background: "rgba(255,255,255,0.06)" },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full transition-all duration-500",
									style: {
										width: `${ath.doneFascia / ath.totalFascia * 100}%`,
										background: ath.doneFascia === ath.totalFascia ? GREEN : BLUE
									}
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-1.5",
								children: ath.fasciaExercises.map((ex, i) => {
									const key = `f${i}`;
									const done = ath.checks[key] === true;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => ath.toggleCheck(key),
										className: "flex items-start gap-2.5 w-full text-left",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 w-4 h-4 shrink-0 rounded border flex items-center justify-center transition-all",
											style: {
												borderColor: done ? GREEN : "rgba(255,255,255,0.2)",
												background: done ? `${GREEN}20` : "transparent"
											},
											children: done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px]",
												style: { color: GREEN },
												children: "✓"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs transition-all",
											style: {
												color: done ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.65)",
												textDecoration: done ? "line-through" : "none"
											},
											children: ex
										})]
									}, key);
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-4",
						style: { background: "hsl(228 28% 7%)" },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-widest",
									style: { color: GREEN },
									children: "GOATA Training"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px]",
									style: { color: "rgba(255,255,255,0.3)" },
									children: "Daily · 30 min"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-black",
									style: { color: ath.doneGoata === ath.totalGoata ? GREEN : BLUE },
									children: [
										ath.doneGoata,
										"/",
										ath.totalGoata
									]
								})]
							}),
							ath.totalGoata > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-3 h-1 rounded-full overflow-hidden",
								style: { background: "rgba(255,255,255,0.06)" },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full transition-all duration-500",
									style: {
										width: `${ath.doneGoata / ath.totalGoata * 100}%`,
										background: ath.doneGoata === ath.totalGoata ? GREEN : GREEN
									}
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-1.5",
								children: GOATA_EXERCISES.map((ex, i) => {
									const key = `g${i}`;
									const done = ath.checks[key] === true;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => ath.toggleCheck(key),
										className: "flex items-start gap-2.5 w-full text-left",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 w-4 h-4 shrink-0 rounded border flex items-center justify-center transition-all",
											style: {
												borderColor: done ? GREEN : "rgba(255,255,255,0.2)",
												background: done ? `${GREEN}20` : "transparent"
											},
											children: done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px]",
												style: { color: GREEN },
												children: "✓"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs transition-all",
											style: {
												color: done ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.65)",
												textDecoration: done ? "line-through" : "none"
											},
											children: ex
										})]
									}, key);
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: ath.logSession,
						disabled: ath.sessionLoggedToday,
						className: "w-full py-4 rounded-2xl font-bold text-sm transition-all",
						style: {
							background: ath.sessionLoggedToday ? "rgba(74,222,128,0.08)" : `rgba(96,165,250,0.12)`,
							border: ath.sessionLoggedToday ? `1px solid ${GREEN}40` : `1px solid ${BLUE}40`,
							color: ath.sessionLoggedToday ? GREEN : BLUE,
							cursor: ath.sessionLoggedToday ? "default" : "pointer"
						},
						children: ath.sessionLoggedToday ? "✓ Session Logged for Today" : "Log Completed Session (+1 this week)"
					})
				]
			})
		]
	});
}
//#endregion
export { SoccerAIPage as t };
