//#region node_modules/.nitro/vite/services/ssr/assets/numerology-tNoiBxGA.js
var PYTHAGOREAN = {
	A: 1,
	B: 2,
	C: 3,
	D: 4,
	E: 5,
	F: 6,
	G: 7,
	H: 8,
	I: 9,
	J: 1,
	K: 2,
	L: 3,
	M: 4,
	N: 5,
	O: 6,
	P: 7,
	Q: 8,
	R: 9,
	S: 1,
	T: 2,
	U: 3,
	V: 4,
	W: 5,
	X: 6,
	Y: 7,
	Z: 8
};
var MASTER = /* @__PURE__ */ new Set([
	11,
	22,
	33
]);
var VOWELS = /* @__PURE__ */ new Set([
	"A",
	"E",
	"I",
	"O",
	"U"
]);
/** Reduce to single digit, preserving master numbers 11, 22, 33.
*  20 is a hidden 11 and never reduces to 2 — a pure 2 stays 2. */
function reduce(n) {
	if (n === 20) return 11;
	if (n <= 9 || MASTER.has(n)) return n;
	return reduce([...String(n)].reduce((a, d) => a + +d, 0));
}
/** Calendar day-of-month energy: 18 → 9, 20 → hidden 11, 2 → pure 2. */
function dayNumber(day) {
	return reduce(day);
}
function calcUniversalYear(year) {
	const compound = digitSum(year);
	return {
		compound,
		reduced: reduce(compound)
	};
}
function calcUniversalMonth(year, month) {
	const compound = calcUniversalYear(year).reduced + month;
	return {
		compound,
		reduced: reduce(compound)
	};
}
function calcUniversalDay(year, month, day) {
	const compound = calcUniversalMonth(year, month).reduced + day;
	return {
		compound,
		reduced: reduce(compound)
	};
}
/** Pythagorean value of any word/phrase (compound + reduced, 20 = hidden 11). */
function pythagoreanValue(text) {
	let compound = 0;
	for (const ch of text.toUpperCase().normalize("NFD").replace(/[^A-Z]/g, "")) compound += PYTHAGOREAN[ch] ?? 0;
	return {
		compound,
		reduced: reduce(compound)
	};
}
/** Full digit sum of a number string — first pass (compound) */
function digitSum(n) {
	return [...String(n)].reduce((a, d) => a + +d, 0);
}
var PLANET_MAP = {
	1: "Sun",
	2: "Moon",
	3: "Jupiter",
	4: "Uranus/Rahu",
	5: "Mercury",
	6: "Venus",
	7: "Neptune/Ketu",
	8: "Saturn",
	9: "Mars"
};
var PHYSICAL_LETTERS = /* @__PURE__ */ new Set([
	"D",
	"E",
	"M",
	"N",
	"V",
	"W"
]);
var MENTAL_LETTERS = /* @__PURE__ */ new Set([
	"A",
	"H",
	"J",
	"Q",
	"S",
	"Z"
]);
var EMOTIONAL_LETTERS = /* @__PURE__ */ new Set([
	"B",
	"C",
	"F",
	"K",
	"L",
	"O",
	"T",
	"U",
	"X"
]);
var INTUITIVE_LETTERS = /* @__PURE__ */ new Set([
	"G",
	"I",
	"P",
	"R",
	"Y"
]);
function isVowel(ch, idx, word) {
	const c = ch.toUpperCase();
	if (VOWELS.has(c)) return true;
	if (c === "Y") return ![...(word[idx - 1] || "") + (word[idx + 1] || "")].some((n) => VOWELS.has(n.toUpperCase()));
	return false;
}
function nameToDigits(name, type) {
	const letters = [...name.toUpperCase()].filter((c) => /[A-Z]/.test(c));
	const word = letters.join("");
	return letters.map((c, i) => ({
		c,
		i
	})).filter(({ c, i }) => {
		if (type === "all") return true;
		const v = isVowel(c, i, word);
		return type === "vowels" ? v : !v;
	}).map(({ c }) => PYTHAGOREAN[c] ?? 0);
}
function sumName(name, type) {
	const compound = nameToDigits(name, type).reduce((a, b) => a + b, 0);
	return {
		compound,
		reduced: reduce(compound)
	};
}
function calcExpression(nameParts, type = "all") {
	const compound = nameParts.filter((p) => p.trim().length > 0).map((p) => sumName(p, type).reduced).reduce((a, b) => a + b, 0);
	return {
		compound,
		reduced: reduce(compound)
	};
}
var KARMIC_DEBT_TRIGGERS = /* @__PURE__ */ new Set([
	13,
	14,
	16,
	19
]);
function calcCoreNumbers(firstName, middleName, lastName, birthMonth, birthDay, birthYear, currentYear = (/* @__PURE__ */ new Date()).getFullYear()) {
	const nameParts = [
		firstName,
		middleName,
		lastName
	].filter(Boolean);
	const fullNameStr = nameParts.join(" ");
	const mPart = reduce(birthMonth);
	const dPart = reduce(birthDay);
	const yPart = reduce(digitSum(birthYear));
	const lpCompound = mPart + dPart + yPart;
	const lifePath = reduce(lpCompound);
	const karmicDebts = [];
	for (const c of [
		lpCompound,
		birthDay,
		birthYear
	]) if (KARMIC_DEBT_TRIGGERS.has(c)) karmicDebts.push(c);
	const exprRaw = calcExpression(nameParts, "all");
	if (KARMIC_DEBT_TRIGGERS.has(exprRaw.compound)) karmicDebts.push(exprRaw.compound);
	const uniqueDebts = [...new Set(karmicDebts)];
	const expr = calcExpression(nameParts, "all");
	const soul = calcExpression(nameParts, "vowels");
	const pers = calcExpression(nameParts, "consonants");
	const birthdayReduced = reduce(birthDay);
	const _refDate = /* @__PURE__ */ new Date();
	const py = calcPersonalYear(birthMonth, birthDay, currentYear === _refDate.getFullYear() ? _refDate.getMonth() + 1 : 12, currentYear === _refDate.getFullYear() ? _refDate.getDate() : 31, currentYear);
	const pyCompound = py.compound;
	const personalYear = py.reduced;
	const allDigits = new Set(nameToDigits(fullNameStr, "all"));
	const karmicLessons = [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9
	].filter((n) => !allDigits.has(n));
	const freq = {};
	for (const d of nameToDigits(fullNameStr, "all")) freq[d] = (freq[d] || 0) + 1;
	const hiddenPassion = Number(Object.entries(freq).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 1);
	const subconsciousSelf = 9 - karmicLessons.length;
	const planes = {
		physical: 0,
		mental: 0,
		emotional: 0,
		intuitive: 0
	};
	for (const c of fullNameStr.toUpperCase()) {
		if (!/[A-Z]/.test(c)) continue;
		if (PHYSICAL_LETTERS.has(c)) planes.physical++;
		else if (MENTAL_LETTERS.has(c)) planes.mental++;
		else if (EMOTIONAL_LETTERS.has(c)) planes.emotional++;
		else if (INTUITIVE_LETTERS.has(c)) planes.intuitive++;
	}
	const m = reduce(birthMonth);
	const d2 = reduce(birthDay);
	const y2 = reduce(digitSum(birthYear));
	const p1 = reduce(m + d2);
	const p2 = reduce(d2 + y2);
	const p3 = reduce(p1 + p2);
	const p4 = reduce(m + y2);
	const c1 = Math.abs(m - d2);
	const c2 = Math.abs(d2 - y2);
	const c3 = Math.abs(c1 - c2);
	const c4 = Math.abs(m - y2);
	const p1End = 36 - lifePath;
	const pinnacleAges = [
		{
			period: 1,
			number: p1,
			from: 0,
			to: p1End
		},
		{
			period: 2,
			number: p2,
			from: p1End + 1,
			to: p1End + 9
		},
		{
			period: 3,
			number: p3,
			from: p1End + 10,
			to: p1End + 18
		},
		{
			period: 4,
			number: p4,
			from: p1End + 19,
			to: null
		}
	];
	const mulank = reduce(birthDay);
	const planet = PLANET_MAP[mulank] ?? "Unknown";
	const maturityNumber = reduce(lifePath + expr.reduced);
	const balanceNumber = reduce(nameParts.map((p) => p.charAt(0).toUpperCase()).filter((c) => /[A-Z]/.test(c)).reduce((sum, c) => sum + (PYTHAGOREAN[c] ?? 0), 0));
	const cornerstone = PYTHAGOREAN[(nameParts[0] ?? "A").charAt(0).toUpperCase()] ?? 1;
	const lastNamePart = nameParts[nameParts.length - 1] ?? "A";
	const capstone = PYTHAGOREAN[lastNamePart.charAt(lastNamePart.length - 1).toUpperCase()] ?? 1;
	const firstVowel = PYTHAGOREAN[[...nameParts[0]?.toUpperCase() ?? ""].find((c) => VOWELS.has(c)) ?? "A"] ?? 1;
	const period1End = 36 - lifePath;
	const period2End = period1End + 27;
	const lifePeriods = [
		{
			period: 1,
			number: reduce(birthMonth),
			from: 0,
			to: period1End,
			ruling: "Birth Month"
		},
		{
			period: 2,
			number: reduce(birthDay),
			from: period1End + 1,
			to: period2End,
			ruling: "Birth Day"
		},
		{
			period: 3,
			number: reduce(digitSum(birthYear)),
			from: period2End + 1,
			to: null,
			ruling: "Birth Year"
		}
	];
	return {
		lifePath,
		lifePathCompound: lpCompound,
		expression: expr.reduced,
		expressionCompound: expr.compound,
		soulUrge: soul.reduced,
		soulUrgeCompound: soul.compound,
		personality: pers.reduced,
		personalityCompound: pers.compound,
		birthday: birthDay,
		birthdayReduced,
		personalYear,
		personalYearCompound: pyCompound,
		karmicLessons,
		karmicDebts: uniqueDebts,
		hiddenPassion,
		subconsciousSelf,
		planesOfExpression: planes,
		pinnacles: [
			p1,
			p2,
			p3,
			p4
		],
		pinnacleAges,
		challenges: [
			c1,
			c2,
			c3,
			c4
		],
		mulank,
		planet,
		maturityNumber,
		balanceNumber,
		cornerstone,
		capstone,
		firstVowel,
		lifePeriods
	};
}
function calcDateEnergy(month, day, year) {
	const fullSum = [...`${String(month).padStart(2, "0")}${String(day).padStart(2, "0")}${year}`].reduce((a, d) => a + +d, 0);
	const compound = fullSum;
	const reduced = reduce(fullSum);
	return {
		fullSum,
		compound,
		reduced,
		secondary: digitSum(fullSum) < 10 ? fullSum : digitSum(fullSum),
		isMaster: MASTER.has(reduced) || MASTER.has(compound),
		label: {
			1: "Action & Leadership",
			2: "Cooperation & Patience",
			3: "Creativity & Expression",
			4: "Structure & Discipline",
			5: "Freedom & Change",
			6: "Harmony & Service",
			7: "Reflection & Wisdom",
			8: "Power & Abundance",
			9: "Completion & Release",
			11: "Master Portal – Illumination",
			22: "Master Builder – Manifestation",
			33: "Master Teacher – Service"
		}[reduced] ?? ""
	};
}
function calcPersonalYear(birthMonth, birthDay, targetMonth, targetDay, targetYear) {
	const effYear = targetMonth < birthMonth || targetMonth === birthMonth && targetDay < birthDay ? targetYear - 1 : targetYear;
	const compound = reduce(birthMonth) + reduce(birthDay) + reduce(digitSum(effYear));
	return {
		compound,
		reduced: reduce(compound),
		cycleYear: effYear
	};
}
function calcPersonalDay(birthMonth, birthDay, targetMonth, targetDay, targetYear) {
	const py = calcPersonalYear(birthMonth, birthDay, targetMonth, targetDay, targetYear).reduced;
	const compound = reduce(py + targetMonth) + digitSum(targetDay);
	return {
		compound,
		reduced: reduce(compound)
	};
}
var LUCKY_COLORS = {
	1: {
		primary: "Gold",
		secondary: "Yellow"
	},
	2: {
		primary: "Silver",
		secondary: "Cream"
	},
	3: {
		primary: "Yellow",
		secondary: "Gold"
	},
	4: {
		primary: "Blue",
		secondary: "Grey"
	},
	5: {
		primary: "Turquoise",
		secondary: "Light Blue"
	},
	6: {
		primary: "Royal Blue",
		secondary: "Green"
	},
	7: {
		primary: "Purple",
		secondary: "Indigo"
	},
	8: {
		primary: "Black",
		secondary: "Dark Blue"
	},
	9: {
		primary: "Red",
		secondary: "Gold"
	},
	10: {
		primary: "Gold",
		secondary: "Royal Blue"
	},
	11: {
		primary: "White",
		secondary: "Silver"
	},
	22: {
		primary: "Iridescent",
		secondary: "Gold"
	},
	28: {
		primary: "Gold",
		secondary: "Royal Blue"
	}
};
function calcCompatibility(lp1, expr1, lp2, expr2) {
	const base = {
		"1-1": 70,
		"1-2": 80,
		"1-3": 85,
		"1-4": 60,
		"1-5": 75,
		"1-6": 65,
		"1-7": 70,
		"1-8": 80,
		"1-9": 65,
		"2-2": 75,
		"2-3": 80,
		"2-4": 85,
		"2-5": 65,
		"2-6": 90,
		"2-7": 80,
		"2-8": 70,
		"2-9": 85,
		"3-3": 75,
		"3-4": 60,
		"3-5": 85,
		"3-6": 80,
		"3-7": 65,
		"3-8": 70,
		"3-9": 80,
		"4-4": 70,
		"4-5": 55,
		"4-6": 75,
		"4-7": 65,
		"4-8": 85,
		"4-9": 60,
		"5-5": 65,
		"5-6": 70,
		"5-7": 80,
		"5-8": 65,
		"5-9": 75,
		"6-6": 80,
		"6-7": 75,
		"6-8": 70,
		"6-9": 90,
		"7-7": 70,
		"7-8": 65,
		"7-9": 80,
		"8-8": 75,
		"8-9": 65,
		"9-9": 75
	}[[Math.min(lp1, lp2), Math.max(lp1, lp2)].join("-")] ?? 70;
	const exprBonus = expr1 === expr2 ? 8 : Math.abs(expr1 - expr2) <= 2 ? 4 : 0;
	const score = Math.min(99, base + exprBonus);
	const label = score >= 85 ? "Excellent" : score >= 70 ? "Strong" : score >= 55 ? "Moderate" : "Challenging";
	return {
		score,
		label,
		detail: `Life Path ${lp1} × ${lp2} harmony — ${label} flow`
	};
}
function calcPersonalMonth(personalYear, targetMonth) {
	const compound = personalYear + targetMonth;
	return {
		compound,
		reduced: reduce(compound)
	};
}
var NUMBER_MEANINGS_FULL = {
	1: {
		title: "The Leader",
		keywords: "Independence, originality, ambition, drive",
		meaning: "The number of creation and new beginnings. Pure masculine/yang energy. Self-starters who forge their own path. Natural leaders who don't follow — they create.",
		planet: "Sun",
		element: "Fire",
		tarot: "The Magician",
		crystal: "Citrine, Ruby",
		color: "Gold, Red"
	},
	2: {
		title: "The Diplomat",
		keywords: "Cooperation, sensitivity, balance, peace",
		meaning: "The number of duality and partnerships. Feminine/yin energy. Peacemakers and mediators. Highly intuitive, sensitive to others' needs.",
		planet: "Moon",
		element: "Water",
		tarot: "The High Priestess",
		crystal: "Moonstone, Pearl",
		color: "Silver, White"
	},
	3: {
		title: "The Communicator",
		keywords: "Creativity, expression, joy, social",
		meaning: "The number of creative self-expression. The artist, writer, speaker. Social butterfly energy. Natural charm and magnetism.",
		planet: "Jupiter",
		element: "Fire",
		tarot: "The Empress",
		crystal: "Yellow Topaz, Amethyst",
		color: "Yellow, Purple"
	},
	4: {
		title: "The Builder",
		keywords: "Structure, discipline, hard work, stability",
		meaning: "The number of foundations and order. Builder of systems and structures. Practical, reliable, and determined. The backbone of society.",
		planet: "Uranus/Rahu",
		element: "Earth",
		tarot: "The Emperor",
		crystal: "Sapphire, Emerald",
		color: "Blue, Green"
	},
	5: {
		title: "The Adventurer",
		keywords: "Freedom, change, versatility, travel",
		meaning: "The number of freedom and dynamic change. Sensory experience seeker. Adaptable, resourceful, and magnetic. Hates routine.",
		planet: "Mercury",
		element: "Air",
		tarot: "The Hierophant",
		crystal: "Turquoise, Aquamarine",
		color: "Turquoise, Light Blue"
	},
	6: {
		title: "The Nurturer",
		keywords: "Love, responsibility, harmony, family",
		meaning: "The number of love and domestic harmony. The cosmic parent. Drawn to beauty, art, and service. Healing presence.",
		planet: "Venus",
		element: "Earth",
		tarot: "The Lovers",
		crystal: "Rose Quartz, Jade",
		color: "Blue, Pink"
	},
	7: {
		title: "The Seeker",
		keywords: "Wisdom, spirituality, analysis, solitude",
		meaning: "The number of the mystic and philosopher. Deep thinker who seeks truth beyond surface reality. Introspective, analytical, spiritual.",
		planet: "Neptune/Ketu",
		element: "Water",
		tarot: "The Chariot",
		crystal: "Amethyst, Labradorite",
		color: "Purple, Violet"
	},
	8: {
		title: "The Powerhouse",
		keywords: "Authority, abundance, karma, achievement",
		meaning: "The number of material mastery and karmic balance. Executive energy. Born to lead organizations, build empires, and manage wealth.",
		planet: "Saturn",
		element: "Earth",
		tarot: "Strength",
		crystal: "Obsidian, Tiger's Eye",
		color: "Black, Dark Blue"
	},
	9: {
		title: "The Humanitarian",
		keywords: "Compassion, wisdom, completion, universal love",
		meaning: "The number of universal service and completion. Old soul energy. Compassionate, wise, and selfless. The final single digit. In GG33, 9 carries Gold / Deep Red completion energy — not the same as raw 1/Red leadership energy.",
		planet: "Mars",
		element: "Fire",
		tarot: "The Hermit",
		crystal: "Garnet, Bloodstone",
		color: "Gold, Deep Red"
	},
	10: {
		title: "Wheel of Fortune",
		keywords: "Completion, new cycle, leadership, fortune",
		meaning: "The complete cycle — 1 (beginning) + 0 (infinite potential). Fortune favors the bold. Completion energy leading to new leadership.",
		planet: "Sun+Pluto",
		element: "Fire/Ether",
		tarot: "Wheel of Fortune",
		crystal: "Citrine",
		color: "Gold"
	},
	11: {
		title: "Master Illuminator",
		keywords: "Intuition, inspiration, spiritual messenger",
		meaning: "The first master number. Channel between the spiritual and physical. Visionary energy. Extremely sensitive and psychically gifted.",
		planet: "Moon (higher octave)",
		element: "Light",
		tarot: "Justice",
		crystal: "Clear Quartz, Selenite",
		color: "White, Silver"
	},
	12: {
		title: "The Sacrifice",
		keywords: "Surrender, perspective shift, spiritual growth",
		meaning: "Learning through sacrifice and new perspectives. Seeing the world from a different angle. Spiritual growth through letting go.",
		planet: "Jupiter+Moon",
		element: "Water",
		tarot: "The Hanged Man",
		crystal: "Lapis Lazuli",
		color: "Blue"
	},
	13: {
		title: "Karmic Debt — Transformation",
		keywords: "Death/rebirth, hard work, perseverance",
		meaning: "Karmic debt number. Must work hard without shortcuts. Transformation through discipline. Past life laziness being corrected.",
		planet: "Uranus",
		element: "Earth",
		tarot: "Death",
		crystal: "Obsidian",
		color: "Black"
	},
	14: {
		title: "Karmic Debt — Temperance",
		keywords: "Moderation, freedom through discipline",
		meaning: "Karmic debt of excess. Past life overindulgence. Must learn moderation and temperance. Freedom comes through self-control.",
		planet: "Mercury",
		element: "Air/Fire",
		tarot: "Temperance",
		crystal: "Amethyst",
		color: "Purple, Blue"
	},
	15: {
		title: "The Alchemist",
		keywords: "Magnetism, temptation, material power",
		meaning: "Magnetic and charismatic. Can attract wealth and pleasure but must use power responsibly. Alchemical transformation energy.",
		planet: "Venus+Mars",
		element: "Fire",
		tarot: "The Devil",
		crystal: "Black Tourmaline",
		color: "Black, Red"
	},
	16: {
		title: "Karmic Debt — The Tower",
		keywords: "Ego destruction, awakening, rebuilding",
		meaning: "Karmic debt of ego. Past life arrogance being corrected. Sudden upheavals that destroy false structures. Spiritual awakening.",
		planet: "Neptune",
		element: "Fire/Water",
		tarot: "The Tower",
		crystal: "Moldavite",
		color: "Red, White"
	},
	17: {
		title: "The Star",
		keywords: "Hope, inspiration, spiritual gifts",
		meaning: "Number of immortality and spiritual gifts. Cosmic protection. Artistic and intellectual brilliance. Stars align in your favor.",
		planet: "Saturn+Sun",
		element: "Air",
		tarot: "The Star",
		crystal: "Star Sapphire",
		color: "Violet, Gold"
	},
	18: {
		title: "The Moon",
		keywords: "Illusion, intuition, hidden enemies, psychic",
		meaning: "Deep emotional and psychic currents. Hidden things come to light. Must trust intuition over appearances. Spiritual warfare.",
		planet: "Mars+Saturn",
		element: "Water",
		tarot: "The Moon",
		crystal: "Moonstone",
		color: "Silver, Grey"
	},
	19: {
		title: "Karmic Debt — The Sun",
		keywords: "Independence, ego lessons, self-reliance",
		meaning: "Karmic debt of abuse of power. Must learn true independence without dominating others. Success through selfless leadership.",
		planet: "Sun+Mars",
		element: "Fire",
		tarot: "The Sun",
		crystal: "Sunstone",
		color: "Gold, Orange"
	},
	20: {
		title: "Judgment",
		keywords: "Awakening, calling, resurrection, purpose",
		meaning: "Spiritual awakening and answering your higher calling. Resurrection of dormant talents. Time to step into your purpose.",
		planet: "Moon (higher)",
		element: "Water/Fire",
		tarot: "Judgement",
		crystal: "Angelite",
		color: "White, Gold"
	},
	21: {
		title: "The World",
		keywords: "Completion, success, fulfillment, travel",
		meaning: "Crown of the Major Arcana. Complete success and fulfillment. World travel and expansion. The promised land energy.",
		planet: "Jupiter+Sun",
		element: "Earth/Fire",
		tarot: "The World",
		crystal: "Lapis Lazuli, Gold",
		color: "Blue, Gold"
	},
	22: {
		title: "Master Builder",
		keywords: "Large-scale vision, manifestation, legacy",
		meaning: "The most powerful master number. Can turn the grandest dreams into physical reality. Architect of civilization.",
		planet: "Uranus (higher octave)",
		element: "Earth/Light",
		tarot: "The Fool (0/22)",
		crystal: "Moldavite, Diamond",
		color: "Gold, Iridescent"
	},
	23: {
		title: "The Royal Star",
		keywords: "Communication, protection, charisma",
		meaning: "One of the most fortunate compounds. Called 'The Royal Star of the Lion.' Success, protection, and favor from those in power.",
		planet: "Mercury+Jupiter",
		element: "Air/Fire",
		tarot: "",
		crystal: "Tiger's Eye",
		color: "Gold, Orange"
	},
	24: {
		title: "Love & Money",
		keywords: "Harmony, financial luck, relationships",
		meaning: "Very fortunate for love and money. Help from others. Community support. Domestic harmony and material comfort.",
		planet: "Venus+Uranus",
		element: "Earth/Water",
		tarot: "",
		crystal: "Rose Quartz, Jade",
		color: "Green, Pink"
	},
	25: {
		title: "The Discerner",
		keywords: "Introspection, wisdom, spiritual strength",
		meaning: "Spiritual strength through trials. Deep wisdom gained from experience. Analytical and intuitive in equal measure.",
		planet: "Neptune+Mercury",
		element: "Water/Air",
		tarot: "",
		crystal: "Amethyst",
		color: "Purple"
	},
	26: {
		title: "Partnerships & Warning",
		keywords: "Business, partnerships, caution",
		meaning: "Success in partnerships but beware of wrong alliances. Must choose associates carefully. Business acumen with caution.",
		planet: "Saturn+Venus",
		element: "Earth",
		tarot: "",
		crystal: "Black Onyx",
		color: "Dark Blue"
	},
	27: {
		title: "The Commander",
		keywords: "Leadership, courage, authority, military",
		meaning: "Command and authority. Military and leadership energy. Courage to lead in any field. Strong willpower and determination.",
		planet: "Mars+Neptune",
		element: "Fire/Water",
		tarot: "",
		crystal: "Ruby, Garnet",
		color: "Red"
	},
	28: {
		title: "The Wealth Number",
		keywords: "Fortune, loss, gain, independence",
		meaning: "Great promise but with the risk of loss. Must be independent. Don't trust blindly. Fortune through self-reliance. Cristian's compound LP.",
		planet: "Sun+Saturn",
		element: "Fire/Earth",
		tarot: "",
		crystal: "Citrine, Tiger's Eye",
		color: "Gold, Royal Blue"
	},
	29: {
		title: "Grace Under Pressure",
		keywords: "Extremes, spiritual tests, resilience",
		meaning: "Number of extremes — great highs and lows. Spiritual tests. Must develop faith and inner strength.",
		planet: "Moon+Mars",
		element: "Water/Fire",
		tarot: "",
		crystal: "Labradorite",
		color: "Silver, Red"
	},
	30: {
		title: "The Loner Intellect",
		keywords: "Creative mind, wit, isolation risk",
		meaning: "Brilliant mind with creative genius. Risk of isolation. Must balance solitude with social connection.",
		planet: "Jupiter+Sun",
		element: "Fire/Air",
		tarot: "",
		crystal: "Yellow Sapphire",
		color: "Yellow"
	},
	31: {
		title: "The Hermit",
		keywords: "Solitude, self-reliance, determination",
		meaning: "Similar to 13 but less karmic. Self-made success through determination. May prefer working alone.",
		planet: "Jupiter+Sun",
		element: "Earth/Fire",
		tarot: "",
		crystal: "Smoky Quartz",
		color: "Brown, Grey"
	},
	32: {
		title: "The Communicator",
		keywords: "Communication, magnetism, public success",
		meaning: "Magnetic communicator. Success through words, media, and public speaking. Natural charm.",
		planet: "Jupiter+Moon",
		element: "Air/Water",
		tarot: "",
		crystal: "Blue Lace Agate",
		color: "Light Blue"
	},
	33: {
		title: "Master Teacher",
		keywords: "Compassion, healing, selfless service",
		meaning: "The highest master number in common use. The Master Teacher. Christ consciousness. Healing through love and service.",
		planet: "Venus (higher octave)",
		element: "Light/Water",
		tarot: "",
		crystal: "Rose Quartz, Diamond",
		color: "Pink, White"
	}
};
var ATBASH_MAP = {};
for (let i = 0; i < 26; i++) {
	const from = String.fromCharCode(65 + i);
	ATBASH_MAP[from] = String.fromCharCode(90 - i);
}
//#endregion
export { calcDateEnergy as a, calcPersonalYear as c, calcUniversalYear as d, dayNumber as f, reduce as h, calcCoreNumbers as i, calcUniversalDay as l, pythagoreanValue as m, NUMBER_MEANINGS_FULL as n, calcPersonalDay as o, digitSum as p, calcCompatibility as r, calcPersonalMonth as s, LUCKY_COLORS as t, calcUniversalMonth as u };
