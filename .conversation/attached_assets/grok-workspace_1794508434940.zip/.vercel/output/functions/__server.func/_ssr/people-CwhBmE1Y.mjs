import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as rankCatalog, b as pairRead, f as fullName, g as matrixNumbers, h as matrixChinese, n as rid, r as useLife } from "./router-Da7lqNNo.mjs";
import { a as Tag, r as Page, t as Card } from "./kit-sB4xIagL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/people-CwhBmE1Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PeoplePage() {
	const { profile, family, setFamily, lookups, setLookups } = useLife();
	const you = {
		name: fullName(profile) || "You",
		year: profile.year,
		month: profile.month,
		day: profile.day
	};
	const [other, setOther] = (0, import_react.useState)({
		name: "",
		year: "1990",
		month: "1",
		day: "1"
	});
	const [rel, setRel] = (0, import_react.useState)("Family");
	const [look, setLook] = (0, import_react.useState)({
		kind: "Brand",
		name: "",
		year: "2000",
		month: "1",
		day: "1"
	});
	const pair = other.name.trim() ? pairRead(you, {
		name: other.name.trim(),
		year: +other.year,
		month: +other.month,
		day: +other.day
	}) : null;
	const countries = (0, import_react.useMemo)(() => rankCatalog(profile, "Country"), [profile]);
	const cities = (0, import_react.useMemo)(() => rankCatalog(profile, "City"), [profile]);
	const brands = (0, import_react.useMemo)(() => rankCatalog(profile, "Brand"), [profile]);
	const cars = (0, import_react.useMemo)(() => rankCatalog(profile, "Car"), [profile]);
	const schools = (0, import_react.useMemo)(() => rankCatalog(profile, "School"), [profile]);
	function addFamily() {
		if (!other.name.trim()) return;
		const person = {
			id: rid(),
			name: other.name.trim(),
			relation: rel,
			year: +other.year,
			month: +other.month,
			day: +other.day
		};
		setFamily([person, ...family]);
	}
	function addLookup() {
		if (!look.name.trim()) return;
		setLookups([{
			id: rid(),
			kind: look.kind,
			name: look.name.trim(),
			year: +look.year,
			month: +look.month,
			day: +look.day
		}, ...lookups]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		kicker: "Compatibility",
		title: "People, places, brands",
		lede: "Any birthdate against any birthdate. Family stays on this device. Countries, cities, brands, cars, and schools are ranked from a founding or birth date against your chart.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-3",
					children: "Two dates"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mb-3",
					children: [
						"You: ",
						you.name,
						", ",
						you.month,
						"/",
						you.day,
						"/",
						you.year
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-4 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rounded-lg border border-border bg-background px-3 py-2 text-sm sm:col-span-2",
							placeholder: "Their name",
							value: other.name,
							onChange: (e) => setOther({
								...other,
								name: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
							value: other.year,
							onChange: (e) => setOther({
								...other,
								year: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
								value: other.month,
								onChange: (e) => setOther({
									...other,
									month: e.target.value
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
								value: other.day,
								onChange: (e) => setOther({
									...other,
									day: e.target.value
								})
							})]
						})
					]
				}),
				pair && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl text-primary",
						children: pair.score
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1 text-sm text-muted-foreground",
						children: pair.lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: l }, l))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2 items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
						value: rel,
						onChange: (e) => setRel(e.target.value),
						placeholder: "Relation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: addFamily,
						className: "rounded-lg border border-border px-3 py-2 text-sm",
						children: "Save to family"
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg mb-3",
				children: "Family tree"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-3",
				children: [family.map((p) => {
					const r = pairRead(you, p);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-start justify-between gap-2 border-b border-border pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-foreground",
							children: [
								p.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["· ", p.relation]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								p.month,
								"/",
								p.day,
								"/",
								p.year,
								" · ",
								r.lines[0],
								" · ",
								r.lines[1]
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
								tone: r.score >= 70 ? "good" : r.score < 50 ? "bad" : "neutral",
								children: r.score
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "text-xs text-destructive",
								onClick: () => setFamily(family.filter((x) => x.id !== p.id)),
								children: "Remove"
							})]
						})]
					}, p.id);
				}), !family.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted-foreground",
					children: "No one saved yet."
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-3",
					children: "Look up a founding date"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-5 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
							value: look.kind,
							onChange: (e) => setLook({
								...look,
								kind: e.target.value
							}),
							children: [
								"Company",
								"Team",
								"Brand",
								"City",
								"Country",
								"Person",
								"Car",
								"School"
							].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: k }, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rounded-lg border border-border bg-background px-3 py-2 text-sm sm:col-span-2",
							placeholder: "Name",
							value: look.name,
							onChange: (e) => setLook({
								...look,
								name: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
							value: look.year,
							onChange: (e) => setLook({
								...look,
								year: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
								value: look.month,
								onChange: (e) => setLook({
									...look,
									month: e.target.value
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
								value: look.day,
								onChange: (e) => setLook({
									...look,
									day: e.target.value
								})
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: addLookup,
					className: "mt-3 rounded-lg bg-primary text-primary-foreground px-3 py-2 text-sm",
					children: "Save lookup"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: lookups.map((l) => {
						const r = pairRead(you, l);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								l.kind,
								" · ",
								l.name,
								" · ",
								r.score,
								" · ",
								r.lines[0]
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "text-xs text-destructive shrink-0",
								onClick: () => setLookups(lookups.filter((x) => x.id !== l.id)),
								children: "Remove"
							})]
						}, l.id);
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rank, {
				title: "Friendliest countries",
				rows: countries
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rank, {
				title: "Friendliest cities",
				rows: cities
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rank, {
				title: "Brands",
				rows: brands
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rank, {
				title: "Cars",
				rows: cars
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rank, {
				title: "Schools",
				rows: schools
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Chinese matrix"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mb-2",
					children: "Friend is the trine. Enemy is the clash. Cat is Rabbit."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
						className: "text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: matrixChinese().map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: row.map((cell) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: `border border-border px-1 py-1 ${cell.rel === "enemy" ? "text-destructive" : cell.rel === "friend" || cell.rel === "same" ? "text-primary" : "text-muted-foreground"}`,
							title: `${cell.a} ${cell.b} ${cell.rel}${cell.secret ? " " + cell.secret : ""}`,
							children: cell.rel === "same" ? "·" : cell.rel === "friend" ? "F" : cell.rel === "enemy" ? "E" : "·"
						}, cell.b)) }, i)) })
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg mb-2",
				children: "Number matrix, 1–9"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
					className: "text-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: matrixNumbers().map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: row.map((cell) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: `border border-border px-2 py-1 ${cell.rel === "enemy" || cell.rel === "worst" ? "text-destructive" : cell.rel === "friend" || cell.rel === "soulmate" || cell.rel === "same" ? "text-primary" : "text-muted-foreground"}`,
						children: [
							cell.a,
							"/",
							cell.b,
							" ",
							cell.rel
						]
					}, cell.b)) }, row[0].a)) })
				})
			})] })
		]
	});
}
function Rank({ title, rows }) {
	const top = rows.slice(0, 3);
	const low = [...rows].slice(-3).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-lg mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid sm:grid-cols-2 gap-4 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-wider text-primary mb-1",
			children: "Closest"
		}), top.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			r.name,
			" · ",
			r.score,
			" · ",
			r.note
		] }, r.name))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-wider text-destructive mb-1",
			children: "Furthest"
		}), low.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			r.name,
			" · ",
			r.score,
			" · ",
			r.note
		] }, r.name))] })]
	})] });
}
var SplitComponent = PeoplePage;
//#endregion
export { SplitComponent as component };
