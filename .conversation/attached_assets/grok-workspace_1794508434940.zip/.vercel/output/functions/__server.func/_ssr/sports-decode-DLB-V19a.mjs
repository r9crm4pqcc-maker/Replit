import { h as reduce, m as pythagoreanValue, p as digitSum$1 } from "./numerology-tNoiBxGA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sports-decode-DLB-V19a.js
function reduceMaster(n) {
	return reduce(Math.abs(n));
}
var digitSum = digitSum$1;
function nameNumber(name) {
	return pythagoreanValue(name);
}
function lifePath(year, month, day) {
	const all = `${year}${month}${day}`.split("").reduce((a, c) => a + Number(c), 0);
	return {
		compound: all,
		reduced: reduceMaster(all)
	};
}
var WESTERN = [
	{
		sign: "Capricorn",
		element: "Earth",
		start: [12, 22]
	},
	{
		sign: "Aquarius",
		element: "Air",
		start: [1, 20]
	},
	{
		sign: "Pisces",
		element: "Water",
		start: [2, 19]
	},
	{
		sign: "Aries",
		element: "Fire",
		start: [3, 21]
	},
	{
		sign: "Taurus",
		element: "Earth",
		start: [4, 20]
	},
	{
		sign: "Gemini",
		element: "Air",
		start: [5, 21]
	},
	{
		sign: "Cancer",
		element: "Water",
		start: [6, 21]
	},
	{
		sign: "Leo",
		element: "Fire",
		start: [7, 23]
	},
	{
		sign: "Virgo",
		element: "Earth",
		start: [8, 23]
	},
	{
		sign: "Libra",
		element: "Air",
		start: [9, 23]
	},
	{
		sign: "Scorpio",
		element: "Water",
		start: [10, 23]
	},
	{
		sign: "Sagittarius",
		element: "Fire",
		start: [11, 22]
	}
];
function westernSign(month, day) {
	for (let i = WESTERN.length - 1; i >= 0; i--) {
		const w = WESTERN[i];
		if (month > w.start[0] || month === w.start[0] && day >= w.start[1]) return {
			sign: w.sign,
			element: w.element
		};
	}
	return WESTERN[0];
}
var SIGNS_LIST = WESTERN.slice().sort((a, b) => a.start[0] * 100 + a.start[1] - (b.start[0] * 100 + b.start[1])).map((s) => s.sign);
var MOON_REF = Date.UTC(2e3, 0, 6) / 864e5;
var SIDEREAL = 27.3216615;
function moonSign(year, month, day) {
	const elapsed = ((Date.UTC(year, month - 1, day) / 864e5 - MOON_REF) % SIDEREAL + SIDEREAL) % SIDEREAL;
	return SIGNS_LIST[Math.floor(elapsed / SIDEREAL * 12) % 12];
}
var ANIMAL_YEAR = [
	"Rat",
	"Ox",
	"Tiger",
	"Rabbit",
	"Dragon",
	"Snake",
	"Horse",
	"Goat",
	"Monkey",
	"Rooster",
	"Dog",
	"Pig"
];
function chineseYear(year, month, day) {
	return ANIMAL_YEAR[(((month < 2 || month === 2 && day < 4 ? year - 1 : year) - 2020) % 12 + 12) % 12];
}
var MONTH_TABLE = [
	{
		startM: 2,
		startD: 4,
		animal: "Tiger"
	},
	{
		startM: 3,
		startD: 6,
		animal: "Rabbit"
	},
	{
		startM: 4,
		startD: 5,
		animal: "Dragon"
	},
	{
		startM: 5,
		startD: 6,
		animal: "Snake"
	},
	{
		startM: 6,
		startD: 6,
		animal: "Horse"
	},
	{
		startM: 7,
		startD: 7,
		animal: "Goat"
	},
	{
		startM: 8,
		startD: 8,
		animal: "Monkey"
	},
	{
		startM: 9,
		startD: 8,
		animal: "Rooster"
	},
	{
		startM: 10,
		startD: 8,
		animal: "Dog"
	},
	{
		startM: 11,
		startD: 7,
		animal: "Pig"
	},
	{
		startM: 12,
		startD: 7,
		animal: "Rat"
	},
	{
		startM: 1,
		startD: 6,
		animal: "Ox"
	}
];
function chineseMonth(month, day) {
	let current = "Ox";
	for (const row of MONTH_TABLE) {
		const m = row.startM, d = row.startD;
		if (month > m || month === m && day >= d) current = row.animal;
	}
	if (month === 1 && day < 6) current = "Rat";
	if (month === 1 && day >= 6) current = "Ox";
	if (month === 2 && day < 4) current = "Ox";
	return current;
}
function julianDay(y, m, d) {
	const a = Math.floor((14 - m) / 12);
	const yr = y + 4800 - a;
	const mo = m + 12 * a - 3;
	return d + Math.floor((153 * mo + 2) / 5) + 365 * yr + Math.floor(yr / 4) - Math.floor(yr / 100) + Math.floor(yr / 400) - 32045;
}
function chineseDay(year, month, day) {
	return ANIMAL_YEAR[((julianDay(year, month, day) + 1) % 12 + 12) % 12];
}
function chineseHour(hour24) {
	const shifted = (hour24 + 1) % 24;
	return ANIMAL_YEAR[Math.floor(shifted / 2)];
}
var LUNAR_BIAS = {
	"New Moon": {
		bias: "FAVORITES",
		note: "Fresh starts favor the chalk"
	},
	"Waxing Crescent": {
		bias: "FAVORITES",
		note: "Building momentum stays with favorites"
	},
	"First Quarter": {
		bias: "FAVORITES",
		note: "Decisive energy backs favorites"
	},
	"Waxing Gibbous": {
		bias: "SLIGHT UNDERDOGS",
		note: "Subtle shift — underdog line value"
	},
	"Full Moon": {
		bias: "UNDERDOGS",
		note: "Maximum chaos — underdogs strike"
	},
	"Waning Gibbous": {
		bias: "UNDERDOGS",
		note: "Release phase keeps underdogs alive"
	},
	"Last Quarter": {
		bias: "UNDERDOGS",
		note: "Surrender energy — dogs hit"
	},
	"Waning Crescent": {
		bias: "FAVORITES",
		note: "Reset to order — favorites again"
	}
};
function moonPhase(year, month, day) {
	const ref = Date.UTC(2e3, 0, 6) / 864e5;
	const cycle = ((Date.UTC(year, month - 1, day) / 864e5 - ref) % 29.53059 + 29.53059) % 29.53059;
	let phase;
	if (cycle < 1.85) phase = "New Moon";
	else if (cycle < 7.38) phase = "Waxing Crescent";
	else if (cycle < 9.22) phase = "First Quarter";
	else if (cycle < 14.77) phase = "Waxing Gibbous";
	else if (cycle < 16.61) phase = "Full Moon";
	else if (cycle < 22.15) phase = "Waning Gibbous";
	else if (cycle < 23.99) phase = "Last Quarter";
	else phase = "Waning Crescent";
	const meta = LUNAR_BIAS[phase];
	return {
		phase,
		waxing: cycle < 14.765,
		bias: meta.bias,
		biasNote: meta.note
	};
}
//#endregion
export { digitSum as a, moonSign as c, westernSign as d, chineseYear as i, nameNumber as l, chineseHour as n, lifePath as o, chineseMonth as r, moonPhase as s, chineseDay as t, reduceMaster as u };
