import { i as __toESM } from "../_runtime.mjs";
import { n as NUMBER_MEANINGS_FULL } from "./numerology-tNoiBxGA.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as nameVowelReading, c as buildChart, r as useLife, s as animalLabel } from "./router-Da7lqNNo.mjs";
import { a as Tag, i as Stat, n as CardTitle, r as Page, t as Card } from "./kit-sB4xIagL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chart-cQGc7-so.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useNow() {
	const [now, setNow] = (0, import_react.useState)({
		y: 2026,
		m: 11,
		d: 4
	});
	(0, import_react.useEffect)(() => {
		const t = /* @__PURE__ */ new Date();
		setNow({
			y: t.getFullYear(),
			m: t.getMonth() + 1,
			d: t.getDate()
		});
	}, []);
	return now;
}
function ChartPage() {
	const { profile, setProfile, ready } = useLife();
	const now = useNow();
	const chart = buildChart(profile, now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		kicker: "Core engine",
		title: chart.name || "Your chart",
		lede: "Everything here is calculated from one birthdate. Add a clock time for the hour pillar and a rising estimate.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex gap-2 overflow-x-auto pb-1 text-xs",
				children: [
					"edit",
					"life",
					"birthday",
					"year",
					"chinese",
					"western",
					"vedic",
					"enemy",
					"lucky",
					"name"
				].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `#${id}`,
					className: "shrink-0 rounded-full border border-border px-3 py-1 text-muted-foreground hover:text-primary capitalize",
					children: id
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "edit",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Birth data" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileForm, {
				profile,
				onSave: setProfile
			}, ready ? "set" : "boot")] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "life",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Life path" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Life path",
							value: `${chart.lifePath.compound}/${chart.lifePath.reduced}`,
							hint: chart.meaning?.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Compound",
							value: String(chart.core.lifePathCompound),
							hint: "Month + day + year, each reduced, then summed."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Planet",
							value: chart.core.planet,
							hint: chart.meaning?.keywords
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-3 leading-relaxed",
					children: chart.meaning?.meaning
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "birthday",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Birthday number" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "Birthday",
				value: `${chart.birthday.compound}/${chart.birthday.reduced}`,
				hint: NUMBER_MEANINGS_FULL[chart.birthday.reduced]?.meaning
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "year",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Personal year" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid sm:grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Personal year",
						value: `${chart.py.compound}/${chart.py.reduced}`,
						hint: NUMBER_MEANINGS_FULL[chart.py.reduced]?.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Cycle starts",
						value: chart.cycleStart,
						hint: "The morning of your birthday."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Cycle ends",
						value: chart.cycleEnd,
						hint: "The day before the next birthday."
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "chinese",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Chinese animal" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Year",
						value: animalLabel(chart.yearAnimal),
						hint: "The year animal."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Month",
						value: animalLabel(chart.birthMonthAnimal),
						hint: `Personal month ${chart.birthPersonalMonth.reduced}. The 9 is the personal month. The animal is separate.`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Day",
						value: animalLabel(chart.dayAnimal),
						hint: "The day animal of the birth date."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Hour",
						value: chart.hour ? animalLabel(chart.hour) : "Add a time",
						hint: chart.hourDaylight ? `Clock ${profile.time} is daylight time. Standard time is ${chart.hourStandard}, and that is the hour.` : "Two-hour pillar from standard time."
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "western",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Western chart" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Sun",
							value: `${chart.sun} · ${chart.sunElement}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Moon",
							value: chart.tropicalMoon,
							hint: "Approximate from the lunar cycle. Not a full ephemeris."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Rising",
							value: chart.rise?.sign ?? "Add a birth time",
							hint: "Solar-time estimate. Place is saved, not used as longitude."
						})
					]
				}),
				chart.rise && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 sm:grid-cols-3 gap-2 mt-4",
					children: chart.rise.houses.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"House ",
								h.house,
								" · ",
								h.name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-foreground",
							children: h.sign
						})]
					}, h.house))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "vedic",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Vedic chart" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mb-3",
					children: "Lahiri-style shift of about 24°. Sun and moon longitudes are approximations from the date, not a Swiss ephemeris."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Sidereal sun",
							value: chart.vedicSun
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Sidereal moon",
							value: chart.vedicMoon
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Nakshatra",
							value: chart.nakshatra,
							hint: "From the approximate sidereal moon."
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "enemy",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Enemy months and hours" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mb-3",
					children: [
						"A month is an enemy when its Chinese animal clashes with your birth month, the ",
						animalLabel(chart.birthMonthAnimal),
						". Your sun is ",
						chart.sun,
						", so the opposite sign is hard and the other signs of the same element are friendly. The personal month number is only how to move. It does not make a month a friend or an enemy."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2 mb-4",
					children: chart.months.map((mo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
						tone: mo.enemy ? "bad" : mo.earth === "friend" ? "good" : "neutral",
						children: [
							[
								"Jan",
								"Feb",
								"Mar",
								"Apr",
								"May",
								"Jun",
								"Jul",
								"Aug",
								"Sep",
								"Oct",
								"Nov",
								"Dec"
							][mo.month - 1],
							" ",
							animalLabel(mo.animal),
							" ",
							mo.enemy ? "enemy" : mo.earth,
							mo.west === "enemy" ? ` · ${mo.sun} hard` : mo.west === "friend" ? ` · ${mo.sun} friendly` : "",
							` · move ${mo.personalMonth.reduced}`
						]
					}, mo.month))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: chart.hours.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
						tone: h.enemy ? "bad" : h.rel === "friend" ? "good" : "neutral",
						children: [
							h.label,
							" ",
							animalLabel(h.sign),
							h.enemy ? " · enemy" : ""
						]
					}, h.label))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "lucky",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Lucky numbers" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-foreground",
					children: "99, 98, 28, 8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: [
						"Colors for the life path: ",
						chart.colors.primary,
						" and ",
						chart.colors.secondary,
						"."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Name" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-3",
					children: "A vowel is the inner sound of the name. The number on the vowel is what that letter is doing."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 text-sm",
					children: (() => {
						const read = nameVowelReading(profile);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [read.rows.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: row.letter
								}),
								" in ",
								row.word,
								" is ",
								row.n,
								". ",
								row.meaning
							]
						}, `${row.word}-${row.letter}-${i}`)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-muted-foreground",
							children: [
								"The vowels add to ",
								read.total,
								read.total === read.reduced ? "" : `, which keeps ${read.reduced}`,
								"."
							]
						})] });
					})()
				})
			] })
		]
	});
}
function ProfileForm({ profile, onSave }) {
	const [form, setForm] = (0, import_react.useState)(profile);
	const [msg, setMsg] = (0, import_react.useState)("");
	const set = (k, v) => setForm((f) => ({
		...f,
		[k]: v
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid sm:grid-cols-2 gap-3",
		onSubmit: (e) => {
			e.preventDefault();
			const year = +form.year, month = +form.month, day = +form.day;
			if (!form.firstName.trim() || month < 1 || month > 12 || day < 1 || day > 31 || year < 1800 || year > 2200) {
				setMsg("Check the name and the date.");
				return;
			}
			onSave({
				...form,
				firstName: form.firstName.trim(),
				year,
				month,
				day,
				time: String(form.time || ""),
				place: form.place
			});
			setMsg("Saved on this device.");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "First",
				value: form.firstName,
				onChange: (v) => set("firstName", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Middle",
				value: form.middleName,
				onChange: (v) => set("middleName", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Last",
				value: form.lastName,
				onChange: (v) => set("lastName", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Place",
				value: form.place,
				onChange: (v) => set("place", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Year",
				value: String(form.year),
				onChange: (v) => set("year", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Month",
				value: String(form.month),
				onChange: (v) => set("month", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Day",
				value: String(form.day),
				onChange: (v) => set("day", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Time (24h)",
				value: form.time,
				onChange: (v) => set("time", v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sm:col-span-2 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "rounded-lg bg-primary text-primary-foreground px-4 py-2 text-sm font-medium",
					children: "Save chart"
				}), msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: msg
				})]
			})
		]
	});
}
function Field({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs text-muted-foreground",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground"
		})]
	});
}
var SplitComponent = ChartPage;
//#endregion
export { SplitComponent as component };
