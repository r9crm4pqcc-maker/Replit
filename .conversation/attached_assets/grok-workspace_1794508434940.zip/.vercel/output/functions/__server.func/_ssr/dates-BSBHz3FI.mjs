import { t as DatesPage } from "./dates-uPVY2408.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dates-BSBHz3FI.js
var SplitComponent = DatesPage;
//#endregion
export { SplitComponent as component };
