import { t as SoccerAIPage } from "./soccer-ai-CrMOYICB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/soccer-ai._-B4fRsRDJ.js
var SplitComponent = SoccerAIPage;
//#endregion
export { SplitComponent as component };
