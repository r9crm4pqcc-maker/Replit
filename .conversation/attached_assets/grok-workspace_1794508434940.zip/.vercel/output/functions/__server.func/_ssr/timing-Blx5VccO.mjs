import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as scanMonth, a as GOALS, k as yearWindows, r as useLife, u as daysInMonth, v as openOn } from "./router-Da7lqNNo.mjs";
import { r as Page, t as Card } from "./kit-sB4xIagL.mjs";
import { t as Link$1 } from "./wouter-CfVlts7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/timing-Blx5VccO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TimingPage() {
	const { profile } = useLife();
	const [goal, setGoal] = (0, import_react.useState)("money");
	const [cursor, setCursor] = (0, import_react.useState)({
		y: 2026,
		m: 11
	});
	const [item, setItem] = (0, import_react.useState)("cleats");
	const [from, setFrom] = (0, import_react.useState)({
		y: 2026,
		m: 11,
		d: 4
	});
	(0, import_react.useEffect)(() => {
		const t = /* @__PURE__ */ new Date();
		const now = {
			y: t.getFullYear(),
			m: t.getMonth() + 1,
			d: t.getDate()
		};
		setCursor({
			y: now.y,
			m: now.m
		});
		setFrom(now);
	}, []);
	const month = scanMonth(profile, cursor.y, cursor.m, goal);
	const windows = yearWindows(profile, cursor.y, goal);
	const opened = openOn(profile, item, from);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		kicker: "Goal timing",
		title: "Best days",
		lede: "Pick a goal, scan a month, then look at the strongest windows in the year. Scores are 0–10 from your chart. They are not odds.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: GOALS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setGoal(g.id),
					className: `rounded-full border px-3 py-1 text-xs ${goal === g.id ? "border-primary text-primary" : "border-border text-muted-foreground"}`,
					children: g.label
				}, g.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 mb-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "text-sm text-primary",
							onClick: () => setCursor((c) => c.m === 1 ? {
								y: c.y - 1,
								m: 12
							} : {
								...c,
								m: c.m - 1
							}),
							children: "Prev"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-lg",
							children: [
								cursor.m,
								"/",
								cursor.y
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "text-sm text-primary",
							onClick: () => setCursor((c) => c.m === 12 ? {
								y: c.y + 1,
								m: 1
							} : {
								...c,
								m: c.m + 1
							}),
							children: "Next"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-7 gap-1",
					children: [Array.from({ length: new Date(Date.UTC(cursor.y, cursor.m - 1, 1)).getUTCDay() }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `b${i}`)), month.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$1, {
						href: `/day/${day.read.iso}`,
						className: "rounded-md border border-border p-1 text-center hover:border-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-foreground",
							children: day.d
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `text-sm font-semibold ${day.score >= 7 ? "text-primary" : day.score <= 3 ? "text-destructive" : "text-muted-foreground"}`,
							children: day.score
						})]
					}, day.d))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground mt-2",
					children: [daysInMonth(cursor.y, cursor.m), " days. 7 and above is a strong window."]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-lg mb-2",
				children: ["Strongest windows in ", cursor.y]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-2 text-sm",
				children: [windows.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: `/day/${w.iso}`,
						className: "text-foreground hover:text-primary",
						children: w.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-primary",
						children: [
							w.score,
							"/10 · ",
							w.reasons.slice(0, 2).join(", ")
						]
					})]
				}, w.iso)), !windows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-muted-foreground",
					children: "No day cleared 7 this year for that goal. Use the month grid and take the highest."
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Lucky-number actions"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Use a day whose personal number matches a primary lucky number when you wear the number, price something, or put it on a jersey."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm mt-2",
					children: "Match the personal day to a primary lucky number on your chart when the goal score on that date is 7 or higher."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Open this on a day"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-3",
					children: "Cleats, a jersey, a website, a shop. The name is numbered, then the next friendly days are listed. Fatal dates and 9-days are skipped."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: item,
					onChange: (e) => setItem(e.target.value),
					className: "w-full rounded-lg border border-border bg-background px-3 py-2 text-sm",
					placeholder: "cleats, jersey, website"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground mt-2",
					children: [
						"Name number ",
						opened.number.compound,
						"/",
						opened.number.reduced
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm",
					children: [opened.hits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: `/day/${h.iso}`,
						className: "text-primary",
						children: h.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [" — ", h.why]
					})] }, h.iso)), !opened.hits.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-muted-foreground",
						children: "No friendly day in the next 200 days. Try another name."
					})]
				})
			] })
		]
	});
}
var SplitComponent = TimingPage;
//#endregion
export { SplitComponent as component };
