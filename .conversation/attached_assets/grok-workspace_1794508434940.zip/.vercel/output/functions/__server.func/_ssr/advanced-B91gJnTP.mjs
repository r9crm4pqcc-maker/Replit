import { i as __toESM } from "../_runtime.mjs";
import { r as colorsForDay } from "./colorology-kzI1lXuK.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as rankCatalog, S as pricesToEight, T as saturnNote, c as buildChart, d as dreamRead, i as DIRECTION, l as careerFor, p as healthFor, r as useLife } from "./router-Da7lqNNo.mjs";
import { i as Stat, r as Page, t as Card } from "./kit-sB4xIagL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/advanced-B91gJnTP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdvancedPage() {
	const { profile } = useLife();
	const [now, setNow] = (0, import_react.useState)({
		y: 2026,
		m: 11,
		d: 4
	});
	const [dream, setDream] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("100");
	const [ack, setAck] = (0, import_react.useState)(false);
	const [concept, setConcept] = (0, import_react.useState)({
		year: "",
		month: "",
		day: "",
		time: ""
	});
	(0, import_react.useEffect)(() => {
		const t = /* @__PURE__ */ new Date();
		setNow({
			y: t.getFullYear(),
			m: t.getMonth() + 1,
			d: t.getDate()
		});
		setAck(localStorage.getItem("life-manifest-ack") === "yes");
		const saved = localStorage.getItem("life-conception-v1");
		if (saved) try {
			setConcept(JSON.parse(saved));
		} catch {}
	}, []);
	const chart = buildChart(profile, now);
	const saturn = saturnNote(profile, now.y, now.m, now.d);
	const dayColors = colorsForDay(chart.py.reduced, 5);
	const dreamOut = dream.trim() ? dreamRead(dream) : null;
	const prices = pricesToEight(+price || 0);
	const places = rankCatalog(profile, "City").slice(0, 5);
	const countries = rankCatalog(profile, "Country").slice(0, 3);
	const cars = rankCatalog(profile, "Car");
	const schools = rankCatalog(profile, "School");
	const career = careerFor(chart.lifePath.reduced);
	const health = healthFor(chart.lifePath.reduced, chart.sun);
	const conception = concept.year && concept.month && concept.day ? buildChart({
		...profile,
		year: +concept.year,
		month: +concept.month,
		day: +concept.day,
		time: concept.time || profile.time
	}, now) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		kicker: "Advanced",
		title: "The deeper layer",
		lede: "Saturn, color, dreams, conception pillars, manifestation as a tradition, prices that reduce to 8, where to be, career, and health correspondences. Health notes are not a diagnosis.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Saturn season and eclipses"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-2 gap-3 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Age",
						value: String(saturn.age)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Eclipse house",
						value: saturn.eclipseHouse ? `House ${saturn.eclipseHouse}` : "Add a birth time",
						hint: "Whole-sign house of today's sun from the rising estimate."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "text-sm text-muted-foreground space-y-1",
					children: saturn.lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: l }, l))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground mt-2",
					children: [saturn.saturnNumbers, " Eclipse dates are a 2024–2028 catalog, not a live astronomy feed."]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Power colors"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"Life path colors: ",
						chart.colors.primary,
						", ",
						chart.colors.secondary,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: [
						"For personal year ",
						chart.py.reduced,
						": wear ",
						dayColors.best.map((c) => c.name).join(", ") || "gold",
						"."
					]
				}),
				dayColors.avoid.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: [
						"Leave aside: ",
						dayColors.avoid.map((c) => c.name).join(", "),
						"."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Dream reading"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: dream,
					onChange: (e) => setDream(e.target.value),
					rows: 4,
					className: "w-full rounded-lg border border-border bg-background px-3 py-2 text-sm",
					placeholder: "Write the dream in a few sentences."
				}),
				dreamOut && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm mt-3 leading-relaxed",
					children: [
						dreamOut.reading,
						" (",
						dreamOut.letters,
						" letters.)"
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Conception pillars"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mb-2",
					children: "Optional. Year, month, and hour of a conception date, read with the same animal rules. This is not a medical record."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2",
					children: [
						"year",
						"month",
						"day",
						"time"
					].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						placeholder: k,
						value: concept[k],
						onChange: (e) => setConcept({
							...concept,
							[k]: e.target.value
						}),
						className: "rounded-lg border border-border bg-background px-2 py-2 text-sm"
					}, k))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "mt-2 text-sm text-primary",
					onClick: () => localStorage.setItem("life-conception-v1", JSON.stringify(concept)),
					children: "Save conception date"
				}),
				conception && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm mt-3",
					children: [
						"Year ",
						conception.yearAnimal,
						" · month ",
						conception.birthMonthAnimal,
						" · hour ",
						conception.hour ?? "no time",
						" · life path ",
						conception.lifePath.compound,
						"/",
						conception.lifePath.reduced,
						"."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Manifestation toolkit"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex gap-2 text-sm items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: ack,
						onChange: (e) => {
							setAck(e.target.checked);
							localStorage.setItem("life-manifest-ack", e.target.checked ? "yes" : "no");
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I understand these are traditional methods. They are not a promise of money, health, or outcomes." })]
				}),
				ack && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Water: write one aim. On a 28-day or a master day, read it once over a glass of water and drink it. Then do the practical step the same day." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "28 and 33: use those dates for the ask, not for wishing. 28 is the wealth compound in this chart. 33 is the teacher number — offer something, do not only take." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Gold: hold or wear gold on an 8-day or a wealth day while you price the work. Gold is a reminder, not a charm that replaces the invoice." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Diamonds: on an 11, 22, or 33 day, write the one clear sentence. Cut the rest. Clarity is the method." })
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Lucky prices"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-2",
					children: "Prices whose digits reduce to 8. Marketing tradition in this system, not a sales guarantee."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: price,
					onChange: (e) => setPrice(e.target.value),
					className: "rounded-lg border border-border bg-background px-3 py-2 text-sm w-32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm mt-2",
					children: prices.join(", ") || "Enter a number."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Where to live, which car, which school"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"Favorable direction from your year animal: ",
						DIRECTION[chart.yearAnimal],
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: [
						"Closest cities: ",
						places.map((p) => `${p.name} (${p.score})`).join(", "),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: [
						"Closest countries: ",
						countries.map((p) => `${p.name} (${p.score})`).join(", "),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: [
						"Cars, closest first: ",
						cars.map((p) => `${p.name} ${p.score}`).join(" · "),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: [
						"Schools: ",
						schools.map((p) => `${p.name} ${p.score}`).join(" · "),
						"."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: career.paths
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: ["Challenge: ", career.challenge]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: [
						"Expression ",
						chart.core.expression,
						" wants the work to sound like ",
						chart.meaning?.keywords,
						"."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Health correspondences"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-destructive mb-2",
					children: "Traditional number and sign notes. Not medical advice. See a clinician for symptoms."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: health.number
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: health.element
				})
			] })
		]
	});
}
var SplitComponent = AdvancedPage;
//#endregion
export { SplitComponent as component };
