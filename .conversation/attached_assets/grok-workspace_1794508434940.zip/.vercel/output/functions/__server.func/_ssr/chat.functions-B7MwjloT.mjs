import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat.functions-B7MwjloT.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MODULE_PROMPTS = {
	numerology: "You are a warm, conversational numerology guide. Speak like a knowledgeable friend — natural sentences, contractions, empathy. Cover life path, expression, soul urge, personality, birthday, karmic debt, personal year/month/day, master numbers (11/22/33) using Pythagorean reduction. Give practical, specific answers. Never refuse — always give a numerological read.",
	astrology: "You are a warm, conversational Western + Vedic astrologer. Natural, humanized, no jargon dumps. Cover sun/moon/rising, houses, aspects, transits, retrogrades, nodes, dashas when asked. Clear, specific interpretations. Never refuse.",
	tools: "You are a helpful decode assistant for gematria, tarot, matrix calendar, compatibility, forecasts, feng shui, bazi, chakra, and rife frequencies. Warm, humanized, conversational. Direct, specific answers.",
	sports: "You are a sports-decode expert blending numerology, astrology, Chinese zodiac and lunar cycles across NFL, NBA, MLB, NHL, MLS, EPL, World Cup. Warm, human tone. Walk through founded-date lifepath, day energy, lunar bias, and give a clear lean. Never refuse.",
	trading: "You are a market-decode expert (MarketCode). Blend numerology (universal day/month/year, master/karmic), Chinese four pillars, lunar phase/sign bias, planetary retrogrades, Gann geometry, and sector mapping. Warm and human. Clear directional bias, risk notes, sector picks. Never refuse."
};
var MAX_CHARS = 4e3;
var sendChat_createServerFn_handler = createServerRpc({
	id: "1f52bca271952cad5ff37d96814219878833f65591cf5b6efeb8abd49a80b0d9",
	name: "sendChat",
	filename: "src/lib/chat.functions.ts"
}, (opts) => sendChat.__executeServer(opts));
var sendChat = createServerFn({ method: "POST" }).inputValidator((data) => {
	const d = data;
	if (!d || !Array.isArray(d.messages)) throw new Error("messages required");
	return {
		messages: d.messages.slice(-16).map((m) => {
			return {
				role: m?.role === "assistant" ? "assistant" : "user",
				content: String(m?.content ?? "").slice(0, MAX_CHARS)
			};
		}),
		module: typeof d.module === "string" ? d.module.slice(0, 40) : "tools"
	};
}).handler(sendChat_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return { text: "AI chat is not available in this environment yet." };
	const system = MODULE_PROMPTS[data.module] ?? MODULE_PROMPTS.tools;
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 700,
			messages: [{
				role: "system",
				content: system
			}, ...data.messages]
		})
	});
	if (!res.ok) return { text: `AI is unavailable right now (${res.status}). Try again in a moment.` };
	return { text: (await res.json()).choices?.[0]?.message?.content ?? "" };
});
//#endregion
export { sendChat_createServerFn_handler };
