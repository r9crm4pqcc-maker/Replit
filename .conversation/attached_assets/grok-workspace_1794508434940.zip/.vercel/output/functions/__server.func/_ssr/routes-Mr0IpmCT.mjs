import { t as HomePage } from "./home-DIURO68c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Mr0IpmCT.js
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
