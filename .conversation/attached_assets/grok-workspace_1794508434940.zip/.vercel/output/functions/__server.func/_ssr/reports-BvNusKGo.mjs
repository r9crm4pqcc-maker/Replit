import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as seasonOf, K as signRelation, P as chineseMonthSign, c as buildChart, r as useLife, u as daysInMonth, w as readDay, y as padDate } from "./router-Da7lqNNo.mjs";
import { a as Tag, i as Stat, r as Page, t as Card } from "./kit-sB4xIagL.mjs";
import { t as Link$1 } from "./wouter-CfVlts7N.mjs";
import { n as useDailyPing } from "./home-DIURO68c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-BvNusKGo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReportsPage() {
	const { profile } = useLife();
	const [tab, setTab] = (0, import_react.useState)("day");
	const [cursor, setCursor] = (0, import_react.useState)({
		y: 2026,
		m: 11
	});
	const [today, setToday] = (0, import_react.useState)({
		y: 2026,
		m: 11,
		d: 4
	});
	const [ping, setPing] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const t = /* @__PURE__ */ new Date();
		const now = {
			y: t.getFullYear(),
			m: t.getMonth() + 1,
			d: t.getDate()
		};
		setToday(now);
		setCursor({
			y: now.y,
			m: now.m
		});
	}, []);
	const day = readDay(profile, today.y, today.m, today.d);
	useDailyPing(day.headline, day.iso);
	const chart = buildChart(profile, today);
	async function enablePing() {
		if (typeof Notification === "undefined") {
			setPing("This browser has no notifications.");
			return;
		}
		if (await Notification.requestPermission() !== "granted") {
			setPing("Notifications stayed off.");
			return;
		}
		localStorage.removeItem("life-ping");
		setPing("On. The daily line fires when you open the app.");
		try {
			new Notification("Life Code", { body: day.headline });
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		kicker: "Intelligence",
		title: "Daily, monthly, yearly",
		lede: "The daily line is the universal number over your personal number. Alerts fire in the browser when you open the app. There is no server pushing them while the app is closed.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					"day",
					"month",
					"year"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(t),
					className: `rounded-full border px-3 py-1 text-sm capitalize ${tab === t ? "border-primary text-primary" : "border-border text-muted-foreground"}`,
					children: t
				}, t))
			}),
			tab === "day" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: day.headline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-2",
					children: day.reading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 mt-3",
					children: [
						day.flags.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children: f }, f)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
							tone: day.earth === "enemy" ? "bad" : day.earth === "friend" ? "good" : "neutral",
							children: ["Earth ", day.earth]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
							tone: day.west === "enemy" ? "bad" : day.west === "friend" ? "good" : "neutral",
							children: ["Western ", day.west]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: enablePing,
					className: "mt-4 rounded-lg bg-primary text-primary-foreground px-4 py-2 text-sm",
					children: "Turn on the daily alert"
				}),
				ping && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-2",
					children: ping
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: `/day/${day.iso}`,
						className: "text-sm text-primary",
						children: "Full day page"
					})
				})
			] }),
			tab === "month" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 mb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-sm text-primary",
						onClick: () => setCursor((c) => c.m === 1 ? {
							y: c.y - 1,
							m: 12
						} : {
							...c,
							m: c.m - 1
						}),
						children: "Prev"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-lg",
						children: [
							padDate(cursor.m, 1).split(" ")[0],
							" ",
							cursor.y
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-sm text-primary",
						onClick: () => setCursor((c) => c.m === 12 ? {
							y: c.y + 1,
							m: 1
						} : {
							...c,
							m: c.m + 1
						}),
						children: "Next"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthBody, {
				profileYear: chart.yearAnimal,
				y: cursor.y,
				m: cursor.m,
				life: chart.lifePath.reduced,
				py: chart.py.reduced
			})] }),
			tab === "year" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 mb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-sm text-primary",
						onClick: () => setCursor((c) => ({
							...c,
							y: c.y - 1
						})),
						children: "Prev"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						children: cursor.y
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-sm text-primary",
						onClick: () => setCursor((c) => ({
							...c,
							y: c.y + 1
						})),
						children: "Next"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(YearBody, {
				y: cursor.y,
				profile,
				animal: chart.yearAnimal
			})] })
		]
	});
}
function MonthBody({ y, m, life, py, profileYear }) {
	const { profile } = useLife();
	const sample = readDay(profile, y, m, Math.min(15, daysInMonth(y, m)));
	const animal = chineseMonthSign(m, 15);
	const earth = signRelation(profileYear, animal);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid sm:grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Personal month",
						value: String(sample.personalMonth.reduced),
						hint: `Life path ${life} · personal year ${py}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Chinese month",
						value: animal,
						hint: `Versus your year animal: ${earth}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Western season",
						value: seasonOf(m, 15),
						hint: `Sun on the 15th is ${sample.sun}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-7 gap-1 text-center text-xs",
				children: [
					[
						"S",
						"M",
						"T",
						"W",
						"T",
						"F",
						"S"
					].map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-muted-foreground py-1",
						children: d
					}, d + i)),
					Array.from({ length: new Date(Date.UTC(y, m - 1, 1)).getUTCDay() }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `b${i}`)),
					Array.from({ length: daysInMonth(y, m) }, (_, i) => {
						const d = i + 1;
						const r = readDay(profile, y, m, d);
						const hot = r.tones.length > 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
							href: `/day/${r.iso}`,
							className: `rounded-md py-2 ${hot ? "bg-primary/15 text-primary" : "text-foreground"} ${r.earth === "enemy" ? "ring-1 ring-destructive/50" : ""}`,
							children: d
						}, d);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Highlighted days carry a date mark. A red ring means the Chinese month is an enemy — that applies all month once the animal has switched."
			})
		]
	});
}
function YearBody({ y, profile, animal }) {
	const rows = Array.from({ length: 12 }, (_, i) => {
		const m = i + 1;
		return {
			m,
			read: readDay(profile, y, m, 15),
			animal: chineseMonthSign(m, 15)
		};
	});
	const py = rows[0]?.read.personalYear;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid sm:grid-cols-3 gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Personal year",
					value: py ? `${py.compound}/${py.reduced}` : "—",
					hint: `Cycle year ${py?.cycleYear ?? ""}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Chinese year",
					value: animal,
					hint: "Your birth animal, scored against each month."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Universal year",
					value: String(rows[5]?.read.universalYear.reduced ?? "")
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-border text-sm",
			children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "py-2 flex flex-wrap justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: padDate(r.m, 1).split(" ")[0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground",
					children: [
						"PM ",
						r.read.personalMonth.reduced,
						" · ",
						r.animal,
						" · ",
						r.read.earth,
						" · ",
						seasonOf(r.m, 15)
					]
				})]
			}, r.m))
		})]
	});
}
var SplitComponent = ReportsPage;
//#endregion
export { SplitComponent as component };
