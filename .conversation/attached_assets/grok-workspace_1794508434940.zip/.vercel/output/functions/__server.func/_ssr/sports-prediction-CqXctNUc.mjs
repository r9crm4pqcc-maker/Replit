import { i as __toESM } from "../_runtime.mjs";
import { c as calcPersonalYear } from "./numerology-tNoiBxGA.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Calendar, S as CircleAlert, f as RefreshCw, g as LoaderCircle, y as Globe } from "../_libs/lucide-react.mjs";
import { A as SIGNS, B as healingood, F as chineseSign, G as runVotes, H as luckyNumber, I as compat, K as signRelation, L as dayOfYear, M as TEAM_COLORS, N as chineseDaySign, P as chineseMonthSign, R as fmt, U as numberRelation, V as lifePath, W as reduceNum, j as SPECIAL_NUMBERS, z as fmtMD } from "./router-Da7lqNNo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sports-prediction-CqXctNUc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MLB = {
	"Arizona Diamondbacks": {
		founded: [
			1998,
			3,
			31
		],
		city: "Phoenix",
		cityFounded: [
			1881,
			2,
			25
		],
		stadium: "Chase Field",
		stadiumOpened: [
			1998,
			3,
			31
		]
	},
	"Atlanta Braves": {
		founded: [
			1871,
			1,
			20
		],
		city: "Atlanta",
		cityFounded: [
			1847,
			12,
			29
		],
		stadium: "Truist Park",
		stadiumOpened: [
			2017,
			3,
			31
		]
	},
	"Baltimore Orioles": {
		founded: [
			1954,
			4,
			13
		],
		city: "Baltimore",
		cityFounded: [
			1729,
			7,
			30
		],
		stadium: "Oriole Park at Camden Yards",
		stadiumOpened: [
			1992,
			4,
			6
		]
	},
	"Boston Red Sox": {
		founded: [
			1901,
			4,
			26
		],
		city: "Boston",
		cityFounded: [
			1630,
			9,
			7
		],
		stadium: "Fenway Park",
		stadiumOpened: [
			1912,
			4,
			20
		]
	},
	"Chicago Cubs": {
		founded: [
			1876,
			4,
			25
		],
		city: "Chicago",
		cityFounded: [
			1837,
			3,
			4
		],
		stadium: "Wrigley Field",
		stadiumOpened: [
			1914,
			4,
			23
		]
	},
	"Chicago White Sox": {
		founded: [
			1901,
			4,
			24
		],
		city: "Chicago",
		cityFounded: [
			1837,
			3,
			4
		],
		stadium: "Guaranteed Rate Field",
		stadiumOpened: [
			1991,
			4,
			18
		]
	},
	"Cincinnati Reds": {
		founded: [
			1869,
			5,
			4
		],
		city: "Cincinnati",
		cityFounded: [
			1819,
			3,
			1
		],
		stadium: "Great American Ball Park",
		stadiumOpened: [
			2003,
			3,
			31
		]
	},
	"Cleveland Guardians": {
		founded: [
			1901,
			4,
			24
		],
		city: "Cleveland",
		cityFounded: [
			1836,
			3,
			5
		],
		stadium: "Progressive Field",
		stadiumOpened: [
			1994,
			4,
			4
		]
	},
	"Colorado Rockies": {
		founded: [
			1993,
			4,
			5
		],
		city: "Denver",
		cityFounded: [
			1861,
			11,
			7
		],
		stadium: "Coors Field",
		stadiumOpened: [
			1995,
			4,
			26
		]
	},
	"Detroit Tigers": {
		founded: [
			1901,
			4,
			25
		],
		city: "Detroit",
		cityFounded: [
			1815,
			9,
			13
		],
		stadium: "Comerica Park",
		stadiumOpened: [
			2e3,
			4,
			11
		]
	},
	"Houston Astros": {
		founded: [
			1962,
			4,
			10
		],
		city: "Houston",
		cityFounded: [
			1837,
			6,
			5
		],
		stadium: "Daikin Park",
		stadiumOpened: [
			2e3,
			3,
			30
		]
	},
	"Kansas City Royals": {
		founded: [
			1969,
			4,
			8
		],
		city: "Kansas City",
		cityFounded: [
			1850,
			6,
			1
		],
		stadium: "Kauffman Stadium",
		stadiumOpened: [
			1973,
			4,
			10
		]
	},
	"Los Angeles Angels": {
		founded: [
			1961,
			4,
			11
		],
		city: "Anaheim",
		cityFounded: [
			1876,
			3,
			18
		],
		stadium: "Angel Stadium",
		stadiumOpened: [
			1966,
			4,
			9
		]
	},
	"Los Angeles Dodgers": {
		founded: [
			1884,
			5,
			1
		],
		city: "Los Angeles",
		cityFounded: [
			1850,
			4,
			4
		],
		stadium: "Dodger Stadium",
		stadiumOpened: [
			1962,
			4,
			10
		]
	},
	"Miami Marlins": {
		founded: [
			1993,
			4,
			5
		],
		city: "Miami",
		cityFounded: [
			1896,
			7,
			28
		],
		stadium: "loanDepot park",
		stadiumOpened: [
			2012,
			4,
			4
		]
	},
	"Milwaukee Brewers": {
		founded: [
			1969,
			4,
			7
		],
		city: "Milwaukee",
		cityFounded: [
			1846,
			1,
			31
		],
		stadium: "American Family Field",
		stadiumOpened: [
			2001,
			4,
			6
		]
	},
	"Minnesota Twins": {
		founded: [
			1901,
			4,
			26
		],
		city: "Minneapolis",
		cityFounded: [
			1867,
			2,
			13
		],
		stadium: "Target Field",
		stadiumOpened: [
			2010,
			4,
			12
		]
	},
	"New York Mets": {
		founded: [
			1962,
			4,
			11
		],
		city: "New York",
		cityFounded: [
			1624,
			1,
			1
		],
		stadium: "Citi Field",
		stadiumOpened: [
			2009,
			4,
			13
		]
	},
	"New York Yankees": {
		founded: [
			1903,
			1,
			9
		],
		city: "New York",
		cityFounded: [
			1624,
			1,
			1
		],
		stadium: "Yankee Stadium",
		stadiumOpened: [
			2009,
			4,
			16
		]
	},
	"Oakland Athletics": {
		founded: [
			1901,
			4,
			26
		],
		city: "Oakland",
		cityFounded: [
			1852,
			5,
			4
		],
		stadium: "Sutter Health Park",
		stadiumOpened: [
			2e3,
			5,
			15
		]
	},
	"Philadelphia Phillies": {
		founded: [
			1883,
			5,
			1
		],
		city: "Philadelphia",
		cityFounded: [
			1701,
			10,
			25
		],
		stadium: "Citizens Bank Park",
		stadiumOpened: [
			2004,
			4,
			12
		]
	},
	"Pittsburgh Pirates": {
		founded: [
			1882,
			5,
			2
		],
		city: "Pittsburgh",
		cityFounded: [
			1816,
			3,
			18
		],
		stadium: "PNC Park",
		stadiumOpened: [
			2001,
			3,
			31
		]
	},
	"San Diego Padres": {
		founded: [
			1969,
			4,
			8
		],
		city: "San Diego",
		cityFounded: [
			1850,
			3,
			27
		],
		stadium: "Petco Park",
		stadiumOpened: [
			2004,
			4,
			8
		]
	},
	"San Francisco Giants": {
		founded: [
			1883,
			5,
			1
		],
		city: "San Francisco",
		cityFounded: [
			1850,
			4,
			15
		],
		stadium: "Oracle Park",
		stadiumOpened: [
			2e3,
			4,
			11
		]
	},
	"Seattle Mariners": {
		founded: [
			1977,
			4,
			6
		],
		city: "Seattle",
		cityFounded: [
			1869,
			12,
			2
		],
		stadium: "T-Mobile Park",
		stadiumOpened: [
			1999,
			7,
			15
		]
	},
	"St. Louis Cardinals": {
		founded: [
			1882,
			5,
			2
		],
		city: "St. Louis",
		cityFounded: [
			1822,
			12,
			9
		],
		stadium: "Busch Stadium",
		stadiumOpened: [
			2006,
			4,
			10
		]
	},
	"Tampa Bay Rays": {
		founded: [
			1998,
			3,
			31
		],
		city: "St. Petersburg",
		cityFounded: [
			1892,
			2,
			29
		],
		stadium: "Tropicana Field",
		stadiumOpened: [
			1990,
			3,
			3
		]
	},
	"Texas Rangers": {
		founded: [
			1961,
			4,
			11
		],
		city: "Arlington",
		cityFounded: [
			1876,
			4,
			19
		],
		stadium: "Globe Life Field",
		stadiumOpened: [
			2020,
			7,
			24
		]
	},
	"Toronto Blue Jays": {
		founded: [
			1977,
			4,
			7
		],
		city: "Toronto",
		cityFounded: [
			1834,
			3,
			6
		],
		stadium: "Rogers Centre",
		stadiumOpened: [
			1989,
			6,
			3
		]
	},
	"Washington Nationals": {
		founded: [
			1969,
			4,
			8
		],
		city: "Washington",
		cityFounded: [
			1790,
			7,
			16
		],
		stadium: "Nationals Park",
		stadiumOpened: [
			2008,
			3,
			30
		]
	}
};
var NBA = {
	"Atlanta Hawks": {
		founded: [
			1946,
			11,
			1
		],
		city: "Atlanta",
		cityFounded: [
			1847,
			12,
			29
		],
		stadium: "State Farm Arena",
		stadiumOpened: [
			1999,
			9,
			18
		]
	},
	"Boston Celtics": {
		founded: [
			1946,
			6,
			6
		],
		city: "Boston",
		cityFounded: [
			1630,
			9,
			7
		],
		stadium: "TD Garden",
		stadiumOpened: [
			1995,
			9,
			30
		]
	},
	"Brooklyn Nets": {
		founded: [
			1967,
			1,
			1
		],
		city: "New York",
		cityFounded: [
			1624,
			1,
			1
		],
		stadium: "Barclays Center",
		stadiumOpened: [
			2012,
			9,
			21
		]
	},
	"Charlotte Hornets": {
		founded: [
			1988,
			11,
			4
		],
		city: "Charlotte",
		cityFounded: [
			1768,
			11,
			7
		],
		stadium: "Spectrum Center",
		stadiumOpened: [
			2005,
			10,
			21
		]
	},
	"Chicago Bulls": {
		founded: [
			1966,
			1,
			16
		],
		city: "Chicago",
		cityFounded: [
			1837,
			3,
			4
		],
		stadium: "United Center",
		stadiumOpened: [
			1994,
			8,
			18
		]
	},
	"Cleveland Cavaliers": {
		founded: [
			1970,
			2,
			6
		],
		city: "Cleveland",
		cityFounded: [
			1836,
			3,
			5
		],
		stadium: "Rocket Arena",
		stadiumOpened: [
			1994,
			10,
			17
		]
	},
	"Dallas Mavericks": {
		founded: [
			1980,
			5,
			1
		],
		city: "Dallas",
		cityFounded: [
			1856,
			2,
			2
		],
		stadium: "American Airlines Center",
		stadiumOpened: [
			2001,
			7,
			17
		]
	},
	"Denver Nuggets": {
		founded: [
			1967,
			2,
			2
		],
		city: "Denver",
		cityFounded: [
			1861,
			11,
			7
		],
		stadium: "Ball Arena",
		stadiumOpened: [
			1999,
			10,
			1
		]
	},
	"Detroit Pistons": {
		founded: [
			1941,
			1,
			1
		],
		city: "Detroit",
		cityFounded: [
			1815,
			9,
			13
		],
		stadium: "Little Caesars Arena",
		stadiumOpened: [
			2017,
			9,
			5
		]
	},
	"Golden State Warriors": {
		founded: [
			1946,
			6,
			6
		],
		city: "San Francisco",
		cityFounded: [
			1850,
			4,
			15
		],
		stadium: "Chase Center",
		stadiumOpened: [
			2019,
			9,
			6
		]
	},
	"Houston Rockets": {
		founded: [
			1967,
			2,
			6
		],
		city: "Houston",
		cityFounded: [
			1837,
			6,
			5
		],
		stadium: "Toyota Center",
		stadiumOpened: [
			2003,
			10,
			6
		]
	},
	"Indiana Pacers": {
		founded: [
			1967,
			4,
			1
		],
		city: "Indianapolis",
		cityFounded: [
			1847,
			3,
			30
		],
		stadium: "Gainbridge Fieldhouse",
		stadiumOpened: [
			1999,
			11,
			6
		]
	},
	"LA Clippers": {
		founded: [
			1970,
			6,
			24
		],
		city: "Inglewood",
		cityFounded: [
			1908,
			2,
			14
		],
		stadium: "Intuit Dome",
		stadiumOpened: [
			2024,
			8,
			15
		]
	},
	"Los Angeles Lakers": {
		founded: [
			1947,
			11,
			1
		],
		city: "Los Angeles",
		cityFounded: [
			1850,
			4,
			4
		],
		stadium: "Crypto.com Arena",
		stadiumOpened: [
			1999,
			10,
			17
		]
	},
	"Memphis Grizzlies": {
		founded: [
			1995,
			4,
			27
		],
		city: "Memphis",
		cityFounded: [
			1826,
			12,
			19
		],
		stadium: "FedExForum",
		stadiumOpened: [
			2004,
			9,
			6
		]
	},
	"Miami Heat": {
		founded: [
			1988,
			4,
			22
		],
		city: "Miami",
		cityFounded: [
			1896,
			7,
			28
		],
		stadium: "Kaseya Center",
		stadiumOpened: [
			1999,
			12,
			31
		]
	},
	"Milwaukee Bucks": {
		founded: [
			1968,
			1,
			22
		],
		city: "Milwaukee",
		cityFounded: [
			1846,
			1,
			31
		],
		stadium: "Fiserv Forum",
		stadiumOpened: [
			2018,
			8,
			26
		]
	},
	"Minnesota Timberwolves": {
		founded: [
			1989,
			4,
			22
		],
		city: "Minneapolis",
		cityFounded: [
			1867,
			2,
			13
		],
		stadium: "Target Center",
		stadiumOpened: [
			1990,
			10,
			13
		]
	},
	"New Orleans Pelicans": {
		founded: [
			1988,
			4,
			22
		],
		city: "New Orleans",
		cityFounded: [
			1718,
			5,
			7
		],
		stadium: "Smoothie King Center",
		stadiumOpened: [
			1999,
			10,
			19
		]
	},
	"New York Knicks": {
		founded: [
			1946,
			6,
			6
		],
		city: "New York",
		cityFounded: [
			1624,
			1,
			1
		],
		stadium: "Madison Square Garden",
		stadiumOpened: [
			1968,
			2,
			11
		]
	},
	"Oklahoma City Thunder": {
		founded: [
			1967,
			6,
			23
		],
		city: "Oklahoma City",
		cityFounded: [
			1890,
			7,
			15
		],
		stadium: "Paycom Center",
		stadiumOpened: [
			2002,
			6,
			8
		]
	},
	"Orlando Magic": {
		founded: [
			1989,
			4,
			22
		],
		city: "Orlando",
		cityFounded: [
			1875,
			7,
			31
		],
		stadium: "Kia Center",
		stadiumOpened: [
			2010,
			10,
			1
		]
	},
	"Philadelphia 76ers": {
		founded: [
			1946,
			11,
			1
		],
		city: "Philadelphia",
		cityFounded: [
			1701,
			10,
			25
		],
		stadium: "Wells Fargo Center",
		stadiumOpened: [
			1996,
			8,
			31
		]
	},
	"Phoenix Suns": {
		founded: [
			1968,
			1,
			22
		],
		city: "Phoenix",
		cityFounded: [
			1881,
			2,
			25
		],
		stadium: "PHX Arena",
		stadiumOpened: [
			1992,
			6,
			6
		]
	},
	"Portland Trail Blazers": {
		founded: [
			1970,
			2,
			6
		],
		city: "Portland",
		cityFounded: [
			1851,
			2,
			8
		],
		stadium: "Moda Center",
		stadiumOpened: [
			1995,
			10,
			12
		]
	},
	"Sacramento Kings": {
		founded: [
			1923,
			1,
			1
		],
		city: "Sacramento",
		cityFounded: [
			1850,
			2,
			27
		],
		stadium: "Golden 1 Center",
		stadiumOpened: [
			2016,
			10,
			4
		]
	},
	"San Antonio Spurs": {
		founded: [
			1967,
			6,
			23
		],
		city: "San Antonio",
		cityFounded: [
			1837,
			6,
			5
		],
		stadium: "Frost Bank Center",
		stadiumOpened: [
			2002,
			10,
			18
		]
	},
	"Toronto Raptors": {
		founded: [
			1995,
			11,
			3
		],
		city: "Toronto",
		cityFounded: [
			1834,
			3,
			6
		],
		stadium: "Scotiabank Arena",
		stadiumOpened: [
			1999,
			2,
			19
		]
	},
	"Utah Jazz": {
		founded: [
			1974,
			6,
			7
		],
		city: "Salt Lake City",
		cityFounded: [
			1851,
			1,
			19
		],
		stadium: "Delta Center",
		stadiumOpened: [
			1991,
			10,
			4
		]
	},
	"Washington Wizards": {
		founded: [
			1961,
			1,
			1
		],
		city: "Washington",
		cityFounded: [
			1790,
			7,
			16
		],
		stadium: "Capital One Arena",
		stadiumOpened: [
			1997,
			12,
			2
		]
	}
};
var NFL = {
	"Arizona Cardinals": {
		founded: [
			1898,
			1,
			1
		],
		city: "Glendale",
		cityFounded: [
			1910,
			6,
			18
		],
		stadium: "State Farm Stadium",
		stadiumOpened: [
			2006,
			8,
			1
		]
	},
	"Atlanta Falcons": {
		founded: [
			1965,
			6,
			30
		],
		city: "Atlanta",
		cityFounded: [
			1847,
			12,
			29
		],
		stadium: "Mercedes-Benz Stadium",
		stadiumOpened: [
			2017,
			8,
			26
		]
	},
	"Baltimore Ravens": {
		founded: [
			1996,
			2,
			9
		],
		city: "Baltimore",
		cityFounded: [
			1729,
			7,
			30
		],
		stadium: "M&T Bank Stadium",
		stadiumOpened: [
			1998,
			9,
			6
		]
	},
	"Buffalo Bills": {
		founded: [
			1959,
			10,
			28
		],
		city: "Orchard Park",
		cityFounded: [
			1850,
			1,
			1
		],
		stadium: "Highmark Stadium",
		stadiumOpened: [
			1973,
			8,
			17
		]
	},
	"Carolina Panthers": {
		founded: [
			1993,
			10,
			26
		],
		city: "Charlotte",
		cityFounded: [
			1768,
			11,
			7
		],
		stadium: "Bank of America Stadium",
		stadiumOpened: [
			1996,
			9,
			14
		]
	},
	"Chicago Bears": {
		founded: [
			1919,
			9,
			17
		],
		city: "Chicago",
		cityFounded: [
			1837,
			3,
			4
		],
		stadium: "Soldier Field",
		stadiumOpened: [
			1924,
			10,
			9
		]
	},
	"Cincinnati Bengals": {
		founded: [
			1968,
			5,
			23
		],
		city: "Cincinnati",
		cityFounded: [
			1819,
			3,
			1
		],
		stadium: "Paycor Stadium",
		stadiumOpened: [
			2e3,
			8,
			19
		]
	},
	"Cleveland Browns": {
		founded: [
			1946,
			6,
			4
		],
		city: "Cleveland",
		cityFounded: [
			1836,
			3,
			5
		],
		stadium: "Huntington Bank Field",
		stadiumOpened: [
			1999,
			9,
			12
		]
	},
	"Dallas Cowboys": {
		founded: [
			1960,
			1,
			28
		],
		city: "Arlington",
		cityFounded: [
			1876,
			4,
			19
		],
		stadium: "AT&T Stadium",
		stadiumOpened: [
			2009,
			5,
			27
		]
	},
	"Denver Broncos": {
		founded: [
			1959,
			8,
			14
		],
		city: "Denver",
		cityFounded: [
			1861,
			11,
			7
		],
		stadium: "Empower Field at Mile High",
		stadiumOpened: [
			2001,
			9,
			10
		]
	},
	"Detroit Lions": {
		founded: [
			1930,
			1,
			1
		],
		city: "Detroit",
		cityFounded: [
			1815,
			9,
			13
		],
		stadium: "Ford Field",
		stadiumOpened: [
			2002,
			8,
			24
		]
	},
	"Green Bay Packers": {
		founded: [
			1919,
			8,
			11
		],
		city: "Green Bay",
		cityFounded: [
			1838,
			1,
			1
		],
		stadium: "Lambeau Field",
		stadiumOpened: [
			1957,
			9,
			29
		]
	},
	"Houston Texans": {
		founded: [
			1999,
			10,
			6
		],
		city: "Houston",
		cityFounded: [
			1837,
			6,
			5
		],
		stadium: "NRG Stadium",
		stadiumOpened: [
			2002,
			8,
			24
		]
	},
	"Indianapolis Colts": {
		founded: [
			1953,
			1,
			23
		],
		city: "Indianapolis",
		cityFounded: [
			1847,
			3,
			30
		],
		stadium: "Lucas Oil Stadium",
		stadiumOpened: [
			2008,
			8,
			16
		]
	},
	"Jacksonville Jaguars": {
		founded: [
			1993,
			11,
			30
		],
		city: "Jacksonville",
		cityFounded: [
			1832,
			2,
			9
		],
		stadium: "EverBank Stadium",
		stadiumOpened: [
			1995,
			8,
			18
		]
	},
	"Kansas City Chiefs": {
		founded: [
			1960,
			8,
			14
		],
		city: "Kansas City",
		cityFounded: [
			1850,
			6,
			1
		],
		stadium: "GEHA Field at Arrowhead Stadium",
		stadiumOpened: [
			1972,
			8,
			12
		]
	},
	"Las Vegas Raiders": {
		founded: [
			1960,
			1,
			30
		],
		city: "Paradise",
		cityFounded: [
			1950,
			1,
			1
		],
		stadium: "Allegiant Stadium",
		stadiumOpened: [
			2020,
			7,
			31
		]
	},
	"Los Angeles Chargers": {
		founded: [
			1959,
			8,
			14
		],
		city: "Inglewood",
		cityFounded: [
			1908,
			2,
			14
		],
		stadium: "SoFi Stadium",
		stadiumOpened: [
			2020,
			9,
			8
		]
	},
	"Los Angeles Rams": {
		founded: [
			1936,
			1,
			1
		],
		city: "Inglewood",
		cityFounded: [
			1908,
			2,
			14
		],
		stadium: "SoFi Stadium",
		stadiumOpened: [
			2020,
			9,
			8
		]
	},
	"Miami Dolphins": {
		founded: [
			1965,
			8,
			16
		],
		city: "Miami Gardens",
		cityFounded: [
			2003,
			5,
			13
		],
		stadium: "Hard Rock Stadium",
		stadiumOpened: [
			1987,
			8,
			16
		]
	},
	"Minnesota Vikings": {
		founded: [
			1960,
			1,
			28
		],
		city: "Minneapolis",
		cityFounded: [
			1867,
			2,
			13
		],
		stadium: "U.S. Bank Stadium",
		stadiumOpened: [
			2016,
			7,
			22
		]
	},
	"New England Patriots": {
		founded: [
			1959,
			11,
			16
		],
		city: "Foxborough",
		cityFounded: [
			1778,
			6,
			10
		],
		stadium: "Gillette Stadium",
		stadiumOpened: [
			2002,
			9,
			9
		]
	},
	"New Orleans Saints": {
		founded: [
			1967,
			11,
			1
		],
		city: "New Orleans",
		cityFounded: [
			1718,
			5,
			7
		],
		stadium: "Caesars Superdome",
		stadiumOpened: [
			1975,
			8,
			3
		]
	},
	"New York Giants": {
		founded: [
			1925,
			8,
			1
		],
		city: "East Rutherford",
		cityFounded: [
			1894,
			3,
			28
		],
		stadium: "MetLife Stadium",
		stadiumOpened: [
			2010,
			4,
			10
		]
	},
	"New York Jets": {
		founded: [
			1959,
			8,
			14
		],
		city: "East Rutherford",
		cityFounded: [
			1894,
			3,
			28
		],
		stadium: "MetLife Stadium",
		stadiumOpened: [
			2010,
			4,
			10
		]
	},
	"Philadelphia Eagles": {
		founded: [
			1933,
			7,
			8
		],
		city: "Philadelphia",
		cityFounded: [
			1701,
			10,
			25
		],
		stadium: "Lincoln Financial Field",
		stadiumOpened: [
			2003,
			8,
			3
		]
	},
	"Pittsburgh Steelers": {
		founded: [
			1933,
			7,
			8
		],
		city: "Pittsburgh",
		cityFounded: [
			1816,
			3,
			18
		],
		stadium: "Acrisure Stadium",
		stadiumOpened: [
			2001,
			8,
			25
		]
	},
	"San Francisco 49ers": {
		founded: [
			1944,
			6,
			4
		],
		city: "Santa Clara",
		cityFounded: [
			1852,
			7,
			5
		],
		stadium: "Levi's Stadium",
		stadiumOpened: [
			2014,
			7,
			17
		]
	},
	"Seattle Seahawks": {
		founded: [
			1974,
			6,
			4
		],
		city: "Seattle",
		cityFounded: [
			1869,
			12,
			2
		],
		stadium: "Lumen Field",
		stadiumOpened: [
			2002,
			7,
			28
		]
	},
	"Tampa Bay Buccaneers": {
		founded: [
			1974,
			4,
			24
		],
		city: "Tampa",
		cityFounded: [
			1849,
			1,
			18
		],
		stadium: "Raymond James Stadium",
		stadiumOpened: [
			1998,
			9,
			20
		]
	},
	"Tennessee Titans": {
		founded: [
			1959,
			8,
			14
		],
		city: "Nashville",
		cityFounded: [
			1806,
			12,
			24
		],
		stadium: "Nissan Stadium",
		stadiumOpened: [
			1999,
			8,
			27
		]
	},
	"Washington Commanders": {
		founded: [
			1932,
			7,
			9
		],
		city: "Landover",
		cityFounded: [
			1973,
			1,
			1
		],
		stadium: "Northwest Stadium",
		stadiumOpened: [
			1997,
			9,
			14
		]
	}
};
var NHL = {
	"Anaheim Ducks": {
		founded: [
			1993,
			3,
			1
		],
		city: "Anaheim",
		cityFounded: [
			1876,
			3,
			18
		],
		stadium: "Honda Center",
		stadiumOpened: [
			1993,
			6,
			17
		]
	},
	"Boston Bruins": {
		founded: [
			1924,
			11,
			1
		],
		city: "Boston",
		cityFounded: [
			1630,
			9,
			7
		],
		stadium: "TD Garden",
		stadiumOpened: [
			1995,
			9,
			30
		]
	},
	"Buffalo Sabres": {
		founded: [
			1970,
			5,
			22
		],
		city: "Buffalo",
		cityFounded: [
			1832,
			4,
			20
		],
		stadium: "KeyBank Center",
		stadiumOpened: [
			1996,
			9,
			21
		]
	},
	"Calgary Flames": {
		founded: [
			1972,
			6,
			6
		],
		city: "Calgary",
		cityFounded: [
			1894,
			1,
			1
		],
		stadium: "Scotiabank Saddledome",
		stadiumOpened: [
			1983,
			10,
			15
		]
	},
	"Carolina Hurricanes": {
		founded: [
			1971,
			11,
			1
		],
		city: "Raleigh",
		cityFounded: [
			1792,
			12,
			31
		],
		stadium: "Lenovo Center",
		stadiumOpened: [
			1999,
			10,
			29
		]
	},
	"Chicago Blackhawks": {
		founded: [
			1926,
			9,
			25
		],
		city: "Chicago",
		cityFounded: [
			1837,
			3,
			4
		],
		stadium: "United Center",
		stadiumOpened: [
			1994,
			8,
			18
		]
	},
	"Colorado Avalanche": {
		founded: [
			1972,
			6,
			6
		],
		city: "Denver",
		cityFounded: [
			1861,
			11,
			7
		],
		stadium: "Ball Arena",
		stadiumOpened: [
			1999,
			10,
			1
		]
	},
	"Columbus Blue Jackets": {
		founded: [
			1997,
			6,
			25
		],
		city: "Columbus",
		cityFounded: [
			1812,
			2,
			14
		],
		stadium: "Nationwide Arena",
		stadiumOpened: [
			2e3,
			9,
			9
		]
	},
	"Dallas Stars": {
		founded: [
			1967,
			6,
			5
		],
		city: "Dallas",
		cityFounded: [
			1856,
			2,
			2
		],
		stadium: "American Airlines Center",
		stadiumOpened: [
			2001,
			7,
			17
		]
	},
	"Detroit Red Wings": {
		founded: [
			1926,
			9,
			25
		],
		city: "Detroit",
		cityFounded: [
			1815,
			9,
			13
		],
		stadium: "Little Caesars Arena",
		stadiumOpened: [
			2017,
			9,
			5
		]
	},
	"Edmonton Oilers": {
		founded: [
			1971,
			11,
			1
		],
		city: "Edmonton",
		cityFounded: [
			1904,
			10,
			8
		],
		stadium: "Rogers Place",
		stadiumOpened: [
			2016,
			9,
			8
		]
	},
	"Florida Panthers": {
		founded: [
			1993,
			6,
			14
		],
		city: "Sunrise",
		cityFounded: [
			1961,
			6,
			22
		],
		stadium: "Amerant Bank Arena",
		stadiumOpened: [
			1998,
			10,
			3
		]
	},
	"Los Angeles Kings": {
		founded: [
			1967,
			6,
			5
		],
		city: "Los Angeles",
		cityFounded: [
			1850,
			4,
			4
		],
		stadium: "Crypto.com Arena",
		stadiumOpened: [
			1999,
			10,
			17
		]
	},
	"Minnesota Wild": {
		founded: [
			1997,
			6,
			25
		],
		city: "Saint Paul",
		cityFounded: [
			1854,
			3,
			4
		],
		stadium: "Grand Casino Arena",
		stadiumOpened: [
			2e3,
			9,
			29
		]
	},
	"Montreal Canadiens": {
		founded: [
			1909,
			12,
			4
		],
		city: "Montreal",
		cityFounded: [
			1832,
			6,
			5
		],
		stadium: "Bell Centre",
		stadiumOpened: [
			1996,
			3,
			16
		]
	},
	"Nashville Predators": {
		founded: [
			1997,
			6,
			25
		],
		city: "Nashville",
		cityFounded: [
			1806,
			12,
			24
		],
		stadium: "Bridgestone Arena",
		stadiumOpened: [
			1996,
			12,
			18
		]
	},
	"New Jersey Devils": {
		founded: [
			1974,
			6,
			11
		],
		city: "Newark",
		cityFounded: [
			1666,
			1,
			1
		],
		stadium: "Prudential Center",
		stadiumOpened: [
			2007,
			10,
			25
		]
	},
	"New York Islanders": {
		founded: [
			1972,
			6,
			6
		],
		city: "Elmont",
		cityFounded: [
			1882,
			1,
			1
		],
		stadium: "UBS Arena",
		stadiumOpened: [
			2021,
			11,
			20
		]
	},
	"New York Rangers": {
		founded: [
			1926,
			5,
			15
		],
		city: "New York",
		cityFounded: [
			1624,
			1,
			1
		],
		stadium: "Madison Square Garden",
		stadiumOpened: [
			1968,
			2,
			11
		]
	},
	"Ottawa Senators": {
		founded: [
			1990,
			12,
			6
		],
		city: "Ottawa",
		cityFounded: [
			1855,
			1,
			1
		],
		stadium: "Canadian Tire Centre",
		stadiumOpened: [
			1996,
			1,
			17
		]
	},
	"Philadelphia Flyers": {
		founded: [
			1967,
			6,
			5
		],
		city: "Philadelphia",
		cityFounded: [
			1701,
			10,
			25
		],
		stadium: "Wells Fargo Center",
		stadiumOpened: [
			1996,
			8,
			31
		]
	},
	"Pittsburgh Penguins": {
		founded: [
			1967,
			6,
			5
		],
		city: "Pittsburgh",
		cityFounded: [
			1816,
			3,
			18
		],
		stadium: "PPG Paints Arena",
		stadiumOpened: [
			2010,
			8,
			1
		]
	},
	"San Jose Sharks": {
		founded: [
			1991,
			5,
			9
		],
		city: "San Jose",
		cityFounded: [
			1850,
			3,
			27
		],
		stadium: "SAP Center at San Jose",
		stadiumOpened: [
			1993,
			9,
			7
		]
	},
	"Seattle Kraken": {
		founded: [
			2018,
			12,
			4
		],
		city: "Seattle",
		cityFounded: [
			1869,
			12,
			2
		],
		stadium: "Climate Pledge Arena",
		stadiumOpened: [
			2021,
			10,
			22
		]
	},
	"St. Louis Blues": {
		founded: [
			1967,
			6,
			5
		],
		city: "St. Louis",
		cityFounded: [
			1822,
			12,
			9
		],
		stadium: "Enterprise Center",
		stadiumOpened: [
			1994,
			10,
			8
		]
	},
	"Tampa Bay Lightning": {
		founded: [
			1992,
			12,
			16
		],
		city: "Tampa",
		cityFounded: [
			1849,
			1,
			18
		],
		stadium: "Benchmark International Arena",
		stadiumOpened: [
			1996,
			10,
			20
		]
	},
	"Toronto Maple Leafs": {
		founded: [
			1917,
			11,
			26
		],
		city: "Toronto",
		cityFounded: [
			1834,
			3,
			6
		],
		stadium: "Scotiabank Arena",
		stadiumOpened: [
			1999,
			2,
			19
		]
	},
	"Utah Hockey Club": {
		founded: [
			2024,
			4,
			18
		],
		city: "Salt Lake City",
		cityFounded: [
			1851,
			1,
			19
		],
		stadium: "Delta Center",
		stadiumOpened: [
			1991,
			10,
			4
		]
	},
	"Utah Mammoth": {
		founded: [
			2024,
			4,
			18
		],
		city: "Salt Lake City",
		cityFounded: [
			1851,
			1,
			19
		],
		stadium: "Delta Center",
		stadiumOpened: [
			1991,
			10,
			4
		]
	},
	"Vancouver Canucks": {
		founded: [
			1970,
			5,
			22
		],
		city: "Vancouver",
		cityFounded: [
			1886,
			4,
			6
		],
		stadium: "Rogers Arena",
		stadiumOpened: [
			1995,
			9,
			17
		]
	},
	"Vegas Golden Knights": {
		founded: [
			2017,
			6,
			22
		],
		city: "Paradise",
		cityFounded: [
			1950,
			1,
			1
		],
		stadium: "T-Mobile Arena",
		stadiumOpened: [
			2016,
			4,
			6
		]
	},
	"Washington Capitals": {
		founded: [
			1974,
			6,
			11
		],
		city: "Washington",
		cityFounded: [
			1790,
			7,
			16
		],
		stadium: "Capital One Arena",
		stadiumOpened: [
			1997,
			12,
			2
		]
	},
	"Winnipeg Jets": {
		founded: [
			1999,
			6,
			25
		],
		city: "Winnipeg",
		cityFounded: [
			1873,
			11,
			8
		],
		stadium: "Canada Life Centre",
		stadiumOpened: [
			2004,
			11,
			16
		]
	}
};
var TEAM_DB = {
	...MLB,
	...NBA,
	...NFL,
	...NHL
};
var ALIASES = {
	"LA Lakers": "Los Angeles Lakers",
	"LA Clippers": "LA Clippers",
	"Saint Louis Cardinals": "St. Louis Cardinals",
	"St Louis Cardinals": "St. Louis Cardinals",
	"St Louis Blues": "St. Louis Blues",
	"Athletics": "Oakland Athletics",
	"Sacramento Athletics": "Oakland Athletics"
};
function getTeamMeta(name) {
	if (TEAM_DB[name]) return TEAM_DB[name];
	if (ALIASES[name]) return TEAM_DB[ALIASES[name]];
	const lower = name.toLowerCase();
	for (const k of Object.keys(TEAM_DB)) if (k.toLowerCase().endsWith(lower) || lower.endsWith(k.toLowerCase())) return TEAM_DB[k];
}
/** Route ESPN calls through our same-origin proxy (ESPN sends no CORS headers). */
function espnFetch(url) {
	return fetch(`/api/public/espn?url=${encodeURIComponent(url)}`);
}
var LEAGUE_MAP = {
	NBA: {
		label: "NBA",
		espnPath: "basketball/nba",
		emoji: "🏀"
	},
	WNBA: {
		label: "WNBA",
		espnPath: "basketball/wnba",
		emoji: "🏀"
	},
	NFL: {
		label: "NFL",
		espnPath: "football/nfl",
		emoji: "🏈"
	},
	MLB: {
		label: "MLB",
		espnPath: "baseball/mlb",
		emoji: "⚾"
	},
	NHL: {
		label: "NHL",
		espnPath: "hockey/nhl",
		emoji: "🏒"
	},
	UFC: {
		label: "UFC",
		espnPath: "mma/ufc",
		emoji: "🥊"
	},
	MLS: {
		label: "MLS",
		espnPath: "soccer/usa.1",
		emoji: "⚽"
	},
	"Premier League": {
		label: "Premier League",
		espnPath: "soccer/eng.1",
		emoji: "⚽"
	},
	"La Liga": {
		label: "La Liga",
		espnPath: "soccer/esp.1",
		emoji: "⚽"
	},
	Bundesliga: {
		label: "Bundesliga",
		espnPath: "soccer/ger.1",
		emoji: "⚽"
	},
	"Serie A": {
		label: "Serie A",
		espnPath: "soccer/ita.1",
		emoji: "⚽"
	},
	"Ligue 1": {
		label: "Ligue 1",
		espnPath: "soccer/fra.1",
		emoji: "⚽"
	},
	UCL: {
		label: "UEFA Champions League",
		espnPath: "soccer/uefa.champions",
		emoji: "🏆"
	},
	UEL: {
		label: "UEFA Europa League",
		espnPath: "soccer/uefa.europa",
		emoji: "🏆"
	},
	UECL: {
		label: "UEFA Conference League",
		espnPath: "soccer/uefa.europa.conf",
		emoji: "🏆"
	},
	"Liga MX": {
		label: "Liga MX",
		espnPath: "soccer/mex.1",
		emoji: "⚽"
	},
	"World Cup": {
		label: "FIFA World Cup 2026",
		espnPath: "soccer/fifa.world",
		emoji: "🌍"
	},
	"College Football": {
		label: "College Football",
		espnPath: "football/college-football",
		emoji: "🏈"
	},
	"College Basketball": {
		label: "College Basketball",
		espnPath: "basketball/mens-college-basketball",
		emoji: "🏀"
	}
};
function getLeagueInfo(league) {
	return LEAGUE_MAP[league] ?? {
		label: league,
		espnPath: ""
	};
}
function pad(n) {
	return n < 10 ? `0${n}` : `${n}`;
}
function formatDate(year, month, day) {
	return `${year}${pad(month)}${pad(day)}`;
}
async function fetchScoreboardEvents(league, path, dates) {
	const primary = `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${dates}&limit=100`;
	const sources = league === "MLB" ? [primary, `https://cdn.espn.com/core/mlb/scoreboard?xhr=1&dates=${dates}`] : [primary];
	for (const source of sources) try {
		const res = await espnFetch(source);
		if (!res.ok) continue;
		const data = await res.json();
		const events = data.events ?? data.content?.sbData?.events ?? [];
		if (events.length > 0) return events;
	} catch {}
	return [];
}
async function fetchESPNGames(league, month, day, year) {
	const cfg = getLeagueInfo(league);
	if (!cfg.espnPath) return [];
	const events = await fetchScoreboardEvents(league, cfg.espnPath, formatDate(year, month, day));
	if (league === "UFC") return events.flatMap((ev) => mapFights(ev));
	return events.map((ev) => mapEvent(ev, league)).filter(Boolean);
}
/** UFC: each bout on the card becomes one "game"; red corner (order 1) = home. */
function mapFights(ev) {
	return (ev.competitions ?? []).map((c, i) => {
		const [h, a] = [...c.competitors ?? []].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
		if (!h || !a) return null;
		const st = c.status?.type?.state ?? ev.status?.type?.state ?? "pre";
		const rec = (x) => x.records?.find((r) => r.type === "total")?.summary ?? x.records?.[0]?.summary ?? "";
		return {
			id: String(c.id ?? `${ev.id}-${i}`),
			league: "UFC",
			status: st === "in" ? "in" : st === "post" ? "post" : "pre",
			statusDetail: `${c.type?.abbreviation ?? "Bout"} · ${ev.name ?? ""}`,
			startTime: c.date ?? ev.date,
			homeTeam: h.athlete?.displayName ?? "Fighter A",
			homeTeamId: String(h.id),
			homeAbbr: h.athlete?.shortName ?? "",
			homeRecord: rec(h),
			homeScore: st === "post" ? h.winner ? "1" : "0" : "",
			awayTeam: a.athlete?.displayName ?? "Fighter B",
			awayTeamId: String(a.id),
			awayAbbr: a.athlete?.shortName ?? "",
			awayRecord: rec(a),
			awayScore: st === "post" ? a.winner ? "1" : "0" : "",
			venue: c.venue?.fullName ?? ev.venues?.[0]?.fullName,
			odds: {}
		};
	}).filter(Boolean).reverse();
}
/** UFC fighter birth date (YYYY-MM-DD) from ESPN's athlete endpoint. */
async function fetchFighterDob(id) {
	if (!id) return void 0;
	try {
		const d = await (await espnFetch(`https://site.web.api.espn.com/apis/common/v3/sports/mma/athletes/${id}`)).json();
		const m = String(d?.athlete?.displayDOB ?? "").match(/(\d+)\/(\d+)\/(\d{4})/);
		return m ? `${m[3]}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}` : void 0;
	} catch {
		return;
	}
}
function mapEvent(ev, league) {
	const comp = ev.competitions?.[0];
	if (!comp) return null;
	const home = comp.competitors.find((c) => c.homeAway === "home");
	const away = comp.competitors.find((c) => c.homeAway === "away");
	if (!home || !away) return null;
	const stateRaw = ev.status?.type?.state ?? "pre";
	const state = stateRaw === "in" ? "in" : stateRaw === "post" ? "post" : "pre";
	const odds = comp.odds?.[0];
	const spread = odds?.details ?? "";
	const overUnder = odds?.overUnder != null ? String(odds.overUnder) : "";
	const extractLeaders = (c) => {
		const names = [];
		for (const p of c.probables ?? []) {
			const n = p.athlete?.fullName ?? p.athlete?.displayName;
			if (n && !names.includes(n)) names.push(n);
		}
		for (const grp of c.leaders ?? []) for (const l of grp.leaders ?? []) {
			const n = l.athlete?.fullName ?? l.athlete?.displayName;
			if (n && !names.includes(n)) names.push(n);
		}
		return names.slice(0, 6);
	};
	return {
		id: ev.id,
		league,
		status: state,
		statusDetail: ev.status?.type?.shortDetail ?? "",
		startTime: ev.date,
		homeTeam: home.team.displayName,
		homeTeamId: home.team.id,
		homeAbbr: home.team.abbreviation,
		homeRecord: home.records?.[0]?.summary ?? "",
		homeScore: home.score ?? "",
		homeLogo: home.team.logo,
		awayTeam: away.team.displayName,
		awayTeamId: away.team.id,
		awayAbbr: away.team.abbreviation,
		awayRecord: away.records?.[0]?.summary ?? "",
		awayScore: away.score ?? "",
		awayLogo: away.team.logo,
		venue: comp.venue?.fullName,
		broadcast: comp.broadcasts?.[0]?.names?.[0],
		odds: {
			spreadHome: spread,
			spreadAway: spread,
			moneylineHome: odds?.homeTeamOdds?.moneyLine != null ? String(odds.homeTeamOdds.moneyLine) : "",
			moneylineAway: odds?.awayTeamOdds?.moneyLine != null ? String(odds.awayTeamOdds.moneyLine) : "",
			overUnder
		},
		homeLeaders: extractLeaders(home),
		awayLeaders: extractLeaders(away)
	};
}
var SITE = "https://site.api.espn.com/apis/site/v2/sports";
var WEB = "https://site.web.api.espn.com/apis/common/v3/sports";
var CORE = "https://sports.core.api.espn.com/v2/sports";
/** Core API paths need a `leagues` segment: baseball/mlb → baseball/leagues/mlb. */
function corePath(path) {
	const [sport, ...rest] = path.split("/");
	return rest.length ? `${sport}/leagues/${rest.join("/")}` : sport;
}
async function j(url) {
	try {
		const r = await espnFetch(url);
		if (!r.ok) return null;
		return await r.json();
	} catch {
		return null;
	}
}
var iso$1 = (s) => s ? s.slice(0, 10) : void 0;
function findRecord(list, type) {
	const r = list?.find((x) => (x.type ?? x.name ?? "").toLowerCase() === type);
	return r?.summary ?? r?.displayValue ?? void 0;
}
/** Season + career pitching lines from the athlete stats endpoint. */
async function pitcherStats(path, athleteId, season) {
	const cat = (await j(`${WEB}/${path}/athletes/${athleteId}/stats`))?.categories?.find((c) => c.name === "pitching");
	if (!cat) return null;
	const labels = cat.labels ?? [];
	const idx = (l) => labels.indexOf(l);
	const rows = (cat.statistics ?? []).filter((r) => r?.stats?.length);
	const num = (row, l) => Number(row.stats[idx(l)] ?? 0) || 0;
	let cw = 0, cl = 0;
	for (const r of rows) {
		cw += num(r, "W");
		cl += num(r, "L");
	}
	const cur = rows.find((r) => String(r?.season?.year ?? r?.season?.displayName ?? "") === String(season)) ?? rows[rows.length - 1];
	return {
		season: cur ? `${num(cur, "W")}-${num(cur, "L")}` : void 0,
		career: rows.length ? `${cw}-${cl}` : void 0,
		era: cur ? String(cur.stats[idx("ERA")] ?? "") : void 0,
		whip: cur ? String(cur.stats[idx("WHIP")] ?? "") : void 0,
		strikeouts: cur ? String(cur.stats[idx("K")] ?? "") : void 0
	};
}
async function buildStarter(path, prob, season) {
	const ath = prob?.athlete;
	const id = String(prob?.playerId ?? ath?.id ?? "");
	if (!ath?.displayName && !ath?.fullName) return void 0;
	const [core, stats] = await Promise.all([id ? j(`${CORE}/${corePath(path)}/athletes/${id}?lang=en&region=us`) : Promise.resolve(null), id ? pitcherStats(path, id, season) : Promise.resolve(null)]);
	return {
		common: ath.displayName ?? ath.fullName,
		full: core?.fullName ?? ath.fullName,
		dob: iso$1(core?.dateOfBirth),
		jersey: ath.jersey,
		record: stats?.season,
		careerRecord: stats?.career,
		era: stats?.era,
		whip: stats?.whip,
		strikeouts: stats?.strikeouts
	};
}
async function buildManager(path, teamId, season) {
	let list = await j(`${CORE}/${corePath(path)}/seasons/${season}/teams/${teamId}/coaches?lang=en&region=us`);
	if (!list?.items?.length) list = await j(`${CORE}/${corePath(path)}/seasons/${season - 1}/teams/${teamId}/coaches?lang=en&region=us`);
	const ref = list?.items?.[0]?.$ref;
	if (!ref) return void 0;
	const c = await j(ref.replace("http://", "https://"));
	if (!c) return void 0;
	const common = `${(c.firstName ?? "").trim()} ${(c.lastName ?? "").trim()}`.trim();
	if (!common) return void 0;
	let record;
	const rref = c.records?.[0]?.record?.$ref;
	if (rref) {
		const rec = await j(rref.replace("http://", "https://"));
		record = rec?.summary ?? rec?.displayValue;
	}
	return {
		common,
		full: c.person?.fullName ?? common,
		dob: iso$1(c.dateOfBirth),
		record
	};
}
/** One call → every participant number the protocol needs, no manual entry. */
async function fetchAutoMatchup(league, gameId) {
	const path = getLeagueInfo(league).espnPath;
	const gaps = [];
	const out = {
		retrievedAt: (/* @__PURE__ */ new Date()).toISOString(),
		home: {},
		away: {},
		pitchersConfirmed: false,
		gaps
	};
	if (!path || !gameId) {
		gaps.push("league feed unavailable");
		return out;
	}
	const s = await j(`${SITE}/${path}/summary?event=${gameId}`);
	if (!s) {
		gaps.push("ESPN summary unreachable");
		return out;
	}
	const comp = s.header?.competitions?.[0];
	const season = Number(s.header?.season?.year ?? (/* @__PURE__ */ new Date()).getFullYear());
	const competitors = comp?.competitors ?? [];
	out.venue = s.gameInfo?.venue?.fullName;
	out.venueCity = s.gameInfo?.venue?.address?.city;
	out.venueState = s.gameInfo?.venue?.address?.state;
	const series = s.seasonseries ?? [];
	const current = series.find((x) => x.type === "current") ?? series[0];
	if (current) {
		out.seriesRecord = current.seriesScore ?? current.summary;
		out.seriesGame = (current.events?.filter((e) => e.status === "post").length ?? 0) + 1;
	}
	out.seasonSeries = (series.find((x) => x.type === "season") ?? series.find((x) => /season/i.test(x.title ?? "")))?.summary ?? current?.summary;
	const sides = await Promise.all(competitors.map(async (c) => {
		const teamId = String(c.team?.id ?? c.id ?? "");
		const side = {
			teamId,
			shortName: c.team?.shortDisplayName ?? c.team?.name ?? c.team?.abbreviation,
			longName: c.team?.displayName ?? c.team?.shortDisplayName,
			record: findRecord(c.record, "total") ?? c.record?.[0]?.summary,
			homeRecord: findRecord(c.record, "home"),
			roadRecord: findRecord(c.record, "road") ?? findRecord(c.record, "away")
		};
		const prob = c.probables?.[0];
		const [starter, manager] = await Promise.all([prob ? buildStarter(path, prob, season) : Promise.resolve(void 0), teamId ? buildManager(path, teamId, season) : Promise.resolve(void 0)]);
		side.starter = starter;
		side.manager = manager;
		return {
			homeAway: c.homeAway,
			side
		};
	}));
	for (const { homeAway, side } of sides) if (homeAway === "home") out.home = side;
	else out.away = side;
	for (const block of s.lastFiveGames ?? []) {
		const id = String(block.team?.id ?? "");
		const wins = (block.events ?? []).filter((e) => /W/.test(e.gameResult ?? "")).length;
		const games = (block.events ?? []).length;
		if (!games) continue;
		const line = `${wins}-${games - wins}`;
		if (out.home.teamId === id) out.home.last10 = line;
		if (out.away.teamId === id) out.away.last10 = line;
	}
	out.pitchersConfirmed = !!(out.home.starter && out.away.starter);
	if (!out.home.starter || !out.away.starter) gaps.push("starters not yet posted by the league");
	if (!out.home.manager || !out.away.manager) gaps.push("head coach/manager feed unavailable for this league");
	if (!out.home.starter?.careerRecord && !out.away.starter?.careerRecord) gaps.push("career pitching lines unavailable");
	return out;
}
var LOG_KEY = "shem-sports-steplog-v1";
function readLog() {
	if (typeof window === "undefined") return [];
	try {
		return JSON.parse(localStorage.getItem(LOG_KEY) || "[]");
	} catch {
		return [];
	}
}
function writeLog(l) {
	if (typeof window !== "undefined") localStorage.setItem(LOG_KEY, JSON.stringify(l));
}
function logStepPick(e) {
	const l = readLog();
	const ex = l.find((x) => x.id === e.id);
	if (ex) {
		if (!ex.actual) {
			ex.pick = e.pick;
			ex.votes = e.votes;
			ex.confidence = e.confidence;
			ex.margin = e.margin;
			ex.noBet = e.noBet;
		}
	} else l.push(e);
	writeLog(l);
}
function scoreStepPick(id, actual) {
	const l = readLog();
	const ex = l.find((x) => x.id === id);
	if (ex && !ex.actual) {
		ex.actual = actual;
		writeLog(l);
	}
}
function stepHitRates() {
	const scored = readLog().filter((e) => e.actual && e.actual !== "draw");
	const steps = {};
	for (const e of scored) for (const layer of new Set(e.votes.map((v) => v.layer))) {
		const w = {
			home: 0,
			away: 0
		};
		e.votes.filter((v) => v.layer === layer).forEach((v) => w[v.side] += v.weight);
		if (w.home === w.away) continue;
		const s = steps[layer] ??= {
			hits: 0,
			total: 0
		};
		s.total++;
		if ((w.home > w.away ? "home" : "away") === e.actual) s.hits++;
	}
	const hits = scored.filter((e) => e.pick === e.actual).length;
	const bands = {};
	for (const e of scored) {
		if (e.confidence == null) continue;
		const c = e.confidence, k = c >= 85 ? "Exceptional" : c >= 70 ? "Strong" : c >= 50 ? "Good" : c >= 30 ? "Mixed" : "Challenging";
		const b = bands[k] ??= {
			hits: 0,
			total: 0
		};
		b.total++;
		if (e.pick === e.actual) b.hits++;
	}
	const stacks = {};
	for (const e of scored) {
		if (e.margin == null) continue;
		const k = e.margin < 3 ? "Under +3" : e.margin < 6 ? "+3 to +6" : "+6 or more";
		const b = stacks[k] ??= {
			hits: 0,
			total: 0
		};
		b.total++;
		if (e.pick === e.actual) b.hits++;
	}
	return {
		total: scored.length,
		hits,
		steps,
		bands,
		stacks
	};
}
var KEY = "sports_entity_overrides_v1";
var subs = /* @__PURE__ */ new Set();
var cache = null;
var entityKey = (kind, name) => `${kind}:${name.trim().toLowerCase()}`;
function read() {
	if (cache) return cache;
	if (typeof window === "undefined") return {};
	try {
		cache = JSON.parse(localStorage.getItem(KEY) || "{}");
	} catch {
		cache = {};
	}
	return cache;
}
function write(next) {
	cache = next;
	localStorage.setItem(KEY, JSON.stringify(next));
	subs.forEach((f) => f());
}
function setOverride(key, patch) {
	const cur = read();
	write({
		...cur,
		[key]: {
			...cur[key],
			...patch,
			updated: (/* @__PURE__ */ new Date()).toISOString()
		}
	});
}
function clearOverride(key) {
	const { [key]: _, ...rest } = read();
	write(rest);
}
var EMPTY = {};
function useOverrides() {
	return (0, import_react.useSyncExternalStore)((f) => {
		subs.add(f);
		return () => subs.delete(f);
	}, read, () => EMPTY);
}
var STEMS = [
	"Wood",
	"Wood",
	"Fire",
	"Fire",
	"Earth",
	"Earth",
	"Metal",
	"Metal",
	"Water",
	"Water"
];
var MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
var monthName = (m) => MONTHS[(m - 1 + 12) % 12];
var ordinal = (y, m, d) => Math.floor(Date.UTC(y, m - 1, d) / 864e5) + 719163;
var num = (n) => ({
	compound: n,
	reduced: reduceNum(n)
});
var show = (n) => n.compound === n.reduced ? `${n.reduced}` : `${n.compound}/${n.reduced}`;
var digits = (n) => [...String(Math.abs(n))].reduce((a, c) => a + +c, 0);
function isoWeek(y, m, d) {
	const t = new Date(Date.UTC(y, m - 1, d));
	const day = t.getUTCDay() || 7;
	t.setUTCDate(t.getUTCDate() + 4 - day);
	const y0 = Date.UTC(t.getUTCFullYear(), 0, 1);
	return Math.ceil(((t.getTime() - y0) / 864e5 + 1) / 7);
}
function moon(y, m, d) {
	const syn = 29.530588853;
	const age = ((Date.UTC(y, m - 1, d, 12) - Date.UTC(2e3, 0, 6, 18, 14)) / 864e5 % syn + syn) % syn;
	const illum = Math.round((1 - Math.cos(2 * Math.PI * age / syn)) / 2 * 100);
	const phase = age < 1.85 ? "New Moon" : age < 5.54 ? "Waxing Crescent" : age < 9.23 ? "First Quarter" : age < 12.92 ? "Waxing Gibbous" : age < 16.61 ? "Full Moon" : age < 20.3 ? "Waning Gibbous" : age < 23.99 ? "Last Quarter" : age < 27.68 ? "Waning Crescent" : "New Moon";
	return {
		phase,
		illum,
		label: `${phase}, ${illum}%`
	};
}
var yearStem = (y) => ((y - 4) % 10 + 10) % 10;
var yearPillar = (y) => `${STEMS[yearStem(y)]} ${chineseSign(y)}`;
function monthPillar(y, m, d) {
	const sign = chineseMonthSign(m, d);
	const fromTiger = (SIGNS.indexOf(sign) - 2 + 12) % 12;
	return `${STEMS[(yearStem(y) % 5 * 2 + 2 + fromTiger) % 10]} ${sign}`;
}
var dayStem = (y, m, d) => (ordinal(y, m, d) + 4) % 10;
var dayPillar = (y, m, d) => `${STEMS[dayStem(y, m, d)]} ${chineseDaySign(y, m, d)}`;
function hourPillar(y, m, d, hour) {
	const b = Math.floor((hour + 1) / 2) % 12;
	const stem = (dayStem(y, m, d) % 5 * 2 + b) % 10;
	const start = (b * 2 + 23) % 24;
	const h12 = (h) => `${(h + 11) % 12 + 1}:00 ${h < 12 ? "AM" : "PM"}`;
	return `${STEMS[stem]} ${SIGNS[b]} (${h12(start)} – ${h12((start + 2) % 24)})`;
}
/** Healingood-style date matrix built from the GG33 number chart. */
var SUITS = [
	"♥",
	"♣",
	"♦",
	"♠"
];
var RANKS = [
	"A",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10",
	"J",
	"Q",
	"K"
];
/** Destiny Cards solar value: 55 − (2×month + day). 0 = Joker (Dec 31). */
var solarValue = (m, d) => 55 - (2 * m + d);
function birthCard(m, d) {
	const v = solarValue(m, d);
	if (v <= 0) return "Joker";
	return `${RANKS[(v - 1) % 13]}${SUITS[Math.floor((v - 1) / 13)]}`;
}
/** Date matrix straight from the Healingood 366-day chart for the birth / founding day. */
function dateMatrix(b, game) {
	const [, bm, bd] = b;
	const h = healingood(bm, bd);
	const L = (k) => h[k].map(fmtMD);
	const fatal = L("fatal"), soulmate = L("soulmate"), beneficial = L("beneficial"), challenging = L("challenging"), lovers = L("lovers");
	const [, gm, gd] = game;
	const today = [];
	const g = `${monthName(gm)} ${gd}`;
	if (gm === bm && gd === bd) today.push("Game is on the birthday — Beneficial");
	if (soulmate.includes(g)) today.push("Game date is a Soulmate date");
	if (fatal.includes(g)) today.push("Game date is a Fatal Attraction date");
	if (beneficial.includes(g)) today.push("Game date is a Beneficial date");
	if (lovers.includes(g)) today.push("Game date is a Lovers & Friends date");
	if (challenging.includes(g)) today.push("Game date is a Challenging / Rival date");
	return {
		card: birthCard(bm, bd),
		fatal,
		challenging,
		soulmate,
		beneficial,
		lovers,
		today
	};
}
function dateScore(m) {
	let s = 0;
	for (const t of m.today) {
		if (/Soulmate|Beneficial/.test(t)) s += 1;
		if (/Challenging/.test(t)) s -= 1;
		if (/Fatal/.test(t)) s -= .5;
	}
	return s;
}
/** Every cycle for one dated entity (team, player, city, stadium) on the game day. */
function readEntity(b, game, kickoffHour) {
	const [y, m, d] = b;
	const [gy, gm, gd] = game;
	const py = calcPersonalYear(m, d, gm, gd, gy);
	const pm = num(py.reduced + gm);
	const pd = num(pm.reduced + digits(gd));
	const pw = num(py.reduced + isoWeek(gy, gm, gd));
	const hr = (h) => reduceNum(pd.reduced + digits(h % 24));
	const doy = dayOfYear(y, m, d);
	const woy = isoWeek(y, m, d);
	const lucky = luckyNumber(y, m);
	return {
		date: b,
		lp: lifePath(y, m, d),
		secondary: num(d),
		doy,
		doyRoot: reduceNum(doy),
		woy,
		woyRoot: reduceNum(woy),
		moon: moon(y, m, d),
		yearP: yearPillar(y),
		monthP: monthPillar(y, m, d),
		dayP: dayPillar(y, m, d),
		py: {
			compound: py.compound,
			reduced: py.reduced
		},
		pm,
		pd,
		pw,
		ph: [
			hr(kickoffHour),
			hr(kickoffHour + 1),
			hr(kickoffHour + 3)
		],
		lucky,
		luckyRoot: reduceNum(lucky),
		matrix: dateMatrix(b, game)
	};
}
function gameEnergies(game, kickoffHour) {
	const [y, m, d] = game;
	const uy = reduceNum(digits(y));
	const doy = dayOfYear(y, m, d);
	const woy = isoWeek(y, m, d);
	return {
		lp: num(m + d + uy),
		secondary: num(d),
		doy,
		doyRoot: reduceNum(doy),
		woy,
		woyRoot: reduceNum(woy),
		moon: moon(y, m, d),
		yearP: yearPillar(y),
		monthP: monthPillar(y, m, d),
		dayP: dayPillar(y, m, d),
		hourP: [hourPillar(y, m, d, kickoffHour), hourPillar(y, m, d, (kickoffHour + 2) % 24)]
	};
}
var recordRoot = (rec) => {
	const m = rec?.match(/(\d+)-(\d+)/);
	if (!m) return null;
	return reduceNum(+m[1] + +m[2]);
};
/** Side score from the full decode. Closing hour outweighs start and mid (0.15 / 0.15 / 0.40). */
function sideScore(r, gameLp, w = 1) {
	const rel = (n) => {
		const x = numberRelation(n, gameLp);
		return x === "same" || x === "friend" || x === "soulmate" ? 1 : x === "enemy" || x === "worst" ? -1 : compat(n, gameLp).rel === "friendly" ? .5 : compat(n, gameLp).rel === "enemy" ? -.5 : 0;
	};
	return w * (rel(r.pd.reduced) + .5 * rel(r.pw.reduced) + .15 * rel(r.ph[0]) + .15 * rel(r.ph[1]) + .4 * rel(r.ph[2]) + dateScore(r.matrix));
}
var fmtDate = (t) => `${monthName(t[1])} ${t[2]}, ${t[0]}`;
var parseDob = (s) => {
	const m = s?.match(/^(\d{4})-(\d{2})-(\d{2})/);
	return m ? [
		+m[1],
		+m[2],
		+m[3]
	] : void 0;
};
function lines(e, r) {
	if (!r) return ["Birth / founding date not available yet — decode for this entry cannot run."];
	const out = [];
	if (e.kind !== "player" && e.kind !== "city") out.push(`Founding Date: ${fmtDate(r.date)}`);
	if (e.kind === "player" || e.kind === "city") out.push(`${e.kind === "city" ? "Incorporated" : "Born"}: ${fmtDate(r.date)}`);
	out.push(`Lifepath: ${show(r.lp)}`, `Secondary Energy: ${show(r.secondary)}`, `Day Of The Year: ${r.doy} (root ${r.doyRoot})`, `Week Of The Year: ${r.woy} (root ${r.woyRoot})`);
	if (e.kind === "team" || e.kind === "stadium") out.push(`Lunar Cycle: ${r.moon.label}`);
	out.push(`Personal Year Cycle: ${show(r.py)}`, `Personal Month Cycle: ${show(r.pm)}`, `Personal Day Cycle: ${show(r.pd)}`, `Personal Week Cycle: ${show(r.pw)}`, `Personal Hour Cycle: ${r.ph[0]} at start → ${r.ph[1]} mid-game → ${r.ph[2]} closing (closing weighted highest)`, `Chinese Zodiac Year: ${r.yearP}`, `Chinese Zodiac Month: ${r.monthP}`, `Chinese Zodiac Day: ${r.dayP}`, `Lucky Number: ${r.lucky} (root ${r.luckyRoot})`);
	if (e.kind === "player") out.push(`Jersey Number: ${e.jersey ?? "not in feed"}${e.jersey && +e.jersey === r.lucky ? " — matches Lucky Number" : ""}`);
	if (e.kind === "team") {
		const rr = recordRoot(e.record);
		out.push(`Current Record: ${e.record ?? "not in feed"}${rr ? ` (${rr} vibration)` : ""}`);
	}
	out.push(`Birth Card: ${r.matrix.card}`, `Fatal Attraction Dates: ${r.matrix.fatal.join(", ")}`, `Challenging / Rival Dates: ${r.matrix.challenging.join(", ")}`, `Soulmate Dates: ${r.matrix.soulmate.join(", ") || "—"}`, `Beneficial Dates: ${r.matrix.beneficial.join(", ")}`);
	r.matrix.today.forEach((t) => out.push(`⚡ TONIGHT: ${t}`));
	return out;
}
function computeFullDecode(raw, game, kickoffHour, ov = {}) {
	const entities = raw.map((e) => {
		const o = ov[entityKey(e.kind, e.name)];
		return o ? {
			...e,
			date: parseDob(o.date) ?? e.date,
			jersey: o.jersey || e.jersey,
			edited: true
		} : e;
	});
	const ge = gameEnergies(game, kickoffHour);
	const reads = entities.map((e) => ({
		e,
		r: e.date ? readEntity(e.date, game, kickoffHour) : null
	}));
	let home = 0, away = 0;
	for (const { e, r } of reads) {
		if (!r) continue;
		const w = e.kind === "team" ? 1 : e.kind === "player" ? .5 : .25;
		const s = sideScore(r, ge.lp.reduced, w);
		if (e.side === "away") away += s;
		else home += s;
	}
	return {
		ge,
		reads,
		home,
		away
	};
}
function FullDecode({ title, data, homeName, awayName, verdict }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const { ge, reads } = data;
	const gameLines = [
		`Lifepath: ${show(ge.lp)}`,
		`Secondary Energy: ${show(ge.secondary)}`,
		`Day Of The Year: ${ge.doy} (root ${ge.doyRoot})`,
		`Week Of The Year: ${ge.woy} (root ${ge.woyRoot})`,
		`Lunar Cycle: ${ge.moon.label}`,
		`Chinese Zodiac Year: ${ge.yearP}`,
		`Chinese Zodiac Month: ${ge.monthP}`,
		`Chinese Zodiac Day: ${ge.dayP}`,
		`Chinese Zodiac Hour: ${ge.hourP[0]} → ${ge.hourP[1]}`
	];
	const group = (k) => reads.filter((x) => x.e.kind === k);
	const sections = [
		["PART 2 · THE TEAMS", group("team")],
		["PART 3 · KEY PLAYERS", group("player")],
		["PART 4 · THE CITY", group("city")],
		["PART 5 · THE STADIUM", group("stadium")]
	];
	const head = (x) => `${x.e.edited ? "✎ " : ""}${x.e.side === "away" ? "AWAY · " : x.e.side === "home" ? "HOME · " : ""}${x.e.name}${x.e.role ? ` (${x.e.role})` : ""}`;
	const copy = () => {
		const txt = [
			title,
			"",
			"PART 1 · GAME ENERGIES",
			...gameLines.map((l) => `• ${l}`),
			...sections.flatMap(([t, xs]) => [
				"",
				t,
				...xs.flatMap((x) => [
					"",
					head(x),
					...lines(x.e, x.r).map((l) => `• ${l}`)
				])
			]),
			"",
			"SYSTEMIC VERDICT",
			verdict
		].join("\n");
		navigator.clipboard?.writeText(txt).then(() => {
			setCopied(true);
			setTimeout(() => setCopied(false), 1500);
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 rounded-lg border border-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2 px-3 py-2 bg-muted/40",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-bold tracking-[0.18em] text-primary",
				children: "FULL DECODE · 5 PARTS"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setEditing((v) => !v),
					className: "text-[10px] font-bold px-2 py-1 rounded border border-primary text-primary",
					children: editing ? "DONE" : "EDIT DATES"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: copy,
					className: "text-[10px] font-bold px-2 py-1 rounded bg-primary text-primary-foreground",
					children: copied ? "COPIED" : "COPY DECODE"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-3 space-y-3 text-[11px]",
			children: [
				editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateEditor, { entities: reads.map((x) => x.e) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
					title: "PART 1 · GAME ENERGIES",
					items: gameLines
				}),
				sections.map(([t, xs]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-bold tracking-[0.16em] text-primary mb-1",
					children: t
				}), xs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "Not in the feed for this game."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
					children: xs.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: head(x),
						items: lines(x.e, x.r)
					}, i))
				})] }, t)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-primary/10 border border-primary/30 p-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-bold tracking-[0.16em] text-primary mb-1",
							children: "SYSTEMIC VERDICT"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-foreground",
							children: verdict
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground mt-1",
							children: [
								"Full-decode score · ",
								awayName,
								" ",
								data.away.toFixed(2),
								" vs ",
								homeName,
								" ",
								data.home.toFixed(2)
							]
						})
					]
				})
			]
		})]
	});
}
function Block({ title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-muted/30 p-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-bold text-foreground mb-1",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-0.5",
			children: items.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: l.startsWith("⚡") ? "text-primary font-semibold" : "text-muted-foreground",
				children: ["• ", l]
			}, i))
		})]
	});
}
var iso = (t) => t ? `${t[0]}-${String(t[1]).padStart(2, "0")}-${String(t[2]).padStart(2, "0")}` : "";
function DateEditor({ entities }) {
	const ov = useOverrides();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-primary/40 p-2 space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-bold tracking-[0.16em] text-primary",
			children: "DATE TOOLBOX · saved for this and every future game"
		}), entities.map((e) => {
			const k = entityKey(e.kind, e.name);
			const o = ov[k];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "w-48 truncate text-foreground",
						children: [
							e.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									"(",
									e.role ?? e.kind,
									")"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						defaultValue: o?.date ?? iso(e.date),
						onBlur: (ev) => ev.target.value && setOverride(k, { date: ev.target.value }),
						className: "bg-background border border-border rounded px-1 py-0.5"
					}),
					e.kind === "player" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						placeholder: "Jersey",
						defaultValue: o?.jersey ?? e.jersey ?? "",
						onBlur: (ev) => setOverride(k, { jersey: ev.target.value }),
						className: "w-16 bg-background border border-border rounded px-1 py-0.5"
					}),
					!e.date && !o && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-destructive font-semibold",
						children: "MISSING"
					}),
					o && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary font-semibold",
						children: "EDITED"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => clearOverride(k),
						className: "underline text-muted-foreground",
						children: "reset"
					})] })
				]
			}, k);
		})]
	});
}
/** Page-level toolbox: every saved edit, across all sports. */
function SavedEdits() {
	const ov = useOverrides();
	const [open, setOpen] = (0, import_react.useState)(false);
	const keys = Object.keys(ov);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => setOpen((v) => !v),
			className: "text-xs font-bold px-3 py-1.5 rounded bg-primary text-primary-foreground",
			children: [
				"DATE TOOLBOX · ",
				keys.length,
				" saved edits"
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 rounded-lg border border-border p-3 text-[11px] space-y-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: "Pick a sport, then press EDIT DATES on any game to change a team, player, coach, city or stadium date. Edits here apply to all future games."
			}), keys.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: "No edits yet."
			}) : keys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-56 truncate text-foreground",
						children: k.replace(":", " · ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						defaultValue: ov[k].date ?? "",
						onBlur: (ev) => ev.target.value && setOverride(k, { date: ev.target.value }),
						className: "bg-background border border-border rounded px-1 py-0.5"
					}),
					ov[k].jersey && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: ["#", ov[k].jersey]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => clearOverride(k),
						className: "underline text-muted-foreground",
						children: "remove"
					})
				]
			}, k))]
		})]
	});
}
var MASTERS = /* @__PURE__ */ new Set([
	11,
	22,
	33
]);
var CHART_COMPOUNDS = /* @__PURE__ */ new Set([
	11,
	22,
	28,
	33
]);
function toneOf(word) {
	if (word === "Friend" || word === "Beneficial") return "friend";
	if (word === "Enemy" || word === "Fatal" || word === "Challenging") return "enemy";
	if (word === "Master" || word === "Extreme") return "master";
	return "neutral";
}
function chartWord(a, b) {
	const rel = numberRelation(a, b);
	const row = compat(a, b);
	if (rel === "worst") return {
		word: "Enemy",
		note: "worst pair on the chart"
	};
	if (rel === "enemy") return {
		word: "Enemy",
		note: "enemy on the chart"
	};
	if (rel === "soulmate") return {
		word: "Friend",
		note: "soulmate pair"
	};
	if (rel === "same") return {
		word: "Friend",
		note: "same number"
	};
	if (rel === "friend") return {
		word: "Friend",
		note: row.pct ? `${row.pct}% friendly` : "friendly on the chart"
	};
	if (row.rel === "enemy") return {
		word: "Enemy",
		note: "enemy on the chart"
	};
	if (row.rel === "friendly") return {
		word: "Friend",
		note: row.pct ? `${row.pct}% friendly` : "friendly on the chart"
	};
	return {
		word: "Neutral",
		note: "no friend or enemy pair"
	};
}
function lpKeys(n) {
	const keys = [n.reduced];
	if (n.compound !== n.reduced && CHART_COMPOUNDS.has(n.compound)) keys.unshift(n.compound);
	return [...new Set(keys)];
}
function mdLabel(date) {
	if (!date) return void 0;
	return `${monthName(date[1])} ${date[2]}`;
}
function venueBucket(matrix, label) {
	if (!matrix || !label) return "Unknown";
	if (matrix.fatal.includes(label)) return "Fatal";
	if (matrix.beneficial.includes(label) || matrix.soulmate.includes(label) || matrix.lovers.includes(label)) return "Beneficial";
	if (matrix.challenging.includes(label)) return "Challenging";
	return "Neutral";
}
function isKeyPlayer(role) {
	return /pitcher|quarterback|^qb$|fighter|^player$|goalkeeper|keeper/i.test(role ?? "");
}
function buildMatchBrief(v, entities, names) {
	const name = (side) => side === "home" ? names.home : side === "away" ? names.away : side === "venue" ? "Venue" : "Even";
	const doing = v.steps.map((s) => ({
		label: s.label,
		edge: s.edge ? name(s.edge) : "Even",
		reason: s.reason
	}));
	const homeLp = v.reads.home.lp;
	const awayLp = v.reads.away.lp;
	const ud = v.universalDay;
	const chart = [];
	if (homeLp && awayLp) for (const a of lpKeys(homeLp)) for (const b of lpKeys(awayLp)) {
		const hit = chartWord(a, b);
		chart.push({
			tone: toneOf(hit.word),
			text: `${names.home} Life Path ${a} vs ${names.away} Life Path ${b} — ${hit.word} (${hit.note})`
		});
	}
	else chart.push({
		tone: "info",
		text: "One founding or birth date is missing, so Life Path vs Life Path cannot be charted yet."
	});
	for (const [side, lp] of [["home", homeLp], ["away", awayLp]]) {
		if (!lp) continue;
		for (const k of lpKeys(lp)) {
			const hit = chartWord(k, ud.reduced);
			chart.push({
				tone: toneOf(hit.word),
				text: `${name(side)} Life Path ${k} vs Universal Day ${fmt(ud)} — ${hit.word} (${hit.note})`
			});
		}
	}
	const stackFor = (side) => {
		const rows = v.votes.filter((x) => x.side === side);
		const strong = rows.filter((x) => x.weight >= 1).length;
		const head = {
			tone: strong ? "friend" : "neutral",
			text: `${name(side)} — ${rows.length} layer${rows.length === 1 ? "" : "s"} stacking, ${strong} strong (weight 1 or more)`
		};
		if (!rows.length) return [head, {
			tone: "neutral",
			text: "No layer landed on this side."
		}];
		return [head, ...rows.map((x) => ({
			tone: x.weight >= 1 ? "friend" : "info",
			text: `${x.weight >= 1 ? "Strong" : "Light"} ${x.weight} · ${x.layer} — ${x.reason}`
		}))];
	};
	const animals = [];
	const flagged = /* @__PURE__ */ new Set();
	const flag = (who, sign, other, otherSign) => {
		const rel = signRelation(sign, otherSign);
		if (rel === "neutral" || sign === otherSign) return;
		const key = `${who}|${sign}|${otherSign}|${rel}`;
		if (flagged.has(key)) return;
		flagged.add(key);
		animals.push({
			tone: rel === "friend" ? "friend" : "enemy",
			text: `${who} (${sign}) is ${rel === "friend" ? "friends" : "enemies"} with ${other} (${otherSign})`
		});
	};
	const dated = entities.filter((e) => e.yearSign);
	for (const e of dated) {
		const sign = e.yearSign;
		const who = e.kind === "team" ? e.name : `${e.name}${e.role ? ` (${e.role})` : ""}`;
		flag(who, sign, `the ${v.yearSign} year`, v.yearSign);
		flag(who, sign, `the ${v.monthSign} month`, v.monthSign);
	}
	const homeSign = v.reads.home.sign;
	const awaySign = v.reads.away.sign;
	if (homeSign && awaySign) flag(names.home, homeSign, names.away, awaySign);
	for (const e of dated.filter((x) => x.kind === "player")) {
		const opp = e.side === "home" ? awaySign : e.side === "away" ? homeSign : void 0;
		const oppName = e.side === "home" ? names.away : names.home;
		if (opp && e.yearSign) flag(`${e.name}${e.role ? ` (${e.role})` : ""}`, e.yearSign, oppName, opp);
	}
	if (!animals.length) animals.push({
		tone: "neutral",
		text: `No friend or enemy animal flags. Checked teams, coaches, and key players against each other and against the ${v.yearSign} year and ${v.monthSign} month.`
	});
	const dayKeys = /* @__PURE__ */ new Set([
		ud.reduced,
		ud.compound,
		v.dayOfMonth.reduced,
		v.dayOfMonth.compound
	]);
	if (v.dayOfMonth.compound === 28) {
		dayKeys.add(8);
		dayKeys.add(1);
	}
	const jerseys = [];
	for (const e of entities.filter((x) => x.kind === "player" && x.jersey && Number(x.jersey))) {
		const j = Number(e.jersey);
		const hits = [];
		if (dayKeys.has(j)) hits.push(`matches a day key number (${[...dayKeys].join(", ")})`);
		if (e.lucky != null && j === e.lucky) hits.push(`matches Lucky Number ${e.lucky}`);
		if (e.lp && (j === e.lp.reduced || j === e.lp.compound)) hits.push(`matches Life Path ${fmt(e.lp)}`);
		jerseys.push({
			tone: hits.length ? "friend" : "neutral",
			text: hits.length ? `${e.name}${e.role ? ` (${e.role})` : ""} #${j} — ${hits.join("; ")}` : `${e.name}${e.role ? ` (${e.role})` : ""} #${j} — no resonance with the day, Lucky Number, or Life Path`
		});
	}
	if (!jerseys.length) jerseys.push({
		tone: "info",
		text: "No jersey numbers in the feed yet."
	});
	const [awayStar, homeStar] = ["away", "home"].map((side) => entities.find((e) => e.kind === "player" && e.side === side && isKeyPlayer(e.role) && e.lp));
	const duel = [];
	if (awayStar?.lp && homeStar?.lp) {
		const role = /pitcher/i.test(`${awayStar.role} ${homeStar.role}`) ? "Pitcher vs pitcher" : "Key player vs key player";
		duel.push({
			tone: "info",
			text: `${role} on ${v.dayOfMonth.compound}/${ud.reduced}: ${awayStar.name} vs ${homeStar.name}`
		});
		for (const a of lpKeys(awayStar.lp)) for (const b of lpKeys(homeStar.lp)) {
			const hit = chartWord(a, b);
			duel.push({
				tone: toneOf(hit.word),
				text: `Life Path ${awayStar.name} ${a} vs ${homeStar.name} ${b} — ${hit.word} (${hit.note})`
			});
		}
		for (const star of [awayStar, homeStar]) {
			if (!star.pd) continue;
			const hit = chartWord(star.pd.reduced, ud.reduced);
			duel.push({
				tone: toneOf(hit.word),
				text: `${star.name} Personal Day ${fmt(star.pd)} vs Universal Day ${fmt(ud)} — ${hit.word} (${hit.note})`
			});
		}
		if (awayStar.yearSign && homeStar.yearSign) {
			const rel = signRelation(awayStar.yearSign, homeStar.yearSign);
			duel.push({
				tone: rel === "neutral" ? "neutral" : rel === "friend" ? "friend" : "enemy",
				text: `Animals: ${awayStar.name} ${awayStar.yearSign} vs ${homeStar.name} ${homeStar.yearSign} — ${rel}`
			});
		}
	} else duel.push({
		tone: "info",
		text: "Key-player comparison is waiting on a posted starter (pitcher, quarterback, or fighter) and a birth date for both sides."
	});
	const masters = [];
	const seenMaster = /* @__PURE__ */ new Set();
	const markMaster = (label, n) => {
		if (n == null || !MASTERS.has(n)) return;
		const key = `${label}|${n}`;
		if (seenMaster.has(key)) return;
		seenMaster.add(key);
		masters.push({
			tone: "master",
			text: `${label} is ${n} — master number, elevated`
		});
	};
	markMaster(`Universal Day ${fmt(ud)}`, ud.reduced);
	markMaster(`Universal Day compound ${ud.compound}`, ud.compound);
	markMaster(`Calendar day ${v.dayOfMonth.compound}`, v.dayOfMonth.reduced);
	markMaster(`Calendar day ${v.dayOfMonth.compound}`, v.dayOfMonth.compound);
	for (const e of entities) {
		markMaster(`${e.name} Life Path`, e.lp?.reduced);
		markMaster(`${e.name} Life Path compound`, e.lp?.compound);
		markMaster(`${e.name} Personal Day`, e.pd?.reduced);
		markMaster(`${e.name} Personal Day compound`, e.pd?.compound);
		markMaster(`${e.name} Lucky Number`, e.lucky);
		if (e.jersey) markMaster(`${e.name} jersey`, Number(e.jersey));
	}
	if (!masters.length) masters.push({
		tone: "neutral",
		text: "No 11, 22, or 33 on the day, the Life Paths, the Personal Days, the lucky numbers, or the jerseys."
	});
	const extreme = [];
	const eventNums = [
		ud.compound,
		ud.reduced,
		v.dayOfMonth.compound,
		v.dayOfMonth.reduced
	];
	const eventNote = eventNums.filter((n) => SPECIAL_NUMBERS[n]).map((n) => SPECIAL_NUMBERS[n]);
	return {
		doing,
		sections: finish(v, entities, names, chart, stackFor, animals, jerseys, duel, masters, extreme, eventNums.some((n) => MASTERS.has(n)), eventNote),
		upgrades: accuracyUpgrades(v)
	};
}
function accuracyUpgrades(v) {
	const f = v.flags;
	const color = [{
		tone: "info",
		text: `Color score home ${f.colorHome} / away ${f.colorAway} (max 2 each). Red = 9 and is punished on a 9-day, a 9-cycle, and a 1-day. Black is punished on a 9-day. Blue and white score only on a 1-day. Gold scores on 8/17/26/28. Green scores on 3 or 8.`
	}, ...v.votes.filter((x) => x.layer === "Colors").map((x) => ({
		tone: "info",
		text: `${x.side === "home" ? "Home" : "Away"} +${x.weight} — ${x.reason}`
	}))];
	if (v.votes.every((x) => x.layer !== "Colors")) color.push({
		tone: "neutral",
		text: "No color points landed."
	});
	if (f.volatility) color.push({
		tone: "enemy",
		text: f.volatility
	});
	const userTone = /Fatal|Challenging/.test(f.userChart) ? "enemy" : /Beneficial|Soulmate|Lovers/.test(f.userChart) ? "friend" : "neutral";
	const toneOfStadium = (t) => /Fatal|Challenging/.test(t) ? "enemy" : /Beneficial|Soulmate|Lovers/.test(t) ? "friend" : "neutral";
	return [
		{
			n: 1,
			title: "Colorology",
			lines: color
		},
		{
			n: 2,
			title: "Your chart on this date",
			lines: [{
				tone: userTone,
				text: f.userChart
			}]
		},
		{
			n: 3,
			title: "Wealth day",
			lines: f.wealth ? [{
				tone: "master",
				text: f.wealth
			}] : [{
				tone: "neutral",
				text: "Not an 8 / 17 / 26 / 28 wealth day."
			}]
		},
		{
			n: 4,
			title: "Hour cycle",
			lines: [{
				tone: "info",
				text: f.hour
			}, ...v.decision.volatility.filter((t) => /flip|9-cycle|under|eclipse/i.test(t)).map((t) => ({
				tone: "enemy",
				text: t
			}))]
		},
		{
			n: 5,
			title: "Master multiplier",
			lines: f.masters.length ? f.masters.map((t) => ({
				tone: "master",
				text: t
			})) : [{
				tone: "neutral",
				text: f.equalMasters ? "Both sides hold a master number, so neither side gets the boost." : "No master multiplier. Neither side uniquely holds 11, 22, or 33."
			}]
		},
		{
			n: 6,
			title: "Record vibration",
			lines: f.record9.length ? f.record9.map((t) => ({
				tone: "enemy",
				text: t
			})) : [{
				tone: "neutral",
				text: "No 9-vibration record penalty."
			}]
		},
		{
			n: 7,
			title: "Stadium founding vs each team",
			lines: f.stadium.length ? f.stadium.map((t) => ({
				tone: toneOfStadium(t),
				text: t
			})) : [{
				tone: "info",
				text: "Stadium opening date is not on file."
			}]
		},
		{
			n: 8,
			title: "Your cycle and the window",
			lines: [
				...v.decision.bettor.map((t) => ({
					tone: /enemy|Fatal|fade/i.test(t) ? "enemy" : /friend|same|supports/i.test(t) ? "friend" : "info",
					text: t
				})),
				{
					tone: "info",
					text: v.decision.lunar
				},
				{
					tone: "info",
					text: v.decision.powerColor
				},
				...v.decision.manifestation ? [{
					tone: "master",
					text: v.decision.manifestation
				}] : [],
				...v.decision.eclipse ? [{
					tone: "enemy",
					text: v.decision.eclipse
				}] : []
			]
		}
	];
}
function finish(v, entities, names, chart, stackFor, animals, jerseys, duel, masters, _extreme, dayIsMaster, eventNote) {
	const extreme = [];
	for (const e of entities) {
		if (!e.date || e.kind === "city" || e.kind === "stadium") continue;
		const [, m, d] = e.date;
		if (m !== names.month || d !== v.dayOfMonth.compound) continue;
		const whoMaster = MASTERS.has(e.lp?.reduced ?? -1) || MASTERS.has(e.lp?.compound ?? -1);
		const combined = whoMaster || dayIsMaster || eventNote.length > 0;
		const why = [
			whoMaster ? `Life Path ${e.lp ? fmt(e.lp) : ""} is a master` : "",
			dayIsMaster ? "the game date carries a master number" : "",
			eventNote[0] ?? ""
		].filter(Boolean).join("; ");
		extreme.push({
			tone: combined ? "master" : "friend",
			text: combined ? `EXTREME — ${e.name} birthday falls on the game date (${monthName(m)} ${d}) and ${why}` : `${e.name} birthday falls on the game date (${monthName(m)} ${d}), but no master or event number is attached`
		});
	}
	if (!extreme.length) extreme.push({
		tone: "neutral",
		text: "Nobody's birthday or founding day is this calendar date, so there is no extreme resonance."
	});
	const city = entities.find((e) => e.kind === "city");
	const stadium = entities.find((e) => e.kind === "stadium");
	const cityMd = mdLabel(city?.date);
	const stadMd = mdLabel(stadium?.date);
	const venue = [];
	for (const side of ["away", "home"]) {
		const team = entities.find((e) => e.kind === "team" && e.side === side);
		const who = side === "home" ? names.home : names.away;
		if (!team?.matrix) {
			venue.push({
				tone: "info",
				text: `${who}: founding date missing, so city and stadium stay Unchecked.`
			});
			continue;
		}
		const cityHit = venueBucket(team.matrix, cityMd);
		const stadHit = venueBucket(team.matrix, stadMd);
		const line = (place, label, hit) => label ? `${place} (${label}) is ${hit} for ${who}` : `${place} date is not on file — Neutral for ${who} (unchecked)`;
		venue.push({
			tone: toneOf(cityHit === "Unknown" ? "Neutral" : cityHit),
			text: line(city?.name ?? "City", cityMd, cityHit === "Unknown" ? "Neutral" : cityHit)
		});
		venue.push({
			tone: toneOf(stadHit === "Unknown" ? "Neutral" : stadHit),
			text: line(stadium?.name ?? "Stadium", stadMd, stadHit === "Unknown" ? "Neutral" : stadHit)
		});
	}
	return [
		{
			n: 1,
			title: "Number compatibility chart",
			lines: chart
		},
		{
			n: 2,
			title: "Stacking breakdown",
			lines: [...stackFor("away"), ...stackFor("home")]
		},
		{
			n: 3,
			title: "Chinese animal friend / enemy",
			lines: animals
		},
		{
			n: 4,
			title: "Jersey number resonance",
			lines: jerseys
		},
		{
			n: 5,
			title: "Pitcher vs pitcher (or key player)",
			lines: duel
		},
		{
			n: 6,
			title: "Master number highlights",
			lines: masters
		},
		{
			n: 7,
			title: "Extreme resonance",
			lines: extreme
		},
		{
			n: 8,
			title: "Venue and city for each side",
			lines: venue
		}
	];
}
var YELLOW = "#FF6A00";
var BLUE = "#60A5FA";
var GREEN = "#4ade80";
var ROSE = "#f472b6";
var LEAGUE_GROUPS = [
	{
		label: "FIFA World Cup 2026",
		leagues: ["World Cup"]
	},
	{
		label: "US Major",
		leagues: [
			"NBA",
			"NFL",
			"MLB",
			"NHL",
			"UFC"
		]
	},
	{
		label: "Soccer",
		leagues: [
			"MLS",
			"Premier League",
			"La Liga",
			"Bundesliga",
			"Serie A",
			"Ligue 1"
		]
	},
	{
		label: "European Cups",
		leagues: [
			"UCL",
			"UEL",
			"UECL"
		]
	},
	{
		label: "More",
		leagues: [
			"Liga MX",
			"WNBA",
			"College Football",
			"College Basketball"
		]
	}
];
var TONE_COLOR = {
	friend: "#4ade80",
	enemy: "#f87171",
	master: "#FF6A00",
	neutral: "rgba(255,255,255,0.55)",
	info: "rgba(255,255,255,0.78)"
};
function RequestedBrief({ brief }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 rounded-lg overflow-hidden",
		style: { border: "1px solid rgba(255,106,0,0.35)" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-3 py-2",
			style: { background: "rgba(255,106,0,0.08)" },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-bold tracking-[0.16em]",
				style: { color: YELLOW },
				children: "WHAT THIS CARD DOES · THEN THE 8 CHECKS YOU ASKED FOR"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-3 space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-bold tracking-[0.14em] mb-1",
						style: { color: BLUE },
						children: "ALREADY RUNNING"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] mb-2",
						style: { color: "rgba(255,255,255,0.62)" },
						children: "Seven weighted votes. Numbers still outrank astrology. Colorology scores 0–2 on every game and can strengthen a lean or break a tie. A 9-vibration record takes a small penalty on 9-days. A master 11/22/33 multiplies that side. The closing hour outweighs the opening hour in the full decode. The pick above is the 7-step score plus that decode."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1",
						children: brief.doing.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-[11px]",
							style: { color: "rgba(255,255,255,0.78)" },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold",
									style: { color: row.edge === "Even" ? "rgba(255,255,255,0.45)" : YELLOW },
									children: [
										row.label,
										" → ",
										row.edge,
										"."
									]
								}),
								" ",
								row.reason
							]
						}, row.label))
					})
				] }),
				brief.sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[10px] font-bold tracking-[0.14em] mb-1",
					style: { color: YELLOW },
					children: [
						section.n,
						". ",
						section.title.toUpperCase()
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-0.5",
					children: section.lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-[11px]",
						style: { color: TONE_COLOR[line.tone] },
						children: ["• ", line.text]
					}, i))
				})] }, section.n)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-bold tracking-[0.14em] mb-1",
					style: { color: BLUE },
					children: "ACCURACY UPGRADES ON THIS GAME"
				}), brief.upgrades.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-bold tracking-[0.12em] mb-0.5",
						style: { color: "rgba(255,255,255,0.55)" },
						children: section.title.toUpperCase()
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-0.5",
						children: section.lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-[11px]",
							style: { color: TONE_COLOR[line.tone] },
							children: ["• ", line.text]
						}, i))
					})]
				}, section.title))] })
			]
		})]
	});
}
function StatusBadge({ status, detail }) {
	if (status === "in") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1 text-[9px] font-bold px-2 py-0.5 rounded-full animate-pulse",
		style: {
			background: "rgba(239,68,68,0.15)",
			color: "#ef4444"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1.5 h-1.5 rounded-full bg-red-500" }), " LIVE"]
	});
	if (status === "post") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-[9px] font-bold px-2 py-0.5 rounded-full",
		style: {
			background: "rgba(74,222,128,0.12)",
			color: GREEN
		},
		children: "FINAL ✓"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-[9px] font-medium px-2 py-0.5 rounded-full",
		style: {
			background: "rgba(96,165,250,0.10)",
			color: BLUE
		},
		children: detail || "Scheduled"
	});
}
function Pill({ children, tone = "muted" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold ${tone === "primary" ? "bg-primary/15 text-primary border-primary/30" : tone === "danger" ? "bg-destructive/15 text-destructive border-destructive/40" : "bg-muted text-muted-foreground border-border"}`,
		children
	});
}
function GameCard({ game, year, month, day, idx, league }) {
	const [auto, setAuto] = (0, import_react.useState)(null);
	const [autoLoading, setAutoLoading] = (0, import_react.useState)(true);
	const isFight = league === "UFC";
	const [dobs, setDobs] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (!isFight) return;
		let alive = true;
		Promise.all([fetchFighterDob(game.homeTeamId), fetchFighterDob(game.awayTeamId)]).then(([h, a]) => {
			if (alive) {
				setDobs({
					home: h,
					away: a
				});
				setAutoLoading(false);
			}
		});
		return () => {
			alive = false;
		};
	}, [game.id, isFight]);
	(0, import_react.useEffect)(() => {
		if (isFight) return;
		let alive = true;
		setAutoLoading(true);
		fetchAutoMatchup(league, game.id).then((a) => {
			if (alive) {
				setAuto(a);
				setAutoLoading(false);
			}
		}).catch(() => {
			if (alive) setAutoLoading(false);
		});
		return () => {
			alive = false;
		};
	}, [game.id, league]);
	const homeMeta = getTeamMeta(game.homeTeam);
	const awayMeta = getTeamMeta(game.awayTeam);
	const starterRole = league === "NFL" || league === "College Football" ? "quarterback" : league === "MLB" ? "pitcher" : "player";
	const kickoff = (0, import_react.useMemo)(() => {
		const t = new Date(game.startTime);
		return isNaN(t.getTime()) ? 19 : t.getHours();
	}, [game.startTime]);
	const v = (0, import_react.useMemo)(() => {
		const person = (p, role) => p?.common ? [{
			name: p.common,
			role,
			dob: p.dob,
			jersey: p.jersey
		}] : [];
		const team = (name, meta, side, rec, split) => ({
			name,
			founded: meta?.founded ? [
				meta.founded[0],
				meta.founded[1],
				meta.founded[2]
			] : void 0,
			colors: TEAM_COLORS[name],
			record: side?.record ?? rec ?? void 0,
			split,
			people: [...person(side?.starter, starterRole), ...person(side?.manager, "coach")]
		});
		if (isFight) {
			const dt = (d) => {
				const m = d?.match(/^(\d{4})-(\d{2})-(\d{2})/);
				return m ? [
					+m[1],
					+m[2],
					+m[3]
				] : void 0;
			};
			return runVotes({
				year,
				month,
				day,
				league,
				individual: true,
				hour: kickoff,
				home: {
					name: game.homeTeam,
					founded: dt(dobs.home),
					record: game.homeRecord,
					people: []
				},
				away: {
					name: game.awayTeam,
					founded: dt(dobs.away),
					record: game.awayRecord,
					people: []
				}
			});
		}
		return runVotes({
			year,
			month,
			day,
			league,
			hour: kickoff,
			home: team(game.homeTeam, homeMeta, auto?.home, game.homeRecord, auto?.home?.homeRecord),
			away: team(game.awayTeam, awayMeta, auto?.away, game.awayRecord, auto?.away?.roadRecord),
			stadiumOpened: homeMeta?.stadiumOpened,
			cityFounded: homeMeta?.cityFounded,
			stadium: homeMeta?.stadium,
			city: homeMeta?.city
		});
	}, [
		game.id,
		year,
		month,
		day,
		auto,
		league,
		dobs,
		kickoff
	]);
	const ov = useOverrides();
	const full = (0, import_react.useMemo)(() => {
		const tri = (t) => t ? [
			t[0],
			t[1],
			t[2]
		] : void 0;
		const rec = (s, base) => [
			s?.record ?? base,
			s?.streak && `Streak ${s.streak}`,
			s?.homeRecord && `Home ${s.homeRecord}`,
			s?.roadRecord && `Away ${s.roadRecord}`
		].filter(Boolean).join(" · ") || void 0;
		return computeFullDecode(isFight ? [{
			kind: "player",
			side: "away",
			name: game.awayTeam,
			role: "fighter",
			date: parseDob(dobs.away),
			record: game.awayRecord
		}, {
			kind: "player",
			side: "home",
			name: game.homeTeam,
			role: "fighter",
			date: parseDob(dobs.home),
			record: game.homeRecord
		}] : [
			{
				kind: "team",
				side: "away",
				name: game.awayTeam,
				date: tri(awayMeta?.founded),
				record: rec(auto?.away, game.awayRecord)
			},
			{
				kind: "team",
				side: "home",
				name: game.homeTeam,
				date: tri(homeMeta?.founded),
				record: rec(auto?.home, game.homeRecord)
			},
			...["away", "home"].flatMap((s) => {
				const a = auto?.[s];
				const out = [];
				out.push(a?.starter ? {
					kind: "player",
					side: s,
					name: a.starter.common,
					role: starterRole,
					date: parseDob(a.starter.dob),
					jersey: a.starter.jersey
				} : {
					kind: "player",
					side: s,
					name: `${s === "home" ? game.homeTeam : game.awayTeam} starter`,
					role: "not posted yet"
				});
				out.push(a?.manager ? {
					kind: "player",
					side: s,
					name: a.manager.common,
					role: "coach",
					date: parseDob(a.manager.dob),
					jersey: a.manager.jersey
				} : {
					kind: "player",
					side: s,
					name: `${s === "home" ? game.homeTeam : game.awayTeam} coach`,
					role: "not in feed"
				});
				return out;
			}),
			{
				kind: "city",
				side: "venue",
				name: homeMeta?.city ?? "Host city",
				date: tri(homeMeta?.cityFounded)
			},
			{
				kind: "stadium",
				side: "venue",
				name: game.venue ?? homeMeta?.stadium ?? "Stadium",
				date: tri(homeMeta?.stadiumOpened)
			}
		], [
			year,
			month,
			day
		], kickoff, ov);
	}, [
		game.id,
		year,
		month,
		day,
		auto,
		dobs,
		kickoff,
		isFight,
		ov
	]);
	const totalHome = v.home + full.home, totalAway = v.away + full.away;
	const finalPick = totalHome === totalAway ? v.pick : totalHome > totalAway ? "home" : "away";
	const pickName = finalPick === "home" ? game.homeTeam : game.awayTeam;
	const brief = (0, import_react.useMemo)(() => {
		const signOf = (name) => v.entities.find((e) => e.name === name)?.yearSign;
		const mapped = full.reads.map((x) => ({
			side: x.e.side,
			kind: x.e.kind,
			name: x.e.name,
			role: x.e.role,
			jersey: x.e.jersey,
			date: x.e.date,
			yearSign: signOf(x.e.name),
			lp: x.r?.lp,
			pd: x.r?.pd,
			lucky: x.r?.lucky,
			matrix: x.r?.matrix
		}));
		return buildMatchBrief(v, mapped, {
			home: game.homeTeam,
			away: game.awayTeam,
			month
		});
	}, [
		v,
		full,
		game.homeTeam,
		game.awayTeam,
		month
	]);
	const stackGap = +Math.abs(totalHome - totalAway).toFixed(2);
	const sideLine = (label, pts, opp) => `${pts >= opp ? "PICK" : "OTHER SIDE"} ${label} — ${pts.toFixed(2)} vs ${opp.toFixed(2)}`;
	const strength = v.band;
	const verdict = `PICK ${pickName}. Combined ${game.awayTeam} ${totalAway.toFixed(2)} / ${game.homeTeam} ${totalHome.toFixed(2)}, gap +${stackGap.toFixed(2)}. Confidence ${v.confidence}% (${v.band}). ${sideLine(game.awayTeam, totalAway, totalHome)}. ${sideLine(game.homeTeam, totalHome, totalAway)}.`;
	const isFinal = game.status === "post";
	const logId = `${year}-${month}-${day}|${game.id}`;
	(0, import_react.useEffect)(() => {
		if (autoLoading) return;
		logStepPick({
			id: logId,
			date: `${year}-${month}-${day}`,
			home: game.homeTeam,
			away: game.awayTeam,
			pick: finalPick,
			confidence: v.confidence,
			margin: stackGap,
			votes: v.votes.map((x) => ({
				side: x.side,
				layer: x.layer,
				weight: x.weight
			}))
		});
		if (isFinal) {
			const h = Number(game.homeScore), a = Number(game.awayScore);
			scoreStepPick(logId, h > a ? "home" : a > h ? "away" : "draw");
		}
	}, [
		autoLoading,
		isFinal,
		logId,
		v
	]);
	const result = isFinal ? `${game.awayAbbr} ${game.awayScore} – ${game.homeScore} ${game.homeAbbr}` : null;
	const hit = isFinal ? (Number(game.homeScore) > Number(game.awayScore) ? "home" : "away") === finalPick : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-2xl border border-border bg-card overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 mb-3 flex-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10px] font-bold tracking-[0.18em] text-primary",
						children: [
							isFight ? "FIGHT" : "GAME",
							" ",
							idx + 1,
							" · ",
							(game.venue ?? homeMeta?.stadium ?? "").toUpperCase()
						]
					}), result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
						tone: hit ? "primary" : "danger",
						children: [
							"FINAL ",
							result,
							" · ",
							hit ? "HIT" : "MISS"
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
						status: game.status,
						detail: game.statusDetail
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-3 mb-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Away"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-black text-foreground truncate",
									children: game.awayTeam
								}),
								game.awayRecord && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: game.awayRecord
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground",
									children: "PICK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base font-black text-primary",
									children: pickName.toUpperCase()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-4xl font-black text-foreground leading-none my-1",
									children: [v.confidence, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
									tone: "primary",
									children: strength
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[9px] text-muted-foreground mt-1",
									children: ["gap +", stackGap.toFixed(2)]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Home"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-black text-foreground truncate",
									children: game.homeTeam
								}),
								game.homeRecord && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: game.homeRecord
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 rounded-full bg-muted overflow-hidden mb-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-primary",
						style: { width: `${v.confidence}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-[9px] text-muted-foreground mb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "0 Challenging" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "30 Mixed" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "50 Good" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "70 Strong" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "85 Exceptional" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-muted/40 p-3 mb-3 space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold text-foreground",
							children: verdict
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px]",
							style: { color: totalAway >= totalHome ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))" },
							children: sideLine(game.awayTeam, totalAway, totalHome)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px]",
							style: { color: totalHome >= totalAway ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))" },
							children: sideLine(game.homeTeam, totalHome, totalAway)
						})
					]
				}),
				v.alerts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg border border-destructive/40 bg-destructive/10 p-3 mb-3 space-y-1",
					children: v.alerts.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-bold text-destructive",
						children: ["⚠ ", a]
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestedBrief, { brief }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FullDecode, {
					title: `${game.awayTeam} @ ${game.homeTeam} · ${month}/${day}/${year}`,
					data: full,
					homeName: game.homeTeam,
					awayName: game.awayTeam,
					verdict
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[10px] font-bold tracking-[0.18em] text-primary mb-2",
					children: [
						"FULL SIDE-BY-SIDE DECODE · Game day #",
						v.gameDayOfYear,
						" · ",
						v.gameDaySign,
						" day"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto mb-4 rounded-lg border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-[11px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/40 text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Side",
								"Role",
								"Name",
								"Date",
								"Life Path",
								"Day #",
								"Day energy",
								"Lucky",
								"Year / Month / Day animal",
								"Personal Day"
							].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left font-semibold px-2 py-1.5 whitespace-nowrap",
								children: h
							}, h)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: v.entities.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-1.5 whitespace-nowrap",
									children: e.side === "venue" ? "Venue" : e.side === "home" ? game.homeTeam : game.awayTeam
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-1.5",
									children: e.role
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-1.5 font-semibold text-foreground whitespace-nowrap",
									children: e.name
								}),
								e.date ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-1.5 whitespace-nowrap",
										children: e.date
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-1.5",
										children: e.lp && fmt(e.lp)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-1.5",
										children: e.dayOfYear
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-1.5",
										children: e.dayEnergy && fmt(e.dayEnergy)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-1.5",
										children: e.lucky
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-2 py-1.5 whitespace-nowrap",
										children: [
											e.yearSign,
											" / ",
											e.monthSign,
											" / ",
											e.daySign
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-2 py-1.5 whitespace-nowrap",
										children: [
											e.pd && fmt(e.pd),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: e.pdRel === "enemy" || e.pdRel === "worst" ? "text-destructive" : e.pdRel === "neutral" ? "text-muted-foreground" : "text-primary",
												children: [
													"(",
													e.pdRel,
													")"
												]
											})
										]
									})
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 7,
									className: "px-2 py-1.5 text-muted-foreground",
									children: "Birth / founding date not available yet"
								})
							]
						}, i)) })]
					})
				}),
				autoLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] mt-3 text-muted-foreground",
					children: "Loading starters, coaches and birthdays…"
				}) : v.missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[10px] mt-3 text-muted-foreground",
					children: ["Not available yet: ", [...new Set(v.missing)].join(" · ")]
				})
			]
		})
	});
}
function HitRatePanel() {
	const [r, setR] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setR(stepHitRates());
		const t = setInterval(() => setR(stepHitRates()), 5e3);
		return () => clearInterval(t);
	}, []);
	if (!r) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-bold tracking-[0.18em] text-primary mb-2",
				children: "SIGNAL HIT RATE"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-foreground mb-3",
				children: [
					"Overall: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
						r.hits,
						"/",
						r.total
					] }),
					r.total ? ` (${Math.round(100 * r.hits / r.total)}%)` : "",
					" · ",
					r.total < 30 ? `${30 - r.total} more scored picks until this is reliable` : "reliable sample reached"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-2",
				children: [
					Object.entries(r.steps).map(([k, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-muted/40 p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted-foreground",
							children: k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-bold text-foreground",
							children: [
								s.hits,
								"/",
								s.total,
								" · ",
								Math.round(100 * s.hits / s.total),
								"%"
							]
						})]
					}, k)),
					Object.entries(r.bands).map(([k, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-primary/30 p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] text-primary",
							children: [k, " picks"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-bold text-foreground",
							children: [
								s.hits,
								"/",
								s.total,
								" · ",
								Math.round(100 * s.hits / s.total),
								"%"
							]
						})]
					}, k)),
					Object.entries(r.stacks).map(([k, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] text-muted-foreground",
							children: ["Stack ", k]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-bold text-foreground",
							children: [
								s.hits,
								"/",
								s.total,
								" · ",
								Math.round(100 * s.hits / s.total),
								"%"
							]
						})]
					}, k)),
					Object.keys(r.steps).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground col-span-full",
						children: "Finished games are scored automatically — check back after games end."
					})
				]
			})
		]
	});
}
function SportsPredictionPage() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const today = /* @__PURE__ */ new Date();
	const [month, setMonth] = (0, import_react.useState)(today.getMonth() + 1);
	const [day, setDay] = (0, import_react.useState)(today.getDate());
	const [year, setYear] = (0, import_react.useState)(today.getFullYear());
	const [league, setLeague] = (0, import_react.useState)("MLB");
	const userPicked = (0, import_react.useRef)(false);
	const [games, setGames] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [allGames, setAllGames] = (0, import_react.useState)({});
	const fetchVersion = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const leagueInfo = getLeagueInfo(league);
	const fetchGames = (0, import_react.useCallback)(async () => {
		const v = ++fetchVersion.current;
		setLoading(true);
		setError(null);
		try {
			const r = await fetchESPNGames(league, month, day, year);
			if (fetchVersion.current !== v) return;
			setGames(r);
		} catch {
			if (fetchVersion.current !== v) return;
			setError("Failed to fetch games");
			setGames([]);
		} finally {
			if (fetchVersion.current === v) setLoading(false);
		}
	}, [
		league,
		month,
		day,
		year
	]);
	(0, import_react.useEffect)(() => {
		fetchGames();
	}, [fetchGames]);
	const fetchAll = (0, import_react.useCallback)(async () => {
		const majors = [
			"World Cup",
			"NBA",
			"NFL",
			"MLB",
			"NHL",
			"MLS",
			"Premier League",
			"La Liga",
			"UFC"
		];
		const out = {};
		await Promise.all(majors.map(async (lg) => {
			try {
				out[lg] = await fetchESPNGames(lg, month, day, year);
			} catch {
				out[lg] = [];
			}
		}));
		setAllGames(out);
		const order = [
			"World Cup",
			"NBA",
			"MLB",
			"NHL",
			"NFL",
			"MLS",
			"Premier League",
			"La Liga"
		];
		if (!userPicked.current && (out[league]?.length ?? 0) === 0) {
			const first = order.find((lg) => (out[lg]?.length ?? 0) > 0);
			if (first) setLeague(first);
		}
	}, [
		month,
		day,
		year
	]);
	(0, import_react.useEffect)(() => {
		fetchAll();
	}, [fetchAll]);
	const leagueCounts = (0, import_react.useMemo)(() => {
		const c = {};
		for (const [lg, lgg] of Object.entries(allGames)) if (lgg.length) c[lg] = lgg.length;
		return c;
	}, [allGames]);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "max-w-6xl" });
	const displayDate = new Date(year, month - 1, day).toLocaleDateString("en-US", {
		weekday: "long",
		month: "long",
		day: "numeric",
		year: "numeric"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-6xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl p-6 relative overflow-hidden",
				style: {
					background: "hsl(var(--card))",
					border: "1px solid rgba(250,204,21,0.15)"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10px] font-bold tracking-[0.25em] mb-2 flex items-center gap-2",
						style: { color: BLUE },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { size: 12 }),
							" 7-STEP DECODE · ",
							leagueInfo.label.toUpperCase()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "text-5xl md:text-6xl font-black leading-none tracking-tight",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-white",
								children: "SPORTS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: { color: YELLOW },
								children: "CODE CARD"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] mt-3 tracking-widest",
						style: {
							color: "rgba(96,165,250,0.7)",
							fontFamily: "ui-monospace, monospace"
						},
						children: displayDate.toUpperCase()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavedEdits, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-end gap-2",
						children: [[
							{
								l: "Month",
								v: month,
								s: setMonth,
								min: 1,
								max: 12,
								w: "w-16"
							},
							{
								l: "Day",
								v: day,
								s: setDay,
								min: 1,
								max: 31,
								w: "w-16"
							},
							{
								l: "Year",
								v: year,
								s: setYear,
								min: 2020,
								max: 2030,
								w: "w-20"
							}
						].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[8px] uppercase tracking-widest mb-1 text-center",
							style: { color: "rgba(255,255,255,0.3)" },
							children: f.l
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: f.min,
							max: f.max,
							value: f.v,
							onChange: (e) => f.s(+e.target.value),
							className: `${f.w} text-center rounded-xl px-2 py-2 text-sm font-bold`,
							style: {
								background: "rgba(255,255,255,0.06)",
								border: "1px solid rgba(255,255,255,0.1)",
								color: "white",
								outline: "none"
							}
						})] }, f.l)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: fetchGames,
							disabled: loading,
							className: "ml-2 flex items-center gap-1.5 text-[10px] px-3 py-2 rounded-xl",
							style: {
								background: "rgba(96,165,250,0.12)",
								color: BLUE,
								border: "1px solid rgba(96,165,250,0.25)"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								size: 11,
								className: loading ? "animate-spin" : ""
							}), " Refresh"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[9px] uppercase tracking-[0.2em] mb-3 font-semibold",
				style: { color: "rgba(255,255,255,0.35)" },
				children: "Select League"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: LEAGUE_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[7px] uppercase tracking-widest mb-1.5",
					style: { color: "rgba(255,255,255,0.25)" },
					children: group.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: group.leagues.map((l) => {
						const info = getLeagueInfo(l);
						const active = league === l;
						const count = leagueCounts[l];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								userPicked.current = true;
								setLeague(l);
								if (l === "UFC") {
									const d = /* @__PURE__ */ new Date();
									const dow = d.getDay();
									d.setDate(d.getDate() + (dow === 0 ? -1 : 6 - dow));
									setYear(d.getFullYear());
									setMonth(d.getMonth() + 1);
									setDay(d.getDate());
								}
							},
							className: "px-3 py-1.5 rounded-xl text-[9px] font-semibold flex items-center gap-1.5",
							style: active ? {
								background: "rgba(96,165,250,0.18)",
								color: BLUE,
								border: "1px solid rgba(96,165,250,0.35)"
							} : {
								background: "rgba(255,255,255,0.03)",
								color: count ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.25)",
								border: "1px solid rgba(255,255,255,0.06)"
							},
							children: [
								info.emoji,
								" ",
								l,
								count !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[7px] px-1 rounded-full",
									style: {
										background: active ? "rgba(96,165,250,0.25)" : "rgba(74,222,128,0.12)",
										color: active ? BLUE : GREEN
									},
									children: count
								})
							]
						}, l);
					})
				})] }, group.label))
			})] }),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl p-12 text-center",
				style: {
					background: "hsl(228 28% 7%)",
					border: "1px solid rgba(255,255,255,0.05)"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					size: 28,
					className: "animate-spin mx-auto mb-3",
					style: { color: BLUE }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-semibold text-white",
					children: [
						"Loading ",
						leagueInfo.label,
						"…"
					]
				})]
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl p-8 text-center",
				style: {
					background: "hsl(228 28% 7%)",
					border: "1px solid rgba(239,68,68,0.15)"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
						size: 24,
						className: "mx-auto mb-2",
						style: { color: ROSE }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-white mb-1",
						children: "Connection Error"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs",
						style: { color: "rgba(255,255,255,0.4)" },
						children: error
					})
				]
			}) : games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl p-10 text-center",
				style: {
					background: "hsl(228 28% 7%)",
					border: "1px solid rgba(255,255,255,0.05)"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
						size: 28,
						className: "mx-auto mb-3",
						style: { color: "rgba(255,255,255,0.15)" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-white mb-1",
						children: [
							"No ",
							leagueInfo.label,
							" games"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs",
						style: { color: "rgba(255,255,255,0.4)" },
						children: "Try another league with games today."
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HitRatePanel, {}), games.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameCard, {
					game: g,
					year,
					month,
					day,
					idx: i,
					league
				}, g.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[8px] text-center",
				style: { color: "rgba(255,255,255,0.2)" },
				children: "Live schedules from ESPN · 7-step numerology decode · For entertainment — bet responsibly."
			})
		]
	});
}
var SplitComponent = SportsPredictionPage;
//#endregion
export { SplitComponent as component };
