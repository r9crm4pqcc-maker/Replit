import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as seasonOf, o as LIST_LABEL, r as useLife, w as readDay, x as parseIso } from "./router-Da7lqNNo.mjs";
import { a as Tag, i as Stat, r as Page, t as Card } from "./kit-sB4xIagL.mjs";
import { n as useParams, t as Link$1 } from "./wouter-CfVlts7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/day._-D14Nl3wV.js
var import_jsx_runtime = require_jsx_runtime();
function DayPage() {
	const { sub } = useParams();
	const { profile } = useLife();
	const parsed = sub ? parseIso(sub) : null;
	if (!parsed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		kicker: "Date",
		title: "That date is not valid",
		lede: "Use a real calendar day.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
			href: "/dates",
			className: "text-sm text-primary",
			children: "Back to the library"
		})
	});
	const read = readDay(profile, parsed.y, parsed.m, parsed.d);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		kicker: read.weekday,
		title: `${read.m}/${read.d}/${read.y}`,
		lede: read.headline.replace(/^Today is /, "This is "),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					read.tones.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
						tone: t === "fatal" || t === "challenging" ? "bad" : "good",
						children: LIST_LABEL[t]
					}, t)),
					read.flags.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children: f }, f)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
						tone: read.earth === "enemy" ? "bad" : read.earth === "friend" ? "good" : "neutral",
						children: ["Earth ", read.earth]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
						tone: read.west === "enemy" ? "bad" : read.west === "friend" ? "good" : "neutral",
						children: ["Western ", read.west]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, { children: ["Number ", read.number] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Universal day",
						value: read.labelU,
						hint: `${read.universalMonth.reduced} month · ${read.universalYear.reduced} year`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Personal day",
						value: read.labelP,
						hint: `Year ${read.personalYear.reduced} · month ${read.personalMonth.reduced}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Sky",
						value: read.sun,
						hint: `${seasonOf(read.m, read.d)} · moon ${read.moonSign} · ${read.moon}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Chinese month",
						value: read.monthAnimal,
						hint: `Marker vs your year animal: ${read.earth}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg mb-2",
					children: "Combined reading"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-foreground/90",
					children: read.reading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-1 text-sm text-muted-foreground",
					children: read.notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n }, n))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid sm:grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg text-primary mb-2",
					children: "Do"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 text-sm text-foreground/90",
					children: read.dos.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: x }, x))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg text-destructive mb-2",
					children: "Avoid"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 text-sm text-foreground/90",
					children: read.avoids.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: x }, x))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
				href: "/dates",
				className: "text-sm text-primary",
				children: "All date lists"
			})
		]
	});
}
var SplitComponent = DayPage;
//#endregion
export { SplitComponent as component };
