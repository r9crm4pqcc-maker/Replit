import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as digitSum, c as moonSign, d as westernSign, i as chineseYear, l as nameNumber, n as chineseHour, o as lifePath, r as chineseMonth, s as moonPhase, t as chineseDay, u as reduceMaster } from "./sports-decode-DLB-V19a.mjs";
import { T as Check, n as X, o as TriangleAlert, p as Moon, s as TrendingUp, u as Sparkles, w as ChevronDown, x as Clock } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/trading-ai-D2PFTcO6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TRADING_ENTITIES = [
	{
		symbol: "SPX",
		name: "S&P 500",
		category: "index",
		anchorDate: "03/04/1957",
		description: "S&P 500 composite index",
		sector: "Capricorn"
	},
	{
		symbol: "NDX",
		name: "Nasdaq 100",
		category: "index",
		anchorDate: "02/08/1971",
		description: "Nasdaq composite index",
		sector: "Aquarius"
	},
	{
		symbol: "DJI",
		name: "Dow Jones",
		category: "index",
		anchorDate: "05/26/1896",
		description: "Dow Jones Industrial",
		sector: "Capricorn"
	},
	{
		symbol: "RUT",
		name: "Russell 2000",
		category: "index",
		anchorDate: "01/01/1984",
		description: "Small-cap index",
		sector: "Aries"
	},
	{
		symbol: "SPY",
		name: "SPY ETF",
		category: "etf",
		anchorDate: "01/22/1993",
		description: "SPDR S&P 500 ETF",
		sector: "Capricorn"
	},
	{
		symbol: "QQQ",
		name: "QQQ ETF",
		category: "etf",
		anchorDate: "03/10/1999",
		description: "Invesco Nasdaq ETF",
		sector: "Aquarius"
	},
	{
		symbol: "NVDA",
		name: "NVIDIA",
		category: "stock",
		anchorDate: "01/22/1999",
		description: "AI / GPU leader",
		sector: "Aquarius"
	},
	{
		symbol: "TSLA",
		name: "Tesla",
		category: "stock",
		anchorDate: "06/29/2010",
		description: "EV & energy",
		sector: "Cancer"
	},
	{
		symbol: "AAPL",
		name: "Apple",
		category: "stock",
		anchorDate: "12/12/1980",
		description: "Consumer electronics",
		sector: "Sagittarius"
	},
	{
		symbol: "AMD",
		name: "AMD",
		category: "stock",
		anchorDate: "09/27/1972",
		description: "Semiconductors",
		sector: "Libra"
	},
	{
		symbol: "META",
		name: "Meta",
		category: "stock",
		anchorDate: "02/01/2012",
		description: "Social media",
		sector: "Aquarius"
	},
	{
		symbol: "AMZN",
		name: "Amazon",
		category: "stock",
		anchorDate: "05/15/1997",
		description: "E-commerce & cloud",
		sector: "Taurus"
	},
	{
		symbol: "GOOGL",
		name: "Alphabet",
		category: "stock",
		anchorDate: "08/19/2004",
		description: "Search & cloud",
		sector: "Leo"
	},
	{
		symbol: "MSFT",
		name: "Microsoft",
		category: "stock",
		anchorDate: "03/13/1986",
		description: "Software & cloud",
		sector: "Pisces"
	},
	{
		symbol: "COIN",
		name: "Coinbase",
		category: "stock",
		anchorDate: "04/14/2021",
		description: "Crypto exchange",
		sector: "Aries"
	},
	{
		symbol: "MSTR",
		name: "MicroStrategy",
		category: "stock",
		anchorDate: "06/11/1998",
		description: "BTC treasury",
		sector: "Gemini"
	},
	{
		symbol: "PLTR",
		name: "Palantir",
		category: "stock",
		anchorDate: "09/30/2020",
		description: "AI / data",
		sector: "Libra"
	},
	{
		symbol: "SMCI",
		name: "Super Micro",
		category: "stock",
		anchorDate: "03/29/2007",
		description: "AI server hardware",
		sector: "Aries"
	},
	{
		symbol: "BTC",
		name: "Bitcoin",
		category: "crypto",
		anchorDate: "01/03/2009",
		description: "Bitcoin genesis",
		sector: "Capricorn"
	},
	{
		symbol: "ETH",
		name: "Ethereum",
		category: "crypto",
		anchorDate: "07/30/2015",
		description: "Ethereum mainnet",
		sector: "Leo"
	}
];
var MERCURY_RETRO = [
	["2024-04-01", "2024-04-25"],
	["2024-08-05", "2024-08-28"],
	["2024-11-25", "2024-12-15"],
	["2025-03-15", "2025-04-07"],
	["2025-07-18", "2025-08-11"],
	["2025-11-09", "2025-11-29"],
	["2026-02-26", "2026-03-20"],
	["2026-06-29", "2026-07-23"],
	["2026-10-24", "2026-11-13"],
	["2027-02-09", "2027-03-03"],
	["2027-06-10", "2027-07-04"],
	["2027-10-07", "2027-10-28"]
];
var ECLIPSES = [
	"2024-03-25",
	"2024-04-08",
	"2024-09-18",
	"2024-10-02",
	"2025-03-14",
	"2025-03-29",
	"2025-09-07",
	"2025-09-21",
	"2026-02-17",
	"2026-03-03",
	"2026-08-12",
	"2026-08-28",
	"2027-02-06",
	"2027-02-20",
	"2027-07-18",
	"2027-08-02",
	"2027-08-17"
];
function inWindow(dateISO, windows) {
	const d = dateISO.slice(0, 10);
	return windows.some(([a, b]) => a <= d && d <= b);
}
function inList(dateISO, list) {
	return list.includes(dateISO.slice(0, 10));
}
var SECTOR_MAP = {
	Aquarius: "Tech / AI / software / semis",
	Pisces: "Biotech / pharma / speculative growth",
	Aries: "Momentum / startups / high beta",
	Taurus: "Banking / assets / commodities / real estate",
	Gemini: "Communications / media / telecom",
	Cancer: "Consumer / housing / food",
	Leo: "Entertainment / luxury / branding",
	Virgo: "Healthcare / precision / analytics",
	Libra: "Retail / fashion / consumer balance",
	Scorpio: "Energy / oil / hidden value",
	Sagittarius: "Travel / expansion / global",
	Capricorn: "Institutions / industrials / legacy"
};
var LUNAR_DIR = {
	"New Moon": "LONG",
	"Waxing Crescent": "LONG",
	"First Quarter": "LONG",
	"Waxing Gibbous": "LONG",
	"Full Moon": "SHORT",
	"Waning Gibbous": "SHORT",
	"Last Quarter": "SHORT",
	"Waning Crescent": "NEUTRAL"
};
var STEM_ELEMENTS = [
	"Wood",
	"Wood",
	"Fire",
	"Fire",
	"Earth",
	"Earth",
	"Metal",
	"Metal",
	"Water",
	"Water"
];
function stemElement(year) {
	return STEM_ELEMENTS[((year - 4) % 10 + 10) % 10];
}
var GENERATES = {
	Wood: "Fire",
	Fire: "Earth",
	Earth: "Metal",
	Metal: "Water",
	Water: "Wood"
};
var CONTROLS = {
	Wood: "Earth",
	Earth: "Water",
	Water: "Fire",
	Fire: "Metal",
	Metal: "Wood"
};
function uniYear(year) {
	return reduceMaster(digitSum(year));
}
function uniMonth(year, month) {
	return reduceMaster(uniYear(year) + reduceMaster(month));
}
function uniDayRaw(y, m, d) {
	return `${String(m).padStart(2, "0")}${String(d).padStart(2, "0")}${y}`.split("").reduce((a, c) => a + Number(c), 0);
}
function universalDay(y, m, d) {
	const raw = uniDayRaw(y, m, d);
	const reduced = reduceMaster(raw);
	return {
		raw,
		reduced,
		master: reduced === 11 || reduced === 22 || reduced === 33 ? reduced : null,
		karmic: raw === 13 || raw === 14 || raw === 16 || raw === 19
	};
}
var DAY_MOOD = {
	1: {
		name: "Initiation",
		character: "Breakouts / buyers lead",
		bias: "LONG"
	},
	2: {
		name: "Balance",
		character: "Range-bound / quiet reversals",
		bias: "NEUTRAL"
	},
	3: {
		name: "Expansion",
		character: "Loud hype pops / scattered",
		bias: "LONG"
	},
	4: {
		name: "Structure",
		character: "Slow grind / support holds",
		bias: "LONG"
	},
	5: {
		name: "Change",
		character: "Whipsaw / news-driven",
		bias: "NEUTRAL"
	},
	6: {
		name: "Harmony",
		character: "Recovery / dip-buying",
		bias: "LONG"
	},
	7: {
		name: "Analysis",
		character: "Pullbacks / traps / low volume",
		bias: "SHORT"
	},
	8: {
		name: "Power",
		character: "Institutional flow / directional",
		bias: "LONG"
	},
	9: {
		name: "Completion",
		character: "Tops/bottoms / exhaustion",
		bias: "SHORT"
	},
	11: {
		name: "Live Wire",
		character: "Sudden swings / emotional spikes",
		bias: "NEUTRAL"
	},
	22: {
		name: "Master Builder",
		character: "Major level breaks on size",
		bias: "LONG"
	},
	33: {
		name: "Master Teacher",
		character: "Crowd blow-offs / big reversals",
		bias: "SHORT"
	}
};
var WINDOWS = {
	1: {
		entry: "9:30–10:15 AM ET",
		exit: "2:00–3:00 PM ET",
		cautions: ["Avoid last hour"]
	},
	2: {
		entry: "10:00–10:45 AM ET",
		exit: "1:00–2:00 PM ET",
		cautions: ["Chop mid-session"]
	},
	3: {
		entry: "9:45–10:30 AM ET",
		exit: "3:00–4:00 PM ET",
		cautions: ["Fade the pop"]
	},
	4: {
		entry: "10:30–11:30 AM ET",
		exit: "2:30–3:30 PM ET",
		cautions: ["Lunch drift"]
	},
	5: {
		entry: "9:30–10:00 AM ET",
		exit: "11:30 AM–12:30 PM",
		cautions: ["Wide stops mandatory"]
	},
	6: {
		entry: "11:00 AM–12:00 PM",
		exit: "2:00–3:00 PM ET",
		cautions: ["Slow tape"]
	},
	7: {
		entry: "9:30–10:15 AM ET",
		exit: "1:30–2:30 PM ET",
		cautions: ["Fade extremes, don't chase"]
	},
	8: {
		entry: "9:30–10:00 AM ET",
		exit: "3:30–4:00 PM ET",
		cautions: ["High volume = real moves"]
	},
	9: {
		entry: "10:00–11:00 AM ET",
		exit: "3:00–4:00 PM ET",
		cautions: ["Reversal risk near close"]
	},
	11: {
		entry: "9:30–9:45 AM ET",
		exit: "Trail — volatile",
		cautions: ["Emotional whipsaw"]
	},
	22: {
		entry: "10:00–11:00 AM ET",
		exit: "Hold trend",
		cautions: ["Size up on confirmation"]
	},
	33: {
		entry: "Stand aside AM",
		exit: "Fade the blow-off PM",
		cautions: ["Crowd euphoria — reverse"]
	}
};
function calcMarketCode(entity, month, day, year) {
	const dateISO = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
	const dateStr = dateISO;
	const uy = uniYear(year);
	const um = uniMonth(year, month);
	const ud = universalDay(year, month, day);
	const mood = DAY_MOOD[ud.reduced] ?? DAY_MOOD[9];
	const [am, ad, ay] = entity.anchorDate.split("/").map(Number);
	const lp = lifePath(ay, am, ad).reduced;
	const nn = nameNumber(entity.name).reduced;
	const resonance = ud.reduced === lp || ud.reduced === nn;
	const mp = moonPhase(year, month, day);
	const lunarDir = LUNAR_DIR[mp.phase];
	const ms = moonSign(year, month, day);
	const ss = westernSign(month, day).sign;
	const spotlight = SECTOR_MAP[ms] ?? "—";
	const sectorMatch = !!entity.sector && (ms === entity.sector || ss === entity.sector);
	const noonISO = new Date(Date.UTC(year, month - 1, day, 12)).toISOString();
	const pillars = {
		year: chineseYear(year, month, day),
		month: chineseMonth(month, day),
		day: chineseDay(year, month, day),
		hour: chineseHour(new Date(noonISO).getUTCHours())
	};
	const entityElement = stemElement(ay);
	const dayElement = stemElement(year);
	let elementSupport = "neutral";
	if (entityElement === dayElement) elementSupport = "same";
	else if (GENERATES[dayElement] === entityElement) elementSupport = "generates";
	else if (CONTROLS[dayElement] === entityElement) elementSupport = "controls";
	const mercuryRetro = inWindow(dateISO, MERCURY_RETRO);
	const eclipseWindow = inList(dateISO, ECLIPSES);
	let candidateDirection = "STAND ASIDE";
	if (lunarDir !== "NEUTRAL" && mood.bias !== "NEUTRAL" && lunarDir === mood.bias) candidateDirection = lunarDir;
	else if (lunarDir === mood.bias && lunarDir !== "NEUTRAL") candidateDirection = lunarDir;
	const checks = [];
	checks.push({
		label: "Lunar phase agrees",
		passed: candidateDirection !== "STAND ASIDE" && lunarDir === candidateDirection,
		note: `${mp.phase} → ${lunarDir}`
	});
	checks.push({
		label: "Universal Day # agrees",
		passed: candidateDirection !== "STAND ASIDE" && mood.bias === candidateDirection,
		note: `#${ud.reduced} ${mood.name} → ${mood.bias}`
	});
	checks.push({
		label: "Sector match (Sun/Moon ↔ entity)",
		passed: sectorMatch,
		note: entity.sector ? `entity=${entity.sector} · moon=${ms} · sun=${ss}` : "no sector on entity"
	});
	checks.push({
		label: "Resonance (Day # = LP or Name #)",
		passed: resonance,
		note: `LP ${lp} · Name # ${nn} · Day ${ud.reduced}`
	});
	checks.push({
		label: "Planetary aspect agrees",
		passed: false,
		note: "manual ephemeris check — v1 defaults to false"
	});
	const seasonalTurns = [
		"03-20",
		"06-21",
		"09-22",
		"12-21"
	];
	const md = dateISO.slice(5);
	const gann = seasonalTurns.some((t) => Math.abs((/* @__PURE__ */ new Date(`${year}-${t}`)).getTime() - new Date(dateISO).getTime()) <= 864e5);
	checks.push({
		label: "Gann anniversary / cardinal ±1d",
		passed: gann,
		note: gann ? `near seasonal cardinal ${md}` : "no seasonal turn nearby"
	});
	checks.push({
		label: "Chinese pillar supports entity",
		passed: elementSupport === "generates" || elementSupport === "same",
		note: `day ${dayElement} ${elementSupport} entity ${entityElement}`
	});
	let score = checks.filter((c) => c.passed).length;
	const vetoes = [];
	if (eclipseWindow) vetoes.push("Eclipse day — stand aside");
	if (ud.karmic) vetoes.push(`Karmic-debt raw total ${ud.raw}`);
	if (mercuryRetro && score < 5) vetoes.push("Mercury retrograde + score < 5");
	let action = "NO TRADE";
	if (vetoes.length === 0 && candidateDirection !== "STAND ASIDE") {
		if (score >= 5) action = "FULL SIZE";
		else if (score >= 3) action = "HALF SIZE";
	}
	const win = WINDOWS[ud.reduced] ?? WINDOWS[9];
	const breakdown = `Date ${dateStr}\nUniversal: Y${uy}·M${um}·D${ud.reduced} (raw ${ud.raw}${ud.master ? ` · MASTER ${ud.master}` : ""}${ud.karmic ? ` · KARMIC` : ""})\nDay mood: ${mood.name} — ${mood.character} → ${mood.bias}\nEntity ${entity.symbol}: LP ${lp} · Name # ${nn} · ${entityElement} year${resonance ? " · RESONANCE" : ""}\nLunar: ${mp.phase} → ${lunarDir} · moon ${ms} · sun ${ss}\nSector spotlight: ${spotlight}${sectorMatch ? " · MATCH ✓" : ""}\nChinese pillars: Y-${pillars.year} · M-${pillars.month} · D-${pillars.day} · H-${pillars.hour}\nElement: day ${dayElement} ${elementSupport} entity ${entityElement}\nMercury retro: ${mercuryRetro} · Eclipse: ${eclipseWindow}\nDirection: ${candidateDirection} · Score: ${score}/7 · Vetoes: ${vetoes.length ? vetoes.join("; ") : "none"} → ${action}`;
	return {
		date: dateStr,
		entity,
		universalYear: uy,
		universalMonth: um,
		universalDay: ud.reduced,
		universalDayRaw: ud.raw,
		masterDay: ud.master,
		karmicDay: ud.karmic,
		dayMood: mood.name,
		dayCharacter: mood.character,
		entityLifepath: lp,
		entityNameNumber: nn,
		resonance,
		lunarPhase: mp.phase,
		lunarBias: lunarDir,
		moonSign: ms,
		sunSign: ss,
		sectorSpotlight: spotlight,
		sectorMatch,
		chinesePillars: pillars,
		entityElement,
		dayElement,
		elementSupport,
		mercuryRetro,
		eclipseWindow,
		candidateDirection,
		checks,
		score,
		vetoes,
		action,
		entryWindow: win.entry,
		exitWindow: win.exit,
		cautionZones: win.cautions,
		breakdown
	};
}
function calcWeek(entity, startDate) {
	return Array.from({ length: 7 }, (_, i) => {
		const d = new Date(startDate);
		d.setDate(d.getDate() + i);
		return calcMarketCode(entity, d.getMonth() + 1, d.getDate(), d.getFullYear());
	});
}
var BLUE = "hsl(212 95% 65%)";
var YELLOW = "hsl(48 96% 53%)";
var GREEN = "#4ade80";
var RED = "#f87171";
var PURPLE = "#a78bfa";
var cats = [
	"All",
	"index",
	"etf",
	"stock",
	"crypto"
];
var DIR_COLOR = {
	LONG: GREEN,
	SHORT: RED,
	"STAND ASIDE": YELLOW
};
var ACTION_COLOR = {
	"FULL SIZE": GREEN,
	"HALF SIZE": YELLOW,
	"NO TRADE": RED
};
var ACTION_BG = {
	"FULL SIZE": "rgba(74,222,128,0.15)",
	"HALF SIZE": "rgba(250,204,21,0.15)",
	"NO TRADE": "rgba(248,113,113,0.15)"
};
var ACTION_BORDER = {
	"FULL SIZE": "rgba(74,222,128,0.35)",
	"HALF SIZE": "rgba(250,204,21,0.30)",
	"NO TRADE": "rgba(248,113,113,0.35)"
};
var ZODIAC_ICON = {
	Rat: "🐀",
	Ox: "🐂",
	Tiger: "🐅",
	Rabbit: "🐇",
	Dragon: "🐉",
	Snake: "🐍",
	Horse: "🐎",
	Goat: "🐐",
	Monkey: "🐒",
	Rooster: "🐓",
	Dog: "🐕",
	Pig: "🐖"
};
function Chip({ label, value, color = "white" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg px-3 py-2",
		style: {
			background: "rgba(255,255,255,0.03)",
			border: "1px solid rgba(255,255,255,0.06)"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[8px] uppercase tracking-widest font-bold mb-0.5",
			style: { color: "rgba(255,255,255,0.4)" },
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[12px] font-black",
			style: {
				color,
				fontFamily: "ui-monospace, monospace"
			},
			children: value
		})]
	});
}
function TradingAIPage() {
	const today = /* @__PURE__ */ new Date();
	const [selSymbol, setSelSymbol] = (0, import_react.useState)("SPX");
	const [cat, setCat] = (0, import_react.useState)("All");
	const [showBreakdown, setShowBreakdown] = (0, import_react.useState)(false);
	const [view, setView] = (0, import_react.useState)("day");
	const filtered = (0, import_react.useMemo)(() => TRADING_ENTITIES.filter((e) => cat === "All" || e.category === cat), [cat]);
	const entity = TRADING_ENTITIES.find((e) => e.symbol === selSymbol) ?? TRADING_ENTITIES[0];
	const day = (0, import_react.useMemo)(() => calcMarketCode(entity, today.getMonth() + 1, today.getDate(), today.getFullYear()), [entity, selSymbol]);
	const weekStart = new Date(today);
	weekStart.setDate(today.getDate() - today.getDay());
	const weekResults = (0, import_react.useMemo)(() => calcWeek(entity, weekStart), [entity, selSymbol]);
	const dir = day.candidateDirection;
	const dirColor = DIR_COLOR[dir];
	const actionColor = ACTION_COLOR[day.action];
	const actionBg = ACTION_BG[day.action];
	const actionBorder = ACTION_BORDER[day.action];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-4xl space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, {
						size: 13,
						style: { color: YELLOW }
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs",
						style: { color: "rgba(255,255,255,0.3)" },
						children: "Trading AI · MarketCode Engine"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "page-title",
					children: "Trading AI"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "page-subtitle",
					children: "MarketCode — numerology · lunar · Chinese pillars · confluence scoring"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5 flex-wrap",
				children: cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setCat(c),
					className: "px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all",
					style: cat === c ? {
						background: "rgba(250,204,21,0.12)",
						color: YELLOW,
						border: "1px solid rgba(250,204,21,0.25)"
					} : {
						color: "rgba(255,255,255,0.4)",
						border: "1px solid transparent"
					},
					children: c
				}, c))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card p-3 overflow-y-auto",
					style: {
						background: "hsl(228 28% 7%)",
						maxHeight: "480px"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10px] uppercase tracking-widest mb-3 sticky top-0",
						style: {
							color: "rgba(255,255,255,0.3)",
							background: "hsl(228 28% 7%)"
						},
						children: [
							"Select Entity (",
							filtered.length,
							")"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-0.5",
						children: filtered.map((e) => {
							const r = calcMarketCode(e, today.getMonth() + 1, today.getDate(), today.getFullYear());
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelSymbol(e.symbol),
								className: "w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-left",
								style: selSymbol === e.symbol ? {
									background: "rgba(96,165,250,0.12)",
									border: "1px solid rgba(96,165,250,0.2)"
								} : { border: "1px solid transparent" },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold",
									style: { color: "rgba(255,255,255,0.9)" },
									children: e.symbol
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[9px]",
									style: { color: "rgba(255,255,255,0.3)" },
									children: e.name
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[9px] font-bold px-1.5 py-0.5 rounded",
									style: {
										background: ACTION_BG[r.action],
										color: ACTION_COLOR[r.action],
										border: `1px solid ${ACTION_BORDER[r.action]}`
									},
									children: [r.score, "/7"]
								})]
							}, e.symbol);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-5",
							style: {
								background: "hsl(228 28% 7%)",
								border: `1px solid ${actionBorder}`
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between flex-wrap gap-3 mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] uppercase tracking-widest mb-1",
										style: { color: "rgba(255,255,255,0.3)" },
										children: [
											entity.symbol,
											" · ",
											entity.name,
											" · ",
											entity.anchorDate
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold",
										style: { color: "rgba(255,255,255,0.55)" },
										children: today.toLocaleDateString("en-US", {
											weekday: "long",
											month: "long",
											day: "numeric",
											year: "numeric"
										})
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-2 rounded-xl px-4 py-2",
											style: {
												background: actionBg,
												border: `1px solid ${actionBorder}`
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-2xl font-black",
												style: { color: dirColor },
												children: dir
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold px-2 py-0.5 rounded",
												style: {
													color: actionColor,
													background: "rgba(0,0,0,0.3)"
												},
												children: day.action
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] mt-1",
											style: { color: "rgba(255,255,255,0.4)" },
											children: [
												"Score ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													style: { color: actionColor },
													className: "font-black text-sm",
													children: day.score
												}),
												"/7 confluence"
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 md:grid-cols-4 gap-2 mb-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "Universal Day #",
											value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [day.universalDay, day.masterDay ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												style: { color: YELLOW },
												className: "ml-1 text-[9px]",
												children: ["M", day.masterDay]
											}) : null] }),
											color: BLUE
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "Universal Month",
											value: String(day.universalMonth),
											color: PURPLE
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "Universal Year",
											value: String(day.universalYear),
											color: PURPLE
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "Raw Total",
											value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [day.universalDayRaw, day.karmicDay ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: { color: RED },
												className: "ml-1 text-[9px]",
												children: "KARMIC"
											}) : null] }),
											color: "white"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg p-3 mb-3",
									style: {
										background: "rgba(96,165,250,0.05)",
										border: "1px solid rgba(96,165,250,0.15)"
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] uppercase tracking-widest font-bold mb-1",
											style: { color: BLUE },
											children: "Day Mood"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm font-black text-white",
											children: [
												"#",
												day.universalDay,
												" · ",
												day.dayMood
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] mt-0.5",
											style: { color: "rgba(255,255,255,0.55)" },
											children: day.dayCharacter
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-4 gap-2 mb-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "CZ Year",
											value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												ZODIAC_ICON[day.chinesePillars.year] ?? "🌀",
												" ",
												day.chinesePillars.year
											] })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "CZ Month",
											value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												ZODIAC_ICON[day.chinesePillars.month] ?? "🌀",
												" ",
												day.chinesePillars.month
											] })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "CZ Day",
											value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												ZODIAC_ICON[day.chinesePillars.day] ?? "🌀",
												" ",
												day.chinesePillars.day
											] })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "CZ Hour",
											value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												ZODIAC_ICON[day.chinesePillars.hour] ?? "🌀",
												" ",
												day.chinesePillars.hour
											] })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-2 mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg p-3",
										style: {
											background: "rgba(250,204,21,0.05)",
											border: "1px solid rgba(250,204,21,0.15)"
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] uppercase tracking-widest font-bold mb-1 flex items-center gap-1",
												style: { color: YELLOW },
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { size: 10 }), " Lunar"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs font-black text-white",
												children: [
													day.lunarPhase,
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														style: { color: DIR_COLOR[day.lunarBias] },
														children: ["→ ", day.lunarBias]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] mt-0.5",
												style: { color: "rgba(255,255,255,0.5)" },
												children: [
													"Moon in ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: day.moonSign }),
													" · Sun in ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: day.sunSign })
												]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg p-3",
										style: {
											background: "rgba(167,139,250,0.05)",
											border: "1px solid rgba(167,139,250,0.15)"
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] uppercase tracking-widest font-bold mb-1 flex items-center gap-1",
												style: { color: PURPLE },
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { size: 10 }), " Sector Spotlight"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-black text-white",
												children: day.sectorSpotlight
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] mt-0.5",
												style: { color: "rgba(255,255,255,0.5)" },
												children: [
													"Entity sector: ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: entity.sector ?? "—" }),
													day.sectorMatch && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "ml-1",
														style: { color: GREEN },
														children: "MATCH ✓"
													})
												]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2 mb-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "Entity Lifepath",
											value: String(day.entityLifepath),
											color: BLUE
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "Name Number",
											value: String(day.entityNameNumber),
											color: BLUE
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											label: "Element",
											value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												day.entityElement,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[9px]",
													style: { color: "rgba(255,255,255,0.4)" },
													children: [
														"(",
														day.elementSupport,
														")"
													]
												})
											] }),
											color: PURPLE
										})
									]
								}),
								day.resonance && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "rounded-lg p-2 mb-3 text-center",
									style: {
										background: "rgba(74,222,128,0.08)",
										border: "1px solid rgba(74,222,128,0.25)"
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-bold",
										style: { color: GREEN },
										children: "⚡ RESONANCE — Day # matches entity Lifepath or Name #"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg p-3 mb-3",
									style: {
										background: "rgba(255,255,255,0.02)",
										border: "1px solid rgba(255,255,255,0.05)"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[9px] uppercase tracking-widest font-bold mb-2",
										style: { color: "rgba(255,255,255,0.5)" },
										children: [
											"Confluence Checklist — ",
											day.score,
											"/7"
										]
									}), day.checks.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-2 py-1 border-b last:border-b-0",
										style: { borderColor: "rgba(255,255,255,0.04)" },
										children: [c.passed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											size: 12,
											className: "mt-0.5",
											style: { color: GREEN }
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
											size: 12,
											className: "mt-0.5",
											style: { color: "rgba(255,255,255,0.3)" }
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-semibold",
												style: { color: c.passed ? "white" : "rgba(255,255,255,0.5)" },
												children: c.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px]",
												style: { color: "rgba(255,255,255,0.35)" },
												children: c.note
											})]
										})]
									}, i))]
								}),
								day.vetoes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg p-3 mb-3",
									style: {
										background: "rgba(248,113,113,0.08)",
										border: "1px solid rgba(248,113,113,0.30)"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] uppercase tracking-widest font-black mb-1 flex items-center gap-1",
										style: { color: RED },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { size: 11 }), " ACTIVE VETOES — NO TRADE"]
									}), day.vetoes.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px]",
										style: { color: "rgba(255,255,255,0.75)" },
										children: ["· ", v]
									}, i))]
								}),
								(day.mercuryRetro || day.eclipseWindow) && day.vetoes.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "rounded-lg p-2 mb-3 text-center",
									style: {
										background: "rgba(250,204,21,0.06)",
										border: "1px solid rgba(250,204,21,0.25)"
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px]",
										style: { color: YELLOW },
										children: [
											"⚠ ",
											day.mercuryRetro && "Mercury Retrograde active — reduce conviction. ",
											day.eclipseWindow && "Eclipse window."
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-2 mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg p-3",
										style: {
											background: "rgba(74,222,128,0.04)",
											border: "1px solid rgba(74,222,128,0.15)"
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[9px] uppercase tracking-widest font-bold mb-0.5 flex items-center gap-1",
											style: { color: GREEN },
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { size: 10 }), " Entry Window"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-white",
											children: day.entryWindow
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg p-3",
										style: {
											background: "rgba(250,204,21,0.04)",
											border: "1px solid rgba(250,204,21,0.15)"
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[9px] uppercase tracking-widest font-bold mb-0.5 flex items-center gap-1",
											style: { color: YELLOW },
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { size: 10 }), " Exit Window"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-white",
											children: day.exitWindow
										})]
									})]
								}),
								day.cautionZones.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px]",
									style: { color: "rgba(255,255,255,0.4)" },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											style: { color: RED },
											children: "Caution:"
										}),
										" ",
										day.cautionZones.join(" · ")
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 flex justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setShowBreakdown((b) => !b),
										className: "flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg transition-all",
										style: {
											color: BLUE,
											background: "rgba(96,165,250,0.08)",
											border: "1px solid rgba(96,165,250,0.15)"
										},
										children: ["Full breakdown ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
											size: 12,
											style: { transform: showBreakdown ? "rotate(180deg)" : "none" }
										})]
									})
								}),
								showBreakdown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 p-3 rounded-lg text-xs font-mono whitespace-pre-wrap leading-relaxed",
									style: {
										background: "rgba(0,0,0,0.3)",
										color: "rgba(255,255,255,0.55)"
									},
									children: day.breakdown
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1.5 flex-wrap",
							children: [
								["day", "Day"],
								["week", "Week"],
								["month", "Month"],
								["method", "Style"]
							].map(([v, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setView(v),
								className: "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
								style: view === v ? {
									background: "rgba(96,165,250,0.12)",
									color: BLUE,
									border: "1px solid rgba(96,165,250,0.2)"
								} : {
									color: "rgba(255,255,255,0.4)",
									border: "1px solid transparent"
								},
								children: label
							}, v))
						}),
						view === "week" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-4",
							style: { background: "hsl(228 28% 7%)" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] uppercase tracking-widest mb-3",
								style: { color: "rgba(255,255,255,0.3)" },
								children: ["Weekly MarketCode — ", entity.symbol]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: weekResults.map((r, i) => {
									const dName = new Date(weekStart.getTime() + i * 864e5).toLocaleDateString("en-US", {
										weekday: "short",
										month: "short",
										day: "numeric"
									});
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between p-2.5 rounded-lg",
										style: { background: "rgba(255,255,255,0.03)" },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs",
											style: { color: "rgba(255,255,255,0.6)" },
											children: dName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px]",
													style: { color: "rgba(255,255,255,0.5)" },
													children: [
														"#",
														r.universalDay,
														" · ",
														r.lunarPhase
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold",
													style: { color: DIR_COLOR[r.candidateDirection] },
													children: r.candidateDirection
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] font-bold px-2 py-0.5 rounded",
													style: {
														background: ACTION_BG[r.action],
														color: ACTION_COLOR[r.action]
													},
													children: [
														r.score,
														"/7 · ",
														r.action
													]
												})
											]
										})]
									}, i);
								})
							})]
						}),
						view === "month" && (() => {
							const m = today.getMonth() + 1;
							const y = today.getFullYear();
							const daysInMonth = new Date(y, m, 0).getDate();
							const monthDays = Array.from({ length: daysInMonth }, (_, i) => {
								const dd = i + 1;
								return {
									day: dd,
									...calcMarketCode(entity, m, dd, y)
								};
							});
							const rank = (a) => a.score - (a.vetoes.length > 0 ? 10 : 0);
							const best = [...monthDays].sort((a, b) => rank(b) - rank(a)).slice(0, 5);
							const worst = [...monthDays].filter((d) => d.action === "NO TRADE").slice(0, 5);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "glass-card p-4",
										style: { background: "hsl(228 28% 7%)" },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] uppercase tracking-widest mb-3",
											style: { color: GREEN },
											children: "Top 5 MarketCode Days"
										}), best.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between p-2 rounded-lg mb-1",
											style: { background: "rgba(74,222,128,0.04)" },
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black",
													style: {
														background: "rgba(74,222,128,0.15)",
														color: GREEN
													},
													children: i + 1
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold text-white",
													children: new Date(y, m - 1, d.day).toLocaleDateString("en-US", {
														weekday: "short",
														month: "short",
														day: "numeric"
													})
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[9px] font-bold",
												style: { color: DIR_COLOR[d.candidateDirection] },
												children: [
													d.candidateDirection,
													" · ",
													d.score,
													"/7"
												]
											})]
										}, d.day))]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "glass-card p-4",
										style: { background: "hsl(228 28% 7%)" },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] uppercase tracking-widest mb-3",
												style: { color: RED },
												children: "Veto / No-Trade Days"
											}),
											worst.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs",
												style: { color: "rgba(255,255,255,0.35)" },
												children: "No hard vetoes this month."
											}),
											worst.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between p-2 rounded-lg mb-1",
												style: { background: "rgba(248,113,113,0.04)" },
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold text-white",
													children: new Date(y, m - 1, d.day).toLocaleDateString("en-US", {
														weekday: "short",
														month: "short",
														day: "numeric"
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[9px]",
													style: { color: RED },
													children: d.vetoes[0] ?? "no signal"
												})]
											}, d.day))
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "glass-card p-4",
									style: { background: "hsl(228 28% 7%)" },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase tracking-widest mb-3",
										style: { color: "rgba(255,255,255,0.3)" },
										children: "Full Month Calendar"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-7 gap-1",
										children: [
											[
												"Su",
												"Mo",
												"Tu",
												"We",
												"Th",
												"Fr",
												"Sa"
											].map((dd) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-center text-[8px] font-semibold py-0.5",
												style: { color: "rgba(255,255,255,0.3)" },
												children: dd
											}, dd)),
											Array.from({ length: new Date(y, m - 1, 1).getDay() }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `p${i}`)),
											monthDays.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-1 rounded text-center",
												style: { background: `${ACTION_COLOR[d.action]}12` },
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] font-bold",
													style: { color: d.day === today.getDate() ? "white" : "rgba(255,255,255,0.6)" },
													children: d.day
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-1.5 h-1.5 rounded-full mx-auto mt-0.5",
													style: { background: DIR_COLOR[d.candidateDirection] }
												})]
											}, d.day))
										]
									})]
								})]
							});
						})(),
						view === "method" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-5",
							style: {
								background: "hsl(228 28% 7%)",
								border: "1px solid rgba(250,204,21,0.15)"
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-widest mb-2",
									style: { color: YELLOW },
									children: "Sector Map (Part 5)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
									children: Object.entries(SECTOR_MAP).map(([sign, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg p-3",
										style: {
											background: "rgba(255,255,255,0.03)",
											border: "1px solid rgba(255,255,255,0.05)"
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-black text-white",
											children: sign
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px]",
											style: { color: "rgba(255,255,255,0.5)" },
											children: s
										})]
									}, sign))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] mt-3",
									style: { color: "rgba(255,255,255,0.4)" },
									children: "Sun sign (month) + Moon sign (~2.5 days) light up their sectors. When the entity's founding sun sign or listed sector matches either, the confluence check \"Sector match\" fires."
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[8px] text-center",
				style: { color: "rgba(255,255,255,0.2)" },
				children: "ShemUniverse MarketCode · deterministic numerology + approx lunar/pillars · Mercury retro & eclipse windows hard-coded 2024-2027 · Not financial advice."
			})
		]
	});
}
var SplitComponent = TradingAIPage;
//#endregion
export { SplitComponent as component };
