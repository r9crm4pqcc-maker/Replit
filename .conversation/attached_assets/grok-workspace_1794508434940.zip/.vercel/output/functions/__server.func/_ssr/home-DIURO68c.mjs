import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as upcoming, c as buildChart, f as fullName, o as LIST_LABEL, r as useLife, w as readDay } from "./router-Da7lqNNo.mjs";
import { a as Tag, t as Card } from "./kit-sB4xIagL.mjs";
import { t as Link$1 } from "./wouter-CfVlts7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/home-DIURO68c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MODULES = [
	{
		href: "/chart",
		title: "Your chart",
		text: "Life path, name, Chinese pillars, Western and Vedic, enemy months, lucky numbers."
	},
	{
		href: "/dates",
		title: "Date library",
		text: "Soulmate, fatal, challenging, love, beneficial, wealth, 28, and master days."
	},
	{
		href: "/reports",
		title: "Reports",
		text: "Daily, monthly, and yearly. Turn on the daily alert."
	},
	{
		href: "/timing",
		title: "Goal timing",
		text: "Best days for money, launch, travel, love, surgery, cleats, an LLC, a contract."
	},
	{
		href: "/people",
		title: "People & lookup",
		text: "Two birthdates, a family tree, cities, countries, brands, cars, schools."
	},
	{
		href: "/advanced",
		title: "Advanced",
		text: "Saturn, color, dreams, conception, manifestation, prices, career, health."
	}
];
function useToday() {
	const [today, setToday] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const t = /* @__PURE__ */ new Date();
		setToday({
			y: t.getFullYear(),
			m: t.getMonth() + 1,
			d: t.getDate()
		});
	}, []);
	return today;
}
function useDailyPing(headline, iso) {
	(0, import_react.useEffect)(() => {
		if (!headline || !iso || typeof Notification === "undefined") return;
		if (Notification.permission !== "granted") return;
		if (localStorage.getItem("life-ping") === iso) return;
		localStorage.setItem("life-ping", iso);
		try {
			new Notification("Life Code", { body: headline });
		} catch {}
	}, [headline, iso]);
}
function HomePage() {
	const { profile } = useLife();
	const today = useToday();
	const read = today ? readDay(profile, today.y, today.m, today.d) : null;
	const chart = today ? buildChart(profile, today) : null;
	const next = today ? upcoming(profile, today, 5) : [];
	useDailyPing(read?.headline ?? "", read?.iso ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-5xl mx-auto space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.18em] text-primary font-medium",
						children: "Life Code"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl sm:text-4xl font-semibold text-foreground mt-1",
						children: chart?.name ?? fullName(profile)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground mt-1",
						children: [
							profile.month,
							"/",
							profile.day,
							"/",
							profile.year,
							profile.time ? ` · ${profile.time}` : "",
							profile.place ? ` · ${profile.place}` : ""
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
					href: "/chart",
					className: "text-sm rounded-lg border border-border px-3 py-2 text-foreground hover:border-primary",
					children: "Edit birth data"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: !read || !chart ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Reading today…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: read.weekday
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl text-foreground",
						children: read.headline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
								tone: "hot",
								children: ["Universal ", read.labelU]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, { children: ["Personal ", read.labelP] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
								tone: read.earth === "enemy" ? "bad" : read.earth === "friend" ? "good" : "neutral",
								children: ["Earth ", read.earth]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
								tone: read.west === "enemy" ? "bad" : read.west === "friend" ? "good" : "neutral",
								children: ["Western ", read.west]
							}),
							read.tones.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
								tone: t === "fatal" || t === "challenging" ? "bad" : "good",
								children: LIST_LABEL[t]
							}, t))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-foreground/90 leading-relaxed",
						children: read.reading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid sm:grid-cols-2 gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-primary mb-1",
							children: "Do"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1 text-muted-foreground",
							children: read.dos.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: x }, x))
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-destructive mb-1",
							children: "Avoid"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1 text-muted-foreground",
							children: read.avoids.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: x }, x))
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: `/day/${read.iso}`,
						className: "inline-block text-sm text-primary hover:underline",
						children: "Open the full day"
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-3",
				children: MODULES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$1, {
					href: m.href,
					className: "glass-card p-4 block hover:border-primary/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg text-foreground",
						children: m.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-1 leading-relaxed",
						children: m.text
					})]
				}, m.href))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg mb-3",
				children: "Coming up"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-2",
				children: [next.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$1, {
					href: `/day/${n.iso}`,
					className: "flex flex-wrap items-baseline justify-between gap-2 text-sm hover:text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: n.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: n.tones.map((t) => LIST_LABEL[t]).join(" · ")
					})]
				}) }, n.iso)), !next.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted-foreground",
					children: "No marked dates in the next year."
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: "/sports-prediction",
						className: "text-muted-foreground hover:text-primary",
						children: "Sports Prediction"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: "/soccer-ai",
						className: "text-muted-foreground hover:text-primary",
						children: "Soccer AI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						href: "/trading-ai",
						className: "text-muted-foreground hover:text-primary",
						children: "Stock Market AI"
					})
				]
			})
		]
	});
}
//#endregion
export { useDailyPing as n, HomePage as t };
