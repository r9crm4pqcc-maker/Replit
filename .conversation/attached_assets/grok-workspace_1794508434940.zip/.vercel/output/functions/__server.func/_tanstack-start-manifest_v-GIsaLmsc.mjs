//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-GIsaLmsc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/advanced",
			"/astrology",
			"/bazi",
			"/career",
			"/chakra",
			"/chart",
			"/compatibility",
			"/dates",
			"/day-life",
			"/feng-shui",
			"/forecasts",
			"/gematria",
			"/matrix-calendar",
			"/numerology",
			"/people",
			"/reports",
			"/rife",
			"/soccer-ai",
			"/sports-prediction",
			"/tarot",
			"/timing",
			"/trading-ai",
			"/day/$",
			"/api/public/espn"
		],
		preloads: [
			"/assets/index-WzYVbAb_.js",
			"/assets/numerology-BOh1a1ho.js",
			"/assets/createLucideIcon-S5vSEHv8.js",
			"/assets/colorology-CwpmsDPn.js",
			"/assets/vote-decode-BzpM9AZu.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-WzYVbAb_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DkhXL2rm.js", "/assets/home-DgKbb_Cx.js"]
	},
	"/advanced": {
		filePath: "/workspace/src/routes/advanced.tsx",
		children: void 0,
		preloads: ["/assets/advanced-8YXJR1n7.js", "/assets/kit-CKWNs-Zr.js"]
	},
	"/chart": {
		filePath: "/workspace/src/routes/chart.tsx",
		children: void 0,
		preloads: ["/assets/chart-C3iKUYHa.js", "/assets/kit-CKWNs-Zr.js"]
	},
	"/dates": {
		filePath: "/workspace/src/routes/dates.tsx",
		children: ["/dates/$"],
		preloads: ["/assets/dates-BFT1ygrz.js", "/assets/dates-nZ5mUIgs.js"]
	},
	"/people": {
		filePath: "/workspace/src/routes/people.tsx",
		children: void 0,
		preloads: ["/assets/people-BtjtXUQC.js", "/assets/kit-CKWNs-Zr.js"]
	},
	"/reports": {
		filePath: "/workspace/src/routes/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-QKwdazwD.js",
			"/assets/wouter-CBKxqHqt.js",
			"/assets/kit-CKWNs-Zr.js",
			"/assets/home-DgKbb_Cx.js"
		]
	},
	"/soccer-ai": {
		filePath: "/workspace/src/routes/soccer-ai.tsx",
		children: ["/soccer-ai/$"],
		preloads: ["/assets/soccer-ai-DMVxx-o4.js", "/assets/soccer-ai-BrXTlO4n.js"]
	},
	"/sports-prediction": {
		filePath: "/workspace/src/routes/sports-prediction.tsx",
		children: void 0,
		preloads: ["/assets/sports-prediction-C0Nd9pRt.js"]
	},
	"/timing": {
		filePath: "/workspace/src/routes/timing.tsx",
		children: void 0,
		preloads: [
			"/assets/timing-C1Zsq1Io.js",
			"/assets/wouter-CBKxqHqt.js",
			"/assets/kit-CKWNs-Zr.js"
		]
	},
	"/trading-ai": {
		filePath: "/workspace/src/routes/trading-ai.tsx",
		children: void 0,
		preloads: ["/assets/trading-ai-C7Je82tG.js", "/assets/sports-decode-AOmowMHK.js"]
	},
	"/dates/$": {
		filePath: "/workspace/src/routes/dates.$.tsx",
		children: void 0,
		preloads: ["/assets/dates._-BFT1ygrz.js"]
	},
	"/day/$": {
		filePath: "/workspace/src/routes/day.$.tsx",
		children: void 0,
		preloads: [
			"/assets/day._-eoN1Or3H.js",
			"/assets/wouter-CBKxqHqt.js",
			"/assets/kit-CKWNs-Zr.js"
		]
	},
	"/soccer-ai/$": {
		filePath: "/workspace/src/routes/soccer-ai.$.tsx",
		children: void 0,
		preloads: ["/assets/soccer-ai._-DMVxx-o4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
